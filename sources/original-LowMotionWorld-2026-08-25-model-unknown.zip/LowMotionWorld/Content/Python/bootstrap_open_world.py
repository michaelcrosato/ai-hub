"""Create the editable World Partition map and Blueprint extension points.

Run inside Unreal Editor from Tools > Execute Python Script. The script is
idempotent: existing assets are reused and the map is never overwritten.
"""

import unreal


PROJECT_ROOT = "/Game"
MAP_PACKAGE = "/Game/Maps/L_LowMotionOpenWorld"
BLUEPRINT_ROOT = "/Game/Blueprints"


def log(message):
    unreal.log(f"[LowMotionWorld] {message}")


def warn(message):
    unreal.log_warning(f"[LowMotionWorld] {message}")


def ensure_folder(path):
    if not unreal.EditorAssetLibrary.does_directory_exist(path):
        unreal.EditorAssetLibrary.make_directory(path)


def load_native_class(path):
    native_class = unreal.load_class(None, path)
    if not native_class:
        raise RuntimeError(f"Could not load native class: {path}. Compile the C++ project first.")
    return native_class


def ensure_child_blueprint(asset_name, parent_class_path):
    asset_path = f"{BLUEPRINT_ROOT}/{asset_name}"
    existing = unreal.EditorAssetLibrary.load_asset(asset_path)
    if existing:
        log(f"Reusing {asset_path}")
        return existing

    factory = unreal.BlueprintFactory()
    factory.set_editor_property("parent_class", load_native_class(parent_class_path))
    asset = unreal.AssetToolsHelpers.get_asset_tools().create_asset(
        asset_name, BLUEPRINT_ROOT, unreal.Blueprint, factory
    )
    if not asset:
        raise RuntimeError(f"Failed to create {asset_path}")
    unreal.EditorAssetLibrary.save_loaded_asset(asset, only_if_is_dirty=False)
    log(f"Created {asset_path}")
    return asset


def create_blueprint_extension_points():
    ensure_folder(BLUEPRINT_ROOT)
    definitions = {
        "BP_LMWCharacter": "/Script/LowMotionWorld.LMWCharacter",
        "BP_LMWPhysicsProp": "/Script/LowMotionWorld.LMWPhysicsProp",
        "BP_LMWFeatureSwitch": "/Script/LowMotionWorld.LMWFeatureSwitch",
        "BP_LMWImpulsePad": "/Script/LowMotionWorld.LMWImpulsePad",
        "BPC_LMWFeature": "/Script/LowMotionWorld.LMWVisibilityFeatureComponent",
    }
    for asset_name, parent_path in definitions.items():
        ensure_child_blueprint(asset_name, parent_path)


def find_open_world_template():
    candidates = (
        "/Engine/Maps/Templates/OpenWorld",
        "/Engine/Maps/Templates/OpenWorld.OpenWorld",
    )
    for candidate in candidates:
        if unreal.EditorAssetLibrary.does_asset_exist(candidate):
            return candidate
    # The subsystem often resolves the package even if engine content is hidden.
    return candidates[0]


def create_open_world_map():
    ensure_folder("/Game/Maps")
    if unreal.EditorAssetLibrary.does_asset_exist(MAP_PACKAGE):
        warn(f"{MAP_PACKAGE} already exists; it was not overwritten.")
        unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).load_level(MAP_PACKAGE)
        return False

    level_subsystem = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
    template = find_open_world_template()
    created = level_subsystem.new_level_from_template(MAP_PACKAGE, template)
    if not created:
        raise RuntimeError(
            "Open World template creation failed. Use File > New Level > Open World, "
            f"save it as {MAP_PACKAGE}, then run this script again."
        )
    level_subsystem.save_current_level()
    log(f"Created World Partition map {MAP_PACKAGE}")
    return True


def spawn_starter_markers():
    actor_subsystem = unreal.get_editor_subsystem(unreal.EditorActorSubsystem)
    existing_labels = {
        actor.get_actor_label() for actor in actor_subsystem.get_all_level_actors()
    }

    entries = (
        ("LMW_PlayerStart", "/Script/Engine.PlayerStart", unreal.Vector(0, 0, 250), unreal.Rotator()),
        ("LMW_FeatureSwitch", "/Script/LowMotionWorld.LMWFeatureSwitch", unreal.Vector(350, -350, 100), unreal.Rotator()),
        ("LMW_ImpulsePad", "/Script/LowMotionWorld.LMWImpulsePad", unreal.Vector(900, 0, 100), unreal.Rotator()),
    )

    for label, class_path, location, rotation in entries:
        if label in existing_labels:
            continue
        actor = actor_subsystem.spawn_actor_from_class(load_native_class(class_path), location, rotation)
        if actor:
            actor.set_actor_label(label)
            try:
                actor.set_editor_property("is_spatially_loaded", True)
            except Exception:
                pass
            log(f"Placed {label}")

    unreal.get_editor_subsystem(unreal.LevelEditorSubsystem).save_current_level()


def set_default_maps():
    try:
        settings = unreal.get_default_object(unreal.GameMapsSettings)
        map_reference = unreal.SoftObjectPath(f"{MAP_PACKAGE}.{MAP_PACKAGE.rsplit('/', 1)[-1]}")
        settings.set_editor_property("editor_startup_map", map_reference)
        settings.set_editor_property("game_default_map", map_reference)
        settings.save_config()
        log("Set the new map as editor and game default.")
    except Exception as exc:
        warn(f"Could not update default maps automatically: {exc}")
        warn("Set both maps manually under Project Settings > Maps & Modes.")


def main():
    create_blueprint_extension_points()
    create_open_world_map()
    spawn_starter_markers()
    set_default_maps()
    log("Bootstrap complete. Save All, then press Play.")


if __name__ == "__main__":
    main()
