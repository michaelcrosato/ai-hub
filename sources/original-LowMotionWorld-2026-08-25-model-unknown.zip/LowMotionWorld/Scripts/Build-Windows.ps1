param(
    [string]$EngineRoot = "C:\Program Files\Epic Games\UE_5.7",
    [ValidateSet("Development", "Shipping")]
    [string]$Configuration = "Development"
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $PSScriptRoot
$ProjectFile = Join-Path $ProjectRoot "LowMotionWorld.uproject"
$BuildTool = Join-Path $EngineRoot "Engine\Binaries\DotNET\UnrealBuildTool\UnrealBuildTool.exe"

if (-not (Test-Path $BuildTool)) {
    throw "UnrealBuildTool was not found at '$BuildTool'. Pass -EngineRoot with your UE 5.7 installation."
}

& $BuildTool LowMotionWorldEditor Win64 $Configuration -Project="$ProjectFile" -WaitMutex -FromMsBuild
if ($LASTEXITCODE -ne 0) {
    throw "UnrealBuildTool failed with exit code $LASTEXITCODE."
}

Write-Host "LowMotionWorldEditor built successfully."
