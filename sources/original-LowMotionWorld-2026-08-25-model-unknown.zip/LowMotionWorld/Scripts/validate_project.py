#!/usr/bin/env python3
"""Fast source-package validation that does not require an Unreal installation."""

from __future__ import annotations

import json
import pathlib
import re
import sys


ROOT = pathlib.Path(__file__).resolve().parents[1]


def fail(message: str) -> None:
    print(f"ERROR: {message}")
    raise SystemExit(1)


def validate_json() -> None:
    project_file = ROOT / "LowMotionWorld.uproject"
    try:
        data = json.loads(project_file.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"invalid uproject JSON: {exc}")
    if data.get("FileVersion") != 3:
        fail("unexpected .uproject FileVersion")
    if not any(module.get("Name") == "LowMotionWorld" for module in data.get("Modules", [])):
        fail("runtime module is missing from .uproject")


def validate_generated_headers() -> None:
    for header in (ROOT / "Source").rglob("*.h"):
        text = header.read_text(encoding="utf-8")
        if "UCLASS" not in text and "UINTERFACE" not in text and "USTRUCT" not in text and "UENUM" not in text:
            continue
        expected = f'#include "{header.stem}.generated.h"'
        if expected not in text:
            fail(f"missing generated include in {header.relative_to(ROOT)}")
        generated_line = text.index(expected)
        following_include = re.search(r"#include\s+[<\"]", text[generated_line + len(expected) :])
        if following_include:
            fail(f"generated include is not last in {header.relative_to(ROOT)}")


def validate_braces() -> None:
    for source in (ROOT / "Source").rglob("*.*"):
        if source.suffix not in {".h", ".cpp", ".cs"}:
            continue
        text = source.read_text(encoding="utf-8")
        if text.count("{") != text.count("}"):
            fail(f"unbalanced braces in {source.relative_to(ROOT)}")


def validate_required_files() -> None:
    required = (
        "Config/DefaultEngine.ini",
        "Source/LowMotionWorld/LowMotionWorld.Build.cs",
        "Source/LowMotionWorld/Public/GameFramework/LMWCharacter.h",
        "Source/LowMotionWorld/Public/Components/LMWPhysicsCarryComponent.h",
        "Content/Python/bootstrap_open_world.py",
        "README.md",
    )
    for relative in required:
        if not (ROOT / relative).is_file():
            fail(f"required file missing: {relative}")


def main() -> int:
    validate_json()
    validate_generated_headers()
    validate_braces()
    validate_required_files()
    source_count = sum(1 for path in (ROOT / "Source").rglob("*") if path.is_file())
    print(f"OK: source package validated ({source_count} source/build files).")
    print("NOTE: compile verification still requires Unreal Engine 5.7 on Windows.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
