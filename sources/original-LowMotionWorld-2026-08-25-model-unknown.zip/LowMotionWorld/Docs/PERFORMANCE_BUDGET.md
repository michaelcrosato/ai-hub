# RTX 3060 Performance Budget

The target is **1080p at 60 fps** or **1440p output at 75% TSR**, which keeps the
internal pixel count near 1080p. Treat every number as a starting budget and
profile a packaged build on the exact desktop or laptop RTX 3060 variant.

## Presets

| Group | Performance | Balanced (default) | Quality | Showcase |
| --- | ---: | ---: | ---: | ---: |
| Internal target | 900p | 1080p | 1200p | Native output |
| View distance | High | High | Epic | Epic |
| Anti-aliasing | High | Epic | Epic | Epic |
| Shadows | High | High | Epic | Epic |
| Lumen GI/reflections | High | High | Epic | Epic + HWRT |
| Post / textures | High | Epic | Epic | Epic |
| Effects / foliage | High / Medium | Epic / High | Epic | Epic |
| Frame cap | 60 | 60 | 30 | 30 |

The renderer supports all major UE5 effects, but the runtime defaults are
coherent rather than uniformly maximal. Cinematic scalability (`4`) is omitted
from gameplay profiles because Epic treats it as a Movie Render Queue tier.

## Lumen

- Default to Software Lumen for open worlds with foliage and overlapping
  instances.
- Hardware Lumen is an opt-in showcase mode. Keep Ray Lighting Mode on Surface
  Cache; hit lighting is too expensive for the normal game.
- Rough materials are cheaper than broad mirror-like surfaces. Foliage dedicated
  reflection rays are disabled by default.
- Moving static actors invalidates the Global Distance Field cache. Mark movable
  things correctly.
- Use `Stat GPU` and `ProfileGPU`; inspect Lumen Scene Lighting, Screen Probe
  Gather, and Reflections separately.

## Nanite and VSM

- Enable Nanite on supported environment meshes, including low-poly meshes.
  Nanite helps cluster culling and integrates well with Virtual Shadow Maps.
- Keep opaque geometry where possible. Large masked foliage cards can overdraw
  heavily even when their visible shape looks sparse.
- Clamp World Position Offset and stop distant foliage wind; moving/WPO geometry
  continually invalidates VSM cache pages.
- Avoid contact shadows everywhere. Reserve them for small details that genuinely
  need them.
- Quantize a day/night directional light rotation instead of moving it every frame.

## World Partition baseline

- One 2D runtime grid
- Cell size: 25,600 cm (256 m)
- Loading range: 76,800 cm (768 m)
- Simplified-mesh HLOD for buildings/cliffs
- Instancing HLOD for suitable foliage and repeated props
- Build HLOD before profiling long sight lines

The exact grid must follow traversal speed, SSD bandwidth, line of sight, and
cell memory. Multiple runtime grids can hurt performance.

## Chaos budget

Chaos destruction is often CPU-limited even on a strong GPU:

- Keep only nearby, readable chunks as simulated bodies.
- Sleep, disable, merge, or remove settled debris.
- Avoid fracture and hardware Lumen in the same worst-case moment until profiled;
  moving fragments update ray-tracing structures and invalidate shadow pages.
- Limit concurrent Geometry Collections and fracture depth independently from the
  graphics preset.
- Use Niagara for dust and tiny debris.

## Worst-case test scene

Profile a packaged Development build containing all of these at once:

1. Dense foliage and long sight lines.
2. Volumetric fog/clouds and several local lights.
3. A changing sun angle.
4. Smooth reflective surfaces in view.
5. Active Chaos fragments plus carried rigid bodies.
6. Fast traversal across World Partition cell boundaries.

Record frame time, GPU pass timings, VRAM use, active ray-tracing instances,
VSM physical page pressure, streaming hitches, active Chaos bodies, and peak
game-thread time. Lower the system that misses its budget; do not hide an
architecture problem with a blanket resolution reduction.
