# Blueprint Cookbook

## Create an interactable actor

1. Create an Actor Blueprint and add the `LMWInteractable` interface under
   **Class Settings > Implemented Interfaces**.
2. Implement **Get Interaction Prompt**, **Can Interact**, and **Interact**.
3. Implement **Begin Focus/End Focus** for highlight, sound, or material response.
4. Ensure the component the player aims at blocks the **Visibility** trace channel.

No character cast is required. The player interaction component discovers the
interface and calls the Blueprint implementation through Unreal's interface
dispatch path.

## Create a new modular feature

1. Create a Blueprint Component derived from `BPC_LMWFeature` or directly from
   `LMWFeatureComponent`.
2. Set **Feature Id** to a namespaced value such as `Feature.Power.TurbineA`.
3. Implement **On Feature Enabled** and **On Feature Disabled**.
4. Add the component to any number of actors.
5. Put the same ID on an `LMWFeatureSwitch`, or call **Set Feature Group Enabled**
   on `LMWFeatureWorldSubsystem` from an objective Blueprint.

The built-in demo uses the ID `Feature.Demo`: the red switch enables a hidden
platform without holding a hard reference to it.

## Create a Chaos prop

1. Create a child of `BP_LMWPhysicsProp`.
2. Assign a Static Mesh with simple collision.
3. Enable Nanite on suitable environment-grade meshes, but keep a valid simple
   collision representation for Chaos.
4. Set mass through the mesh's physical material or mass override. The player
   carry component rejects objects heavier than `MaxCarryMass`.
5. Bind **On Physics Impact** to sound, Niagara, decals, damage, or a camera shake.
6. Keep tiny cosmetic debris in Niagara instead of spawning many rigid bodies.

## Create a curated Chaos breakable

Geometry Collections are content assets and must be made in Unreal Editor:

1. Enable **Fracture Mode**, create a Geometry Collection from a watertight mesh,
   and fracture it into a modest clustered hierarchy.
2. Use level-specific damage thresholds and anchor structural pieces.
3. Add a Field System Component to the Blueprint actor.
4. On a qualifying hit, apply a Stay Dynamic field, then an External Strain field
   whose value exceeds the collection threshold, then an optional radial force.
5. Use Sleep/Disable fields or debris removal after pieces settle.
6. Keep full fracture for nearby hero objects. Swap distant destruction to a
   state change, static replacement mesh, or Niagara effect.

## Add first-person tool motion without hand animation

Attach a low-poly static mesh to the camera and layer these inexpensive signals:

- spring-interpolated location/rotation for sway;
- a short curve or Timeline for recoil and charge;
- material parameters for energy/heat/state;
- Niagara at the tool tip;
- MetaSound or ordinary sound cues;
- camera shake and controller vibration;
- decals at impact points.

Keep gameplay traces on the camera/controller, not on the cosmetic tool mesh.
The tool can be hidden or replaced without changing mechanics.

## Blueprint event hygiene

- Prefer events and timers to Blueprint Tick.
- Keep references local to a World Partition cell; use IDs or soft references
  across cells.
- Put common tuning in data assets after two or more actors share it.
- Do not enable physics collision notifications on every prop. Enable them only
  where gameplay or feedback consumes the event.
- Route expensive reactions through distance and concurrency limits.
