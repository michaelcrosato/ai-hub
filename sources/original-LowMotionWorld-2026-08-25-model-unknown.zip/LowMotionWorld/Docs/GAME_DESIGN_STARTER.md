# Game Design Starter

## Creative direction

Use a world of monumental static architecture, strange machines, atmospheric
weather, hard-edged color fields, and physically responsive objects. The player
never needs a fully animated body. Their identity comes through camera height,
tool behavior, audio, UI, footsteps, material response, and the consequences of
touching the world.

This suits low-poly art unusually well: strong silhouettes and restrained
materials keep geometry readable, while Lumen, fog, shadow, reflections, Niagara,
and sound provide richness.

## Core verbs

- Explore
- Observe and scan
- Grab, carry, stack, balance, and throw
- Push/pull with impulses
- Route power or signals
- Activate mechanisms
- Break selected structures
- Change the world and return later

## Challenge families with little bespoke animation

| Family | Examples | Presentation |
| --- | --- | --- |
| Mass | scales, counterweights, stacking | Chaos bodies, lights, sound |
| Momentum | launch arcs, ricochet, pendulums | trails, decals, camera shake |
| Constraints | doors, cranes, bridges, turbines | physics constraints, motors |
| Energy | power routing, polarity, heat | emissive materials, Niagara |
| Perception | scanning, spectral filters, alignment | post process, audio, UI |
| Destruction | weak walls, supports, blocked paths | Geometry Collections, fields |
| World state | flooded/dry, powered/dark, intact/ruined | Data Layers, material swaps |

Enemies, if needed, can begin as rolling spheres, hovering drones, fixed turrets,
or articulated machines. They communicate intent through light, sound, rotation,
projected shapes, and physics rather than humanoid animation sets.

## First vertical slice

Build one streamed ruin with a 10–15 minute loop:

1. Reach a sealed machine room.
2. Scan three components to understand the fault.
3. Carry and stack rigid modules onto a mass plate.
4. Use an impulse pad to reach an upper control switch.
5. Restore power; a modular feature group activates lights and a bridge.
6. Throw an object through one curated Chaos weak wall for a shortcut.
7. Leave the World Partition cell, return, and verify the restored state persists.

That slice validates the art direction, player feel, interaction contracts,
Blueprint workflow, Chaos budgets, streaming, and the future save-system boundary
without requiring a character animation pipeline.

## Art constraints that become style

- Favor static meshes, rigid pieces, constraints, and shader motion.
- Use three material families per biome: matte structure, reflective accent,
  emissive state.
- Reserve saturated color for gameplay state and navigation.
- Build silhouettes at landscape scale; use fog and lighting for depth.
- Give every interaction a response in at least two channels: visual + audio,
  audio + haptic, or motion + material.
- Avoid continuous motion that invalidates shadows unless it communicates gameplay.
