# Architecture

## Design rule

Use a **C++ spine with Blueprint leaves**. C++ owns state, validation, traces,
physics control, and shared contracts. Blueprints choose assets, tune values,
and author cosmetic response. That makes each new gameplay idea a component or
actor instead of another branch inside the character class.

## Runtime map

```text
LMWGameMode
  -> LMWPlayerController
  -> LMWCharacter
       -> LMWInteractionComponent -> LMWInteractable interface
       -> LMWPhysicsCarryComponent -> PhysicsHandle -> Chaos rigid body
       -> LMWHealthComponent

LMWFeatureSwitch
  -> LMWFeatureWorldSubsystem
       -> feature components matching FeatureId
```

## Core types

| Type | Responsibility | Blueprint seam |
| --- | --- | --- |
| `ALMWCharacter` | Capsule movement, camera, input forwarding | Child BP adds tool meshes and feedback |
| `ULMWInteractionComponent` | View trace, focus, prompt, interaction dispatch | Bind focus/interaction delegates |
| `ILMWInteractable` | Small stable contract for anything usable | Implement all events in a Blueprint actor |
| `ULMWPhysicsCarryComponent` | Mass-gated Chaos handle, carry, drop, throw | Tune distances/strength and bind delegates |
| `ULMWHealthComponent` | Reusable damage state and death signal | Bind UI, sound, material, destruction |
| `ULMWFeatureComponent` | Self-registering optional mechanic base | Override enable/disable events |
| `ULMWFeatureWorldSubsystem` | Resolves feature groups by `FName` | Activate a group without actor references |
| `ULMWGraphicsSettingsSubsystem` | Coherent quality profiles | Call from a UMG settings screen |

## Adding a gameplay idea

1. If the idea changes an actor over time or owns reusable state, derive a new
   component from `ULMWFeatureComponent`.
2. Give it a stable ID such as `Feature.Power.NorthGate`.
3. Put invariant state transitions and validation in C++.
4. Expose tuning with `EditAnywhere` and presentation through multicast delegates
   or `BlueprintNativeEvent` functions.
5. Add the component to a Blueprint actor and author art/VFX/audio there.
6. Toggle it through `ULMWFeatureWorldSubsystem` from a switch, objective, save
   restore, or world-state event.

If a feature grows large and independent, move it to a Game Feature plugin later.
The component boundary is deliberately compatible with that extraction.

## Open-world rules

- Start from the **Open World** map template. It enables World Partition, One
  File Per Actor, Data Layers, and HLOD.
- Keep gameplay actors spatially loaded. Only real global managers stay always
  loaded.
- Avoid hard references between actors in different World Partition cells.
  Prefer stable IDs, soft asset references, feature IDs, and event messages.
- Do not put gameplay state in a Level Blueprint; a reference there can affect
  streaming behavior and makes the mechanic difficult to reuse.
- Player Controllers are World Partition streaming sources by default. For fast
  travel, activate a temporary streaming source at the destination, wait until
  streaming completes, teleport, then deactivate it.
- Put alternate world states (intact/destroyed, day/night, flooded/dry) in Data
  Layers. Put fine per-object persistence in a save subsystem when added.

## Future production modules

The starter intentionally keeps one runtime module for a low-friction first
iteration. When the project earns the complexity, extract these boundaries:

- `GameCore`: shared structs, interfaces, tags, settings
- `GameRuntime`: framework, save, world events
- `GF_PhysicsTools`: carry/push/pull/fracture
- `GF_Encounters`: challenge spawning and activation
- `GF_Presentation`: camera/tool motion, VFX, audio

Add Gameplay Tags before IDs need hierarchy or replication semantics, and add
GAS when actions require costs, cooldowns, prediction, status effects, or a
large ability catalog. Neither is necessary for the first physics vertical slice.
