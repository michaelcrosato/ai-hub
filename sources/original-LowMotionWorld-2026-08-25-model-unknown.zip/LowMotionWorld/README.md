# Low Motion World

Low Motion World is a source-first Unreal Engine 5.7 starter for a visually rich,
first-person open-world game whose mechanics do not depend on bespoke character
animation. C++ owns reusable rules and performance-sensitive loops; Blueprint is
the rapid content layer.

The project launches into an asset-free playable test yard built from Engine
primitives. It includes first-person movement, contextual interaction, Chaos
grab/carry/throw, impulse traversal, a modular feature registry, a working
feature switch, health, an HUD, and RTX 3060-oriented renderer presets.

## Requirements

- Unreal Engine 5.7 (change the target/include-order declarations as well as
  `EngineAssociation` before intentionally back-porting to an older UE5 release)
- Visual Studio 2022 with **Game development with C++** and the Windows SDK
- Windows 10/11, DirectX 12, Shader Model 6
- An SSD is strongly recommended for Nanite and open-world streaming

## First run

1. Right-click `LowMotionWorld.uproject` and choose **Generate Visual Studio
   project files**.
2. Build the `LowMotionWorldEditor` Development Editor target, or run:

   ```powershell
   .\Scripts\Build-Windows.ps1 -EngineRoot "C:\Program Files\Epic Games\UE_5.7"
   ```

3. Open `LowMotionWorld.uproject` and press **Play**. The default Engine Entry
   map receives a generated low-poly physics test yard at runtime.
4. In Unreal Editor, choose **Tools > Execute Python Script** and select
   `Content/Python/bootstrap_open_world.py`.
5. The script creates `L_LowMotionOpenWorld`, Blueprint children for the main
   C++ types, and three starter actors. Save All and press Play again.

If the Open World template path differs in your engine build, create a level
manually with **File > New Level > Open World**, save it as
`/Game/Maps/L_LowMotionOpenWorld`, then rerun the script.

## Controls

| Input | Action |
| --- | --- |
| WASD / Mouse | Move / look |
| Shift | Sprint |
| Space / Ctrl or C | Jump / crouch |
| E | Context interaction |
| Q | Grab or release a Chaos rigid body |
| Mouse wheel | Move a held object closer/farther |
| Left mouse | Throw held object |
| Right mouse | Drop held object |
| `~` then `SetGraphicsPreset Balanced` | Apply a graphics preset |

Valid preset names are `Performance`, `Balanced`, `Quality`, and `Showcase`.
Balanced is the default for an RTX 3060 and targets a 1080p internal image (100%
at 1080p output, 75% at 1440p, 50% at 4K). Showcase enables hardware Lumen and a
30 fps cap for the current session; use it for stills or carefully profiled
scenes, not as a universal gameplay default.

## What to extend in Blueprint

- `BP_LMWCharacter`: camera feedback, static-mesh tools, sound, optional hands.
- `BP_LMWPhysicsProp`: mesh, mass, material, hit VFX, and physical material.
- `BP_LMWFeatureSwitch`: target feature ID, lights, audio, and one-shot logic.
- `BP_LMWImpulsePad`: launch direction/strength and Niagara feedback.
- `BPC_LMWFeature`: owner-specific behavior in **On Feature Enabled/Disabled**.

Create child Blueprints; do not edit engine primitives or place core game logic
in a Level Blueprint. See [Blueprint Cookbook](Docs/BLUEPRINT_COOKBOOK.md).

## Architecture at a glance

| Layer | Owns |
| --- | --- |
| C++ framework | Player spawn, input routing, HUD, settings |
| C++ components | Interaction, physics carry, health, feature lifecycle |
| World subsystem | Feature lookup by stable ID without hard actor references |
| Blueprint children | Assets, tuning, presentation, individual challenge rules |
| World Partition | Spatial streaming, Data Layers, HLOD, One File Per Actor |

See [Architecture](Docs/ARCHITECTURE.md), [Blueprint Cookbook](Docs/BLUEPRINT_COOKBOOK.md),
[Performance Budget](Docs/PERFORMANCE_BUDGET.md), and
[Game Design Starter](Docs/GAME_DESIGN_STARTER.md).

## Renderer policy

The project enables DX12/SM6, Nanite, Lumen GI/reflections, Virtual Shadow Maps,
TSR, volumetric fog, Sky Atmosphere, distance fields, ray-tracing shader support,
and virtual texturing. Software Lumen is the RTX 3060 gameplay default because
dense open worlds and Chaos debris make hardware ray-tracing scene updates
expensive. The project still exposes hardware Lumen through the Showcase preset.

Epic's guidance treats Lumen High as the 60 fps tier, Epic as the 30 fps tier,
and Cinematic as a Movie Render Queue tier. Visual richness comes from good
materials, lighting, composition, fog, decals, Niagara, and controlled contrast—not
from forcing every scalability group to Cinematic.

## Validation

Without Unreal installed, run:

```bash
python3 Scripts/validate_project.py
```

This checks the package structure, `.uproject` JSON, Unreal generated-header
rules, and basic source integrity. A full compile and play test still require a
local Unreal Engine installation.

## Official references

- [World Partition](https://dev.epicgames.com/documentation/en-us/unreal-engine/world-partition-in-unreal-engine?application_version=5.7)
- [Lumen Performance Guide](https://dev.epicgames.com/documentation/en-us/unreal-engine/lumen-performance-guide-for-unreal-engine?application_version=5.7)
- [Nanite Virtualized Geometry](https://dev.epicgames.com/documentation/en-us/unreal-engine/nanite-virtualized-geometry-in-unreal-engine)
- [Virtual Shadow Maps](https://dev.epicgames.com/documentation/en-us/unreal-engine/virtual-shadow-maps-in-unreal-engine)
- [Chaos Destruction](https://dev.epicgames.com/documentation/en-us/unreal-engine/chaos-destruction-in-unreal-engine)
