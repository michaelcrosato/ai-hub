using UnrealBuildTool;
using System.Collections.Generic;

public class LowMotionWorldTarget : TargetRules
{
    public LowMotionWorldTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Game;
        DefaultBuildSettings = BuildSettingsVersion.V6;
        IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_7;
        ExtraModuleNames.Add("LowMotionWorld");
    }
}
