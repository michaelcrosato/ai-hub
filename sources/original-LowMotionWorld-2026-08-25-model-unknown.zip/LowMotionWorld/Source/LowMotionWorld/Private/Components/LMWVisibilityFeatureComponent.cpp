#include "Components/LMWVisibilityFeatureComponent.h"

#include "GameFramework/Actor.h"

void ULMWVisibilityFeatureComponent::OnFeatureEnabled_Implementation()
{
    Super::OnFeatureEnabled_Implementation();
    if (AActor* Owner = GetOwner())
    {
        if (bControlVisibility)
        {
            Owner->SetActorHiddenInGame(false);
        }
        if (bControlCollision)
        {
            Owner->SetActorEnableCollision(true);
        }
    }
}

void ULMWVisibilityFeatureComponent::OnFeatureDisabled_Implementation()
{
    Super::OnFeatureDisabled_Implementation();
    if (AActor* Owner = GetOwner())
    {
        if (bControlVisibility)
        {
            Owner->SetActorHiddenInGame(true);
        }
        if (bControlCollision)
        {
            Owner->SetActorEnableCollision(false);
        }
    }
}
