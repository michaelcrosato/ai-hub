#include "Components/LMWInteractionComponent.h"

#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "Interaction/LMWInteractable.h"
#include "Engine/World.h"

ULMWInteractionComponent::ULMWInteractionComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
    PrimaryComponentTick.TickGroup = TG_PostPhysics;
}

void ULMWInteractionComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    ScanAccumulator += DeltaTime;
    if (ScanAccumulator >= ScanInterval)
    {
        ScanAccumulator = 0.0f;
        ScanForInteractable();
    }
}

void ULMWInteractionComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    SetFocusedActor(nullptr);
    Super::EndPlay(EndPlayReason);
}

bool ULMWInteractionComponent::TryInteract()
{
    AActor* Target = FocusedActor.Get();
    if (!IsValid(Target) || !Target->GetClass()->ImplementsInterface(ULMWInteractable::StaticClass()))
    {
        return false;
    }

    AActor* Interactor = GetOwner();
    if (!ILMWInteractable::Execute_CanInteract(Target, Interactor))
    {
        return false;
    }

    ILMWInteractable::Execute_Interact(Target, Interactor);
    OnInteractionSucceeded.Broadcast(Target);
    RefreshFocus();
    return true;
}

AActor* ULMWInteractionComponent::GetFocusedActor() const
{
    return FocusedActor.Get();
}

FText ULMWInteractionComponent::GetCurrentPrompt() const
{
    return CurrentPrompt;
}

void ULMWInteractionComponent::RefreshFocus()
{
    ScanForInteractable();
}

void ULMWInteractionComponent::ScanForInteractable()
{
    FVector TraceStart;
    FVector TraceEnd;
    if (!GetViewRay(TraceStart, TraceEnd))
    {
        SetFocusedActor(nullptr);
        return;
    }

    FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(LMWInteractionTrace), true, GetOwner());
    QueryParams.bReturnPhysicalMaterial = false;

    FHitResult Hit;
    AActor* Candidate = nullptr;
    if (GetWorld()->LineTraceSingleByChannel(Hit, TraceStart, TraceEnd, TraceChannel, QueryParams))
    {
        AActor* HitActor = Hit.GetActor();
        if (IsValid(HitActor) && HitActor->GetClass()->ImplementsInterface(ULMWInteractable::StaticClass()))
        {
            Candidate = HitActor;
        }
    }

    SetFocusedActor(Candidate);
}

void ULMWInteractionComponent::SetFocusedActor(AActor* NewActor)
{
    AActor* Previous = FocusedActor.Get();
    if (Previous == NewActor)
    {
        if (IsValid(NewActor))
        {
            const FText NewPrompt = ILMWInteractable::Execute_GetInteractionPrompt(NewActor, GetOwner());
            if (!CurrentPrompt.EqualTo(NewPrompt))
            {
                CurrentPrompt = NewPrompt;
                OnFocusChanged.Broadcast(NewActor, CurrentPrompt);
            }
        }
        else if (!CurrentPrompt.IsEmpty())
        {
            // A streamed-out or destroyed weak target resolves to null, just like
            // an explicitly cleared focus, so clear its stale HUD prompt too.
            CurrentPrompt = FText::GetEmpty();
            FocusedActor.Reset();
            OnFocusChanged.Broadcast(nullptr, CurrentPrompt);
        }
        return;
    }

    if (IsValid(Previous) && Previous->GetClass()->ImplementsInterface(ULMWInteractable::StaticClass()))
    {
        ILMWInteractable::Execute_EndFocus(Previous, GetOwner());
    }

    FocusedActor = NewActor;
    CurrentPrompt = FText::GetEmpty();

    if (IsValid(NewActor))
    {
        ILMWInteractable::Execute_BeginFocus(NewActor, GetOwner());
        CurrentPrompt = ILMWInteractable::Execute_GetInteractionPrompt(NewActor, GetOwner());
    }

    OnFocusChanged.Broadcast(NewActor, CurrentPrompt);
}

bool ULMWInteractionComponent::GetViewRay(FVector& OutStart, FVector& OutEnd) const
{
    const APawn* PawnOwner = Cast<APawn>(GetOwner());
    const APlayerController* PlayerController = PawnOwner ? Cast<APlayerController>(PawnOwner->GetController()) : nullptr;
    if (!PlayerController)
    {
        return false;
    }

    FRotator ViewRotation;
    PlayerController->GetPlayerViewPoint(OutStart, ViewRotation);
    OutEnd = OutStart + ViewRotation.Vector() * InteractionDistance;
    return true;
}
