#include "Components/LMWHealthComponent.h"

#include "GameFramework/Controller.h"
#include "GameFramework/Pawn.h"

ULMWHealthComponent::ULMWHealthComponent()
{
    PrimaryComponentTick.bCanEverTick = false;
}

void ULMWHealthComponent::BeginPlay()
{
    Super::BeginPlay();
    CurrentHealth = FMath::Clamp(CurrentHealth, 0.0f, MaxHealth);
    GetOwner()->OnTakeAnyDamage.AddDynamic(this, &ULMWHealthComponent::HandleDamage);
}

void ULMWHealthComponent::Heal(float Amount, AActor* SourceActor)
{
    if (Amount <= 0.0f || !IsAlive())
    {
        return;
    }

    const float PreviousHealth = CurrentHealth;
    CurrentHealth = FMath::Clamp(CurrentHealth + Amount, 0.0f, MaxHealth);
    const float AppliedDelta = CurrentHealth - PreviousHealth;
    if (!FMath::IsNearlyZero(AppliedDelta))
    {
        OnHealthChanged.Broadcast(this, CurrentHealth, AppliedDelta, SourceActor);
    }
}

void ULMWHealthComponent::ResetHealth()
{
    const float PreviousHealth = CurrentHealth;
    CurrentHealth = MaxHealth;
    OnHealthChanged.Broadcast(this, CurrentHealth, CurrentHealth - PreviousHealth, GetOwner());
}

float ULMWHealthComponent::GetHealthNormalized() const
{
    return MaxHealth > 0.0f ? CurrentHealth / MaxHealth : 0.0f;
}

void ULMWHealthComponent::HandleDamage(AActor* DamagedActor, float Damage, const UDamageType* DamageType, AController* InstigatedBy, AActor* DamageCauser)
{
    if (Damage <= 0.0f || !IsAlive())
    {
        return;
    }

    const float PreviousHealth = CurrentHealth;
    CurrentHealth = FMath::Clamp(CurrentHealth - Damage, 0.0f, MaxHealth);
    const float AppliedDelta = CurrentHealth - PreviousHealth;
    AActor* InstigatorActor = DamageCauser;
    if (!InstigatorActor && InstigatedBy)
    {
        InstigatorActor = InstigatedBy->GetPawn();
    }

    OnHealthChanged.Broadcast(this, CurrentHealth, AppliedDelta, InstigatorActor);
    if (PreviousHealth > 0.0f && CurrentHealth <= 0.0f)
    {
        OnDeath.Broadcast(GetOwner(), InstigatorActor);
    }
}
