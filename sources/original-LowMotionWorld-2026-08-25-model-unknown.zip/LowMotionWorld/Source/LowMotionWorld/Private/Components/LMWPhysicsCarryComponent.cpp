#include "Components/LMWPhysicsCarryComponent.h"

#include "PhysicsEngine/PhysicsHandleComponent.h"
#include "Components/PrimitiveComponent.h"
#include "GameFramework/Pawn.h"
#include "GameFramework/PlayerController.h"
#include "Engine/World.h"

ULMWPhysicsCarryComponent::ULMWPhysicsCarryComponent()
{
    PrimaryComponentTick.bCanEverTick = true;
    PrimaryComponentTick.TickGroup = TG_PrePhysics;
}

void ULMWPhysicsCarryComponent::BeginPlay()
{
    Super::BeginPlay();

    PhysicsHandle = NewObject<UPhysicsHandleComponent>(GetOwner(), TEXT("LMWPhysicsHandle"));
    if (PhysicsHandle)
    {
        GetOwner()->AddInstanceComponent(PhysicsHandle);
        PhysicsHandle->RegisterComponent();
        PhysicsHandle->LinearStiffness = 1150.0f;
        PhysicsHandle->LinearDamping = 160.0f;
        PhysicsHandle->AngularStiffness = 1500.0f;
        PhysicsHandle->AngularDamping = 180.0f;
        PhysicsHandle->InterpolationSpeed = 18.0f;
        PhysicsHandle->bInterpolateTarget = true;
    }
}

void ULMWPhysicsCarryComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    Drop();
    if (PhysicsHandle)
    {
        PhysicsHandle->DestroyComponent();
        PhysicsHandle = nullptr;
    }
    Super::EndPlay(EndPlayReason);
}

void ULMWPhysicsCarryComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
    Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

    if (!IsCarrying() || !PhysicsHandle)
    {
        return;
    }

    FVector ViewStart;
    FVector ViewEnd;
    FRotator ViewRotation;
    if (GetViewRay(HoldDistance, ViewStart, ViewEnd, ViewRotation))
    {
        FVector SafeTarget = ViewEnd;
        if (CarrySweepRadius > 0.0f)
        {
            FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(LMWCarrySweep), false, GetOwner());
            if (UPrimitiveComponent* Held = HeldComponent.Get())
            {
                QueryParams.AddIgnoredActor(Held->GetOwner());
            }

            FHitResult SweepHit;
            const FCollisionShape Shape = FCollisionShape::MakeSphere(CarrySweepRadius);
            if (GetWorld()->SweepSingleByChannel(SweepHit, ViewStart, ViewEnd, FQuat::Identity, TraceChannel, Shape, QueryParams))
            {
                SafeTarget = SweepHit.Location - ViewRotation.Vector() * 5.0f;
            }
        }

        const FRotator TargetRotation = bKeepGrabbedRotation ? HeldRotation : ViewRotation;
        PhysicsHandle->SetTargetLocationAndRotation(SafeTarget, TargetRotation);
    }
    else
    {
        Drop();
    }
}

bool ULMWPhysicsCarryComponent::TryGrab()
{
    if (IsCarrying() || !PhysicsHandle)
    {
        return false;
    }

    FVector TraceStart;
    FVector TraceEnd;
    FRotator ViewRotation;
    if (!GetViewRay(GrabDistance, TraceStart, TraceEnd, ViewRotation))
    {
        return false;
    }

    FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(LMWPhysicsGrabTrace), true, GetOwner());
    QueryParams.bReturnPhysicalMaterial = false;

    FHitResult Hit;
    if (!GetWorld()->LineTraceSingleByChannel(Hit, TraceStart, TraceEnd, TraceChannel, QueryParams))
    {
        return false;
    }

    UPrimitiveComponent* HitComponent = Hit.GetComponent();
    if (!IsValid(HitComponent) || !HitComponent->IsSimulatingPhysics(Hit.BoneName))
    {
        return false;
    }

    const float ObjectMass = HitComponent->GetMass();
    if (ObjectMass <= 0.0f || ObjectMass > MaxCarryMass)
    {
        return false;
    }

    HeldComponent = HitComponent;
    HeldBoneName = Hit.BoneName;
    HeldRotation = HitComponent->GetComponentRotation();
    HoldDistance = FMath::Clamp(FVector::Distance(TraceStart, Hit.ImpactPoint), MinHoldDistance, MaxHoldDistance);

    HitComponent->WakeRigidBody(HeldBoneName);
    PhysicsHandle->GrabComponentAtLocationWithRotation(HitComponent, HeldBoneName, Hit.ImpactPoint, HeldRotation);
    if (PhysicsHandle->GetGrabbedComponent() != HitComponent)
    {
        HeldComponent.Reset();
        HeldBoneName = NAME_None;
        return false;
    }
    OnObjectGrabbed.Broadcast(HitComponent);
    return true;
}

void ULMWPhysicsCarryComponent::ToggleGrab()
{
    if (IsCarrying())
    {
        Drop();
    }
    else
    {
        TryGrab();
    }
}

void ULMWPhysicsCarryComponent::Drop()
{
    UPrimitiveComponent* ReleasedComponent = HeldComponent.Get();
    if (PhysicsHandle && PhysicsHandle->GetGrabbedComponent())
    {
        PhysicsHandle->ReleaseComponent();
    }

    HeldComponent.Reset();
    HeldBoneName = NAME_None;

    if (IsValid(ReleasedComponent))
    {
        OnObjectDropped.Broadcast(ReleasedComponent);
    }
}

void ULMWPhysicsCarryComponent::Throw()
{
    UPrimitiveComponent* ThrownComponent = HeldComponent.Get();
    const FName ThrownBone = HeldBoneName;
    if (!IsValid(ThrownComponent))
    {
        return;
    }

    FVector ViewStart;
    FVector ViewEnd;
    FRotator ViewRotation;
    const bool bHasView = GetViewRay(100.0f, ViewStart, ViewEnd, ViewRotation);

    Drop();
    if (bHasView && IsValid(ThrownComponent))
    {
        ThrownComponent->AddImpulse(ViewRotation.Vector() * ThrowImpulse, ThrownBone, true);
    }
}

void ULMWPhysicsCarryComponent::SetHoldDistance(float NewDistance)
{
    HoldDistance = FMath::Clamp(NewDistance, MinHoldDistance, MaxHoldDistance);
}

bool ULMWPhysicsCarryComponent::IsCarrying() const
{
    return HeldComponent.IsValid() && PhysicsHandle && PhysicsHandle->GetGrabbedComponent();
}

UPrimitiveComponent* ULMWPhysicsCarryComponent::GetHeldComponent() const
{
    return HeldComponent.Get();
}

bool ULMWPhysicsCarryComponent::GetViewRay(float Distance, FVector& OutStart, FVector& OutEnd, FRotator& OutRotation) const
{
    const APawn* PawnOwner = Cast<APawn>(GetOwner());
    const APlayerController* PlayerController = PawnOwner ? Cast<APlayerController>(PawnOwner->GetController()) : nullptr;
    if (!PlayerController)
    {
        return false;
    }

    PlayerController->GetPlayerViewPoint(OutStart, OutRotation);
    OutEnd = OutStart + OutRotation.Vector() * Distance;
    return true;
}
