#include "Components/LMWFeatureComponent.h"

#include "World/LMWFeatureWorldSubsystem.h"
#include "Engine/World.h"

ULMWFeatureComponent::ULMWFeatureComponent()
{
    PrimaryComponentTick.bCanEverTick = false;
}

void ULMWFeatureComponent::BeginPlay()
{
    Super::BeginPlay();

    // Force the initial callback so Blueprint/C++ children always synchronize
    // their owner's visual and collision state on BeginPlay.
    bFeatureEnabled = !bStartsEnabled;
    SetFeatureEnabled(bStartsEnabled);

    if (ULMWFeatureWorldSubsystem* Registry = GetWorld()->GetSubsystem<ULMWFeatureWorldSubsystem>())
    {
        Registry->RegisterFeature(this);
    }
}

void ULMWFeatureComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
    if (ULMWFeatureWorldSubsystem* Registry = GetWorld()->GetSubsystem<ULMWFeatureWorldSubsystem>())
    {
        Registry->UnregisterFeature(this);
    }

    Super::EndPlay(EndPlayReason);
}

void ULMWFeatureComponent::SetFeatureEnabled(bool bNewEnabled)
{
    if (bFeatureEnabled == bNewEnabled)
    {
        return;
    }

    bFeatureEnabled = bNewEnabled;
    SetComponentTickEnabled(bFeatureEnabled);

    if (bFeatureEnabled)
    {
        OnFeatureEnabled();
    }
    else
    {
        OnFeatureDisabled();
    }

    OnFeatureStateChanged.Broadcast(this, bFeatureEnabled);
}

void ULMWFeatureComponent::OnFeatureEnabled_Implementation()
{
}

void ULMWFeatureComponent::OnFeatureDisabled_Implementation()
{
}
