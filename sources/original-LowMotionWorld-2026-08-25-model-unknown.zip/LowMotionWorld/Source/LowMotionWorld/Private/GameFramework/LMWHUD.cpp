#include "GameFramework/LMWHUD.h"

#include "Components/LMWInteractionComponent.h"
#include "GameFramework/LMWCharacter.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"

void ALMWHUD::DrawHUD()
{
    Super::DrawHUD();
    if (!Canvas)
    {
        return;
    }

    const FVector2D Center(Canvas->ClipX * 0.5f, Canvas->ClipY * 0.5f);
    const FLinearColor ActiveColor = CrosshairColor;
    DrawLine(Center.X - CrosshairSize, Center.Y, Center.X + CrosshairSize, Center.Y, ActiveColor, 1.5f);
    DrawLine(Center.X, Center.Y - CrosshairSize, Center.X, Center.Y + CrosshairSize, ActiveColor, 1.5f);

    const ALMWCharacter* Character = PlayerOwner ? Cast<ALMWCharacter>(PlayerOwner->GetPawn()) : nullptr;
    const ULMWInteractionComponent* Interaction = Character ? Character->GetInteractionComponent() : nullptr;
    if (Interaction && !Interaction->GetCurrentPrompt().IsEmpty())
    {
        const FString Prompt = FString::Printf(TEXT("[E] %s"), *Interaction->GetCurrentPrompt().ToString());
        float TextWidth = 0.0f;
        float TextHeight = 0.0f;
        GetTextSize(Prompt, TextWidth, TextHeight, GEngine->GetMediumFont(), 1.0f);
        DrawText(Prompt, FLinearColor::White, Center.X - TextWidth * 0.5f, Center.Y + 30.0f, GEngine->GetMediumFont(), 1.0f, false);
    }

    if (bShowControlHint)
    {
        DrawText(TEXT("WASD move  |  Shift sprint  |  Space jump  |  Q grab  |  Wheel distance  |  LMB throw  |  E use"),
            FLinearColor(0.75f, 0.82f, 0.86f, 0.85f), 24.0f, Canvas->ClipY - 42.0f,
            GEngine->GetSmallFont(), 1.0f, false);
    }
}
