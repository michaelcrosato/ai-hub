#include "GameFramework/LMWGameMode.h"

#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/Controller.h"
#include "GameFramework/LMWCharacter.h"
#include "GameFramework/LMWHUD.h"
#include "GameFramework/LMWPlayerController.h"
#include "GameFramework/PlayerStart.h"
#include "Settings/LMWProjectSettings.h"
#include "World/LMWStarterWorld.h"

ALMWGameMode::ALMWGameMode()
{
    DefaultPawnClass = ALMWCharacter::StaticClass();
    PlayerControllerClass = ALMWPlayerController::StaticClass();
    HUDClass = ALMWHUD::StaticClass();
}

AActor* ALMWGameMode::ChoosePlayerStart_Implementation(AController* Player)
{
    if (AActor* ExistingStart = Super::ChoosePlayerStart_Implementation(Player))
    {
        return ExistingStart;
    }

    // Engine/Entry can be intentionally empty. Supplying a fallback guarantees
    // that the source-only starter remains playable before any .umap is authored.
    return GetWorld() ? GetWorld()->SpawnActor<APlayerStart>(FVector(0.0f, 0.0f, 120.0f), FRotator::ZeroRotator) : nullptr;
}

void ALMWGameMode::BeginPlay()
{
    Super::BeginPlay();

    const ULMWProjectSettings* Settings = GetDefault<ULMWProjectSettings>();
    const FString MapName = GetWorld() ? GetWorld()->GetMapName() : FString();
    const bool bIsEngineEntryMap = MapName.Contains(TEXT("Entry"), ESearchCase::IgnoreCase);
    if (!Settings || !Settings->bSpawnStarterWorld || !bIsEngineEntryMap)
    {
        return;
    }

    for (TActorIterator<ALMWStarterWorld> It(GetWorld()); It; ++It)
    {
        return;
    }

    GetWorld()->SpawnActor<ALMWStarterWorld>(FVector::ZeroVector, FRotator::ZeroRotator);
}
