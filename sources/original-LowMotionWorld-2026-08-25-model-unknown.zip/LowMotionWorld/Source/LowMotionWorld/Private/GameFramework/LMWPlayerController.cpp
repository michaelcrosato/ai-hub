#include "GameFramework/LMWPlayerController.h"

#include "Engine/GameInstance.h"
#include "Settings/LMWGraphicsSettingsSubsystem.h"

ALMWPlayerController::ALMWPlayerController()
{
    bShowMouseCursor = false;
    bEnableClickEvents = false;
    bEnableMouseOverEvents = false;
}

void ALMWPlayerController::SetGraphicsPreset(const FString& PresetName)
{
    if (PresetName.Equals(TEXT("Performance"), ESearchCase::IgnoreCase))
    {
        ApplyGraphicsPreset(ELMWGraphicsPreset::Performance);
    }
    else if (PresetName.Equals(TEXT("Balanced"), ESearchCase::IgnoreCase))
    {
        ApplyGraphicsPreset(ELMWGraphicsPreset::Balanced);
    }
    else if (PresetName.Equals(TEXT("Quality"), ESearchCase::IgnoreCase))
    {
        ApplyGraphicsPreset(ELMWGraphicsPreset::Quality);
    }
    else if (PresetName.Equals(TEXT("Showcase"), ESearchCase::IgnoreCase))
    {
        ApplyGraphicsPreset(ELMWGraphicsPreset::Showcase);
    }
    else
    {
        ClientMessage(TEXT("Unknown preset. Use Performance, Balanced, Quality, or Showcase."));
    }
}

void ALMWPlayerController::ApplyGraphicsPreset(ELMWGraphicsPreset Preset)
{
    if (UGameInstance* GameInstance = GetGameInstance())
    {
        if (ULMWGraphicsSettingsSubsystem* Graphics = GameInstance->GetSubsystem<ULMWGraphicsSettingsSubsystem>())
        {
            Graphics->ApplyGraphicsPreset(Preset, true);
            ClientMessage(FString::Printf(TEXT("Applied graphics preset: %s"), *UEnum::GetValueAsString(Preset)));
        }
    }
}
