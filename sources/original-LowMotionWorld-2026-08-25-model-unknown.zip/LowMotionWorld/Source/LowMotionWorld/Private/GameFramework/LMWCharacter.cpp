#include "GameFramework/LMWCharacter.h"

#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/InputComponent.h"
#include "Components/LMWHealthComponent.h"
#include "Components/LMWInteractionComponent.h"
#include "Components/LMWPhysicsCarryComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"

ALMWCharacter::ALMWCharacter()
{
    PrimaryActorTick.bCanEverTick = false;

    GetCapsuleComponent()->InitCapsuleSize(42.0f, 92.0f);
    GetCapsuleComponent()->SetCollisionProfileName(TEXT("Pawn"));

    bUseControllerRotationPitch = false;
    bUseControllerRotationYaw = true;
    bUseControllerRotationRoll = false;

    UCharacterMovementComponent* Movement = GetCharacterMovement();
    Movement->bOrientRotationToMovement = false;
    Movement->MaxWalkSpeed = WalkSpeed;
    Movement->MaxWalkSpeedCrouched = 280.0f;
    Movement->BrakingDecelerationWalking = 1800.0f;
    Movement->AirControl = 0.35f;
    Movement->JumpZVelocity = 480.0f;
    Movement->GetNavAgentPropertiesRef().bCanCrouch = true;

    FirstPersonCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));
    FirstPersonCamera->SetupAttachment(GetCapsuleComponent());
    FirstPersonCamera->SetRelativeLocation(FVector(-10.0f, 0.0f, 68.0f));
    FirstPersonCamera->bUsePawnControlRotation = true;
    FirstPersonCamera->FieldOfView = 95.0f;

    InteractionComponent = CreateDefaultSubobject<ULMWInteractionComponent>(TEXT("InteractionComponent"));
    PhysicsCarryComponent = CreateDefaultSubobject<ULMWPhysicsCarryComponent>(TEXT("PhysicsCarryComponent"));
    HealthComponent = CreateDefaultSubobject<ULMWHealthComponent>(TEXT("HealthComponent"));

    // A skeletal mesh is intentionally optional. Blueprint children can add a
    // tool mesh or hands without changing the gameplay implementation.
    GetMesh()->SetHiddenInGame(true);
    GetMesh()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}

void ALMWCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);

    check(PlayerInputComponent);
    PlayerInputComponent->BindAxis(TEXT("MoveForward"), this, &ALMWCharacter::MoveForward);
    PlayerInputComponent->BindAxis(TEXT("MoveRight"), this, &ALMWCharacter::MoveRight);
    PlayerInputComponent->BindAxis(TEXT("Turn"), this, &ALMWCharacter::LookYaw);
    PlayerInputComponent->BindAxis(TEXT("LookUp"), this, &ALMWCharacter::LookPitch);
    PlayerInputComponent->BindAxis(TEXT("HoldDistance"), this, &ALMWCharacter::AdjustHoldDistance);

    PlayerInputComponent->BindAction(TEXT("Jump"), IE_Pressed, this, &ACharacter::Jump);
    PlayerInputComponent->BindAction(TEXT("Jump"), IE_Released, this, &ACharacter::StopJumping);
    PlayerInputComponent->BindAction(TEXT("Sprint"), IE_Pressed, this, &ALMWCharacter::StartSprint);
    PlayerInputComponent->BindAction(TEXT("Sprint"), IE_Released, this, &ALMWCharacter::StopSprint);
    PlayerInputComponent->BindAction(TEXT("Crouch"), IE_Pressed, this, &ALMWCharacter::ToggleCrouch);
    PlayerInputComponent->BindAction(TEXT("Interact"), IE_Pressed, this, &ALMWCharacter::Interact);
    PlayerInputComponent->BindAction(TEXT("Grab"), IE_Pressed, this, &ALMWCharacter::ToggleGrab);
    PlayerInputComponent->BindAction(TEXT("Throw"), IE_Pressed, this, &ALMWCharacter::ThrowHeld);
    PlayerInputComponent->BindAction(TEXT("Drop"), IE_Pressed, this, &ALMWCharacter::DropHeld);
}

void ALMWCharacter::MoveForward(float Value)
{
    if (!FMath::IsNearlyZero(Value))
    {
        AddMovementInput(GetActorForwardVector(), Value);
    }
}

void ALMWCharacter::MoveRight(float Value)
{
    if (!FMath::IsNearlyZero(Value))
    {
        AddMovementInput(GetActorRightVector(), Value);
    }
}

void ALMWCharacter::LookYaw(float Value)
{
    AddControllerYawInput(Value * MouseSensitivity);
}

void ALMWCharacter::LookPitch(float Value)
{
    AddControllerPitchInput(Value * MouseSensitivity);
}

void ALMWCharacter::AdjustHoldDistance(float Value)
{
    if (!FMath::IsNearlyZero(Value) && PhysicsCarryComponent && PhysicsCarryComponent->IsCarrying())
    {
        PhysicsCarryComponent->SetHoldDistance(PhysicsCarryComponent->HoldDistance + Value * 25.0f);
    }
}

void ALMWCharacter::StartSprint()
{
    GetCharacterMovement()->MaxWalkSpeed = SprintSpeed;
}

void ALMWCharacter::StopSprint()
{
    GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
}

void ALMWCharacter::ToggleCrouch()
{
    if (bIsCrouched)
    {
        UnCrouch();
    }
    else
    {
        Crouch();
    }
}

void ALMWCharacter::Interact()
{
    if (InteractionComponent)
    {
        InteractionComponent->TryInteract();
    }
}

void ALMWCharacter::ToggleGrab()
{
    if (PhysicsCarryComponent)
    {
        PhysicsCarryComponent->ToggleGrab();
    }
}

void ALMWCharacter::ThrowHeld()
{
    if (PhysicsCarryComponent && PhysicsCarryComponent->IsCarrying())
    {
        PhysicsCarryComponent->Throw();
    }
}

void ALMWCharacter::DropHeld()
{
    if (PhysicsCarryComponent)
    {
        PhysicsCarryComponent->Drop();
    }
}
