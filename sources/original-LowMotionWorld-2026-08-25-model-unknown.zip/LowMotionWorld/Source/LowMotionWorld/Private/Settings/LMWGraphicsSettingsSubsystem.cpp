#include "Settings/LMWGraphicsSettingsSubsystem.h"

#include "Engine/Engine.h"
#include "GameFramework/GameUserSettings.h"
#include "HAL/IConsoleManager.h"

void ULMWGraphicsSettingsSubsystem::ApplyGraphicsPreset(ELMWGraphicsPreset Preset, bool bSaveSettings)
{
    bool bApplied = false;

    switch (Preset)
    {
        case ELMWGraphicsPreset::Performance:
            bApplied = ApplyScalability(2, 2, 2, 2, 2, 2, 2, 2, 1, 2,
                GetResolutionPercentForInternalHeight(900.0f), 60.0f, false);
            break;
        case ELMWGraphicsPreset::Balanced:
            bApplied = ApplyScalability(2, 2, 2, 2, 2, 3, 3, 2, 2, 3,
                GetResolutionPercentForInternalHeight(1080.0f), 60.0f, false);
            break;
        case ELMWGraphicsPreset::Quality:
            bApplied = ApplyScalability(3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                GetResolutionPercentForInternalHeight(1200.0f), 30.0f, false);
            break;
        case ELMWGraphicsPreset::Showcase:
            bApplied = ApplyScalability(3, 3, 3, 3, 3, 3, 3, 3, 3, 3,
                100.0f, 30.0f, true);
            break;
        default:
            break;
    }

    if (!bApplied)
    {
        UE_LOG(LogTemp, Warning, TEXT("LowMotionWorld could not fully apply graphics preset %s."), *UEnum::GetValueAsString(Preset));
        return;
    }

    ActivePreset = Preset;
    // Hardware-Lumen state is intentionally session-only: unlike scalability
    // groups it is not represented by UGameUserSettings. Avoid persisting half
    // of the Showcase preset and silently restoring a mismatched state later.
    if (bSaveSettings && Preset != ELMWGraphicsPreset::Showcase && GEngine && GEngine->GetGameUserSettings())
    {
        GEngine->GetGameUserSettings()->SaveSettings();
    }
}

bool ULMWGraphicsSettingsSubsystem::ApplyScalability(int32 ViewDistance, int32 AntiAliasing, int32 Shadows,
    int32 GlobalIllumination, int32 Reflections, int32 PostProcess, int32 Textures, int32 Effects,
    int32 Foliage, int32 Shading, float ResolutionPercent, float FrameRateLimit, bool bHardwareLumen)
{
    if (!GEngine || !GEngine->GetGameUserSettings())
    {
        return false;
    }

    UGameUserSettings* Settings = GEngine->GetGameUserSettings();
    Settings->SetViewDistanceQuality(ViewDistance);
    Settings->SetAntiAliasingQuality(AntiAliasing);
    Settings->SetShadowQuality(Shadows);
    Settings->SetGlobalIlluminationQuality(GlobalIllumination);
    Settings->SetReflectionQuality(Reflections);
    Settings->SetPostProcessingQuality(PostProcess);
    Settings->SetTextureQuality(Textures);
    Settings->SetVisualEffectQuality(Effects);
    Settings->SetFoliageQuality(Foliage);
    Settings->SetShadingQuality(Shading);
    Settings->SetResolutionScaleValueEx(ResolutionPercent);
    Settings->SetFrameRateLimit(FrameRateLimit);
    Settings->ApplySettings(false);

    return SetCVar(TEXT("r.Lumen.HardwareRayTracing"), bHardwareLumen ? 1 : 0);
}

float ULMWGraphicsSettingsSubsystem::GetResolutionPercentForInternalHeight(float TargetInternalHeight) const
{
    const UGameUserSettings* Settings = GEngine ? GEngine->GetGameUserSettings() : nullptr;
    const int32 OutputHeight = Settings ? Settings->GetScreenResolution().Y : 1080;
    if (OutputHeight <= 0)
    {
        return 100.0f;
    }
    return FMath::Clamp(100.0f * TargetInternalHeight / static_cast<float>(OutputHeight), 50.0f, 100.0f);
}

bool ULMWGraphicsSettingsSubsystem::SetCVar(const TCHAR* Name, int32 Value) const
{
    if (IConsoleVariable* Variable = IConsoleManager::Get().FindConsoleVariable(Name))
    {
        Variable->Set(Value, ECVF_SetByGameSetting);
        return Variable->GetInt() == Value;
    }
    return false;
}
