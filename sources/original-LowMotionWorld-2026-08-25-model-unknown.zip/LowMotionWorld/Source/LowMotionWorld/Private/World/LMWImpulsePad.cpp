#include "World/LMWImpulsePad.h"

#include "Components/BoxComponent.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/Character.h"
#include "UObject/ConstructorHelpers.h"

ALMWImpulsePad::ALMWImpulsePad()
{
    PrimaryActorTick.bCanEverTick = false;

    Trigger = CreateDefaultSubobject<UBoxComponent>(TEXT("Trigger"));
    SetRootComponent(Trigger);
    Trigger->SetBoxExtent(FVector(110.0f, 110.0f, 35.0f));
    Trigger->SetCollisionProfileName(TEXT("Trigger"));
    Trigger->OnComponentBeginOverlap.AddDynamic(this, &ALMWImpulsePad::HandleOverlap);

    PadMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PadMesh"));
    PadMesh->SetupAttachment(Trigger);
    PadMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    PadMesh->SetRelativeScale3D(FVector(2.0f, 2.0f, 0.2f));

    static ConstructorHelpers::FObjectFinder<UStaticMesh> CylinderMesh(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
    if (CylinderMesh.Succeeded())
    {
        PadMesh->SetStaticMesh(CylinderMesh.Object);
    }
}

void ALMWImpulsePad::HandleOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor,
    UPrimitiveComponent* OtherComponent, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
    if (!IsValid(OtherActor) || OtherActor == this)
    {
        return;
    }

    const FVector WorldDirection = GetActorTransform().TransformVectorNoScale(LocalLaunchDirection).GetSafeNormal();
    bool bLaunched = false;

    if (bAffectCharacters)
    {
        if (ACharacter* Character = Cast<ACharacter>(OtherActor))
        {
            Character->LaunchCharacter(WorldDirection * LaunchStrength, true, true);
            bLaunched = true;
        }
    }

    if (!bLaunched && bAffectPhysicsBodies && IsValid(OtherComponent) && OtherComponent->IsSimulatingPhysics())
    {
        OtherComponent->AddImpulse(WorldDirection * LaunchStrength, NAME_None, true);
        bLaunched = true;
    }

    if (bLaunched)
    {
        OnLaunched.Broadcast(OtherActor);
    }
}
