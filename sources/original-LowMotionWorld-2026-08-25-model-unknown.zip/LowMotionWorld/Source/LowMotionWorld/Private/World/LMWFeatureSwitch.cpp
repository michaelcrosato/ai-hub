#include "World/LMWFeatureSwitch.h"

#include "Components/PointLightComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/World.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "UObject/ConstructorHelpers.h"
#include "World/LMWFeatureWorldSubsystem.h"

ALMWFeatureSwitch::ALMWFeatureSwitch()
{
    PrimaryActorTick.bCanEverTick = false;

    SwitchMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("SwitchMesh"));
    SetRootComponent(SwitchMesh);
    SwitchMesh->SetCollisionProfileName(TEXT("BlockAllDynamic"));
    SwitchMesh->SetRelativeScale3D(FVector(0.45f, 0.45f, 0.8f));

    StatusLight = CreateDefaultSubobject<UPointLightComponent>(TEXT("StatusLight"));
    StatusLight->SetupAttachment(SwitchMesh);
    StatusLight->SetRelativeLocation(FVector(0.0f, 0.0f, 90.0f));
    StatusLight->SetIntensity(2200.0f);
    StatusLight->SetAttenuationRadius(450.0f);
    StatusLight->SetCastShadows(false);

    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
    if (CubeMesh.Succeeded())
    {
        SwitchMesh->SetStaticMesh(CubeMesh.Object);
    }

    static ConstructorHelpers::FObjectFinder<UMaterialInterface> ShapeMaterial(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
    if (ShapeMaterial.Succeeded())
    {
        SwitchMesh->SetMaterial(0, ShapeMaterial.Object);
    }
}

void ALMWFeatureSwitch::BeginPlay()
{
    Super::BeginPlay();
    DynamicMaterial = SwitchMesh->CreateAndSetMaterialInstanceDynamic(0);
    if (ULMWFeatureWorldSubsystem* Registry = GetWorld()->GetSubsystem<ULMWFeatureWorldSubsystem>())
    {
        Registry->SetFeatureGroupEnabled(TargetFeatureId, bEnabled);
    }
    RefreshVisuals();
}

FText ALMWFeatureSwitch::GetInteractionPrompt_Implementation(AActor* Interactor) const
{
    return bEnabled
        ? NSLOCTEXT("LowMotionWorld", "DisableSwitch", "Disable system")
        : NSLOCTEXT("LowMotionWorld", "EnableSwitch", "Enable system");
}

bool ALMWFeatureSwitch::CanInteract_Implementation(AActor* Interactor) const
{
    return IsValid(Interactor);
}

void ALMWFeatureSwitch::Interact_Implementation(AActor* Interactor)
{
    SetSwitchState(!bEnabled);
}

void ALMWFeatureSwitch::BeginFocus_Implementation(AActor* Interactor)
{
    SwitchMesh->SetRenderCustomDepth(true);
}

void ALMWFeatureSwitch::EndFocus_Implementation(AActor* Interactor)
{
    SwitchMesh->SetRenderCustomDepth(false);
}

void ALMWFeatureSwitch::SetSwitchState(bool bNewEnabled)
{
    if (bEnabled == bNewEnabled)
    {
        return;
    }

    bEnabled = bNewEnabled;
    if (ULMWFeatureWorldSubsystem* Registry = GetWorld()->GetSubsystem<ULMWFeatureWorldSubsystem>())
    {
        Registry->SetFeatureGroupEnabled(TargetFeatureId, bEnabled);
    }
    RefreshVisuals();
    OnSwitchChanged.Broadcast(bEnabled);
}

void ALMWFeatureSwitch::RefreshVisuals()
{
    const FLinearColor Color = bEnabled ? FLinearColor(0.1f, 1.0f, 0.35f) : FLinearColor(1.0f, 0.12f, 0.05f);
    StatusLight->SetLightColor(Color);
    StatusLight->SetIntensity(bEnabled ? 3500.0f : 1400.0f);
    if (DynamicMaterial)
    {
        DynamicMaterial->SetVectorParameterValue(TEXT("Color"), Color * 0.35f);
    }
}
