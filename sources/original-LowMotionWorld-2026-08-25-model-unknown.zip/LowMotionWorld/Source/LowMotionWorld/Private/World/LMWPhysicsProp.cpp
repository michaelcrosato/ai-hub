#include "World/LMWPhysicsProp.h"

#include "Components/StaticMeshComponent.h"
#include "GameFramework/Pawn.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "UObject/ConstructorHelpers.h"

ALMWPhysicsProp::ALMWPhysicsProp()
{
    PrimaryActorTick.bCanEverTick = false;
    bReplicates = true;
    SetReplicateMovement(true);

    PhysicsMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PhysicsMesh"));
    SetRootComponent(PhysicsMesh);
    PhysicsMesh->SetCollisionProfileName(TEXT("PhysicsActor"));
    PhysicsMesh->SetSimulatePhysics(true);
    PhysicsMesh->SetEnableGravity(true);
    PhysicsMesh->SetLinearDamping(0.15f);
    PhysicsMesh->SetAngularDamping(0.35f);
    PhysicsMesh->SetNotifyRigidBodyCollision(true);
    PhysicsMesh->SetIsReplicated(true);

    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
    if (CubeMesh.Succeeded())
    {
        PhysicsMesh->SetStaticMesh(CubeMesh.Object);
    }

    static ConstructorHelpers::FObjectFinder<UMaterialInterface> ShapeMaterial(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
    if (ShapeMaterial.Succeeded())
    {
        PhysicsMesh->SetMaterial(0, ShapeMaterial.Object);
    }
}

void ALMWPhysicsProp::BeginPlay()
{
    Super::BeginPlay();
    PhysicsMesh->OnComponentHit.AddDynamic(this, &ALMWPhysicsProp::HandleHit);
}

void ALMWPhysicsProp::SetPropColor(FLinearColor Color)
{
    if (!DynamicMaterial && PhysicsMesh)
    {
        DynamicMaterial = PhysicsMesh->CreateAndSetMaterialInstanceDynamic(0);
    }
    if (DynamicMaterial)
    {
        DynamicMaterial->SetVectorParameterValue(TEXT("Color"), Color);
    }
}

FText ALMWPhysicsProp::GetInteractionPrompt_Implementation(AActor* Interactor) const
{
    return NSLOCTEXT("LowMotionWorld", "PushPhysicsProp", "Push object");
}

bool ALMWPhysicsProp::CanInteract_Implementation(AActor* Interactor) const
{
    return IsValid(Interactor) && PhysicsMesh && PhysicsMesh->IsSimulatingPhysics();
}

void ALMWPhysicsProp::Interact_Implementation(AActor* Interactor)
{
    if (!CanInteract_Implementation(Interactor))
    {
        return;
    }

    const FVector Direction = (GetActorLocation() - Interactor->GetActorLocation()).GetSafeNormal();
    PhysicsMesh->AddImpulseAtLocation((Direction + FVector::UpVector * 0.2f).GetSafeNormal() * InteractImpulse,
        PhysicsMesh->GetCenterOfMass(), NAME_None);
}

void ALMWPhysicsProp::BeginFocus_Implementation(AActor* Interactor)
{
    PhysicsMesh->SetRenderCustomDepth(true);
}

void ALMWPhysicsProp::EndFocus_Implementation(AActor* Interactor)
{
    PhysicsMesh->SetRenderCustomDepth(false);
}

void ALMWPhysicsProp::HandleHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComponent,
    FVector NormalImpulse, const FHitResult& Hit)
{
    OnPhysicsImpact.Broadcast(Hit, NormalImpulse.Size());
}
