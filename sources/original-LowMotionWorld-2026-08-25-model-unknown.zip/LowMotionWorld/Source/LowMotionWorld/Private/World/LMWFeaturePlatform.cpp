#include "World/LMWFeaturePlatform.h"

#include "Components/LMWVisibilityFeatureComponent.h"
#include "Components/StaticMeshComponent.h"
#include "UObject/ConstructorHelpers.h"

ALMWFeaturePlatform::ALMWFeaturePlatform()
{
    PrimaryActorTick.bCanEverTick = false;

    PlatformMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("PlatformMesh"));
    SetRootComponent(PlatformMesh);
    PlatformMesh->SetCollisionProfileName(TEXT("BlockAll"));
    PlatformMesh->SetRelativeScale3D(FVector(4.0f, 4.0f, 0.35f));

    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeMesh(TEXT("/Engine/BasicShapes/Cube.Cube"));
    if (CubeMesh.Succeeded())
    {
        PlatformMesh->SetStaticMesh(CubeMesh.Object);
    }

    FeatureComponent = CreateDefaultSubobject<ULMWVisibilityFeatureComponent>(TEXT("VisibilityFeature"));
    FeatureComponent->FeatureId = TEXT("Feature.Demo");
    FeatureComponent->bStartsEnabled = false;
}
