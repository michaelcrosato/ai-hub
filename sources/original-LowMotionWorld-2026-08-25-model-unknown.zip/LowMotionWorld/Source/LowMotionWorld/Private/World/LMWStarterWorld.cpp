#include "World/LMWStarterWorld.h"

#include "Components/DirectionalLightComponent.h"
#include "Components/ExponentialHeightFogComponent.h"
#include "Components/SkyLightComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Engine/DirectionalLight.h"
#include "Engine/ExponentialHeightFog.h"
#include "Engine/PostProcessVolume.h"
#include "Engine/SkyAtmosphere.h"
#include "Engine/SkyLight.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "UObject/ConstructorHelpers.h"
#include "World/LMWFeaturePlatform.h"
#include "World/LMWFeatureSwitch.h"
#include "World/LMWImpulsePad.h"
#include "World/LMWPhysicsProp.h"

ALMWStarterWorld::ALMWStarterWorld()
{
    PrimaryActorTick.bCanEverTick = false;

    SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
    SetRootComponent(SceneRoot);

    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeFinder(TEXT("/Engine/BasicShapes/Cube.Cube"));
    CubeMesh = CubeFinder.Object;

    static ConstructorHelpers::FObjectFinder<UMaterialInterface> MaterialFinder(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
    BaseMaterial = MaterialFinder.Object;
}

void ALMWStarterWorld::BeginPlay()
{
    Super::BeginPlay();
    CreateLightingIfNeeded();
    CreateArchitecture();
    SpawnGameplayExamples();
}

UStaticMeshComponent* ALMWStarterWorld::CreateBlock(const FString& Label, const FVector& Location,
    const FVector& Scale, const FLinearColor& Color)
{
    const FName ComponentName = MakeUniqueObjectName(this, UStaticMeshComponent::StaticClass(), FName(*Label));
    UStaticMeshComponent* Block = NewObject<UStaticMeshComponent>(this, ComponentName);
    AddInstanceComponent(Block);
    Block->SetupAttachment(SceneRoot);
    Block->SetMobility(EComponentMobility::Static);
    Block->SetStaticMesh(CubeMesh);
    Block->SetCollisionProfileName(TEXT("BlockAll"));
    Block->SetRelativeLocation(Location);
    Block->SetRelativeScale3D(Scale);
    Block->RegisterComponent();

    if (BaseMaterial)
    {
        UMaterialInstanceDynamic* Material = UMaterialInstanceDynamic::Create(BaseMaterial, Block);
        Material->SetVectorParameterValue(TEXT("Color"), Color);
        Block->SetMaterial(0, Material);
    }
    return Block;
}

void ALMWStarterWorld::CreateLightingIfNeeded()
{
    UWorld* World = GetWorld();
    if (!World)
    {
        return;
    }

    bool bHasSun = false;
    for (TActorIterator<ADirectionalLight> It(World); It; ++It)
    {
        bHasSun = true;
        break;
    }

    if (!bHasSun)
    {
        ADirectionalLight* Sun = World->SpawnActor<ADirectionalLight>(FVector::ZeroVector, FRotator(-42.0f, -28.0f, 0.0f));
        if (Sun)
        {
            Sun->GetLightComponent()->SetIntensity(8.0f);
            Sun->GetLightComponent()->SetLightColor(FLinearColor(1.0f, 0.88f, 0.72f));
            if (UDirectionalLightComponent* SunComponent = Cast<UDirectionalLightComponent>(Sun->GetLightComponent()))
            {
                SunComponent->SetAtmosphereSunLight(true);
            }
            SpawnedExamples.Add(Sun);
        }

        ASkyAtmosphere* Atmosphere = World->SpawnActor<ASkyAtmosphere>();
        ASkyLight* Sky = World->SpawnActor<ASkyLight>();
        AExponentialHeightFog* Fog = World->SpawnActor<AExponentialHeightFog>();
        APostProcessVolume* PostProcess = World->SpawnActor<APostProcessVolume>();

        if (Sky)
        {
            Sky->GetLightComponent()->SetIntensity(1.0f);
            Sky->GetLightComponent()->SetMobility(EComponentMobility::Movable);
            Sky->GetLightComponent()->SetRealTimeCaptureEnabled(true);
            SpawnedExamples.Add(Sky);
        }
        if (Fog)
        {
            Fog->GetComponent()->SetFogDensity(0.012f);
            Fog->GetComponent()->SetFogHeightFalloff(0.18f);
            Fog->GetComponent()->SetVolumetricFog(true);
            SpawnedExamples.Add(Fog);
        }
        if (PostProcess)
        {
            PostProcess->bUnbound = true;
            PostProcess->Settings.bOverride_BloomIntensity = true;
            PostProcess->Settings.BloomIntensity = 0.45f;
            PostProcess->Settings.bOverride_VignetteIntensity = true;
            PostProcess->Settings.VignetteIntensity = 0.18f;
            PostProcess->Settings.bOverride_AutoExposureBias = true;
            PostProcess->Settings.AutoExposureBias = 0.15f;
            SpawnedExamples.Add(PostProcess);
        }
        if (Atmosphere)
        {
            SpawnedExamples.Add(Atmosphere);
        }
    }
}

void ALMWStarterWorld::CreateArchitecture()
{
    const FLinearColor GroundColor(0.025f, 0.045f, 0.06f);
    const FLinearColor StoneColor(0.10f, 0.15f, 0.18f);
    const FLinearColor AccentColor(0.04f, 0.32f, 0.42f);

    CreateBlock(TEXT("Ground"), FVector(0.0f, 0.0f, -160.0f), FVector(85.0f, 85.0f, 1.0f), GroundColor);

    // Ring-shaped ruins keep the starter scene visually legible while using no
    // authored animation or external art assets.
    constexpr int32 PillarCount = 28;
    for (int32 Index = 0; Index < PillarCount; ++Index)
    {
        const float Angle = (2.0f * PI * Index) / PillarCount;
        const float Radius = 2600.0f + FMath::Sin(Angle * 3.0f) * 400.0f;
        const float HeightScale = 2.5f + 3.5f * FMath::Abs(FMath::Sin(Angle * 2.0f));
        const FVector Location(FMath::Cos(Angle) * Radius, FMath::Sin(Angle) * Radius, HeightScale * 50.0f - 110.0f);
        CreateBlock(FString::Printf(TEXT("Ruin_%02d"), Index), Location, FVector(0.7f, 0.7f, HeightScale),
            (Index % 4 == 0) ? AccentColor : StoneColor);
    }

    // Simple traversal staircase and elevated observation deck.
    for (int32 Step = 0; Step < 8; ++Step)
    {
        CreateBlock(FString::Printf(TEXT("Step_%02d"), Step), FVector(650.0f + Step * 120.0f, 700.0f, -100.0f + Step * 42.0f),
            FVector(1.4f, 3.0f, 0.4f), StoneColor);
    }
    CreateBlock(TEXT("ObservationDeck"), FVector(1800.0f, 700.0f, 250.0f), FVector(8.0f, 6.0f, 0.45f), AccentColor);
}

void ALMWStarterWorld::SpawnGameplayExamples()
{
    UWorld* World = GetWorld();
    if (!World)
    {
        return;
    }

    const FLinearColor PropColors[] =
    {
        FLinearColor(0.08f, 0.55f, 0.72f),
        FLinearColor(0.90f, 0.35f, 0.10f),
        FLinearColor(0.55f, 0.15f, 0.70f),
        FLinearColor(0.20f, 0.75f, 0.42f)
    };

    for (int32 Index = 0; Index < 12; ++Index)
    {
        const FVector Location(250.0f + (Index % 4) * 125.0f, -150.0f + (Index / 4) * 125.0f, 30.0f + (Index / 8) * 110.0f);
        ALMWPhysicsProp* Prop = World->SpawnActor<ALMWPhysicsProp>(Location, FRotator(0.0f, Index * 17.0f, 0.0f));
        if (Prop)
        {
            const float Scale = 0.55f + (Index % 3) * 0.15f;
            Prop->SetActorScale3D(FVector(Scale));
            Prop->SetPropColor(PropColors[Index % UE_ARRAY_COUNT(PropColors)]);
            SpawnedExamples.Add(Prop);
        }
    }

    ALMWImpulsePad* Pad = World->SpawnActor<ALMWImpulsePad>(FVector(1050.0f, 650.0f, -60.0f), FRotator::ZeroRotator);
    if (Pad)
    {
        SpawnedExamples.Add(Pad);
    }

    ALMWFeatureSwitch* Switch = World->SpawnActor<ALMWFeatureSwitch>(FVector(150.0f, -600.0f, -55.0f), FRotator::ZeroRotator);
    if (Switch)
    {
        Switch->TargetFeatureId = TEXT("Feature.Demo");
        SpawnedExamples.Add(Switch);
    }

    ALMWFeaturePlatform* Platform = World->SpawnActor<ALMWFeaturePlatform>(FVector(800.0f, -600.0f, -25.0f), FRotator::ZeroRotator);
    if (Platform)
    {
        SpawnedExamples.Add(Platform);
    }
}
