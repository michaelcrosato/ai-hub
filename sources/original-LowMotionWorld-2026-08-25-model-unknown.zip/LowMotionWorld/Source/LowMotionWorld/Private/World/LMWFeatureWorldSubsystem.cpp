#include "World/LMWFeatureWorldSubsystem.h"

#include "Components/LMWFeatureComponent.h"

void ULMWFeatureWorldSubsystem::RegisterFeature(ULMWFeatureComponent* Feature)
{
    if (IsValid(Feature))
    {
        RegisteredFeatures.AddUnique(Feature);
        if (const bool* DesiredState = DesiredFeatureStates.Find(Feature->FeatureId))
        {
            Feature->SetFeatureEnabled(*DesiredState);
        }
    }
}

void ULMWFeatureWorldSubsystem::UnregisterFeature(ULMWFeatureComponent* Feature)
{
    RegisteredFeatures.Remove(Feature);
}

int32 ULMWFeatureWorldSubsystem::SetFeatureGroupEnabled(FName FeatureId, bool bEnabled)
{
    DesiredFeatureStates.FindOrAdd(FeatureId) = bEnabled;
    int32 ChangedCount = 0;
    RegisteredFeatures.RemoveAll([](const ULMWFeatureComponent* Feature)
    {
        return !IsValid(Feature);
    });

    for (ULMWFeatureComponent* Feature : RegisteredFeatures)
    {
        if (Feature && Feature->FeatureId == FeatureId && Feature->IsFeatureEnabled() != bEnabled)
        {
            Feature->SetFeatureEnabled(bEnabled);
            ++ChangedCount;
        }
    }

    return ChangedCount;
}

TArray<ULMWFeatureComponent*> ULMWFeatureWorldSubsystem::GetFeaturesById(FName FeatureId) const
{
    TArray<ULMWFeatureComponent*> Result;
    for (ULMWFeatureComponent* Feature : RegisteredFeatures)
    {
        if (IsValid(Feature) && Feature->FeatureId == FeatureId)
        {
            Result.Add(Feature);
        }
    }
    return Result;
}
