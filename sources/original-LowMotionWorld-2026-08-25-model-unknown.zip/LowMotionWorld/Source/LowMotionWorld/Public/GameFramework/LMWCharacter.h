#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "LMWCharacter.generated.h"

class UCameraComponent;
class ULMWHealthComponent;
class ULMWInteractionComponent;
class ULMWPhysicsCarryComponent;

/** Asset-free first-person character. No skeletal mesh or animation BP is required. */
UCLASS(Blueprintable)
class LOWMOTIONWORLD_API ALMWCharacter : public ACharacter
{
    GENERATED_BODY()

public:
    ALMWCharacter();

    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Player")
    UCameraComponent* GetFirstPersonCamera() const { return FirstPersonCamera; }

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Player")
    ULMWInteractionComponent* GetInteractionComponent() const { return InteractionComponent; }

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Player")
    ULMWPhysicsCarryComponent* GetPhysicsCarryComponent() const { return PhysicsCarryComponent; }

protected:
    void MoveForward(float Value);
    void MoveRight(float Value);
    void LookYaw(float Value);
    void LookPitch(float Value);
    void AdjustHoldDistance(float Value);
    void StartSprint();
    void StopSprint();
    void ToggleCrouch();
    void Interact();
    void ToggleGrab();
    void ThrowHeld();
    void DropHeld();

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Low Motion World|Components")
    TObjectPtr<UCameraComponent> FirstPersonCamera;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Low Motion World|Components")
    TObjectPtr<ULMWInteractionComponent> InteractionComponent;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Low Motion World|Components")
    TObjectPtr<ULMWPhysicsCarryComponent> PhysicsCarryComponent;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Low Motion World|Components")
    TObjectPtr<ULMWHealthComponent> HealthComponent;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Movement", meta = (ClampMin = "1.0", Units = "cm/s"))
    float WalkSpeed = 500.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Movement", meta = (ClampMin = "1.0", Units = "cm/s"))
    float SprintSpeed = 850.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Movement", meta = (ClampMin = "0.01"))
    float MouseSensitivity = 1.0f;
};
