#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "LMWHUD.generated.h"

/** Minimal asset-free HUD. Replace it with UMG in a Blueprint child when desired. */
UCLASS(Blueprintable)
class LOWMOTIONWORLD_API ALMWHUD : public AHUD
{
    GENERATED_BODY()

public:
    virtual void DrawHUD() override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|HUD")
    FLinearColor CrosshairColor = FLinearColor(0.55f, 0.95f, 1.0f, 0.9f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|HUD", meta = (ClampMin = "1.0"))
    float CrosshairSize = 5.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|HUD")
    bool bShowControlHint = true;
};
