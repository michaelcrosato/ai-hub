#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "Settings/LMWProjectSettings.h"
#include "LMWPlayerController.generated.h"

UCLASS(Blueprintable)
class LOWMOTIONWORLD_API ALMWPlayerController : public APlayerController
{
    GENERATED_BODY()

public:
    ALMWPlayerController();

    UFUNCTION(Exec, BlueprintCallable, Category = "Low Motion World|Graphics")
    void SetGraphicsPreset(const FString& PresetName);

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Graphics")
    void ApplyGraphicsPreset(ELMWGraphicsPreset Preset);
};
