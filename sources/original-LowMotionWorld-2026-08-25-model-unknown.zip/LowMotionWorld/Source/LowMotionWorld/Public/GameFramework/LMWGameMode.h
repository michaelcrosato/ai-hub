#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "LMWGameMode.generated.h"

UCLASS(Blueprintable)
class LOWMOTIONWORLD_API ALMWGameMode : public AGameModeBase
{
    GENERATED_BODY()

public:
    ALMWGameMode();

    virtual AActor* ChoosePlayerStart_Implementation(AController* Player) override;

protected:
    virtual void BeginPlay() override;
};
