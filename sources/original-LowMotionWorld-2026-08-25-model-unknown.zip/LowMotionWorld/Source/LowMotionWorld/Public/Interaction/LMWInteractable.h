#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "LMWInteractable.generated.h"

class AActor;

UINTERFACE(BlueprintType)
class LOWMOTIONWORLD_API ULMWInteractable : public UInterface
{
    GENERATED_BODY()
};

/**
 * A deliberately small contract for every usable world object. Designers can
 * implement the events entirely in Blueprint or override them in C++.
 */
class LOWMOTIONWORLD_API ILMWInteractable
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Low Motion World|Interaction")
    FText GetInteractionPrompt(AActor* Interactor) const;

    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Low Motion World|Interaction")
    bool CanInteract(AActor* Interactor) const;

    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Low Motion World|Interaction")
    void Interact(AActor* Interactor);

    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Low Motion World|Interaction")
    void BeginFocus(AActor* Interactor);

    UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Low Motion World|Interaction")
    void EndFocus(AActor* Interactor);
};
