#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "LMWFeatureWorldSubsystem.generated.h"

class ULMWFeatureComponent;

/** Runtime registry that lets switches/objectives address feature groups by ID. */
UCLASS()
class LOWMOTIONWORLD_API ULMWFeatureWorldSubsystem : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    void RegisterFeature(ULMWFeatureComponent* Feature);
    void UnregisterFeature(ULMWFeatureComponent* Feature);

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Features")
    int32 SetFeatureGroupEnabled(FName FeatureId, bool bEnabled);

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Features")
    TArray<ULMWFeatureComponent*> GetFeaturesById(FName FeatureId) const;

private:
    UPROPERTY(Transient)
    TArray<TObjectPtr<ULMWFeatureComponent>> RegisteredFeatures;

    UPROPERTY(Transient)
    TMap<FName, bool> DesiredFeatureStates;
};
