#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Interaction/LMWInteractable.h"
#include "LMWFeatureSwitch.generated.h"

class UPointLightComponent;
class UStaticMeshComponent;
class UMaterialInstanceDynamic;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FLMWSwitchChangedSignature, bool, bEnabled);

/** Blueprint-ready switch that addresses feature components by a stable ID. */
UCLASS(Blueprintable)
class LOWMOTIONWORLD_API ALMWFeatureSwitch : public AActor, public ILMWInteractable
{
    GENERATED_BODY()

public:
    ALMWFeatureSwitch();

    virtual FText GetInteractionPrompt_Implementation(AActor* Interactor) const override;
    virtual bool CanInteract_Implementation(AActor* Interactor) const override;
    virtual void Interact_Implementation(AActor* Interactor) override;
    virtual void BeginFocus_Implementation(AActor* Interactor) override;
    virtual void EndFocus_Implementation(AActor* Interactor) override;

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Features")
    void SetSwitchState(bool bNewEnabled);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Features")
    FName TargetFeatureId = TEXT("Feature.Demo");

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Low Motion World|Features")
    bool bEnabled = false;

    UPROPERTY(BlueprintAssignable, Category = "Low Motion World|Features")
    FLMWSwitchChangedSignature OnSwitchChanged;

protected:
    virtual void BeginPlay() override;
    void RefreshVisuals();

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Low Motion World|Components")
    TObjectPtr<UStaticMeshComponent> SwitchMesh;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Low Motion World|Components")
    TObjectPtr<UPointLightComponent> StatusLight;

private:
    UPROPERTY(Transient)
    TObjectPtr<UMaterialInstanceDynamic> DynamicMaterial;
};
