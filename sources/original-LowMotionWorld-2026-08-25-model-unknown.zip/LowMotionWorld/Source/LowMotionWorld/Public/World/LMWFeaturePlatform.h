#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "LMWFeaturePlatform.generated.h"

class ULMWVisibilityFeatureComponent;
class UStaticMeshComponent;

/** Small C++ example proving that feature groups can control unrelated actors. */
UCLASS(Blueprintable)
class LOWMOTIONWORLD_API ALMWFeaturePlatform : public AActor
{
    GENERATED_BODY()

public:
    ALMWFeaturePlatform();

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Low Motion World|Components")
    TObjectPtr<UStaticMeshComponent> PlatformMesh;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Low Motion World|Components")
    TObjectPtr<ULMWVisibilityFeatureComponent> FeatureComponent;
};
