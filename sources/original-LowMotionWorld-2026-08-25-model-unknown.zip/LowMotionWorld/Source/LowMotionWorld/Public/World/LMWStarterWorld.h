#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "LMWStarterWorld.generated.h"

class UMaterialInterface;
class USceneComponent;
class UStaticMesh;
class UStaticMeshComponent;

/**
 * Generates a playable, low-poly test yard when the project opens on Engine/Entry.
 * It uses only Engine assets, so the source project has an immediate Play button.
 */
UCLASS(Blueprintable)
class LOWMOTIONWORLD_API ALMWStarterWorld : public AActor
{
    GENERATED_BODY()

public:
    ALMWStarterWorld();

protected:
    virtual void BeginPlay() override;

private:
    UStaticMeshComponent* CreateBlock(const FString& Label, const FVector& Location, const FVector& Scale, const FLinearColor& Color);
    void CreateLightingIfNeeded();
    void CreateArchitecture();
    void SpawnGameplayExamples();

    UPROPERTY()
    TObjectPtr<USceneComponent> SceneRoot;

    UPROPERTY()
    TObjectPtr<UStaticMesh> CubeMesh;

    UPROPERTY()
    TObjectPtr<UMaterialInterface> BaseMaterial;

    UPROPERTY(Transient)
    TArray<TObjectPtr<AActor>> SpawnedExamples;
};
