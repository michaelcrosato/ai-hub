#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Interaction/LMWInteractable.h"
#include "LMWPhysicsProp.generated.h"

class UStaticMeshComponent;
class UMaterialInstanceDynamic;
class UPrimitiveComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FLMWPhysicsImpactSignature, const FHitResult&, Hit, float, NormalImpulseStrength);

/** General-purpose Chaos rigid body used by the starter arena and Blueprint children. */
UCLASS(Blueprintable)
class LOWMOTIONWORLD_API ALMWPhysicsProp : public AActor, public ILMWInteractable
{
    GENERATED_BODY()

public:
    ALMWPhysicsProp();

    UStaticMeshComponent* GetPhysicsMesh() const { return PhysicsMesh; }

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Physics")
    void SetPropColor(FLinearColor Color);

    virtual FText GetInteractionPrompt_Implementation(AActor* Interactor) const override;
    virtual bool CanInteract_Implementation(AActor* Interactor) const override;
    virtual void Interact_Implementation(AActor* Interactor) override;
    virtual void BeginFocus_Implementation(AActor* Interactor) override;
    virtual void EndFocus_Implementation(AActor* Interactor) override;

    UPROPERTY(BlueprintAssignable, Category = "Low Motion World|Physics")
    FLMWPhysicsImpactSignature OnPhysicsImpact;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Physics", meta = (ClampMin = "0.0"))
    float InteractImpulse = 350.0f;

protected:
    virtual void BeginPlay() override;

    UFUNCTION()
    void HandleHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComponent,
        FVector NormalImpulse, const FHitResult& Hit);

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Low Motion World|Components")
    TObjectPtr<UStaticMeshComponent> PhysicsMesh;

private:
    UPROPERTY(Transient)
    TObjectPtr<UMaterialInstanceDynamic> DynamicMaterial;
};
