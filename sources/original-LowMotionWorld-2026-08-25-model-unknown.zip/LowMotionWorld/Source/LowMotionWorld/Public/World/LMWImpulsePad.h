#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "LMWImpulsePad.generated.h"

class UBoxComponent;
class UPrimitiveComponent;
class UStaticMeshComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FLMWLaunchedSignature, AActor*, LaunchedActor);

/** Transform/physics-driven traversal element; requires no animation asset. */
UCLASS(Blueprintable)
class LOWMOTIONWORLD_API ALMWImpulsePad : public AActor
{
    GENERATED_BODY()

public:
    ALMWImpulsePad();

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Impulse")
    FVector LocalLaunchDirection = FVector(0.35f, 0.0f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Impulse", meta = (ClampMin = "0.0"))
    float LaunchStrength = 1250.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Impulse")
    bool bAffectCharacters = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Impulse")
    bool bAffectPhysicsBodies = true;

    UPROPERTY(BlueprintAssignable, Category = "Low Motion World|Impulse")
    FLMWLaunchedSignature OnLaunched;

protected:
    UFUNCTION()
    void HandleOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComponent,
        int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Low Motion World|Components")
    TObjectPtr<UBoxComponent> Trigger;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Low Motion World|Components")
    TObjectPtr<UStaticMeshComponent> PadMesh;
};
