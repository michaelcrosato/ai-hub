#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "LMWInteractionComponent.generated.h"

class AActor;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FLMWFocusChangedSignature, AActor*, FocusedActor, FText, Prompt);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FLMWInteractionSignature, AActor*, InteractedActor);

/** Camera-driven interaction scanner with Blueprint-friendly focus events. */
UCLASS(ClassGroup = (LowMotionWorld), BlueprintType, Blueprintable, meta = (BlueprintSpawnableComponent))
class LOWMOTIONWORLD_API ULMWInteractionComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    ULMWInteractionComponent();

    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Interaction")
    bool TryInteract();

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Interaction")
    AActor* GetFocusedActor() const;

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Interaction")
    FText GetCurrentPrompt() const;

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Interaction")
    void RefreshFocus();

    UPROPERTY(BlueprintAssignable, Category = "Low Motion World|Interaction")
    FLMWFocusChangedSignature OnFocusChanged;

    UPROPERTY(BlueprintAssignable, Category = "Low Motion World|Interaction")
    FLMWInteractionSignature OnInteractionSucceeded;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Interaction", meta = (ClampMin = "25.0", Units = "cm"))
    float InteractionDistance = 450.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Interaction")
    TEnumAsByte<ECollisionChannel> TraceChannel = ECC_Visibility;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Interaction", meta = (ClampMin = "0.0", ClampMax = "0.5", Units = "s"))
    float ScanInterval = 0.03f;

private:
    void ScanForInteractable();
    void SetFocusedActor(AActor* NewActor);
    bool GetViewRay(FVector& OutStart, FVector& OutEnd) const;

    UPROPERTY(Transient)
    TWeakObjectPtr<AActor> FocusedActor;

    FText CurrentPrompt;
    float ScanAccumulator = 0.0f;
};
