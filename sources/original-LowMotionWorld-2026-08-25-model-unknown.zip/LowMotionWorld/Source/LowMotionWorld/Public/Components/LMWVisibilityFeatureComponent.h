#pragma once

#include "CoreMinimal.h"
#include "Components/LMWFeatureComponent.h"
#include "LMWVisibilityFeatureComponent.generated.h"

/** Ready-made feature that turns an owner actor's presentation/collision on and off. */
UCLASS(ClassGroup = (LowMotionWorld), BlueprintType, Blueprintable, meta = (BlueprintSpawnableComponent))
class LOWMOTIONWORLD_API ULMWVisibilityFeatureComponent : public ULMWFeatureComponent
{
    GENERATED_BODY()

public:
    virtual void OnFeatureEnabled_Implementation() override;
    virtual void OnFeatureDisabled_Implementation() override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Features")
    bool bControlVisibility = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Features")
    bool bControlCollision = true;
};
