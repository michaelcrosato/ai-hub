#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "LMWFeatureComponent.generated.h"

class ULMWFeatureComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FLMWFeatureStateChangedSignature, ULMWFeatureComponent*, Feature, bool, bEnabled);

/**
 * Base class for optional gameplay ideas. Feature components self-register with
 * the world subsystem and can be enabled by ID without hard actor references.
 */
UCLASS(Abstract, ClassGroup = (LowMotionWorld), BlueprintType, Blueprintable, meta = (BlueprintSpawnableComponent))
class LOWMOTIONWORLD_API ULMWFeatureComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    ULMWFeatureComponent();

    virtual void BeginPlay() override;
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Features")
    void SetFeatureEnabled(bool bNewEnabled);

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Features")
    bool IsFeatureEnabled() const { return bFeatureEnabled; }

    UFUNCTION(BlueprintNativeEvent, Category = "Low Motion World|Features")
    void OnFeatureEnabled();

    UFUNCTION(BlueprintNativeEvent, Category = "Low Motion World|Features")
    void OnFeatureDisabled();

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Low Motion World|Features")
    FName FeatureId = TEXT("Feature.Default");

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Low Motion World|Features")
    bool bStartsEnabled = true;

    UPROPERTY(BlueprintAssignable, Category = "Low Motion World|Features")
    FLMWFeatureStateChangedSignature OnFeatureStateChanged;

private:
    UPROPERTY(VisibleInstanceOnly, Category = "Low Motion World|Features")
    bool bFeatureEnabled = false;
};
