#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "LMWHealthComponent.generated.h"

class AController;
class UDamageType;
class ULMWHealthComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FLMWHealthChangedSignature, ULMWHealthComponent*, HealthComponent, float, NewHealth, float, Delta, AActor*, InstigatorActor);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FLMWDeathSignature, AActor*, DeadActor, AActor*, InstigatorActor);

/** Reusable damage/health state with no dependency on character animation. */
UCLASS(ClassGroup = (LowMotionWorld), BlueprintType, Blueprintable, meta = (BlueprintSpawnableComponent))
class LOWMOTIONWORLD_API ULMWHealthComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    ULMWHealthComponent();

    virtual void BeginPlay() override;

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Health")
    void Heal(float Amount, AActor* SourceActor);

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Health")
    void ResetHealth();

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Health")
    bool IsAlive() const { return CurrentHealth > 0.0f; }

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Health")
    float GetHealthNormalized() const;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Low Motion World|Health", meta = (ClampMin = "1.0"))
    float MaxHealth = 100.0f;

    UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "Low Motion World|Health")
    float CurrentHealth = 100.0f;

    UPROPERTY(BlueprintAssignable, Category = "Low Motion World|Health")
    FLMWHealthChangedSignature OnHealthChanged;

    UPROPERTY(BlueprintAssignable, Category = "Low Motion World|Health")
    FLMWDeathSignature OnDeath;

private:
    UFUNCTION()
    void HandleDamage(AActor* DamagedActor, float Damage, const UDamageType* DamageType, AController* InstigatedBy, AActor* DamageCauser);
};
