#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "LMWPhysicsCarryComponent.generated.h"

class UPhysicsHandleComponent;
class UPrimitiveComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FLMWCarryChangedSignature, UPrimitiveComponent*, Component);

/**
 * A Chaos-backed, camera-directed physics manipulator. It is asset-free and can
 * be added to any player Pawn from C++ or Blueprint.
 */
UCLASS(ClassGroup = (LowMotionWorld), BlueprintType, Blueprintable, meta = (BlueprintSpawnableComponent))
class LOWMOTIONWORLD_API ULMWPhysicsCarryComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    ULMWPhysicsCarryComponent();

    virtual void BeginPlay() override;
    virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
    virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Physics")
    bool TryGrab();

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Physics")
    void ToggleGrab();

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Physics")
    void Drop();

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Physics")
    void Throw();

    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Physics")
    void SetHoldDistance(float NewDistance);

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Physics")
    bool IsCarrying() const;

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Physics")
    UPrimitiveComponent* GetHeldComponent() const;

    UPROPERTY(BlueprintAssignable, Category = "Low Motion World|Physics")
    FLMWCarryChangedSignature OnObjectGrabbed;

    UPROPERTY(BlueprintAssignable, Category = "Low Motion World|Physics")
    FLMWCarryChangedSignature OnObjectDropped;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Physics", meta = (ClampMin = "50.0", Units = "cm"))
    float GrabDistance = 500.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Physics", meta = (ClampMin = "50.0", Units = "cm"))
    float HoldDistance = 220.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Physics", meta = (ClampMin = "50.0", Units = "cm"))
    float MinHoldDistance = 100.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Physics", meta = (ClampMin = "50.0", Units = "cm"))
    float MaxHoldDistance = 400.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Physics", meta = (ClampMin = "0.1", Units = "kg"))
    float MaxCarryMass = 125.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Physics", meta = (ClampMin = "0.0"))
    float ThrowImpulse = 1400.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Physics", meta = (ClampMin = "0.0", Units = "cm"))
    float CarrySweepRadius = 24.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Physics")
    bool bKeepGrabbedRotation = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Low Motion World|Physics")
    TEnumAsByte<ECollisionChannel> TraceChannel = ECC_Visibility;

private:
    bool GetViewRay(float Distance, FVector& OutStart, FVector& OutEnd, FRotator& OutRotation) const;

    UPROPERTY(Transient)
    TObjectPtr<UPhysicsHandleComponent> PhysicsHandle;

    UPROPERTY(Transient)
    TWeakObjectPtr<UPrimitiveComponent> HeldComponent;

    FName HeldBoneName = NAME_None;
    FRotator HeldRotation = FRotator::ZeroRotator;
};
