#pragma once

#include "CoreMinimal.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "Settings/LMWProjectSettings.h"
#include "LMWGraphicsSettingsSubsystem.generated.h"

/** Applies tested scalability clusters while keeping every renderer feature available. */
UCLASS()
class LOWMOTIONWORLD_API ULMWGraphicsSettingsSubsystem : public UGameInstanceSubsystem
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Low Motion World|Graphics")
    void ApplyGraphicsPreset(ELMWGraphicsPreset Preset, bool bSaveSettings = true);

    UFUNCTION(BlueprintPure, Category = "Low Motion World|Graphics")
    ELMWGraphicsPreset GetActivePreset() const { return ActivePreset; }

private:
    bool SetCVar(const TCHAR* Name, int32 Value) const;
    bool ApplyScalability(int32 ViewDistance, int32 AntiAliasing, int32 Shadows, int32 GlobalIllumination,
        int32 Reflections, int32 PostProcess, int32 Textures, int32 Effects, int32 Foliage, int32 Shading,
        float ResolutionPercent, float FrameRateLimit, bool bHardwareLumen);
    float GetResolutionPercentForInternalHeight(float TargetInternalHeight) const;

    UPROPERTY(Transient)
    ELMWGraphicsPreset ActivePreset = ELMWGraphicsPreset::Balanced;
};
