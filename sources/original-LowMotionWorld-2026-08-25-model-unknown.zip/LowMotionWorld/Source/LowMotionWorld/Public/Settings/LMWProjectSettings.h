#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "LMWProjectSettings.generated.h"

UENUM(BlueprintType)
enum class ELMWGraphicsPreset : uint8
{
    Performance UMETA(DisplayName = "Performance (60+ fps)"),
    Balanced UMETA(DisplayName = "Balanced / RTX 3060 Default"),
    Quality UMETA(DisplayName = "Quality (30 fps)"),
    Showcase UMETA(DisplayName = "Showcase / Photo Mode")
};

/** Project-wide knobs available under Project Settings > Game > Low Motion World. */
UCLASS(Config = Game, DefaultConfig, meta = (DisplayName = "Low Motion World"))
class LOWMOTIONWORLD_API ULMWProjectSettings : public UDeveloperSettings
{
    GENERATED_BODY()

public:
    virtual FName GetCategoryName() const override { return TEXT("Game"); }

    UPROPERTY(Config, EditAnywhere, BlueprintReadOnly, Category = "Starter")
    bool bSpawnStarterWorld = true;

};
