# Architecture

## Runtime boot sequence

1. `DefaultEngine.ini` selects `AProceduralCityGameMode` as the global GameMode.
2. `AProceduralCityGameMode::InitGame` creates or discovers an `AProceduralCityGenerator` and creates a runtime `APlayerStart` at a road intersection.
3. The generator's `BeginPlay` creates the city from `Seed` and `FCityGenerationSettings`.
4. The GameMode creates a directional light, sky atmosphere, and skylight only when the loaded map does not already contain those actor types.
5. Unreal spawns `ACityFirstPersonCharacter` through the GameMode.
6. The HUD resolves the generator and displays its most recent generation statistics.

## Generation model

The city is centered around the generator actor. Geometry instances are stored in local space, so moving or rotating the generator moves the entire static city. Physics props are spawned as actors using the generator transform.

A city contains:

- one large ground slab;
- `BlocksX + 1` vertical roads and `BlocksY + 1` horizontal roads;
- a sidewalk slab for every block;
- either a park or a subdivided set of building lots per block;
- repeated decorative instances grouped by mesh/material role;
- a small physics-prop stack near the suggested player start.

`FRandomStream` makes generation deterministic for a given seed. Pressing `R` chooses a new seed, clears all instances and spawned props, rebuilds the city, and teleports current players back to the start.

## Rendering strategy

Repeated geometry uses `UHierarchicalInstancedStaticMeshComponent` rather than spawning an Actor for every building part. Components are grouped by visual and collision role:

- ground;
- road;
- road markings;
- sidewalk;
- roof/detail geometry;
- dark and lit windows;
- park surfaces;
- tree trunks and canopies;
- streetlight poles and lamps;
- one building component per palette color.

Buildings, roads, sidewalks, ground, trunks, poles, roofs, and solid details use blocking collision. Windows, road markings, foliage canopies, lamps, and park overlays do not.

## Physics interaction

`ACityPhysicsProp` owns one movable `UStaticMeshComponent`. It enables gravity and simulation, uses the `PhysicsActor` collision profile, configures mass and damping, and enables continuous collision detection.

`ACityFirstPersonCharacter::PushPhysicsObject` performs a camera-forward visibility trace. When the hit component simulates physics, the character applies an impulse at the impact point. Applying force away from the center naturally adds angular motion.

## Blueprint boundary

The core classes are marked `Blueprintable`. Generation settings and style colors are editable, while runtime actions are exposed with `BlueprintCallable` functions.

Designer event hooks are deliberately narrow:

- `ReceiveCityGenerated(FCityGenerationStats)`
- `ReceiveSprintStateChanged(bool)`
- `ReceivePushed(FVector, FVector)`

This keeps the runtime implementation in C++ while allowing sound, particles, camera effects, UI updates, and presentation logic to be added in Blueprint.

## Asset policy

The C++ constructors load only built-in Engine assets:

- `/Engine/BasicShapes/Cube`
- `/Engine/BasicShapes/Cylinder`
- `/Engine/BasicShapes/Cone`
- `/Engine/BasicShapes/BasicShapeMaterial`

The project therefore has no imported content dependency. Dynamic material instances set the built-in material's `Color` vector parameter.
