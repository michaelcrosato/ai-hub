# Troubleshooting

## Unreal says the modules are missing or built with a different engine version

Confirm the project is associated with Unreal Engine 5.8. On Windows, right-click the `.uproject`, switch the Unreal Engine version if necessary, regenerate project files, and build the `ProceduralCityDemoEditor` target in **Development Editor** configuration.

Delete only generated folders when forcing a clean rebuild:

```text
Binaries/
Intermediate/
Saved/
.vs/
```

Do not delete `Config`, `Content`, or `Source`.

## The project opens but Play uses the wrong pawn or GameMode

Open **Project Settings → Maps & Modes** and verify:

- Default GameMode: `ProceduralCityGameMode` or `BP_ProceduralCityGameMode`
- Editor Startup Map: `CityDemo` after running the setup script
- Game Default Map: `CityDemo` after running the setup script

Also check **World Settings → GameMode Override**. A per-level override takes precedence over the project default.

## The Blueprint setup script cannot find the native classes

Compile the C++ module first, restart the Editor, and run the script again. The script needs the reflected native classes under `/Script/ProceduralCityDemo` before it can create Blueprint children.

## The setup script closes my current map

The Unreal `new_level` operation closes the current persistent level. Save current work before executing `create_city_assets.py`. The script creates the map only once and keeps it on later runs.

## Materials are gray rather than colored

The demo expects the built-in `BasicShapeMaterial` to expose a vector parameter named `Color`. If an Engine installation changes that asset, create a simple project material with a `Vector Parameter` named `Color`, then replace the material path in:

- `ProceduralCityGenerator.cpp`
- `CityPhysicsProp.cpp`

## The city is too slow on the target machine

Reduce, in this order:

1. `Max Window Panels`
2. `Blocks X` and `Blocks Y`
3. `Max Floors`
4. `Max Physics Props Per Park`
5. `Lots Per Side`

Window panels are non-colliding instances, but a very large city can still produce substantial instance, shadow, and overdraw cost.

## The player appears inside geometry after changing dimensions

Call `Get Suggested Player Start` through the generator or press `R` during play. The GameMode recomputes the central road intersection and teleports the player after regeneration.

## A packaged build cannot find the map

Run the setup script first, then explicitly add `/Game/Maps/CityDemo` to **Project Settings → Packaging → List of maps to include in a packaged build**. Confirm `DefaultEngine.ini` no longer points to `/Engine/Maps/Templates/Template_Default`.
