# Blueprint Extensions

Run `Content/Python/create_city_assets.py` after compiling the C++ module to create the Blueprint child classes described below.

## BP_ProceduralCityGenerator

Use Class Defaults to alter the seed, grid dimensions, density, floor range, park distribution, colors, and physics-prop count.

The **On City Generated** event receives `FCityGenerationStats`. Suitable additions include:

- update a UMG statistics panel;
- play a short city-build sound;
- fade the screen in after regeneration;
- change the sky or fog based on the seed;
- record the active seed in a save game.

Avoid spawning one Blueprint Actor for every generated building. The C++ hierarchical instances are the main performance strategy.

## BP_CityFirstPersonCharacter

The **On Sprint State Changed** event receives a Boolean. Suitable additions include:

- interpolate camera field of view;
- adjust footstep cadence;
- enable a subtle camera shake;
- show a stamina widget.

The C++ class owns movement and input, so visual Blueprint logic does not need to reimplement WASD or mouse look.

## BP_CityPhysicsProp

The **On Pushed** event receives the applied impulse and world-space hit location. Suitable additions include:

- spawn a Niagara impact effect;
- play a randomized crate sound;
- place a decal at the contact point;
- increment an interaction counter.

The event fires after the C++ component receives its impulse.

## BP_ProceduralCityGameMode

The setup script assigns the Blueprint character and Blueprint generator classes to this GameMode. Use it as the default GameMode when you want Blueprint children to be active.

The unmodified C++ GameMode remains a safe fallback. It can always generate and run the demo without Blueprint assets.
