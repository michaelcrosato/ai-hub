# Procedural City Demo — Unreal Engine 5

A self-contained first-person demo that builds a low-poly city at runtime from C++ and uses Unreal's built-in physics for pushable props. The project does not require Starter Content, Marketplace assets, textures, imported models, or third-party plugins.

The project targets **Unreal Engine 5.8** (use the latest 5.8 hotfix available). The core demo can run immediately after the C++ module is compiled. An optional Unreal Python setup script creates editable Blueprint children and a project-owned map after the first successful Editor launch.

## What is included

- Deterministic runtime city generation from an integer seed.
- A 6 × 6 default block grid with roads, lane markings, sidewalks, low-poly buildings, windows, rooftop units, parks, trees, benches, and streetlights.
- Hierarchical instanced static meshes for repeated city geometry.
- First-person walking, mouse look, jumping, and sprinting.
- Pushable physics crates with mass, damping, CCD, and impulse interaction.
- A lightweight HUD with controls, generation statistics, and a crosshair.
- Runtime daylight setup when the loaded level does not already contain lighting.
- Blueprint-callable generation functions, editable properties, and Blueprint events.
- An optional Editor Python script that creates four Blueprint subclasses and `/Game/Maps/CityDemo`.

## Run the demo

1. Install Unreal Engine **5.8** and the native C++ toolchain required by that installation.
2. Extract the project to a normal writable folder. Avoid cloud-synced or protected system folders for the first build.
3. Open `ProceduralCityDemo.uproject`.
4. When Unreal asks to build missing modules, choose **Yes**.
5. After the Editor opens, press **Play**.

If Unreal cannot build from the project prompt on Windows:

1. Right-click `ProceduralCityDemo.uproject` and select **Generate Visual Studio project files**.
2. Open `ProceduralCityDemo.sln`.
3. Select **Development Editor** and **Win64**, then build the `ProceduralCityDemoEditor` target.
4. Reopen the `.uproject`.

The default configuration loads Unreal's blank template map. The custom GameMode then creates the generator, player start, city, player pawn, and any missing daylight actors at runtime.

## Controls

| Input | Action |
|---|---|
| `W A S D` | Move |
| Mouse | Look |
| `Left Shift` or `Right Shift` | Sprint |
| `Space` | Jump |
| Left mouse button | Push the physics object under the crosshair |
| `R` | Generate a new city seed and return to the start position |
| `Esc` | Release or recapture the mouse cursor |

## Create the Blueprint assets and project map

The runtime demo does not depend on binary Blueprint assets. After the C++ project has compiled, the supplied Editor script can generate them locally.

Before running the script, save any level you currently have open. Creating a new level closes the current persistent level.

1. In Unreal Editor, select **Tools → Execute Python Script**.
2. Choose `Content/Python/create_city_assets.py`.
3. The script creates:
   - `/Game/Blueprints/BP_ProceduralCityGenerator`
   - `/Game/Blueprints/BP_CityFirstPersonCharacter`
   - `/Game/Blueprints/BP_CityPhysicsProp`
   - `/Game/Blueprints/BP_ProceduralCityGameMode`
   - `/Game/Maps/CityDemo`
4. It wires the Blueprint GameMode to the Blueprint character and generator, wires the generator to the Blueprint physics prop, and updates `Config/DefaultEngine.ini`.
5. Save any prompted assets and restart the Editor.

The script is idempotent: it keeps existing assets rather than replacing them.

## Modify the generated city

After creating the Blueprint assets, open `BP_ProceduralCityGenerator` and edit its Class Defaults. Important settings include:

| Setting | Default | Purpose |
|---|---:|---|
| `Blocks X`, `Blocks Y` | `6`, `6` | City dimensions |
| `Block Size` | `2200 cm` | Interior size of each block |
| `Road Width` | `700 cm` | Width of each road strip |
| `Lots Per Side` | `2` | Subdivision count per block axis |
| `Building Density` | `0.82` | Probability that each lot contains a building |
| `Park Chance` | `0.14` | Probability that a block becomes a park |
| `Min Floors`, `Max Floors` | `3`, `18` | Building height range |
| `Max Window Panels` | `8000` | Safety cap for window instances |
| `Max Physics Props Per Park` | `5` | Maximum pushable crates in each park |
| `Seed` | `1337` | Deterministic city layout |

The C++ generator also exposes `Generate City`, `Generate New Seed`, and `Clear City` as Blueprint-callable and Call-in-Editor functions.

## C++, Blueprints, and physics split

- **C++** owns generation, first-person movement, input, rendering instances, player spawning, the HUD, and physics interaction.
- **Blueprints** provide editable child classes and event hooks without duplicating the core logic.
- **Physics** is enabled on `ACityPhysicsProp` static-mesh components. The player performs a visibility trace and applies an impulse at the hit location.

Blueprint events available for extension:

- `BP_ProceduralCityGenerator`: **On City Generated**
- `BP_CityFirstPersonCharacter`: **On Sprint State Changed**
- `BP_CityPhysicsProp`: **On Pushed**

See [`Docs/BlueprintExtensions.md`](Docs/BlueprintExtensions.md) for suggested visual scripting additions.

## Packaging

For a packaged build, first run `Content/Python/create_city_assets.py` so the project owns its default map. Then:

1. Confirm **Project Settings → Maps & Modes** points to `/Game/Maps/CityDemo` and `BP_ProceduralCityGameMode`.
2. Confirm `CityDemo` is included under **Project Settings → Packaging → List of maps to include in a packaged build**, if your packaging profile does not cook referenced maps automatically.
3. Package for the desired desktop platform.

The optional Blueprint assets are not required by the original C++ runtime configuration, but using the project-owned map avoids relying on an Engine template map in a packaged build.

## Source layout

```text
ProceduralCityDemo/
├── Config/
│   ├── DefaultEngine.ini
│   ├── DefaultGame.ini
│   └── DefaultInput.ini
├── Content/Python/
│   └── create_city_assets.py
├── Docs/
│   ├── Architecture.md
│   ├── BlueprintExtensions.md
│   └── Troubleshooting.md
├── Source/
│   ├── ProceduralCityDemo.Target.cs
│   ├── ProceduralCityDemoEditor.Target.cs
│   └── ProceduralCityDemo/
│       ├── CityFirstPersonCharacter.*
│       ├── CityGenerationTypes.h
│       ├── CityPhysicsProp.*
│       ├── ProceduralCityGameMode.*
│       ├── ProceduralCityGenerator.*
│       ├── ProceduralCityHUD.*
│       └── ProceduralCityDemo.Build.cs
├── Tools/
│   └── validate_project.py
└── ProceduralCityDemo.uproject
```

## Verification status

The source tree, JSON, configuration references, reflected class names, paired C++ declarations/definitions, and Python syntax are checked by `Tools/validate_project.py`.

This delivery environment does not contain Unreal Engine or UnrealBuildTool, so the project has not been compiled or launched here. The first actual engine build occurs on your machine. Any engine-version-specific compiler diagnostic should be handled as described in `Docs/Troubleshooting.md`.
