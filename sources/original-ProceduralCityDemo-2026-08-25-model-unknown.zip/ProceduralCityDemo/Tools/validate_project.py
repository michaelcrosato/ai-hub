#!/usr/bin/env python3
"""Static validation for the text-authored ProceduralCityDemo project.

This does not replace UnrealBuildTool. It catches malformed project JSON, missing
files, obvious delimiter errors, broken reflected-class references, Python syntax
errors, and accidental placeholders before the project is opened in Unreal.
"""

from __future__ import annotations

import ast
import configparser
import json
from pathlib import Path
import re
import sys
from typing import Iterable

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "Source" / "ProceduralCityDemo"

REQUIRED_FILES = [
    "ProceduralCityDemo.uproject",
    "Config/DefaultEngine.ini",
    "Config/DefaultGame.ini",
    "Config/DefaultInput.ini",
    "Source/ProceduralCityDemo.Target.cs",
    "Source/ProceduralCityDemoEditor.Target.cs",
    "Source/ProceduralCityDemo/ProceduralCityDemo.Build.cs",
    "Source/ProceduralCityDemo/ProceduralCityDemo.h",
    "Source/ProceduralCityDemo/ProceduralCityDemo.cpp",
    "Source/ProceduralCityDemo/CityGenerationTypes.h",
    "Source/ProceduralCityDemo/CityPhysicsProp.h",
    "Source/ProceduralCityDemo/CityPhysicsProp.cpp",
    "Source/ProceduralCityDemo/CityFirstPersonCharacter.h",
    "Source/ProceduralCityDemo/CityFirstPersonCharacter.cpp",
    "Source/ProceduralCityDemo/ProceduralCityGenerator.h",
    "Source/ProceduralCityDemo/ProceduralCityGenerator.cpp",
    "Source/ProceduralCityDemo/ProceduralCityGameMode.h",
    "Source/ProceduralCityDemo/ProceduralCityGameMode.cpp",
    "Source/ProceduralCityDemo/ProceduralCityHUD.h",
    "Source/ProceduralCityDemo/ProceduralCityHUD.cpp",
    "Content/Python/create_city_assets.py",
    "README.md",
]

REFLECTED_CLASSES = [
    "CityPhysicsProp",
    "CityFirstPersonCharacter",
    "ProceduralCityGenerator",
    "ProceduralCityGameMode",
    "ProceduralCityHUD",
]


def fail(message: str, errors: list[str]) -> None:
    errors.append(message)


def strip_cpp_comments_and_literals(text: str) -> str:
    pattern = re.compile(
        r"//.*?$|/\*.*?\*/|R\".*?\"|\"(?:\\.|[^\"\\])*\"|'(?:\\.|[^'\\])*'",
        re.MULTILINE | re.DOTALL,
    )
    return pattern.sub("", text)


def check_balanced(path: Path, errors: list[str]) -> None:
    text = strip_cpp_comments_and_literals(path.read_text(encoding="utf-8"))
    pairs = {"}": "{", ")": "(", "]": "["}
    stack: list[tuple[str, int]] = []
    for index, char in enumerate(text):
        if char in "{([":
            stack.append((char, index))
        elif char in "})]":
            if not stack or stack[-1][0] != pairs[char]:
                fail(f"{path.relative_to(ROOT)}: unmatched {char} at character {index}", errors)
                return
            stack.pop()
    if stack:
        char, index = stack[-1]
        fail(f"{path.relative_to(ROOT)}: unmatched {char} at character {index}", errors)


def check_generated_header_order(path: Path, errors: list[str]) -> None:
    text = path.read_text(encoding="utf-8")
    generated = [line for line in text.splitlines() if ".generated.h\"" in line]
    if not generated:
        return
    include_lines = [line.strip() for line in text.splitlines() if line.strip().startswith("#include")]
    if generated[-1].strip() != include_lines[-1]:
        fail(f"{path.relative_to(ROOT)}: generated header must be the final include", errors)


def parse_ini(path: Path) -> configparser.ConfigParser:
    parser = configparser.ConfigParser(strict=False, interpolation=None)
    parser.optionxform = str
    parser.read_string(path.read_text(encoding="utf-8"))
    return parser


def cpp_files() -> Iterable[Path]:
    yield from sorted(SOURCE.glob("*.h"))
    yield from sorted(SOURCE.glob("*.cpp"))


def main() -> int:
    errors: list[str] = []

    for relative in REQUIRED_FILES:
        if not (ROOT / relative).is_file():
            fail(f"Missing required file: {relative}", errors)

    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        return 1

    try:
        project = json.loads((ROOT / "ProceduralCityDemo.uproject").read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"Invalid .uproject JSON: {exc}", errors)
        project = {}

    if project.get("EngineAssociation") != "5.8":
        fail(".uproject EngineAssociation must be 5.8", errors)

    modules = {item.get("Name") for item in project.get("Modules", [])}
    if "ProceduralCityDemo" not in modules:
        fail(".uproject does not declare the ProceduralCityDemo runtime module", errors)

    build_text = (SOURCE / "ProceduralCityDemo.Build.cs").read_text(encoding="utf-8")
    for dependency in ("Core", "CoreUObject", "Engine", "InputCore", "PhysicsCore"):
        if f'"{dependency}"' not in build_text:
            fail(f"Build.cs is missing dependency {dependency}", errors)

    for path in cpp_files():
        check_balanced(path, errors)
        if path.suffix == ".h":
            check_generated_header_order(path, errors)

        text = path.read_text(encoding="utf-8")
        for marker in ("TODO", "FIXME", "YOUR_", "PLACEHOLDER"):
            if marker in text.upper():
                fail(f"{path.relative_to(ROOT)} contains placeholder marker {marker}", errors)

    all_source = "\n".join(path.read_text(encoding="utf-8") for path in cpp_files())
    for class_name in REFLECTED_CLASSES:
        header = SOURCE / f"{class_name}.h"
        cpp = SOURCE / f"{class_name}.cpp"
        if not header.exists() or not cpp.exists():
            fail(f"Missing source pair for {class_name}", errors)
        if f"A{class_name}" not in all_source:
            fail(f"Reflected class A{class_name} is not present in source", errors)

    required_definitions = [
        "ACityFirstPersonCharacter::BeginPlay",
        "ACityFirstPersonCharacter::SetupPlayerInputComponent",
        "ACityFirstPersonCharacter::PushPhysicsObject",
        "ACityPhysicsProp::ConfigureProp",
        "ACityPhysicsProp::ApplyPush",
        "AProceduralCityGenerator::GenerateCity",
        "AProceduralCityGenerator::ClearCity",
        "AProceduralCityGenerator::SanitizeSettings",
        "AProceduralCityGameMode::InitGame",
        "AProceduralCityGameMode::StartPlay",
        "AProceduralCityHUD::DrawHUD",
    ]
    for definition in required_definitions:
        if definition not in all_source:
            fail(f"Missing expected C++ definition: {definition}", errors)

    engine_config = parse_ini(ROOT / "Config/DefaultEngine.ini")
    maps_section = "/Script/EngineSettings.GameMapsSettings"
    if not engine_config.has_section(maps_section):
        fail("DefaultEngine.ini is missing GameMapsSettings", errors)
    else:
        game_mode = engine_config.get(maps_section, "GlobalDefaultGameMode", fallback="")
        if "ProceduralCityDemo" not in game_mode:
            fail("DefaultEngine.ini does not reference the project GameMode", errors)

    input_text = (ROOT / "Config/DefaultInput.ini").read_text(encoding="utf-8")
    for mapping in (
        'AxisName="MoveForward"',
        'AxisName="MoveRight"',
        'AxisName="Turn"',
        'AxisName="LookUp"',
        'ActionName="Jump"',
        'ActionName="Sprint"',
        'ActionName="Push"',
        'ActionName="RegenerateCity"',
        'ActionName="ToggleMouseCapture"',
    ):
        if mapping not in input_text:
            fail(f"DefaultInput.ini is missing mapping {mapping}", errors)

    setup_script = ROOT / "Content/Python/create_city_assets.py"
    try:
        ast.parse(setup_script.read_text(encoding="utf-8"), filename=str(setup_script))
    except SyntaxError as exc:
        fail(f"Editor setup Python syntax error: {exc}", errors)

    # Catch the specific accidental four-argument FVector pattern that is easy to
    # introduce while editing size sanitization code.
    generator_text = (SOURCE / "ProceduralCityGenerator.cpp").read_text(encoding="utf-8")
    safe_size_match = re.search(r"const FVector SafeSize\((.*?)\);", generator_text, re.DOTALL)
    if safe_size_match and safe_size_match.group(1).count("FMath::Max") != 3:
        fail("ProceduralCityGenerator SafeSize must contain exactly three FVector components", errors)

    if errors:
        for error in errors:
            print(f"ERROR: {error}")
        print(f"\nStatic validation failed with {len(errors)} error(s).")
        return 1

    source_count = sum(1 for _ in cpp_files())
    print("Static validation passed.")
    print(f"Project root: {ROOT}")
    print(f"C++ source/header files checked: {source_count}")
    print("Engine target: Unreal Engine 5.8")
    print("Note: UnrealBuildTool compilation is still required on a machine with UE5 installed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
