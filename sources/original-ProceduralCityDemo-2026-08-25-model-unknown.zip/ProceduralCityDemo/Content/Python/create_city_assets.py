"""Create optional Blueprint children and a project-owned map for ProceduralCityDemo.

Run after the C++ module has compiled:
    Unreal Editor -> Tools -> Execute Python Script

The script is idempotent. Existing assets are kept.
"""

from __future__ import annotations

from pathlib import Path
import re
from typing import Dict, Optional

import unreal

BLUEPRINT_FOLDER = "/Game/Blueprints"
MAP_PACKAGE = "/Game/Maps/CityDemo"
MAP_OBJECT_PATH = "/Game/Maps/CityDemo.CityDemo"

BLUEPRINT_SPECS = {
    "generator": (
        "BP_ProceduralCityGenerator",
        "/Script/ProceduralCityDemo.ProceduralCityGenerator",
        "Designer-facing child for city layout, density, palettes, parks, and generation events.",
    ),
    "character": (
        "BP_CityFirstPersonCharacter",
        "/Script/ProceduralCityDemo.CityFirstPersonCharacter",
        "Designer-facing first-person character child with sprint and push Blueprint events.",
    ),
    "physics_prop": (
        "BP_CityPhysicsProp",
        "/Script/ProceduralCityDemo.CityPhysicsProp",
        "Designer-facing Chaos physics prop child with an On Pushed event.",
    ),
    "game_mode": (
        "BP_ProceduralCityGameMode",
        "/Script/ProceduralCityDemo.ProceduralCityGameMode",
        "Blueprint game mode wired to the Blueprint character and generator children.",
    ),
}


def _asset_path(asset_name: str) -> str:
    return f"{BLUEPRINT_FOLDER}/{asset_name}"


def _ensure_blueprint(
    asset_subsystem: unreal.EditorAssetSubsystem,
    asset_tools: unreal.AssetTools,
    asset_name: str,
    native_parent_path: str,
    description: str,
) -> Optional[unreal.Blueprint]:
    asset_path = _asset_path(asset_name)

    if asset_subsystem.does_asset_exist(asset_path):
        asset = asset_subsystem.load_asset(asset_path)
        if isinstance(asset, unreal.Blueprint):
            unreal.log(f"ProceduralCityDemo: keeping existing {asset_path}")
            return asset
        unreal.log_error(f"ProceduralCityDemo: {asset_path} exists but is not a Blueprint")
        return None

    parent_class = unreal.load_class(None, native_parent_path)
    if parent_class is None:
        unreal.log_error(
            f"ProceduralCityDemo: could not load {native_parent_path}. "
            "Compile the C++ project before running this script."
        )
        return None

    factory = unreal.BlueprintFactory()
    factory.set_editor_property("parent_class", parent_class)

    blueprint = asset_tools.create_asset(
        asset_name,
        BLUEPRINT_FOLDER,
        unreal.Blueprint,
        factory,
    )

    if not isinstance(blueprint, unreal.Blueprint):
        unreal.log_error(f"ProceduralCityDemo: failed to create {asset_path}")
        return None

    blueprint.set_editor_property("blueprint_category", "Procedural City Demo")
    blueprint.set_editor_property("blueprint_description", description)
    unreal.log(f"ProceduralCityDemo: created {asset_path}")
    return blueprint


def _generated_class(blueprint: Optional[unreal.Blueprint]):
    if blueprint is None:
        return None
    try:
        return blueprint.generated_class()
    except Exception as exc:  # Unreal exceptions are surfaced as Python exceptions.
        unreal.log_warning(f"ProceduralCityDemo: could not resolve generated class: {exc}")
        return None


def _wire_blueprint_defaults(blueprints: Dict[str, Optional[unreal.Blueprint]]) -> None:
    generator_class = _generated_class(blueprints.get("generator"))
    character_class = _generated_class(blueprints.get("character"))
    physics_prop_class = _generated_class(blueprints.get("physics_prop"))
    game_mode_class = _generated_class(blueprints.get("game_mode"))

    if generator_class and physics_prop_class:
        try:
            generator_defaults = unreal.get_default_object(generator_class)
            generator_defaults.set_editor_property("physics_prop_class", physics_prop_class)
        except Exception as exc:
            unreal.log_warning(f"ProceduralCityDemo: could not wire physics prop Blueprint: {exc}")

    if game_mode_class:
        try:
            game_mode_defaults = unreal.get_default_object(game_mode_class)
            if generator_class:
                game_mode_defaults.set_editor_property("city_generator_class", generator_class)
            if character_class:
                game_mode_defaults.set_editor_property("default_pawn_class", character_class)
        except Exception as exc:
            unreal.log_warning(f"ProceduralCityDemo: could not wire GameMode Blueprint defaults: {exc}")


def _ensure_project_map() -> bool:
    map_file = Path(str(unreal.Paths.project_content_dir())) / "Maps" / "CityDemo.umap"
    if map_file.exists():
        unreal.log(f"ProceduralCityDemo: keeping existing {MAP_PACKAGE}")
        return True

    level_subsystem = unreal.get_editor_subsystem(unreal.LevelEditorSubsystem)
    if level_subsystem is None:
        unreal.log_error("ProceduralCityDemo: LevelEditorSubsystem is unavailable")
        return False

    # new_level closes the current persistent level without saving it. The README
    # warns the user to save current work before executing this setup script.
    if not level_subsystem.new_level(MAP_PACKAGE, False):
        unreal.log_error(f"ProceduralCityDemo: failed to create {MAP_PACKAGE}")
        return False

    unreal.log(f"ProceduralCityDemo: created and opened {MAP_PACKAGE}")
    return True


def _replace_ini_value(text: str, section: str, key: str, value: str) -> str:
    section_header = f"[{section}]"
    section_match = re.search(
        rf"(?ms)^\[{re.escape(section)}\]\s*$.*?(?=^\[|\Z)",
        text,
    )

    line = f"{key}={value}"
    if not section_match:
        suffix = "" if text.endswith("\n") else "\n"
        return f"{text}{suffix}\n{section_header}\n{line}\n"

    block = section_match.group(0)
    key_pattern = re.compile(rf"(?m)^{re.escape(key)}=.*$")
    if key_pattern.search(block):
        replacement = key_pattern.sub(line, block, count=1)
    else:
        replacement = block.rstrip() + f"\n{line}\n\n"

    return text[: section_match.start()] + replacement + text[section_match.end() :]


def _set_default_project_assets(use_blueprint_game_mode: bool) -> None:
    game_mode_path = (
        "/Game/Blueprints/BP_ProceduralCityGameMode.BP_ProceduralCityGameMode_C"
        if use_blueprint_game_mode
        else "/Script/ProceduralCityDemo.ProceduralCityGameMode"
    )

    # Update the live settings object so the current Editor session can use the result.
    try:
        settings = unreal.GameMapsSettings.get_game_maps_settings()
        settings.set_editor_property("editor_startup_map", unreal.SoftObjectPath(MAP_OBJECT_PATH))
        settings.set_editor_property("game_default_map", unreal.SoftObjectPath(MAP_OBJECT_PATH))
        settings.set_editor_property("server_default_map", unreal.SoftObjectPath(MAP_OBJECT_PATH))
        settings.set_editor_property("global_default_game_mode", unreal.SoftClassPath(game_mode_path))
    except Exception as exc:
        unreal.log_warning(f"ProceduralCityDemo: could not update live map settings: {exc}")

    # Persist the defaults in source-controlled project config as well.
    config_path = Path(str(unreal.Paths.project_config_dir())) / "DefaultEngine.ini"
    try:
        config_text = config_path.read_text(encoding="utf-8")
        section = "/Script/EngineSettings.GameMapsSettings"
        config_text = _replace_ini_value(config_text, section, "EditorStartupMap", MAP_OBJECT_PATH)
        config_text = _replace_ini_value(config_text, section, "GameDefaultMap", MAP_OBJECT_PATH)
        config_text = _replace_ini_value(config_text, section, "ServerDefaultMap", MAP_OBJECT_PATH)
        config_text = _replace_ini_value(config_text, section, "GlobalDefaultGameMode", game_mode_path)
        config_path.write_text(config_text, encoding="utf-8")
        unreal.log(f"ProceduralCityDemo: updated {config_path}")
    except Exception as exc:
        unreal.log_warning(f"ProceduralCityDemo: could not update DefaultEngine.ini: {exc}")


def main() -> None:
    if not unreal.is_editor():
        raise RuntimeError("This setup script must run inside Unreal Editor")

    asset_subsystem = unreal.get_editor_subsystem(unreal.EditorAssetSubsystem)
    if asset_subsystem is None:
        raise RuntimeError("EditorAssetSubsystem is unavailable")

    asset_subsystem.make_directory(BLUEPRINT_FOLDER)
    asset_tools = unreal.AssetToolsHelpers.get_asset_tools()

    blueprints: Dict[str, Optional[unreal.Blueprint]] = {}
    for key, (asset_name, parent_path, description) in BLUEPRINT_SPECS.items():
        blueprints[key] = _ensure_blueprint(
            asset_subsystem,
            asset_tools,
            asset_name,
            parent_path,
            description,
        )

    _wire_blueprint_defaults(blueprints)
    asset_subsystem.save_directory(BLUEPRINT_FOLDER, True, True)

    map_ready = _ensure_project_map()
    game_mode_blueprint_ready = _generated_class(blueprints.get("game_mode")) is not None
    if map_ready:
        _set_default_project_assets(game_mode_blueprint_ready)

    unreal.log(
        "ProceduralCityDemo setup complete. Save any prompted assets, restart the Editor, "
        "open CityDemo, and press Play."
    )


if __name__ == "__main__":
    main()
