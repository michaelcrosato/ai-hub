#include "ProceduralCityHUD.h"

#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "EngineUtils.h"
#include "ProceduralCityGenerator.h"

void AProceduralCityHUD::DrawHUD()
{
    Super::DrawHUD();

    if (!Canvas)
    {
        return;
    }

    const float CenterX = Canvas->ClipX * 0.5f;
    const float CenterY = Canvas->ClipY * 0.5f;
    const FLinearColor CrosshairColor = FLinearColor::White;

    DrawLine(CenterX - 8.0f, CenterY, CenterX + 8.0f, CenterY, CrosshairColor, 2.0f);
    DrawLine(CenterX, CenterY - 8.0f, CenterX, CenterY + 8.0f, CrosshairColor, 2.0f);

    if (!bShowInstructions || !GEngine)
    {
        return;
    }

    UFont* Font = GEngine->GetSmallFont();
    DrawText(
        TEXT("WASD Move   Mouse Look   Shift Sprint   Space Jump   LMB Push   R New City   Esc Cursor"),
        FLinearColor::White,
        24.0f,
        24.0f,
        Font,
        1.0f,
        false);

    if (const AProceduralCityGenerator* Generator = ResolveGenerator())
    {
        const FCityGenerationStats& Stats = Generator->LastStats;
        const FString StatsText = FString::Printf(
            TEXT("Seed %d   Buildings %d   Parks %d   Chaos Props %d   Generated %.1f ms"),
            Stats.Seed,
            Stats.BuildingCount,
            Stats.ParkCount,
            Stats.PhysicsPropCount,
            Stats.GenerationTimeMs);

        DrawText(StatsText, FLinearColor(0.82f, 0.9f, 1.0f, 1.0f), 24.0f, 48.0f, Font, 1.0f, false);
    }
}

AProceduralCityGenerator* AProceduralCityHUD::ResolveGenerator()
{
    if (CachedGenerator.IsValid())
    {
        return CachedGenerator.Get();
    }

    if (!GetWorld())
    {
        return nullptr;
    }

    for (TActorIterator<AProceduralCityGenerator> It(GetWorld()); It; ++It)
    {
        CachedGenerator = *It;
        return *It;
    }

    return nullptr;
}
