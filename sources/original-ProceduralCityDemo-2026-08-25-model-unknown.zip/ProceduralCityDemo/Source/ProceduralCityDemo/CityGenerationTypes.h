#pragma once

#include "CoreMinimal.h"
#include "CityGenerationTypes.generated.h"

USTRUCT(BlueprintType)
struct FCityGenerationSettings
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Layout", meta=(ClampMin="2", ClampMax="16", UIMin="2", UIMax="12"))
    int32 BlocksX = 6;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Layout", meta=(ClampMin="2", ClampMax="16", UIMin="2", UIMax="12"))
    int32 BlocksY = 6;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Layout", meta=(ClampMin="1200.0", ClampMax="6000.0", UIMin="1600.0", UIMax="3500.0", Units="cm"))
    float BlockSize = 2200.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Layout", meta=(ClampMin="350.0", ClampMax="1600.0", UIMin="500.0", UIMax="1000.0", Units="cm"))
    float RoadWidth = 700.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Layout", meta=(ClampMin="1", ClampMax="4", UIMin="1", UIMax="3"))
    int32 LotsPerSide = 2;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Layout", meta=(ClampMin="20.0", ClampMax="100.0", Units="cm"))
    float SidewalkHeight = 20.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Buildings", meta=(ClampMin="0.0", ClampMax="1.0", UIMin="0.0", UIMax="1.0"))
    float BuildingDensity = 0.82f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Buildings", meta=(ClampMin="0.0", ClampMax="0.8", UIMin="0.0", UIMax="0.35"))
    float ParkChance = 0.14f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Buildings", meta=(ClampMin="1", ClampMax="80", UIMin="2", UIMax="30"))
    int32 MinFloors = 3;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Buildings", meta=(ClampMin="1", ClampMax="120", UIMin="4", UIMax="40"))
    int32 MaxFloors = 18;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Buildings", meta=(ClampMin="200.0", ClampMax="600.0", UIMin="250.0", UIMax="450.0", Units="cm"))
    float FloorHeight = 300.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Buildings")
    bool bGenerateWindows = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Buildings", meta=(ClampMin="1", ClampMax="8", UIMin="1", UIMax="4"))
    int32 WindowFloorStride = 2;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Buildings", meta=(ClampMin="0", ClampMax="30000", UIMin="1000", UIMax="12000"))
    int32 MaxWindowPanels = 8000;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Parks", meta=(ClampMin="0", ClampMax="30", UIMin="2", UIMax="16"))
    int32 MinTreesPerPark = 6;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Parks", meta=(ClampMin="0", ClampMax="60", UIMin="4", UIMax="24"))
    int32 MaxTreesPerPark = 12;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Physics", meta=(ClampMin="0", ClampMax="30", UIMin="0", UIMax="12"))
    int32 MaxPhysicsPropsPerPark = 5;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="World", meta=(Units="cm"))
    float CityBaseZ = 0.0f;
};

USTRUCT(BlueprintType)
struct FCityGenerationStats
{
    GENERATED_BODY()

    UPROPERTY(BlueprintReadOnly, Category="City")
    int32 Seed = 0;

    UPROPERTY(BlueprintReadOnly, Category="City")
    int32 BlockCount = 0;

    UPROPERTY(BlueprintReadOnly, Category="City")
    int32 BuildingCount = 0;

    UPROPERTY(BlueprintReadOnly, Category="City")
    int32 ParkCount = 0;

    UPROPERTY(BlueprintReadOnly, Category="City")
    int32 WindowPanelCount = 0;

    UPROPERTY(BlueprintReadOnly, Category="City")
    int32 TreeCount = 0;

    UPROPERTY(BlueprintReadOnly, Category="City")
    int32 PhysicsPropCount = 0;

    UPROPERTY(BlueprintReadOnly, Category="City")
    float GenerationTimeMs = 0.0f;
};
