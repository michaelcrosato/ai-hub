#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "ProceduralCityGameMode.generated.h"

class APlayerStart;
class AProceduralCityGenerator;

UCLASS(Blueprintable)
class PROCEDURALCITYDEMO_API AProceduralCityGameMode : public AGameModeBase
{
    GENERATED_BODY()

public:
    AProceduralCityGameMode();

    virtual void InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage) override;
    virtual void StartPlay() override;
    virtual AActor* ChoosePlayerStart_Implementation(AController* Player) override;

    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category="City")
    TSubclassOf<AProceduralCityGenerator> CityGeneratorClass;

    UPROPERTY(BlueprintReadOnly, Transient, Category="City")
    TObjectPtr<AProceduralCityGenerator> CityGenerator;

    UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category="Player")
    FRotator PlayerStartRotation = FRotator(0.0f, 0.0f, 0.0f);

    UFUNCTION(BlueprintCallable, Category="City")
    void RegenerateCity(bool bChooseNewSeed = true);

    UFUNCTION(BlueprintPure, Category="City")
    AProceduralCityGenerator* GetCityGenerator() const { return CityGenerator; }

private:
    UPROPERTY(Transient)
    TObjectPtr<APlayerStart> RuntimePlayerStart;

    void EnsureCityGenerator();
    void EnsureRuntimePlayerStart();
    void EnsureEnvironment();
    void MovePlayersToStart();
};
