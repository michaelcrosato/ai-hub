#include "ProceduralCityGameMode.h"

#include "CityFirstPersonCharacter.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/SkyLightComponent.h"
#include "Engine/DirectionalLight.h"
#include "Engine/SkyAtmosphere.h"
#include "Engine/SkyLight.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/PlayerStart.h"
#include "ProceduralCityGenerator.h"
#include "ProceduralCityHUD.h"

AProceduralCityGameMode::AProceduralCityGameMode()
{
    DefaultPawnClass = ACityFirstPersonCharacter::StaticClass();
    HUDClass = AProceduralCityHUD::StaticClass();
    CityGeneratorClass = AProceduralCityGenerator::StaticClass();
}

void AProceduralCityGameMode::InitGame(
    const FString& MapName,
    const FString& Options,
    FString& ErrorMessage)
{
    Super::InitGame(MapName, Options, ErrorMessage);

    EnsureCityGenerator();
    EnsureRuntimePlayerStart();
}

void AProceduralCityGameMode::StartPlay()
{
    EnsureCityGenerator();
    EnsureRuntimePlayerStart();
    EnsureEnvironment();

    Super::StartPlay();

    if (UWorld* World = GetWorld())
    {
        for (FConstPlayerControllerIterator It = World->GetPlayerControllerIterator(); It; ++It)
        {
            if (APlayerController* PlayerController = It->Get())
            {
                PlayerController->bShowMouseCursor = false;
                FInputModeGameOnly InputMode;
                PlayerController->SetInputMode(InputMode);
            }
        }
    }
}

AActor* AProceduralCityGameMode::ChoosePlayerStart_Implementation(AController* Player)
{
    EnsureRuntimePlayerStart();
    return RuntimePlayerStart ? RuntimePlayerStart.Get() : Super::ChoosePlayerStart_Implementation(Player);
}

void AProceduralCityGameMode::RegenerateCity(const bool bChooseNewSeed)
{
    EnsureCityGenerator();
    if (!CityGenerator)
    {
        return;
    }

    if (bChooseNewSeed)
    {
        CityGenerator->GenerateNewSeed();
    }
    else
    {
        CityGenerator->GenerateCity();
    }

    EnsureRuntimePlayerStart();
    MovePlayersToStart();
}

void AProceduralCityGameMode::EnsureCityGenerator()
{
    if (IsValid(CityGenerator))
    {
        return;
    }

    UWorld* World = GetWorld();
    if (!World)
    {
        return;
    }

    for (TActorIterator<AProceduralCityGenerator> It(World); It; ++It)
    {
        CityGenerator = *It;
        break;
    }

    if (!CityGenerator && CityGeneratorClass)
    {
        FActorSpawnParameters SpawnParameters;
        SpawnParameters.Owner = this;
        SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

        CityGenerator = World->SpawnActor<AProceduralCityGenerator>(
            CityGeneratorClass,
            FVector::ZeroVector,
            FRotator::ZeroRotator,
            SpawnParameters);
    }
}

void AProceduralCityGameMode::EnsureRuntimePlayerStart()
{
    EnsureCityGenerator();

    UWorld* World = GetWorld();
    if (!World)
    {
        return;
    }

    const FVector StartLocation = CityGenerator
        ? CityGenerator->GetSuggestedPlayerStart()
        : FVector(0.0f, 0.0f, 230.0f);

    if (!IsValid(RuntimePlayerStart))
    {
        FActorSpawnParameters SpawnParameters;
        SpawnParameters.Owner = this;
        SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

        RuntimePlayerStart = World->SpawnActor<APlayerStart>(
            APlayerStart::StaticClass(),
            StartLocation,
            PlayerStartRotation,
            SpawnParameters);

        if (RuntimePlayerStart)
        {
            RuntimePlayerStart->Tags.Add(TEXT("ProceduralCityRuntimeStart"));
        }
    }
    else
    {
        RuntimePlayerStart->SetActorLocationAndRotation(StartLocation, PlayerStartRotation);
    }
}

void AProceduralCityGameMode::EnsureEnvironment()
{
    UWorld* World = GetWorld();
    if (!World)
    {
        return;
    }

    bool bHasDirectionalLight = false;
    for (TActorIterator<ADirectionalLight> It(World); It; ++It)
    {
        bHasDirectionalLight = true;
        break;
    }

    if (!bHasDirectionalLight)
    {
        ADirectionalLight* Sun = World->SpawnActor<ADirectionalLight>(
            ADirectionalLight::StaticClass(),
            FVector(0.0f, 0.0f, 5000.0f),
            FRotator(-48.0f, -32.0f, 0.0f));

        if (Sun)
        {
            UDirectionalLightComponent* Light = Sun->GetComponent();
            if (Light)
            {
                Light->SetMobility(EComponentMobility::Movable);
                Light->SetIntensity(8.0f);
                Light->SetLightColor(FLinearColor(1.0f, 0.91f, 0.78f, 1.0f));
                Light->SetAtmosphereSunLight(true);
                Light->SetLightSourceAngle(1.0f);
            }
        }
    }

    bool bHasSkyAtmosphere = false;
    for (TActorIterator<ASkyAtmosphere> It(World); It; ++It)
    {
        bHasSkyAtmosphere = true;
        break;
    }

    if (!bHasSkyAtmosphere)
    {
        World->SpawnActor<ASkyAtmosphere>(
            ASkyAtmosphere::StaticClass(),
            FVector::ZeroVector,
            FRotator::ZeroRotator);
    }

    bool bHasSkyLight = false;
    for (TActorIterator<ASkyLight> It(World); It; ++It)
    {
        bHasSkyLight = true;
        break;
    }

    if (!bHasSkyLight)
    {
        ASkyLight* SkyLight = World->SpawnActor<ASkyLight>(
            ASkyLight::StaticClass(),
            FVector(0.0f, 0.0f, 1000.0f),
            FRotator::ZeroRotator);

        if (SkyLight)
        {
            USkyLightComponent* Light = SkyLight->GetLightComponent();
            if (Light)
            {
                Light->SetMobility(EComponentMobility::Movable);
                Light->SetIntensity(0.85f);
                Light->SetRealTimeCapture(true);
            }
        }
    }
}

void AProceduralCityGameMode::MovePlayersToStart()
{
    UWorld* World = GetWorld();
    if (!World || !RuntimePlayerStart)
    {
        return;
    }

    const FVector StartLocation = RuntimePlayerStart->GetActorLocation();

    for (FConstPlayerControllerIterator It = World->GetPlayerControllerIterator(); It; ++It)
    {
        APlayerController* PlayerController = It->Get();
        if (!PlayerController)
        {
            continue;
        }

        if (APawn* Pawn = PlayerController->GetPawn())
        {
            Pawn->TeleportTo(StartLocation, PlayerStartRotation, false, true);

            if (ACharacter* Character = Cast<ACharacter>(Pawn))
            {
                Character->GetCharacterMovement()->StopMovementImmediately();
            }
        }

        PlayerController->SetControlRotation(PlayerStartRotation);
    }
}
