#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "ProceduralCityHUD.generated.h"

class AProceduralCityGenerator;

UCLASS(Blueprintable)
class PROCEDURALCITYDEMO_API AProceduralCityHUD : public AHUD
{
    GENERATED_BODY()

public:
    virtual void DrawHUD() override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="HUD")
    bool bShowInstructions = true;

private:
    TWeakObjectPtr<AProceduralCityGenerator> CachedGenerator;

    AProceduralCityGenerator* ResolveGenerator();
};
