#include "CityFirstPersonCharacter.h"

#include "Camera/CameraComponent.h"
#include "CityPhysicsProp.h"
#include "Components/CapsuleComponent.h"
#include "Components/InputComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Engine/World.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "ProceduralCityGameMode.h"

ACityFirstPersonCharacter::ACityFirstPersonCharacter()
{
    PrimaryActorTick.bCanEverTick = false;

    GetCapsuleComponent()->InitCapsuleSize(42.0f, 96.0f);

    FirstPersonCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));
    FirstPersonCamera->SetupAttachment(GetCapsuleComponent());
    FirstPersonCamera->SetRelativeLocation(FVector(0.0f, 0.0f, 64.0f));
    FirstPersonCamera->bUsePawnControlRotation = true;

    bUseControllerRotationPitch = false;
    bUseControllerRotationYaw = true;
    bUseControllerRotationRoll = false;

    UCharacterMovementComponent* Movement = GetCharacterMovement();
    Movement->bOrientRotationToMovement = false;
    Movement->MaxWalkSpeed = WalkSpeed;
    Movement->JumpZVelocity = 520.0f;
    Movement->AirControl = 0.32f;
    Movement->BrakingDecelerationWalking = 1800.0f;
    Movement->MaxStepHeight = 48.0f;
}

void ACityFirstPersonCharacter::BeginPlay()
{
    Super::BeginPlay();
    GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
}

void ACityFirstPersonCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);

    check(PlayerInputComponent);

    PlayerInputComponent->BindAxis(TEXT("MoveForward"), this, &ACityFirstPersonCharacter::MoveForward);
    PlayerInputComponent->BindAxis(TEXT("MoveRight"), this, &ACityFirstPersonCharacter::MoveRight);
    PlayerInputComponent->BindAxis(TEXT("Turn"), this, &ACityFirstPersonCharacter::Turn);
    PlayerInputComponent->BindAxis(TEXT("LookUp"), this, &ACityFirstPersonCharacter::LookUp);

    PlayerInputComponent->BindAction(TEXT("Jump"), IE_Pressed, this, &ACharacter::Jump);
    PlayerInputComponent->BindAction(TEXT("Jump"), IE_Released, this, &ACharacter::StopJumping);
    PlayerInputComponent->BindAction(TEXT("Sprint"), IE_Pressed, this, &ACityFirstPersonCharacter::StartSprint);
    PlayerInputComponent->BindAction(TEXT("Sprint"), IE_Released, this, &ACityFirstPersonCharacter::StopSprint);
    PlayerInputComponent->BindAction(TEXT("Push"), IE_Pressed, this, &ACityFirstPersonCharacter::PushPhysicsObject);
    PlayerInputComponent->BindAction(TEXT("RegenerateCity"), IE_Pressed, this, &ACityFirstPersonCharacter::RegenerateCity);
    PlayerInputComponent->BindAction(TEXT("ToggleMouseCapture"), IE_Pressed, this, &ACityFirstPersonCharacter::ToggleMouseCapture);
}

void ACityFirstPersonCharacter::MoveForward(const float Value)
{
    if (FMath::IsNearlyZero(Value) || !Controller)
    {
        return;
    }

    const FRotator ControlRotation = Controller->GetControlRotation();
    const FRotator YawRotation(0.0f, ControlRotation.Yaw, 0.0f);
    AddMovementInput(FRotationMatrix(YawRotation).GetUnitAxis(EAxis::X), Value);
}

void ACityFirstPersonCharacter::MoveRight(const float Value)
{
    if (FMath::IsNearlyZero(Value) || !Controller)
    {
        return;
    }

    const FRotator ControlRotation = Controller->GetControlRotation();
    const FRotator YawRotation(0.0f, ControlRotation.Yaw, 0.0f);
    AddMovementInput(FRotationMatrix(YawRotation).GetUnitAxis(EAxis::Y), Value);
}

void ACityFirstPersonCharacter::Turn(const float Value)
{
    AddControllerYawInput(Value);
}

void ACityFirstPersonCharacter::LookUp(const float Value)
{
    AddControllerPitchInput(Value);
}

void ACityFirstPersonCharacter::StartSprint()
{
    GetCharacterMovement()->MaxWalkSpeed = SprintSpeed;
    ReceiveSprintStateChanged(true);
}

void ACityFirstPersonCharacter::StopSprint()
{
    GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
    ReceiveSprintStateChanged(false);
}

void ACityFirstPersonCharacter::PushPhysicsObject()
{
    UWorld* World = GetWorld();
    if (!World || !FirstPersonCamera)
    {
        return;
    }

    const FVector TraceStart = FirstPersonCamera->GetComponentLocation();
    const FVector TraceEnd = TraceStart + FirstPersonCamera->GetForwardVector() * PushDistance;

    FCollisionQueryParams QueryParams(SCENE_QUERY_STAT(CityPushTrace), false, this);
    FHitResult Hit;

    if (!World->LineTraceSingleByChannel(Hit, TraceStart, TraceEnd, ECC_Visibility, QueryParams))
    {
        return;
    }

    UPrimitiveComponent* HitComponent = Hit.GetComponent();
    if (!HitComponent || !HitComponent->IsSimulatingPhysics(Hit.BoneName))
    {
        return;
    }

    const FVector Impulse = FirstPersonCamera->GetForwardVector() * PushImpulse;

    if (ACityPhysicsProp* PhysicsProp = Cast<ACityPhysicsProp>(Hit.GetActor()))
    {
        PhysicsProp->ApplyPush(Impulse, Hit.ImpactPoint);
    }
    else
    {
        HitComponent->AddImpulseAtLocation(Impulse, Hit.ImpactPoint, Hit.BoneName);
    }
}

void ACityFirstPersonCharacter::RegenerateCity()
{
    if (UWorld* World = GetWorld())
    {
        if (AProceduralCityGameMode* GameMode = World->GetAuthGameMode<AProceduralCityGameMode>())
        {
            GameMode->RegenerateCity(true);
        }
    }
}

void ACityFirstPersonCharacter::ToggleMouseCapture()
{
    APlayerController* PlayerController = Cast<APlayerController>(Controller);
    if (!PlayerController)
    {
        return;
    }

    const bool bReleaseMouse = !PlayerController->bShowMouseCursor;
    PlayerController->bShowMouseCursor = bReleaseMouse;

    if (bReleaseMouse)
    {
        FInputModeGameAndUI InputMode;
        InputMode.SetHideCursorDuringCapture(false);
        InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
        PlayerController->SetInputMode(InputMode);
    }
    else
    {
        FInputModeGameOnly InputMode;
        PlayerController->SetInputMode(InputMode);
    }
}
