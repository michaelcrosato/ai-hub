#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "CityFirstPersonCharacter.generated.h"

class UCameraComponent;
class UInputComponent;

UCLASS(Blueprintable)
class PROCEDURALCITYDEMO_API ACityFirstPersonCharacter : public ACharacter
{
    GENERATED_BODY()

public:
    ACityFirstPersonCharacter();

    virtual void BeginPlay() override;
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Camera")
    TObjectPtr<UCameraComponent> FirstPersonCamera;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Movement", meta=(ClampMin="100.0", ClampMax="2000.0", Units="cm/s"))
    float WalkSpeed = 600.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Movement", meta=(ClampMin="100.0", ClampMax="3000.0", Units="cm/s"))
    float SprintSpeed = 1050.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Interaction", meta=(ClampMin="100.0", ClampMax="3000.0", Units="cm"))
    float PushDistance = 650.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Interaction", meta=(ClampMin="1000.0", ClampMax="500000.0"))
    float PushImpulse = 85000.0f;

    UFUNCTION(BlueprintCallable, Category="Interaction")
    void PushPhysicsObject();

    UFUNCTION(BlueprintImplementableEvent, Category="Movement", meta=(DisplayName="On Sprint State Changed"))
    void ReceiveSprintStateChanged(bool bIsSprinting);

private:
    void MoveForward(float Value);
    void MoveRight(float Value);
    void Turn(float Value);
    void LookUp(float Value);
    void StartSprint();
    void StopSprint();
    void RegenerateCity();
    void ToggleMouseCapture();
};
