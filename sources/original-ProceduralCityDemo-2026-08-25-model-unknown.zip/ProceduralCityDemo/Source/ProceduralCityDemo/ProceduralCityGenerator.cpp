#include "ProceduralCityGenerator.h"

#include "CityPhysicsProp.h"
#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Components/SceneComponent.h"
#include "Engine/StaticMesh.h"
#include "Engine/World.h"
#include "HAL/PlatformTime.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "UObject/ConstructorHelpers.h"

AProceduralCityGenerator::AProceduralCityGenerator()
{
    PrimaryActorTick.bCanEverTick = false;

    SceneRoot = CreateDefaultSubobject<USceneComponent>(TEXT("SceneRoot"));
    SetRootComponent(SceneRoot);

    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeFinder(TEXT("/Engine/BasicShapes/Cube.Cube"));
    static ConstructorHelpers::FObjectFinder<UStaticMesh> CylinderFinder(TEXT("/Engine/BasicShapes/Cylinder.Cylinder"));
    static ConstructorHelpers::FObjectFinder<UStaticMesh> ConeFinder(TEXT("/Engine/BasicShapes/Cone.Cone"));
    static ConstructorHelpers::FObjectFinder<UMaterialInterface> MaterialFinder(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));

    CubeMesh = CubeFinder.Succeeded() ? CubeFinder.Object : nullptr;
    CylinderMesh = CylinderFinder.Succeeded() ? CylinderFinder.Object : CubeMesh;
    ConeMesh = ConeFinder.Succeeded() ? ConeFinder.Object : CubeMesh;
    BaseMaterial = MaterialFinder.Succeeded()
        ? MaterialFinder.Object
        : UMaterial::GetDefaultMaterial(MD_Surface);

    PhysicsPropClass = ACityPhysicsProp::StaticClass();

    BuildingPalette =
    {
        FLinearColor(0.19f, 0.47f, 0.58f, 1.0f),
        FLinearColor(0.72f, 0.31f, 0.24f, 1.0f),
        FLinearColor(0.74f, 0.59f, 0.24f, 1.0f),
        FLinearColor(0.38f, 0.34f, 0.58f, 1.0f),
        FLinearColor(0.35f, 0.48f, 0.38f, 1.0f),
        FLinearColor(0.50f, 0.52f, 0.56f, 1.0f)
    };
}

void AProceduralCityGenerator::BeginPlay()
{
    Super::BeginPlay();

    if (!bGenerateOnBeginPlay)
    {
        return;
    }

    if (bUseRandomSeedOnBeginPlay)
    {
        GenerateNewSeed();
    }
    else
    {
        GenerateCity();
    }
}

void AProceduralCityGenerator::GenerateCity()
{
    const double StartTime = FPlatformTime::Seconds();

    Settings = SanitizeSettings(Settings);
    EnsureRenderComponents();
    ClearCity();

    FRandomStream Random(Seed);
    LastStats.Seed = Seed;

    const int32 BlocksX = Settings.BlocksX;
    const int32 BlocksY = Settings.BlocksY;
    const float BlockSize = Settings.BlockSize;
    const float RoadWidth = Settings.RoadWidth;
    const float BaseZ = Settings.CityBaseZ;
    const float TotalX = BlocksX * BlockSize + (BlocksX + 1) * RoadWidth;
    const float TotalY = BlocksY * BlockSize + (BlocksY + 1) * RoadWidth;

    AddBox(
        GroundInstances,
        FVector(0.0f, 0.0f, BaseZ - 50.0f),
        FVector(TotalX + 5000.0f, TotalY + 5000.0f, 100.0f));

    GenerateRoadNetwork(BlocksX, BlocksY, BlockSize, RoadWidth, TotalX, TotalY);

    const float SidewalkTop = BaseZ + Settings.SidewalkHeight;
    const float FirstBlockX = -TotalX * 0.5f + RoadWidth + BlockSize * 0.5f;
    const float FirstBlockY = -TotalY * 0.5f + RoadWidth + BlockSize * 0.5f;
    const float Pitch = BlockSize + RoadWidth;

    for (int32 BlockY = 0; BlockY < BlocksY; ++BlockY)
    {
        for (int32 BlockX = 0; BlockX < BlocksX; ++BlockX)
        {
            const FVector BlockCenter(
                FirstBlockX + BlockX * Pitch,
                FirstBlockY + BlockY * Pitch,
                0.0f);

            AddBox(
                SidewalkInstances,
                FVector(BlockCenter.X, BlockCenter.Y, BaseZ + Settings.SidewalkHeight * 0.5f),
                FVector(BlockSize, BlockSize, Settings.SidewalkHeight));

            GenerateBlock(BlockX, BlockY, BlockCenter, Random, BlockSize, SidewalkTop);
            GenerateStreetLights(BlockCenter, BlockX, BlockY, BlockSize, SidewalkTop);
            ++LastStats.BlockCount;
        }
    }

    SpawnStarterPhysicsStack(SidewalkTop);

    LastStats.GenerationTimeMs = static_cast<float>((FPlatformTime::Seconds() - StartTime) * 1000.0);
    ReceiveCityGenerated(LastStats);
}

void AProceduralCityGenerator::GenerateNewSeed()
{
    Seed = static_cast<int32>(FPlatformTime::Cycles64() & 0x7fffffffULL);
    if (Seed == 0)
    {
        Seed = 1;
    }

    GenerateCity();
}

void AProceduralCityGenerator::ClearCity()
{
    const TArray<UHierarchicalInstancedStaticMeshComponent*> FixedComponents =
    {
        GroundInstances,
        RoadInstances,
        RoadMarkingInstances,
        SidewalkInstances,
        RoofInstances,
        DarkWindowInstances,
        LitWindowInstances,
        ParkInstances,
        TreeTrunkInstances,
        TreeCanopyInstances,
        StreetPoleInstances,
        StreetLampInstances,
        DetailInstances
    };

    for (UHierarchicalInstancedStaticMeshComponent* Component : FixedComponents)
    {
        if (Component)
        {
            Component->ClearInstances();
        }
    }

    for (UHierarchicalInstancedStaticMeshComponent* Component : BuildingInstances)
    {
        if (Component)
        {
            Component->ClearInstances();
        }
    }

    for (ACityPhysicsProp* Prop : SpawnedPhysicsProps)
    {
        if (IsValid(Prop))
        {
            Prop->Destroy();
        }
    }

    SpawnedPhysicsProps.Reset();
    LastStats = FCityGenerationStats();
}

FVector AProceduralCityGenerator::GetSuggestedPlayerStart() const
{
    const FCityGenerationSettings Safe = SanitizeSettings(Settings);
    const float TotalX = Safe.BlocksX * Safe.BlockSize + (Safe.BlocksX + 1) * Safe.RoadWidth;
    const float TotalY = Safe.BlocksY * Safe.BlockSize + (Safe.BlocksY + 1) * Safe.RoadWidth;
    const float Pitch = Safe.BlockSize + Safe.RoadWidth;

    const int32 RoadIndexX = Safe.BlocksX / 2;
    const int32 RoadIndexY = Safe.BlocksY / 2;
    const float RoadX = -TotalX * 0.5f + Safe.RoadWidth * 0.5f + RoadIndexX * Pitch;
    const float RoadY = -TotalY * 0.5f + Safe.RoadWidth * 0.5f + RoadIndexY * Pitch;

    return GetActorTransform().TransformPosition(
        FVector(RoadX, RoadY, Safe.CityBaseZ + Safe.SidewalkHeight + 210.0f));
}

void AProceduralCityGenerator::EnsureRenderComponents()
{
    if (BuildingPalette.Num() == 0)
    {
        BuildingPalette.Add(FLinearColor(0.42f, 0.48f, 0.55f, 1.0f));
    }

    if (!GroundInstances)
    {
        GroundInstances = CreateInstancesComponent(TEXT("GroundInstances"), CubeMesh, GroundColor, true);
    }
    if (!RoadInstances)
    {
        RoadInstances = CreateInstancesComponent(TEXT("RoadInstances"), CubeMesh, RoadColor, true);
    }
    if (!RoadMarkingInstances)
    {
        RoadMarkingInstances = CreateInstancesComponent(TEXT("RoadMarkingInstances"), CubeMesh, RoadMarkingColor, false, false);
    }
    if (!SidewalkInstances)
    {
        SidewalkInstances = CreateInstancesComponent(TEXT("SidewalkInstances"), CubeMesh, SidewalkColor, true);
    }
    if (!RoofInstances)
    {
        RoofInstances = CreateInstancesComponent(TEXT("RoofInstances"), CubeMesh, RoofColor, true);
    }
    if (!DarkWindowInstances)
    {
        DarkWindowInstances = CreateInstancesComponent(TEXT("DarkWindowInstances"), CubeMesh, DarkWindowColor, false, false);
    }
    if (!LitWindowInstances)
    {
        LitWindowInstances = CreateInstancesComponent(TEXT("LitWindowInstances"), CubeMesh, LitWindowColor, false, false);
    }
    if (!ParkInstances)
    {
        ParkInstances = CreateInstancesComponent(TEXT("ParkInstances"), CubeMesh, ParkColor, false);
    }
    if (!TreeTrunkInstances)
    {
        TreeTrunkInstances = CreateInstancesComponent(TEXT("TreeTrunkInstances"), CylinderMesh, TreeTrunkColor, true);
    }
    if (!TreeCanopyInstances)
    {
        TreeCanopyInstances = CreateInstancesComponent(TEXT("TreeCanopyInstances"), ConeMesh, TreeCanopyColor, false);
    }
    if (!StreetPoleInstances)
    {
        StreetPoleInstances = CreateInstancesComponent(TEXT("StreetPoleInstances"), CylinderMesh, RoofColor, true);
    }
    if (!StreetLampInstances)
    {
        StreetLampInstances = CreateInstancesComponent(TEXT("StreetLampInstances"), CubeMesh, StreetLightColor, false, false);
    }
    if (!DetailInstances)
    {
        DetailInstances = CreateInstancesComponent(TEXT("DetailInstances"), CubeMesh, RoofColor, true);
    }

    EnsureBuildingComponents();
}

void AProceduralCityGenerator::EnsureBuildingComponents()
{
    bool bNeedsRebuild = BuildingInstances.Num() != BuildingPalette.Num();

    if (!bNeedsRebuild)
    {
        for (const UHierarchicalInstancedStaticMeshComponent* Component : BuildingInstances)
        {
            if (!IsValid(Component))
            {
                bNeedsRebuild = true;
                break;
            }
        }
    }

    if (!bNeedsRebuild)
    {
        return;
    }

    DestroyBuildingComponents();

    for (int32 Index = 0; Index < BuildingPalette.Num(); ++Index)
    {
        const FName ComponentName(*FString::Printf(TEXT("BuildingInstances_%02d"), Index));
        BuildingInstances.Add(CreateInstancesComponent(
            ComponentName,
            CubeMesh,
            BuildingPalette[Index],
            true));
    }
}

void AProceduralCityGenerator::DestroyBuildingComponents()
{
    for (UHierarchicalInstancedStaticMeshComponent* Component : BuildingInstances)
    {
        if (IsValid(Component))
        {
            RemoveInstanceComponent(Component);
            Component->DestroyComponent();
        }
    }

    BuildingInstances.Reset();
}

UHierarchicalInstancedStaticMeshComponent* AProceduralCityGenerator::CreateInstancesComponent(
    const FName ComponentName,
    UStaticMesh* Mesh,
    const FLinearColor& Color,
    const bool bEnableCollision,
    const bool bCastShadow)
{
    if (!Mesh)
    {
        return nullptr;
    }

    UHierarchicalInstancedStaticMeshComponent* Component =
        NewObject<UHierarchicalInstancedStaticMeshComponent>(this, ComponentName, RF_Transient);

    Component->SetupAttachment(SceneRoot);
    Component->SetStaticMesh(Mesh);
    Component->SetMobility(EComponentMobility::Movable);
    Component->SetGenerateOverlapEvents(false);
    Component->SetCastShadow(bCastShadow);
    Component->SetReceivesDecals(false);
    Component->SetCanEverAffectNavigation(bEnableCollision);

    if (bEnableCollision)
    {
        Component->SetCollisionProfileName(TEXT("BlockAll"));
        Component->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
    }
    else
    {
        Component->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    }

    if (UMaterialInstanceDynamic* Material = CreateColorMaterial(Color))
    {
        Component->SetMaterial(0, Material);
    }

    AddInstanceComponent(Component);
    Component->RegisterComponent();
    return Component;
}

UMaterialInstanceDynamic* AProceduralCityGenerator::CreateColorMaterial(const FLinearColor& Color)
{
    UMaterialInterface* ParentMaterial = BaseMaterial;
    if (!ParentMaterial)
    {
        ParentMaterial = UMaterial::GetDefaultMaterial(MD_Surface);
    }

    UMaterialInstanceDynamic* Material = UMaterialInstanceDynamic::Create(ParentMaterial, this);
    if (Material)
    {
        Material->SetVectorParameterValue(TEXT("Color"), Color);
        RuntimeMaterials.Add(Material);
    }

    return Material;
}

void AProceduralCityGenerator::AddBox(
    UHierarchicalInstancedStaticMeshComponent* Component,
    const FVector& Center,
    const FVector& Size,
    const FRotator& Rotation) const
{
    if (!Component)
    {
        return;
    }

    const FVector SafeSize(
        FMath::Max(1.0f, Size.X),
        FMath::Max(1.0f, Size.Y),
        FMath::Max(1.0f, Size.Z));

    Component->AddInstance(FTransform(Rotation, Center, SafeSize / 100.0f));
}

void AProceduralCityGenerator::AddCylinder(
    UHierarchicalInstancedStaticMeshComponent* Component,
    const FVector& Center,
    const float Diameter,
    const float Height,
    const FRotator& Rotation) const
{
    if (!Component)
    {
        return;
    }

    const FVector Scale(
        FMath::Max(1.0f, Diameter) / 100.0f,
        FMath::Max(1.0f, Diameter) / 100.0f,
        FMath::Max(1.0f, Height) / 100.0f);

    Component->AddInstance(FTransform(Rotation, Center, Scale));
}

void AProceduralCityGenerator::AddCone(
    UHierarchicalInstancedStaticMeshComponent* Component,
    const FVector& Center,
    const float Diameter,
    const float Height,
    const FRotator& Rotation) const
{
    if (!Component)
    {
        return;
    }

    const FVector Scale(
        FMath::Max(1.0f, Diameter) / 100.0f,
        FMath::Max(1.0f, Diameter) / 100.0f,
        FMath::Max(1.0f, Height) / 100.0f);

    Component->AddInstance(FTransform(Rotation, Center, Scale));
}

void AProceduralCityGenerator::GenerateRoadNetwork(
    const int32 BlocksX,
    const int32 BlocksY,
    const float BlockSize,
    const float RoadWidth,
    const float TotalX,
    const float TotalY)
{
    const float BaseZ = Settings.CityBaseZ;
    const float Pitch = BlockSize + RoadWidth;
    const float RoadCenterZ = BaseZ + 4.0f;
    const float MarkingZ = BaseZ + 9.0f;

    for (int32 RoadIndex = 0; RoadIndex <= BlocksX; ++RoadIndex)
    {
        const float X = -TotalX * 0.5f + RoadWidth * 0.5f + RoadIndex * Pitch;
        AddBox(RoadInstances, FVector(X, 0.0f, RoadCenterZ), FVector(RoadWidth, TotalY, 8.0f));

        for (float Y = -TotalY * 0.5f + 220.0f; Y < TotalY * 0.5f; Y += 540.0f)
        {
            AddBox(RoadMarkingInstances, FVector(X, Y, MarkingZ), FVector(16.0f, 230.0f, 2.0f));
        }
    }

    for (int32 RoadIndex = 0; RoadIndex <= BlocksY; ++RoadIndex)
    {
        const float Y = -TotalY * 0.5f + RoadWidth * 0.5f + RoadIndex * Pitch;
        AddBox(RoadInstances, FVector(0.0f, Y, RoadCenterZ), FVector(TotalX, RoadWidth, 8.0f));

        for (float X = -TotalX * 0.5f + 220.0f; X < TotalX * 0.5f; X += 540.0f)
        {
            AddBox(RoadMarkingInstances, FVector(X, Y, MarkingZ), FVector(230.0f, 16.0f, 2.0f));
        }
    }
}

void AProceduralCityGenerator::GenerateBlock(
    const int32 BlockX,
    const int32 BlockY,
    const FVector& BlockCenter,
    FRandomStream& Random,
    const float BlockSize,
    const float SidewalkTop)
{
    if (Random.FRand() < Settings.ParkChance)
    {
        GeneratePark(BlockCenter, BlockSize, Random, SidewalkTop);
        return;
    }

    const int32 LotsPerSide = Settings.LotsPerSide;
    const float Margin = FMath::Clamp(BlockSize * 0.075f, 100.0f, 260.0f);
    const float Gap = FMath::Clamp(BlockSize * 0.05f, 80.0f, 220.0f);
    const float UsableSize = BlockSize - Margin * 2.0f - Gap * (LotsPerSide - 1);
    const float LotSize = UsableSize / LotsPerSide;

    if (LotSize < 120.0f)
    {
        return;
    }

    const float FirstLotOffset = -BlockSize * 0.5f + Margin + LotSize * 0.5f;

    for (int32 LotY = 0; LotY < LotsPerSide; ++LotY)
    {
        for (int32 LotX = 0; LotX < LotsPerSide; ++LotX)
        {
            if (Random.FRand() > Settings.BuildingDensity)
            {
                continue;
            }

            const FVector LotCenter(
                BlockCenter.X + FirstLotOffset + LotX * (LotSize + Gap),
                BlockCenter.Y + FirstLotOffset + LotY * (LotSize + Gap),
                0.0f);

            GenerateBuilding(LotCenter, LotSize, Random, SidewalkTop);
        }
    }

    // A small amount of street clutter makes non-park blocks less uniform.
    if (((BlockX * 7 + BlockY * 13 + Seed) & 3) == 0)
    {
        const FVector BenchCenter(
            BlockCenter.X + BlockSize * 0.34f,
            BlockCenter.Y - BlockSize * 0.38f,
            SidewalkTop + 23.0f);
        AddBox(DetailInstances, BenchCenter, FVector(170.0f, 50.0f, 46.0f));
    }
}

void AProceduralCityGenerator::GenerateBuilding(
    const FVector& LotCenter,
    const float LotSize,
    FRandomStream& Random,
    const float SidewalkTop)
{
    if (BuildingInstances.Num() == 0)
    {
        return;
    }

    const float Width = LotSize * Random.FRandRange(0.66f, 0.94f);
    const float Depth = LotSize * Random.FRandRange(0.66f, 0.94f);
    const int32 Floors = Random.RandRange(Settings.MinFloors, Settings.MaxFloors);
    const float Height = Floors * Settings.FloorHeight;
    const FVector BuildingCenter(LotCenter.X, LotCenter.Y, SidewalkTop + Height * 0.5f);

    const int32 PaletteIndex = Random.RandRange(0, BuildingInstances.Num() - 1);
    AddBox(BuildingInstances[PaletteIndex], BuildingCenter, FVector(Width, Depth, Height));

    const float RoofUnitHeight = Random.FRandRange(90.0f, 230.0f);
    const float RoofUnitWidth = Width * Random.FRandRange(0.22f, 0.50f);
    const float RoofUnitDepth = Depth * Random.FRandRange(0.22f, 0.50f);
    const FVector RoofCenter(
        LotCenter.X + Random.FRandRange(-Width * 0.12f, Width * 0.12f),
        LotCenter.Y + Random.FRandRange(-Depth * 0.12f, Depth * 0.12f),
        SidewalkTop + Height + RoofUnitHeight * 0.5f);

    AddBox(RoofInstances, RoofCenter, FVector(RoofUnitWidth, RoofUnitDepth, RoofUnitHeight));

    if (Settings.bGenerateWindows && Floors > 1)
    {
        GenerateWindows(BuildingCenter, Width, Depth, Floors, SidewalkTop, Random);
    }

    ++LastStats.BuildingCount;
}

void AProceduralCityGenerator::GenerateWindows(
    const FVector& BuildingCenter,
    const float Width,
    const float Depth,
    const int32 Floors,
    const float BuildingBottom,
    FRandomStream& Random)
{
    const int32 Stride = FMath::Max(1, Settings.WindowFloorStride);
    const float PanelHeight = Settings.FloorHeight * 0.46f;
    const float Thickness = 7.0f;
    const float EdgeX = FMath::Clamp(Width * 0.12f, 55.0f, 130.0f);
    const float EdgeY = FMath::Clamp(Depth * 0.12f, 55.0f, 130.0f);
    const int32 FrontCount = FMath::Clamp(FMath::FloorToInt(Width / 245.0f), 2, 8);
    const int32 SideCount = FMath::Clamp(FMath::FloorToInt(Depth / 245.0f), 2, 8);
    const float FrontStep = (Width - EdgeX * 2.0f) / FrontCount;
    const float SideStep = (Depth - EdgeY * 2.0f) / SideCount;
    const float FrontPanelWidth = FrontStep * 0.62f;
    const float SidePanelWidth = SideStep * 0.62f;

    auto AddWindowPanel = [this, &Random](const FVector& Center, const FVector& Size)
    {
        if (LastStats.WindowPanelCount >= Settings.MaxWindowPanels)
        {
            return;
        }

        UHierarchicalInstancedStaticMeshComponent* Target =
            Random.FRand() < 0.18f ? LitWindowInstances : DarkWindowInstances;

        AddBox(Target, Center, Size);
        ++LastStats.WindowPanelCount;
    };

    for (int32 Floor = 1; Floor < Floors; Floor += Stride)
    {
        const float Z = BuildingBottom + (Floor + 0.54f) * Settings.FloorHeight;

        for (int32 WindowIndex = 0; WindowIndex < FrontCount; ++WindowIndex)
        {
            const float X = BuildingCenter.X - Width * 0.5f + EdgeX + (WindowIndex + 0.5f) * FrontStep;
            AddWindowPanel(
                FVector(X, BuildingCenter.Y + Depth * 0.5f + Thickness * 0.5f, Z),
                FVector(FrontPanelWidth, Thickness, PanelHeight));
            AddWindowPanel(
                FVector(X, BuildingCenter.Y - Depth * 0.5f - Thickness * 0.5f, Z),
                FVector(FrontPanelWidth, Thickness, PanelHeight));
        }

        for (int32 WindowIndex = 0; WindowIndex < SideCount; ++WindowIndex)
        {
            const float Y = BuildingCenter.Y - Depth * 0.5f + EdgeY + (WindowIndex + 0.5f) * SideStep;
            AddWindowPanel(
                FVector(BuildingCenter.X + Width * 0.5f + Thickness * 0.5f, Y, Z),
                FVector(Thickness, SidePanelWidth, PanelHeight));
            AddWindowPanel(
                FVector(BuildingCenter.X - Width * 0.5f - Thickness * 0.5f, Y, Z),
                FVector(Thickness, SidePanelWidth, PanelHeight));
        }
    }
}

void AProceduralCityGenerator::GeneratePark(
    const FVector& BlockCenter,
    const float BlockSize,
    FRandomStream& Random,
    const float SidewalkTop)
{
    AddBox(
        ParkInstances,
        FVector(BlockCenter.X, BlockCenter.Y, SidewalkTop + 3.0f),
        FVector(BlockSize - 150.0f, BlockSize - 150.0f, 6.0f));

    // Two simple paths provide readable low-poly park structure.
    AddBox(
        SidewalkInstances,
        FVector(BlockCenter.X, BlockCenter.Y, SidewalkTop + 6.0f),
        FVector(BlockSize - 180.0f, 120.0f, 8.0f));
    AddBox(
        SidewalkInstances,
        FVector(BlockCenter.X, BlockCenter.Y, SidewalkTop + 6.0f),
        FVector(120.0f, BlockSize - 180.0f, 8.0f));

    const int32 TreeCount = Random.RandRange(Settings.MinTreesPerPark, Settings.MaxTreesPerPark);
    const float TreeRange = BlockSize * 0.5f - 190.0f;

    for (int32 TreeIndex = 0; TreeIndex < TreeCount; ++TreeIndex)
    {
        FVector2D Offset(Random.FRandRange(-TreeRange, TreeRange), Random.FRandRange(-TreeRange, TreeRange));

        // Keep the central paths mostly clear.
        if (FMath::Abs(Offset.X) < 120.0f)
        {
            Offset.X += Offset.X < 0.0f ? -160.0f : 160.0f;
        }
        if (FMath::Abs(Offset.Y) < 120.0f)
        {
            Offset.Y += Offset.Y < 0.0f ? -160.0f : 160.0f;
        }

        const float TrunkHeight = Random.FRandRange(180.0f, 260.0f);
        const float TrunkDiameter = Random.FRandRange(26.0f, 42.0f);
        const float CanopyHeight = Random.FRandRange(250.0f, 410.0f);
        const float CanopyDiameter = Random.FRandRange(180.0f, 310.0f);
        const FVector TreeBase(BlockCenter.X + Offset.X, BlockCenter.Y + Offset.Y, SidewalkTop);

        AddCylinder(
            TreeTrunkInstances,
            TreeBase + FVector(0.0f, 0.0f, TrunkHeight * 0.5f),
            TrunkDiameter,
            TrunkHeight);
        AddCone(
            TreeCanopyInstances,
            TreeBase + FVector(0.0f, 0.0f, TrunkHeight + CanopyHeight * 0.42f),
            CanopyDiameter,
            CanopyHeight);

        ++LastStats.TreeCount;
    }

    const int32 BenchCount = Random.RandRange(2, 4);
    for (int32 BenchIndex = 0; BenchIndex < BenchCount; ++BenchIndex)
    {
        const bool bHorizontal = (BenchIndex & 1) == 0;
        const FVector BenchCenter(
            BlockCenter.X + (bHorizontal ? Random.FRandRange(-BlockSize * 0.32f, BlockSize * 0.32f) : 170.0f),
            BlockCenter.Y + (bHorizontal ? -170.0f : Random.FRandRange(-BlockSize * 0.32f, BlockSize * 0.32f)),
            SidewalkTop + 23.0f);

        AddBox(
            DetailInstances,
            BenchCenter,
            bHorizontal ? FVector(180.0f, 52.0f, 46.0f) : FVector(52.0f, 180.0f, 46.0f));
    }

    const int32 PropCount = Random.RandRange(0, Settings.MaxPhysicsPropsPerPark);
    for (int32 PropIndex = 0; PropIndex < PropCount; ++PropIndex)
    {
        const FVector Size(
            Random.FRandRange(55.0f, 105.0f),
            Random.FRandRange(55.0f, 105.0f),
            Random.FRandRange(55.0f, 115.0f));
        const FVector Location(
            BlockCenter.X + Random.FRandRange(-BlockSize * 0.30f, BlockSize * 0.30f),
            BlockCenter.Y + Random.FRandRange(-BlockSize * 0.30f, BlockSize * 0.30f),
            SidewalkTop + Size.Z * 0.5f + 8.0f);
        const FLinearColor Color(
            Random.FRandRange(0.32f, 0.82f),
            Random.FRandRange(0.16f, 0.55f),
            Random.FRandRange(0.08f, 0.32f),
            1.0f);

        SpawnPhysicsProp(Location, Size, Color, Random.FRandRange(16.0f, 42.0f));
    }

    ++LastStats.ParkCount;
}

void AProceduralCityGenerator::GenerateStreetLights(
    const FVector& BlockCenter,
    const int32 BlockX,
    const int32 BlockY,
    const float BlockSize,
    const float SidewalkTop)
{
    const float CornerOffset = BlockSize * 0.5f - 78.0f;
    const float PoleHeight = 335.0f;
    const FVector2D CornerSigns[4] =
    {
        FVector2D(-1.0f, -1.0f),
        FVector2D( 1.0f, -1.0f),
        FVector2D(-1.0f,  1.0f),
        FVector2D( 1.0f,  1.0f)
    };

    for (int32 CornerIndex = 0; CornerIndex < 4; ++CornerIndex)
    {
        if (((BlockX + BlockY + CornerIndex) & 1) != 0)
        {
            continue;
        }

        const FVector PoleBase(
            BlockCenter.X + CornerSigns[CornerIndex].X * CornerOffset,
            BlockCenter.Y + CornerSigns[CornerIndex].Y * CornerOffset,
            SidewalkTop);

        AddCylinder(
            StreetPoleInstances,
            PoleBase + FVector(0.0f, 0.0f, PoleHeight * 0.5f),
            17.0f,
            PoleHeight);
        AddBox(
            StreetLampInstances,
            PoleBase + FVector(0.0f, 0.0f, PoleHeight + 8.0f),
            FVector(52.0f, 52.0f, 24.0f));
    }
}

void AProceduralCityGenerator::SpawnPhysicsProp(
    const FVector& LocalLocation,
    const FVector& Size,
    const FLinearColor& Color,
    const float MassKg,
    const FRotator& Rotation)
{
    UWorld* World = GetWorld();
    if (!World || !World->IsGameWorld() || !PhysicsPropClass)
    {
        return;
    }

    FActorSpawnParameters SpawnParameters;
    SpawnParameters.Owner = this;
    SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

    const FVector WorldLocation = GetActorTransform().TransformPosition(LocalLocation);
    const FQuat WorldRotation = GetActorQuat() * Rotation.Quaternion();

    ACityPhysicsProp* Prop = World->SpawnActor<ACityPhysicsProp>(
        PhysicsPropClass,
        WorldLocation,
        WorldRotation.Rotator(),
        SpawnParameters);

    if (!Prop)
    {
        return;
    }

    Prop->ConfigureProp(Size, Color, MassKg);
    SpawnedPhysicsProps.Add(Prop);
    ++LastStats.PhysicsPropCount;
}

void AProceduralCityGenerator::SpawnStarterPhysicsStack(const float BaseZ)
{
    const FVector Size(82.0f, 82.0f, 82.0f);
    const FLinearColor Colors[3] =
    {
        FLinearColor(0.76f, 0.25f, 0.10f, 1.0f),
        FLinearColor(0.16f, 0.48f, 0.68f, 1.0f),
        FLinearColor(0.82f, 0.58f, 0.12f, 1.0f)
    };

    for (int32 Index = 0; Index < 3; ++Index)
    {
        SpawnPhysicsProp(
            FVector(520.0f + Index * 92.0f, 0.0f, BaseZ + Size.Z * 0.5f + 10.0f),
            Size,
            Colors[Index % 3],
            24.0f);
    }

    for (int32 Index = 0; Index < 2; ++Index)
    {
        SpawnPhysicsProp(
            FVector(566.0f + Index * 92.0f, 0.0f, BaseZ + Size.Z * 1.5f + 14.0f),
            Size,
            Colors[(Index + 1) % 3],
            24.0f);
    }

    SpawnPhysicsProp(
        FVector(612.0f, 0.0f, BaseZ + Size.Z * 2.5f + 18.0f),
        Size,
        Colors[2],
        24.0f);
}

FCityGenerationSettings AProceduralCityGenerator::SanitizeSettings(const FCityGenerationSettings& InSettings)
{
    FCityGenerationSettings Out = InSettings;

    Out.BlocksX = FMath::Clamp(Out.BlocksX, 2, 16);
    Out.BlocksY = FMath::Clamp(Out.BlocksY, 2, 16);
    Out.BlockSize = FMath::Clamp(Out.BlockSize, 1200.0f, 6000.0f);
    Out.RoadWidth = FMath::Clamp(Out.RoadWidth, 350.0f, 1600.0f);
    Out.LotsPerSide = FMath::Clamp(Out.LotsPerSide, 1, 4);
    Out.SidewalkHeight = FMath::Clamp(Out.SidewalkHeight, 20.0f, 100.0f);
    Out.BuildingDensity = FMath::Clamp(Out.BuildingDensity, 0.0f, 1.0f);
    Out.ParkChance = FMath::Clamp(Out.ParkChance, 0.0f, 0.8f);
    Out.MinFloors = FMath::Clamp(Out.MinFloors, 1, 80);
    Out.MaxFloors = FMath::Clamp(Out.MaxFloors, Out.MinFloors, 120);
    Out.FloorHeight = FMath::Clamp(Out.FloorHeight, 200.0f, 600.0f);
    Out.WindowFloorStride = FMath::Clamp(Out.WindowFloorStride, 1, 8);
    Out.MaxWindowPanels = FMath::Clamp(Out.MaxWindowPanels, 0, 30000);
    Out.MinTreesPerPark = FMath::Clamp(Out.MinTreesPerPark, 0, 30);
    Out.MaxTreesPerPark = FMath::Clamp(Out.MaxTreesPerPark, Out.MinTreesPerPark, 60);
    Out.MaxPhysicsPropsPerPark = FMath::Clamp(Out.MaxPhysicsPropsPerPark, 0, 30);

    return Out;
}
