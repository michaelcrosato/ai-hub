#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CityGenerationTypes.h"
#include "ProceduralCityGenerator.generated.h"

class ACityPhysicsProp;
class UHierarchicalInstancedStaticMeshComponent;
class UMaterialInstanceDynamic;
class UMaterialInterface;
class USceneComponent;
class UStaticMesh;

UCLASS(Blueprintable)
class PROCEDURALCITYDEMO_API AProceduralCityGenerator : public AActor
{
    GENERATED_BODY()

public:
    AProceduralCityGenerator();

    virtual void BeginPlay() override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Generation", meta=(ShowOnlyInnerProperties))
    FCityGenerationSettings Settings;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Generation")
    int32 Seed = 1337;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Generation")
    bool bGenerateOnBeginPlay = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Generation")
    bool bUseRandomSeedOnBeginPlay = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    TArray<FLinearColor> BuildingPalette;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    FLinearColor GroundColor = FLinearColor(0.16f, 0.24f, 0.14f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    FLinearColor RoadColor = FLinearColor(0.055f, 0.065f, 0.075f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    FLinearColor RoadMarkingColor = FLinearColor(0.92f, 0.72f, 0.18f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    FLinearColor SidewalkColor = FLinearColor(0.46f, 0.47f, 0.49f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    FLinearColor RoofColor = FLinearColor(0.12f, 0.14f, 0.16f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    FLinearColor DarkWindowColor = FLinearColor(0.025f, 0.075f, 0.11f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    FLinearColor LitWindowColor = FLinearColor(0.36f, 0.78f, 0.92f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    FLinearColor ParkColor = FLinearColor(0.12f, 0.38f, 0.15f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    FLinearColor TreeTrunkColor = FLinearColor(0.24f, 0.12f, 0.055f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    FLinearColor TreeCanopyColor = FLinearColor(0.055f, 0.42f, 0.12f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Style")
    FLinearColor StreetLightColor = FLinearColor(0.9f, 0.76f, 0.34f, 1.0f);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="City|Physics")
    TSubclassOf<ACityPhysicsProp> PhysicsPropClass;

    UPROPERTY(BlueprintReadOnly, Transient, Category="City|Generation")
    FCityGenerationStats LastStats;

    UFUNCTION(BlueprintCallable, CallInEditor, Category="City|Generation")
    void GenerateCity();

    UFUNCTION(BlueprintCallable, CallInEditor, Category="City|Generation")
    void GenerateNewSeed();

    UFUNCTION(BlueprintCallable, CallInEditor, Category="City|Generation")
    void ClearCity();

    UFUNCTION(BlueprintPure, Category="City|Generation")
    FVector GetSuggestedPlayerStart() const;

    UFUNCTION(BlueprintImplementableEvent, Category="City|Generation", meta=(DisplayName="On City Generated"))
    void ReceiveCityGenerated(FCityGenerationStats Stats);

private:
    UPROPERTY(VisibleAnywhere, Category="City")
    TObjectPtr<USceneComponent> SceneRoot;

    UPROPERTY(Transient)
    TObjectPtr<UStaticMesh> CubeMesh;

    UPROPERTY(Transient)
    TObjectPtr<UStaticMesh> CylinderMesh;

    UPROPERTY(Transient)
    TObjectPtr<UStaticMesh> ConeMesh;

    UPROPERTY(Transient)
    TObjectPtr<UMaterialInterface> BaseMaterial;

    UPROPERTY(Transient)
    TArray<TObjectPtr<UMaterialInstanceDynamic>> RuntimeMaterials;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> GroundInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> RoadInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> RoadMarkingInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> SidewalkInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> RoofInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> DarkWindowInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> LitWindowInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> ParkInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> TreeTrunkInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> TreeCanopyInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> StreetPoleInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> StreetLampInstances;

    UPROPERTY(Transient)
    TObjectPtr<UHierarchicalInstancedStaticMeshComponent> DetailInstances;

    UPROPERTY(Transient)
    TArray<TObjectPtr<UHierarchicalInstancedStaticMeshComponent>> BuildingInstances;

    UPROPERTY(Transient)
    TArray<TObjectPtr<ACityPhysicsProp>> SpawnedPhysicsProps;

    void EnsureRenderComponents();
    void EnsureBuildingComponents();
    void DestroyBuildingComponents();

    UHierarchicalInstancedStaticMeshComponent* CreateInstancesComponent(
        FName ComponentName,
        UStaticMesh* Mesh,
        const FLinearColor& Color,
        bool bEnableCollision,
        bool bCastShadow = true);

    UMaterialInstanceDynamic* CreateColorMaterial(const FLinearColor& Color);

    void AddBox(
        UHierarchicalInstancedStaticMeshComponent* Component,
        const FVector& Center,
        const FVector& Size,
        const FRotator& Rotation = FRotator::ZeroRotator) const;

    void AddCylinder(
        UHierarchicalInstancedStaticMeshComponent* Component,
        const FVector& Center,
        float Diameter,
        float Height,
        const FRotator& Rotation = FRotator::ZeroRotator) const;

    void AddCone(
        UHierarchicalInstancedStaticMeshComponent* Component,
        const FVector& Center,
        float Diameter,
        float Height,
        const FRotator& Rotation = FRotator::ZeroRotator) const;

    void GenerateRoadNetwork(
        int32 BlocksX,
        int32 BlocksY,
        float BlockSize,
        float RoadWidth,
        float TotalX,
        float TotalY);

    void GenerateBlock(
        int32 BlockX,
        int32 BlockY,
        const FVector& BlockCenter,
        FRandomStream& Random,
        float BlockSize,
        float SidewalkTop);

    void GenerateBuilding(
        const FVector& LotCenter,
        float LotSize,
        FRandomStream& Random,
        float SidewalkTop);

    void GenerateWindows(
        const FVector& BuildingCenter,
        float Width,
        float Depth,
        int32 Floors,
        float BuildingBottom,
        FRandomStream& Random);

    void GeneratePark(
        const FVector& BlockCenter,
        float BlockSize,
        FRandomStream& Random,
        float SidewalkTop);

    void GenerateStreetLights(
        const FVector& BlockCenter,
        int32 BlockX,
        int32 BlockY,
        float BlockSize,
        float SidewalkTop);

    void SpawnPhysicsProp(
        const FVector& LocalLocation,
        const FVector& Size,
        const FLinearColor& Color,
        float MassKg,
        const FRotator& Rotation = FRotator::ZeroRotator);

    void SpawnStarterPhysicsStack(float BaseZ);

    static FCityGenerationSettings SanitizeSettings(const FCityGenerationSettings& InSettings);
};
