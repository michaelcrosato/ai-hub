#include "CityPhysicsProp.h"

#include "Components/StaticMeshComponent.h"
#include "Materials/Material.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "UObject/ConstructorHelpers.h"

ACityPhysicsProp::ACityPhysicsProp()
{
    PrimaryActorTick.bCanEverTick = false;

    Mesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Mesh"));
    SetRootComponent(Mesh);

    static ConstructorHelpers::FObjectFinder<UStaticMesh> CubeFinder(TEXT("/Engine/BasicShapes/Cube.Cube"));
    if (CubeFinder.Succeeded())
    {
        Mesh->SetStaticMesh(CubeFinder.Object);
    }

    static ConstructorHelpers::FObjectFinder<UMaterialInterface> MaterialFinder(TEXT("/Engine/BasicShapes/BasicShapeMaterial.BasicShapeMaterial"));
    BaseMaterial = MaterialFinder.Succeeded()
        ? MaterialFinder.Object
        : UMaterial::GetDefaultMaterial(MD_Surface);

    Mesh->SetMobility(EComponentMobility::Movable);
    Mesh->SetCollisionProfileName(TEXT("PhysicsActor"));
    Mesh->SetGenerateOverlapEvents(false);
    Mesh->SetSimulatePhysics(true);
    Mesh->SetEnableGravity(true);
    Mesh->SetLinearDamping(0.25f);
    Mesh->SetAngularDamping(0.45f);
    Mesh->SetUseCCD(true);
}

void ACityPhysicsProp::ConfigureProp(const FVector& SizeCm, const FLinearColor& Color, const float InMassKg)
{
    const FVector SafeSize(
        FMath::Max(10.0f, SizeCm.X),
        FMath::Max(10.0f, SizeCm.Y),
        FMath::Max(10.0f, SizeCm.Z));

    PropColor = Color;
    MassKg = FMath::Max(1.0f, InMassKg);

    Mesh->SetWorldScale3D(SafeSize / 100.0f);
    Mesh->SetMassOverrideInKg(NAME_None, MassKg, true);

    RuntimeMaterial = UMaterialInstanceDynamic::Create(BaseMaterial, this);
    if (RuntimeMaterial)
    {
        RuntimeMaterial->SetVectorParameterValue(TEXT("Color"), PropColor);
        Mesh->SetMaterial(0, RuntimeMaterial);
    }
}

void ACityPhysicsProp::ApplyPush(const FVector& Impulse, const FVector& WorldLocation)
{
    if (!Mesh || !Mesh->IsSimulatingPhysics())
    {
        return;
    }

    Mesh->AddImpulseAtLocation(Impulse, WorldLocation);
    ReceivePushed(Impulse, WorldLocation);
}
