#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "CityPhysicsProp.generated.h"

class UMaterialInstanceDynamic;
class UMaterialInterface;
class UStaticMeshComponent;

UCLASS(Blueprintable)
class PROCEDURALCITYDEMO_API ACityPhysicsProp : public AActor
{
    GENERATED_BODY()

public:
    ACityPhysicsProp();

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Physics")
    TObjectPtr<UStaticMeshComponent> Mesh;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Physics", meta=(ClampMin="1.0", ClampMax="500.0", Units="kg"))
    float MassKg = 28.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Style")
    FLinearColor PropColor = FLinearColor(0.72f, 0.28f, 0.12f, 1.0f);

    UFUNCTION(BlueprintCallable, Category="Physics")
    void ConfigureProp(const FVector& SizeCm, const FLinearColor& Color, float InMassKg);

    UFUNCTION(BlueprintCallable, Category="Physics")
    void ApplyPush(const FVector& Impulse, const FVector& WorldLocation);

    UFUNCTION(BlueprintImplementableEvent, Category="Physics", meta=(DisplayName="On Pushed"))
    void ReceivePushed(const FVector& Impulse, const FVector& WorldLocation);

private:
    UPROPERTY(Transient)
    TObjectPtr<UMaterialInterface> BaseMaterial;

    UPROPERTY(Transient)
    TObjectPtr<UMaterialInstanceDynamic> RuntimeMaterial;
};
