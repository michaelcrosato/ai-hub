using UnrealBuildTool;
using System.Collections.Generic;

public class ProceduralCityDemoEditorTarget : TargetRules
{
    public ProceduralCityDemoEditorTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Editor;
        DefaultBuildSettings = BuildSettingsVersion.Latest;
        IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
        ExtraModuleNames.Add("ProceduralCityDemo");
    }
}
