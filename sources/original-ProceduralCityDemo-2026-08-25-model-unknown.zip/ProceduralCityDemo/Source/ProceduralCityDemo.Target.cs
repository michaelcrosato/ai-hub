using UnrealBuildTool;
using System.Collections.Generic;

public class ProceduralCityDemoTarget : TargetRules
{
    public ProceduralCityDemoTarget(TargetInfo Target) : base(Target)
    {
        Type = TargetType.Game;
        DefaultBuildSettings = BuildSettingsVersion.Latest;
        IncludeOrderVersion = EngineIncludeOrderVersion.Latest;
        ExtraModuleNames.Add("ProceduralCityDemo");
    }
}
