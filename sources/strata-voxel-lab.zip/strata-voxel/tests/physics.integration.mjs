// This suite needs `npm install`. It uses the real Rapier WASM solver.
import test, { before } from 'node:test';
import assert from 'node:assert/strict';
import RAPIER from '@dimforge/rapier3d-compat';
import { mergeColliders } from '../src/voxel/colliders.js';
import { padVolume } from '../src/voxel/mesher.js';
import { PALETTE } from '../src/voxel/palette.js';
before(async()=>{await RAPIER.init();});

test('A falling rigid body lands on a fixed surface and can sleep', () => {
  const world=new RAPIER.World({x:0,y:-9.81,z:0}); world.timestep=1/60;
  world.createCollider(RAPIER.ColliderDesc.cuboid(10,.1,10).setTranslation(0,-.1,0));
  const body=world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(0,4,0).setCcdEnabled(true));
  world.createCollider(RAPIER.ColliderDesc.cuboid(.25,.25,.25).setDensity(2200).setFriction(.8),body);
  for(let i=0;i<600;i++) world.step();
  assert.ok(Math.abs(body.translation().y-.25)<.025); assert.ok(body.isSleeping()); world.free();
});
test('CCD prevents a fast small body from crossing a thin fixed wall', () => {
  const world=new RAPIER.World({x:0,y:0,z:0}); world.timestep=1/60;
  world.createCollider(RAPIER.ColliderDesc.cuboid(.0625,2,2));
  const body=world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(-2,0,0).setLinvel(180,0,0).setCcdEnabled(true));
  world.createCollider(RAPIER.ColliderDesc.cuboid(.0625,.0625,.0625).setRestitution(0),body);
  for(let i=0;i<8;i++) world.step(); assert.ok(body.translation().x<.1); world.free();
});
test('Exact compound voxel colliders conserve computed physical mass', () => {
  const data=new Uint8Array([2,2,0,8,8,8,3,3]), dims=[2,2,2], s=.125;
  const boxes=mergeColliders({data:padVolume(data,dims),dims}); const world=new RAPIER.World({x:0,y:0,z:0});
  const body=world.createRigidBody(RAPIER.RigidBodyDesc.dynamic());
  for(const b of boxes) world.createCollider(RAPIER.ColliderDesc.cuboid(b.w*s/2,b.h*s/2,b.d*s/2)
    .setTranslation((b.x+b.w/2)*s,(b.y+b.h/2)*s,(b.z+b.d/2)*s).setDensity(PALETTE[b.material].density),body);
  const expected=data.reduce((sum,m)=>sum+(m?PALETTE[m].density*s**3:0),0);
  assert.ok(Math.abs(body.mass()-expected)<.001); world.free();
});
test('Contact-force events are available without changing the world during the callback', () => {
  const world=new RAPIER.World({x:0,y:-9.81,z:0}), events=new RAPIER.EventQueue(true); let count=0;
  world.createCollider(RAPIER.ColliderDesc.cuboid(4,.1,4).setTranslation(0,-.1,0));
  const body=world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(0,2,0));
  world.createCollider(RAPIER.ColliderDesc.cuboid(.25,.25,.25).setDensity(1000)
    .setActiveEvents(RAPIER.ActiveEvents.CONTACT_FORCE_EVENTS).setContactForceEventThreshold(1),body);
  for(let i=0;i<180;i++) {world.step(events); events.drainContactForceEvents(e=>{assert.ok(Number.isFinite(e.totalForceMagnitude()));count++;});}
  assert.ok(count>0); events.free(); world.free();
});
