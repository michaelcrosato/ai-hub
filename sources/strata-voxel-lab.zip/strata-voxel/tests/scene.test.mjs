import test from 'node:test';
import assert from 'node:assert/strict';
import { VoxelWorld } from '../src/voxel/world.js';
import { createGarden } from '../src/scene/garden.js';
import { findUnsupported } from '../src/voxel/support.js';
import { meshVolume } from '../src/voxel/mesher.js';
import { mergeColliders } from '../src/voxel/colliders.js';

test('The full test garden starts with no detached cells', () => {
  const w=new VoxelWorld(); createGarden(w); assert.equal(w.count,207735); assert.equal(w.chunks.size,161);
  assert.equal(findUnsupported(w.snapshotDense()).length,0);
});
test('The seeded garden has a stable mesh and collision budget', () => {
  const w=new VoxelWorld(); createGarden(w); let quads=0, colliders=0;
  for(const key of w.chunks.keys()) { const p=w.snapshotChunk(key); quads+=meshVolume(p).quads; colliders+=mergeColliders({...p,preserveMaterials:false}).length; }
  assert.equal(quads*2,35060); assert.equal(colliders,1337);
});
test('Cutting both arch supports detaches the upper arch across chunk boundaries', () => {
  const w=new VoxelWorld(); createGarden(w); w.fill([-24,6,-19],[21,9,-7],0);
  const detached=findUnsupported(w.snapshotDense()); assert.ok(detached.reduce((n,f)=>n+f.count,0)>1000);
});
