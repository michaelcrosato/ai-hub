import test from 'node:test';
import assert from 'node:assert/strict';
import { VoxelWorld, index3, keyOf } from '../src/voxel/world.js';
import { meshVolume, padVolume } from '../src/voxel/mesher.js';
import { mergeColliders } from '../src/voxel/colliders.js';
import { findUnsupported } from '../src/voxel/support.js';
import { raycastVoxels } from '../src/voxel/raycast.js';
import { carveSphere, removeFragment } from '../src/voxel/edit.js';
import { FixedStepClock } from '../src/engine/clock.js';
import { runJob, transferBuffers } from '../src/workers/jobs.js';
import { PALETTE } from '../src/voxel/palette.js';

const input = (data, dims, size = 1) => ({ data: padVolume(data, dims), dims, size });
function triangleArea(g) {
  let area = 0;
  for (let i = 0; i < g.indices.length; i += 3) {
    const vertices = [...g.indices.slice(i, i + 3)].map(j => [...g.positions.slice(j * 3, j * 3 + 3)]);
    const [a, b, c] = vertices, u = b.map((v, d) => v - a[d]), v = c.map((value, d) => value - a[d]);
    const cross = [u[1] * v[2] - u[2] * v[1], u[2] * v[0] - u[0] * v[2], u[0] * v[1] - u[1] * v[0]];
    area += Math.hypot(...cross) / 2;
    const normal = [...g.normals.slice(g.indices[i] * 3, g.indices[i] * 3 + 3)];
    assert.ok(cross.reduce((sum, n, d) => sum + n * normal[d], 0) > 0, 'Triangle winding must face out.');
  }
  return area;
}
function surfaceArea(data, dims) {
  const [nx, ny, nz] = dims; let faces = 0;
  const get = (x, y, z) => x < 0 || y < 0 || z < 0 || x >= nx || y >= ny || z >= nz ? 0 : data[index3(x, y, z, nx, ny)];
  for (let z = 0; z < nz; z++) for (let y = 0; y < ny; y++) for (let x = 0; x < nx; x++) {
    if (!get(x, y, z)) continue;
    for (const d of [[1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]]) if (!get(x+d[0], y+d[1], z+d[2])) faces++;
  }
  return faces;
}
function verifyBoxCover(data, dims, preserveMaterials = true) {
  const [nx, ny, nz] = dims, coverage = new Uint8Array(data.length), boxes = mergeColliders({ ...input(data, dims), preserveMaterials });
  for (const b of boxes) for (let z = b.z; z < b.z + b.d; z++) for (let y = b.y; y < b.y + b.h; y++) for (let x = b.x; x < b.x + b.w; x++) {
    assert.ok(x < nx && y < ny && z < nz); const i = index3(x, y, z, nx, ny);
    assert.ok(data[i], 'A collider must not cover air.'); assert.equal(coverage[i]++, 0, 'Colliders must not overlap.');
    if (preserveMaterials) assert.equal(data[i], b.material);
  }
  data.forEach((m, i) => assert.equal(coverage[i], Number(m !== 0)));
  return boxes;
}

test('Sparse storage handles negative chunk coordinates and material changes', () => {
  const w = new VoxelWorld(); w.set(-1,-17,16,2); w.set(0,0,0,3);
  assert.equal(w.get(-1,-17,16),2); assert.equal(w.count,2); w.set(-1,-17,16,4); assert.equal(w.count,2);
  w.set(-1,-17,16,0); assert.equal(w.get(-1,-17,16),0); assert.equal(w.count,1);
  assert.throws(() => w.set(0.5,0,0,2), RangeError);
});
test('Interior edits invalidate only their chunk', () => {
  const w = new VoxelWorld(); w.set(2,2,2,2); w.set(17,2,2,2); w.dirty.clear(); w.set(3,3,3,2);
  assert.deepEqual([...w.dirty], ['0,0,0']);
});
test('Corner edits invalidate all eight occupied halo neighbours', () => {
  const w = new VoxelWorld();
  for (let z=0;z<2;z++) for(let y=0;y<2;y++) for(let x=0;x<2;x++) w.set(x*16+1,y*16+1,z*16+1,2);
  w.dirty.clear(); w.set(15,15,15,3); assert.equal(w.dirty.size,8);
});
test('Empty mesh has no faces or collision boxes', () => {
  const p = input(new Uint8Array(8), [2,2,2]); assert.equal(meshVolume(p).quads,0); assert.equal(mergeColliders(p).length,0);
});
test('A solid 2-cube merges to six outward quads and one collider', () => {
  const p = input(new Uint8Array(8).fill(2), [2,2,2]), g = meshVolume(p);
  assert.equal(g.quads,6); assert.equal(triangleArea(g),24); assert.equal(mergeColliders(p).length,1);
  assert.ok(g.ao.every(v => v === 1));
});
test('Surface vertices use the configured physical voxel size', () => {
  const g = meshVolume(input(new Uint8Array([2]),[1,1,1],0.125)); assert.equal(Math.max(...g.positions),0.125);
  assert.equal(triangleArea(g),6*0.125**2);
});
test('Chunk halo removes the shared face across a chunk boundary', () => {
  const w = new VoxelWorld(); w.set(15,1,1,2); w.set(16,1,1,2);
  assert.equal(meshVolume(w.snapshotChunk('0,0,0')).quads,5); assert.equal(meshVolume(w.snapshotChunk('1,0,0')).quads,5);
});
test('Different solid materials do not create hidden interior faces', () => {
  const data = new Uint8Array([2,3]); const g = meshVolume(input(data,[2,1,1])); assert.equal(triangleArea(g),10);
});
test('Concave corners produce local ambient occlusion', () => {
  const data = new Uint8Array(27); data[index3(1,1,1,3,3)]=2; data[index3(2,2,1,3,3)]=2;
  const g = meshVolume(input(data,[3,3,3])); assert.ok(g.ao.some(v=>v<0.99)); assert.equal(triangleArea(g),12);
});
test('A hollow volume keeps its cavity in both mesh and colliders', () => {
  const d = new Uint8Array(27).fill(2); d[13]=0;
  assert.equal(triangleArea(meshVolume(input(d,[3,3,3]))),60); verifyBoxCover(d,[3,3,3]);
});
test('Seeded random volumes preserve exact surface area, winding, and collision coverage', () => {
  let seed=1; const rand=()=>((seed=Math.imul(seed,1664525)+1013904223>>>0)/2**32);
  for(let trial=0;trial<50;trial++) {
    const dims=[2+trial%5,3+trial%4,2+trial%3], d=Uint8Array.from({length:dims[0]*dims[1]*dims[2]},()=>rand()<0.43?0:rand()<0.6?2:3);
    assert.equal(triangleArea(meshVolume(input(d,dims))),surfaceArea(d,dims)); verifyBoxCover(d,dims); verifyBoxCover(d,dims,false);
  }
});
test('Collision boxes conserve material volume and mass', () => {
  const d=new Uint8Array([2,2,3,8,8,8,0,4]), dims=[2,2,2]; const boxes=verifyBoxCover(d,dims);
  const mass=d.reduce((sum,m)=>sum+(m?PALETTE[m].density:0),0);
  assert.equal(boxes.reduce((sum,b)=>sum+b.w*b.h*b.d*PALETTE[b.material].density,0),mass);
});
test('Grid raycast handles axis-aligned rays and outward normals', () => {
  const w=new VoxelWorld(16,1); w.set(0,0,0,2);
  const hit=raycastVoxels(w,[3,.5,.5],[-1,0,0]); assert.deepEqual(hit.cell,[0,0,0]); assert.deepEqual(hit.normal,[1,0,0]); assert.equal(hit.distance,2);
});
test('Grid raycast handles negative coordinates and non-unit directions', () => {
  const w=new VoxelWorld(16,1); w.set(-2,0,0,2);
  const hit=raycastVoxels(w,[1,.5,.5],[-7,0,0]); assert.deepEqual(hit.cell,[-2,0,0]); assert.equal(hit.distance,2);
});
test('Grid raycast has a range limit and rejects zero direction', () => {
  const w=new VoxelWorld(16,1); w.set(0,0,0,2);
  assert.equal(raycastVoxels(w,[3,.5,.5],[-1,0,0],1),null); assert.equal(raycastVoxels(w,[3,.5,.5],[0,0,0]),null);
  assert.equal(raycastVoxels(w,[.5,.5,.5],[1,0,0]).distance,0);
});
test('Face-connected voxels remain attached to an anchor', () => {
  const d=new Uint8Array([1,2,2,2]); assert.equal(findUnsupported({data:d,dims:[4,1,1],origin:[0,0,0]}).length,0);
});
test('Diagonal contact is not structural support', () => {
  const d=new Uint8Array([1,0,0,2]); const fragments=findUnsupported({data:d,dims:[2,2,1],origin:[0,0,0]});
  assert.equal(fragments.length,1); assert.equal(fragments[0].count,1); assert.deepEqual(fragments[0].origin,[1,1,0]);
});
test('Disconnected islands are partitioned without lost or repeated cells', () => {
  const d=new Uint8Array(5*4*3).fill(2); const fragments=findUnsupported({data:d,dims:[5,4,3],origin:[-5,2,7]},{maxCells:7,maxSpan:3});
  const seen=new Set(); let count=0;
  for(const f of fragments) {
    assert.ok(f.count<=7); assert.ok(f.dims.every(v=>v<=3)); count+=f.count;
    for(let z=0;z<f.dims[2];z++) for(let y=0;y<f.dims[1];y++) for(let x=0;x<f.dims[0];x++) if(f.data[index3(x,y,z,f.dims[0],f.dims[1])]) {
      const key=keyOf(f.origin[0]+x,f.origin[1]+y,f.origin[2]+z); assert.ok(!seen.has(key)); seen.add(key);
    }
  }
  assert.equal(count,d.length); assert.equal(seen.size,d.length);
});
test('Carving preserves foundation anchors and conserves removed material count', () => {
  const w=new VoxelWorld(16,1); w.fill([-2,-2,-2],[3,3,3],2); w.set(0,0,0,1); const before=w.count;
  const cut=carveSphere(w,[.5,.5,.5],1.6); assert.equal(w.get(0,0,0),1); assert.equal(before-w.count,cut.count);
  assert.equal(cut.data.reduce((sum,m)=>sum+Number(!!m),0),cut.count);
});
test('Invalid and oversized edits fail before mutation', () => {
  const w=new VoxelWorld(); w.set(0,0,0,2); assert.throws(()=>carveSphere(w,[0,0,0],-1));
  assert.throws(()=>carveSphere(w,[0,0,0],20)); assert.equal(w.count,1);
});
test('Removing a supported bridge creates detached voxel fragments', () => {
  const w=new VoxelWorld(); w.set(0,0,0,1); w.set(0,1,0,2); w.set(0,2,0,2); w.set(1,2,0,2);
  w.set(0,1,0,0); const f=findUnsupported(w.snapshotDense()); assert.equal(f.reduce((n,p)=>n+p.count,0),2);
  f.forEach(p=>removeFragment(w,p)); assert.equal(w.count,1);
});
test('Dense topology snapshots have a memory limit', () => {
  const w=new VoxelWorld(); w.set(0,0,0,1); w.set(10000,10000,10000,2); assert.throws(()=>w.snapshotDense(),RangeError);
});
test('Worker mesh jobs retain chunk revision tags', () => {
  const w=new VoxelWorld(); w.set(0,0,0,2); const p=w.snapshotChunk('0,0,0'), result=runJob('mesh',p);
  assert.equal(result.version,p.version); assert.equal(result.key,p.key); assert.equal(result.geometry.quads,6);
});
test('Worker shatter jobs retain all cells and enforce piece limits', () => {
  const d=new Uint8Array(8**3).fill(2), pieces=runJob('shatter',{data:d,dims:[8,8,8],origin:[0,0,0]});
  assert.equal(pieces.reduce((n,p)=>n+p.count,0),512);
  pieces.forEach(p=>{assert.ok(p.count<=64);assert.ok(p.boxes.length<=96);assert.ok(p.geometry.indices.length>0);});
});
test('Transfer lists do not repeat shared buffers', () => {
  const b=new ArrayBuffer(16); assert.equal(transferBuffers({a:new Uint8Array(b),b:new Uint16Array(b)}).length,1);
});
test('Fixed physics steps are independent of display rate', () => {
  for(const fps of [30,60,120]) { const c=new FixedStepClock(); let calls=0; for(let i=0;i<fps;i++) c.advance(1/fps,()=>calls++); assert.equal(calls,60); }
});
test('A long frame cannot create an unbounded catch-up loop', () => {
  const c=new FixedStepClock(); let calls=0; const state=c.advance(5,()=>calls++);
  assert.equal(calls,4); assert.equal(state.steps,4); assert.ok(state.alpha<1); assert.ok(c.droppedSeconds>4.9);
});
test('Pause removes the accumulator without stepping the physics world', () => {
  const c=new FixedStepClock(); c.advance(.01,()=>{}); let calls=0; const state=c.advance(1,()=>calls++,true);
  assert.equal(calls,0); assert.equal(c.accumulator,0); assert.equal(state.alpha,1);
});
test('Clock accounts for simulated, retained, and dropped time', () => {
  const c=new FixedStepClock(); for(const dt of [.017,.031,.2,.01,.5]) c.advance(dt,()=>{});
  assert.ok(Math.abs(c.simulationSeconds+c.accumulator+c.droppedSeconds-(.017+.031+.2+.01+.5))<1e-8);
});
