import test from 'node:test';
import assert from 'node:assert/strict';
import { VoxelWorld, index3 } from '../src/voxel/world.js';
import { findUnsupported, findUnsupportedSparse } from '../src/voxel/support.js';
import { MAT } from '../src/voxel/palette.js';
import { runJob } from '../src/workers/jobs.js';
import { randomSeed, createGarden } from '../src/scene/garden.js';
function cells(fragments) {
  const result = [];
  for (const fragment of fragments) {
    const [nx, ny, nz] = fragment.dims;
    for (let z = 0; z < nz; z++) for (let y = 0; y < ny; y++) for (let x = 0; x < nx; x++) {
      const material = fragment.data[index3(x, y, z, nx, ny)];
      if (material) result.push(`${x + fragment.origin[0]},${y + fragment.origin[1]},${z + fragment.origin[2]}:${material}`);
    }
  }
  return result.sort();
}
test('Sparse support handles an empty world', () => { assert.deepEqual(findUnsupportedSparse(new VoxelWorld().snapshotSparse()), []); });
test('Sparse snapshots do not share live voxel buffers', () => {
  const world = new VoxelWorld(); world.set(0, 0, 0, MAT.LIMESTONE);
  const snapshot = world.snapshotSparse(); snapshot.chunks[0].data.fill(0);
  assert.equal(world.get(0, 0, 0), MAT.LIMESTONE);
});
test('Sparse support agrees with dense support on 24 seeded random volumes', () => {
  const random = randomSeed(844);
  for (let sample = 0; sample < 24; sample++) {
    const world = new VoxelWorld(4);
    for (let z = -5; z <= 5; z++) for (let y = -2; y <= 5; y++) for (let x = -5; x <= 5; x++) {
      if (random() < 0.43) world.set(x, y, z, y === -2 && random() < 0.3 ? MAT.ANCHOR : MAT.LIMESTONE);
    }
    assert.deepEqual(cells(findUnsupportedSparse(world.snapshotSparse())), cells(findUnsupported(world.snapshotDense())));
  }
});
test('Negative chunk borders transmit support in all six directions', () => {
  for (let axis = 0; axis < 3; axis++) for (const direction of [-1, 1]) {
    const world = new VoxelWorld(4); world.set(-4, -4, -4, MAT.ANCHOR);
    for (let step = 1; step <= 12; step++) { const p = [-4, -4, -4]; p[axis] += direction * step; world.set(...p, MAT.LIMESTONE); }
    assert.equal(findUnsupportedSparse(world.snapshotSparse()).length, 0);
    const cut = [-4, -4, -4]; cut[axis] += direction * 5; world.set(...cut, MAT.AIR);
    assert.equal(findUnsupportedSparse(world.snapshotSparse()).reduce((sum, f) => sum + f.count, 0), 7);
  }
});
test('Distant islands do not require a dense buffer for the empty gap', () => {
  const world = new VoxelWorld(); world.set(-1_000_000, 0, -1_000_000, MAT.ANCHOR);
  world.set(-1_000_000, 1, -1_000_000, MAT.LIMESTONE); world.set(1_000_000, 3, 1_000_000, MAT.COPPER);
  assert.throws(() => world.snapshotDense(), RangeError);
  const fragments = findUnsupportedSparse(world.snapshotSparse()); assert.equal(fragments.length, 1);
  assert.deepEqual(fragments[0].origin, [1_000_000, 3, 1_000_000]); assert.equal(fragments[0].count, 1);
});
test('Sparse fragments keep cell and span limits without losing cells', () => {
  const world = new VoxelWorld(4); world.fill([-8, -3, -8], [8, 3, 8], MAT.COPPER);
  const fragments = findUnsupportedSparse(world.snapshotSparse(), { maxCells: 23, maxSpan: 4 });
  assert.equal(fragments.reduce((sum, f) => sum + f.count, 0), world.count);
  assert.equal(new Set(cells(fragments)).size, world.count);
  for (const fragment of fragments) { assert.ok(fragment.count <= 23); assert.ok(fragment.dims.every(n => n <= 4)); }
});
test('A garden arch detaches correctly through the sparse worker job', () => {
  const world = new VoxelWorld(); createGarden(world); world.fill([-24, 6, -19], [21, 9, -7], MAT.AIR);
  const dense = findUnsupported(world.snapshotDense()), prepared = runJob('support-sparse', world.snapshotSparse());
  assert.deepEqual(cells(prepared), cells(dense));
  for (const fragment of prepared) { assert.ok(fragment.geometry.indices.length > 0); assert.ok(fragment.boxes.length <= 96); }
});
test('Invalid sparse snapshots fail clearly', () => {
  assert.throws(() => findUnsupportedSparse({ chunkSize: 0, chunks: [] }), TypeError);
  const chunk = { coord: [0, 0, 0], data: new Uint8Array(64) };
  assert.throws(() => findUnsupportedSparse({ chunkSize: 4, chunks: [chunk, chunk] }), TypeError);
  assert.throws(() => findUnsupportedSparse({ chunkSize: 4, chunks: [chunk] }, { maxSpan: 0 }), RangeError);
});
