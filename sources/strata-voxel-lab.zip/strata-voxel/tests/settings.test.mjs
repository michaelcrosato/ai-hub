import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { PROFILES, initialProfile } from '../src/engine/config.js';
import { GRAPHICS_CONTROLS, normaliseSetting, sanitiseGraphics, profileDefaults, loadSettings, saveSettings, SETTINGS_KEY, formatSetting } from '../src/engine/settings.js';

test('Only Mobile and Desktop profiles are defined', () => {
  assert.deepEqual(Object.keys(PROFILES), ['mobile', 'desktop']);
  for (const profile of Object.values(PROFILES)) {
    for (const key of ['fps', 'targetFps', 'maxDpr', 'maxPixels', 'maxBodies']) assert.equal(key in profile, false);
  }
});
test('Every graphics setting has one slider and valid defaults', () => {
  const keys = GRAPHICS_CONTROLS.map(control => control.key);
  assert.equal(new Set(keys).size, keys.length); assert.equal(keys.length, 27);
  for (const name of Object.keys(PROFILES)) {
    assert.deepEqual(Object.keys(profileDefaults(name)).sort(), [...keys].sort());
    for (const [key, value] of Object.entries(profileDefaults(name))) assert.equal(normaliseSetting(key, value), value, `${name}/${key}`);
  }
});
test('Profile defaults cannot be changed by editing a copy', () => {
  const values = profileDefaults('mobile'); values.exposure = 2;
  assert.equal(PROFILES.mobile.graphics.exposure, 1.08);
  assert.throws(() => profileDefaults('battery'), RangeError);
});
test('Slider validation clamps, snaps, and rejects invalid values', () => {
  assert.equal(normaliseSetting('renderScale', 5), 2);
  assert.equal(normaliseSetting('renderScale', -4), 0.25);
  assert.equal(normaliseSetting('shadowSize', 2000), 2048);
  assert.equal(normaliseSetting('lampCount', 7.6), 8);
  assert.equal(normaliseSetting('fogDensity', 0.0036), 0.004);
  for (const value of [NaN, Infinity, '1', null, undefined]) assert.throws(() => normaliseSetting('exposure', value), TypeError);
  assert.throws(() => normaliseSetting('not-a-setting', 1), RangeError);
});
test('Saved settings are validated against the active schema', () => {
  const values = sanitiseGraphics('mobile', { exposure: 100, renderScale: 'bad', shadowSize: 4200, stray: 42 });
  assert.equal(values.exposure, 3); assert.equal(values.renderScale, 0.65); assert.equal(values.shadowSize, 4096);
  assert.equal('stray' in values, false);
});
test('Each profile keeps separate saved values', () => {
  const data = new Map(), storage = { getItem: key => data.get(key), setItem: (key, value) => data.set(key, value) };
  const settings = loadSettings(storage); settings.graphics.mobile.exposure = 0.8; settings.graphics.desktop.exposure = 1.7;
  settings.profile = 'desktop'; assert.equal(saveSettings(storage, settings), true);
  const read = loadSettings(storage);
  assert.equal(read.profile, 'desktop'); assert.equal(read.graphics.mobile.exposure, 0.8); assert.equal(read.graphics.desktop.exposure, 1.7);
  assert.ok(data.has(SETTINGS_KEY));
});
test('Blocked or corrupt browser storage does not prevent startup', () => {
  const blocked = { getItem() { throw new Error('Blocked'); }, setItem() { throw new Error('Blocked'); } };
  assert.equal(loadSettings(blocked).profile, 'mobile'); assert.equal(saveSettings(blocked, {}), false);
  assert.equal(loadSettings({ getItem: () => '{invalid' }).profile, 'mobile');
  assert.equal(saveSettings(null, {}), false);
  assert.equal(loadSettings({ getItem: () => '{"profile":"__proto__"}' }).profile, 'mobile');
});
test('URLs support two profiles and reject the removed Battery profile', () => {
  assert.equal(initialProfile('?profile=desktop'), 'desktop'); assert.equal(initialProfile('?quality=desktop'), 'desktop');
  assert.equal(initialProfile('?quality=battery'), 'mobile'); assert.equal(initialProfile('?profile=__proto__'), 'mobile');
  assert.equal(initialProfile(''), 'mobile');
});
test('Zero effect values have clear labels', () => {
  const controls = Object.fromEntries(GRAPHICS_CONTROLS.map(control => [control.key, control]));
  assert.equal(formatSetting(controls.shadowSize, 0), 'Off');
  assert.equal(formatSetting(controls.bloomStrength, 0), 'Off');
  assert.equal(formatSetting(controls.renderScale, 1.25), '125%');
});
test('No automatic quality controller or application FPS limiter remains', () => {
  const renderer = readFileSync(new URL('../src/engine/renderer.js', import.meta.url), 'utf8');
  const main = readFileSync(new URL('../src/main.js', import.meta.url), 'utf8');
  assert.doesNotMatch(renderer, /slowWindows|fastWindows|maxPixels|\badapt\(/);
  assert.doesNotMatch(main, /view\.adapt|targetFps|profile\]\.fps/);
});
