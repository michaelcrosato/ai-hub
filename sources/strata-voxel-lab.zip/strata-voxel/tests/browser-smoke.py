"""Optional real browser check. Start `npm run dev` before this test.

Requires installed engine dependencies, Python, Playwright, and Chromium.
This test was not run in the authoring environment. It does not set an FPS target.
"""
from __future__ import annotations
import json
import os
import shutil
from playwright.sync_api import sync_playwright


def main() -> None:
    with sync_playwright() as p:
        executable = os.environ.get('CHROMIUM') or shutil.which('chromium') or shutil.which('chromium-browser')
        browser = p.chromium.launch(headless=True, executable_path=executable)
        page = browser.new_page(viewport={'width': 960, 'height': 720})
        page.set_default_timeout(300_000)
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.goto(os.environ.get('STRATA_URL', 'http://localhost:5173/?backend=webgl'))
        page.wait_for_function('window.strata || !document.querySelector("#error").hidden')
        assert page.evaluate('Boolean(window.strata)'), page.locator('#error-detail').text_content()
        assert page.locator('input[data-graphics]').count() == 27
        assert page.locator('#quality option').all_text_contents() == ['Mobile', 'Desktop']
        page.evaluate("window.strata.setProfile('mobile'); window.strata.setGraphics({exposure:0.8, renderScale:0.5})")
        page.evaluate("window.strata.setProfile('desktop'); window.strata.setGraphics({exposure:1.7})")
        page.evaluate("window.strata.setProfile('mobile')")
        assert page.evaluate('window.strata.stats().graphics.exposure') == 0.8
        page.evaluate("window.strata.setGraphics({shadowSize:512, bloomStrength:0.1, fogDensity:0, lampCount:4})")
        page.wait_for_timeout(200)
        records = []
        for area, count in [('medium', 1095745), ('large', 2891962), ('massive', 9248985), ('small', 207735)]:
            page.evaluate('(area) => window.strata.setArea(area)', area)
            state = page.evaluate('window.strata.stats()')
            assert state['area'] == area and state['staticVoxels'] == count, state
            assert state['graphics']['exposure'] == 0.8
            assert page.evaluate('!window.strata.engine.stopped')
            records.append({'area': area, 'staticVoxels': count, 'backend': state['backend']})
        page.evaluate('window.strata.overview(); window.strata.pause(true)')
        page.evaluate('() => window.strata.drop()')
        assert page.evaluate('window.strata.stats().dynamicBodies') > 0
        page.evaluate('() => window.strata.reset()')
        assert page.evaluate('window.strata.stats().dynamicBodies') == 0
        assert not errors, errors
        print(json.dumps({'scope': 'Real renderer, area switching, saved profile values, and fragment creation.', 'areas': records, 'pageErrors': errors}, indent=2))
        browser.close()

if __name__ == '__main__':
    main()
