"""Offline checks for the real controls module and responsive HTML/CSS.

No three.js renderer or Rapier solver is loaded. All requests use local files.
Requires Python 3.10+, Playwright, and Chromium.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
import re
import shutil
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]

def main() -> None:
    html = re.sub(r'<script\b[^>]*>.*?</script>', '', (ROOT / 'index.html').read_text(), flags=re.S)
    html = re.sub(r'<link\b[^>]*>', '', html)
    html = html.replace('</head>', '<style>' + (ROOT / 'styles.css').read_text() + '</style></head>')
    results = {'scope': 'Offline HTML, CSS, graphics controls, and settings only. No GPU or physics runtime.', 'layouts': []}
    with sync_playwright() as p:
        executable = os.environ.get('CHROMIUM') or shutil.which('chromium') or shutil.which('chromium-browser')
        browser = p.chromium.launch(headless=True, executable_path=executable, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 900})
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.set_content(html)
        page.evaluate("""async sources => {
          const blob = source => URL.createObjectURL(new Blob([source], {type: 'text/javascript'}));
          const configURL = blob(sources.config);
          const settingsURL = blob(sources.settings.replace("'./config.js'", JSON.stringify(configURL)));
          const panelURL = blob(sources.panel.replace("'../engine/settings.js'", JSON.stringify(settingsURL)));
          const settings = await import(settingsURL);
          const { mountGraphicsPanel } = await import(panelURL);
          let values = settings.profileDefaults('mobile');
          window.controlPanel = mountGraphicsPanel(document.querySelector('#graphics-controls'), () => values,
            (key, value) => { values[key] = settings.normaliseSetting(key, value); window.controlPanel.sync(); });
          window.controlValues = () => ({...values}); window.controlSchema = settings.GRAPHICS_CONTROLS;
          document.querySelector('#loading').classList.add('is-hidden');
        }""", {'config': (ROOT / 'src/engine/config.js').read_text(),
               'settings': (ROOT / 'src/engine/settings.js').read_text(),
               'panel': (ROOT / 'src/ui/graphics-panel.js').read_text()})
        assert page.locator('#quality option').all_text_contents() == ['Mobile', 'Desktop']
        assert page.locator('[data-area]').count() == 4
        assert page.locator('input[data-graphics]').count() == 27
        # Exercise every real slider handler at both ends, including shadow-map steps.
        checked = page.evaluate("""() => {
          for (const c of window.controlSchema) {
            const input = document.querySelector(`[data-graphics="${c.key}"]`);
            const saved = input.value;
            for (const v of [input.min, input.max]) {
              input.value = v; input.dispatchEvent(new Event('input', {bubbles: true}));
              const expected = c.values ? c.values[Number(v)] : Number(v);
              if (Math.abs(window.controlValues()[c.key] - expected) > 0.00001) throw new Error(`Bad slider: ${c.key}`);
              if (!input.getAttribute('aria-valuetext')) throw new Error(`Missing value label: ${c.key}`);
            }
            input.value = saved; input.dispatchEvent(new Event('input', {bubbles: true}));
          }
          return window.controlSchema.length;
        }""")
        results['sliderHandlersChecked'] = checked
        for width, height in [(1440, 900), (1280, 720), (390, 844), (360, 780), (320, 568), (844, 390)]:
            page.set_viewport_size({'width': width, 'height': height})
            page.evaluate("document.querySelector('#inspector').classList.remove('open')")
            page.wait_for_timeout(100)
            for selector in ['.tool-dock', '.area-dock']:
                bounds = page.locator(selector).bounding_box()
                assert bounds and bounds['x'] >= -1 and bounds['y'] >= 0, (selector, bounds)
                assert bounds['x'] + bounds['width'] <= width + 1, (selector, bounds)
                assert bounds['y'] + bounds['height'] <= height + 1, (selector, bounds)
            page.evaluate("document.querySelector('#inspector').classList.add('open')")
            page.wait_for_timeout(100)
            panel = page.locator('#inspector').bounding_box()
            assert panel and panel['x'] >= -1 and panel['y'] >= -1, panel
            assert panel['x'] + panel['width'] <= width + 1, panel
            assert panel['y'] + panel['height'] <= height + 1, panel
            assert page.locator('#inspector').evaluate('(el) => el.scrollWidth <= el.clientWidth + 1')
            page.locator('#reset').scroll_into_view_if_needed()
            results['layouts'].append({'width': width, 'height': height, 'toolsFit': True, 'areasFit': True, 'panelFits': True})
        results['pageErrors'] = errors
        assert not errors, errors
        page.set_viewport_size({'width': 1440, 'height': 900})
        page.locator('#inspector').evaluate('(el) => {el.scrollTop = 0;}')
        if os.environ.get('UI_SCREENSHOT'):
            page.screenshot(path=os.environ['UI_SCREENSHOT'])
        browser.close()
    print(json.dumps(results, indent=2))

if __name__ == '__main__':
    main()
