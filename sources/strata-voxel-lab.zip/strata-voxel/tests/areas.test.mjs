import test from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { AREAS, areaPlan, createArea, createAreaAsync, initialArea } from '../src/scene/areas.js';
import { VoxelWorld } from '../src/voxel/world.js';
import { findUnsupportedSparse } from '../src/voxel/support.js';
import { VOXEL_SIZE } from '../src/engine/config.js';
const expected = { small: [24, 1, 207735, 161], medium: [64, 5, 1095745, 1072], large: [128, 13, 2891962, 3165], massive: [256, 41, 9248985, 10204] };
for (const [id, [size, sites, count, chunkCount]] of Object.entries(expected)) {
  test(`${id}: real terrain, fixed voxel size, valid bounds, and no floating cells`, () => {
    const world = new VoxelWorld(), layout = createArea(world, id);
    assert.equal(layout.size, size); assert.equal(layout.sites.length, sites); assert.equal(layout.links.length, sites - 1);
    assert.equal(layout.landmarks.length, sites); assert.equal(layout.pools.length, sites);
    assert.equal(world.voxelSize, 0.125); assert.equal(world.count, count); assert.equal(world.chunks.size, chunkCount);
    assert.equal(findUnsupportedSparse(world.snapshotSparse()).length, 0);
    const half = size / VOXEL_SIZE / 2;
    for (const [key, chunk] of world.chunks) {
      const coord = key.split(',').map(value => Number(value) * 16);
      for (let i = 0; i < chunk.data.length; i++) if (chunk.data[i]) {
        const x = coord[0] + i % 16, y = coord[1] + Math.floor(i / 16) % 16, z = coord[2] + Math.floor(i / 256);
        assert.ok(x >= -half && x < half && z >= -half && z < half && y >= -24 && y < 192, `Cell outside ${id}`);
      }
    }
  });
}
test('Area generation is deterministic', () => {
  function checksum() {
    const world = new VoxelWorld(); createArea(world, 'medium'); const hash = createHash('sha256');
    for (const [key, chunk] of world.chunks) { hash.update(key); hash.update(chunk.data); } return hash.digest('hex');
  }
  assert.equal(checksum(), checksum());
});
test('Asynchronous area generation gives the same data and reports progress', async () => {
  const world = new VoxelWorld(), progress = [], layout = await createAreaAsync(world, 'medium', p => progress.push(p));
  assert.equal(world.count, expected.medium[2]); assert.equal(layout.landmarks.length, 5);
  assert.equal(progress.at(-1), 1); assert.equal(progress.length, 9); assert.ok(progress.every((p, i) => i === 0 || p > progress[i - 1]));
});
test('Area plans and URLs accept only the four named areas', () => {
  assert.deepEqual(Object.keys(AREAS), ['small', 'medium', 'large', 'massive']);
  assert.throws(() => areaPlan('infinite'), RangeError); assert.throws(() => areaPlan('__proto__'), RangeError);
  assert.equal(initialArea('?area=massive'), 'massive'); assert.equal(initialArea('?area=other'), 'small');
});
