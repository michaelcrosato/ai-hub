// CPU data/geometry checks. This does not measure rendering or device performance.
import { writeFile } from 'node:fs/promises';
import { VoxelWorld } from '../src/voxel/world.js';
import { AREAS, createArea } from '../src/scene/areas.js';
import { findUnsupportedSparse } from '../src/voxel/support.js';
import { meshVolume } from '../src/voxel/mesher.js';
import { mergeColliders } from '../src/voxel/colliders.js';
const report = { engine: '0.2.0', scope: 'CPU generation, support, mesh, and collider data. No GPU or Rapier runtime.', areas: [] };
for (const id of Object.keys(AREAS)) {
  const world = new VoxelWorld(), layout = createArea(world, id);
  const unsupported = findUnsupportedSparse(world.snapshotSparse()).reduce((sum, fragment) => sum + fragment.count, 0);
  let triangles = 0, colliders = 0;
  for (const key of world.chunks.keys()) {
    const payload = world.snapshotChunk(key);
    triangles += meshVolume(payload).quads * 2;
    colliders += mergeColliders({ ...payload, preserveMaterials: false }).length;
  }
  const item = { id, widthMetres: layout.size, depthMetres: layout.size, gardens: layout.sites.length,
    links: layout.links.length, voxelMetres: world.voxelSize, occupiedVoxels: world.count,
    allocatedChunks: world.chunks.size, rawChunkBytes: world.chunks.size * world.chunkSize ** 3,
    staticVoxelTriangles: triangles, staticVoxelColliderBoxes: colliders, unsupportedVoxels: unsupported };
  report.areas.push(item); console.log(JSON.stringify(item));
}
await writeFile(new URL('../docs/area-report.json', import.meta.url), JSON.stringify(report, null, 2) + '\n');
