import { readdir } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
let count = 0, failed = false;
async function walk(folder) {
  for (const item of await readdir(folder, { withFileTypes: true })) {
    const file = path.join(folder, item.name);
    if (item.isDirectory()) await walk(file);
    else if (/\.(m?js)$/.test(file)) {
      const result = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' }); count++;
      if (result.status !== 0) { failed = true; console.error(result.stderr); }
    }
  }
}
for (const folder of ['src', 'scripts', 'tests']) await walk(path.join(root, folder));
console.log(`${count} JavaScript files checked.`); process.exitCode = failed ? 1 : 0;
