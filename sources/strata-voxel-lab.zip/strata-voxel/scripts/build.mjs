import { existsSync } from 'node:fs';
import { cp, mkdir, rm, writeFile, readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..'), out = path.join(root, 'dist');
for (const name of ['three/build/three.webgpu.js', '@dimforge/rapier3d-compat/rapier.es.js']) {
  if (!existsSync(path.join(root, 'node_modules', name))) throw new Error(`Missing ${name}. Run npm install first.`);
}
await rm(out, { recursive: true, force: true }); await mkdir(out, { recursive: true });
for (const name of ['index.html', 'styles.css', 'src']) await cp(path.join(root, name), path.join(out, name), { recursive: true });
await mkdir(path.join(out, 'vendor/three'), { recursive: true }); await mkdir(path.join(out, 'vendor/rapier'), { recursive: true });
await cp(path.join(root, 'node_modules/three/build'), path.join(out, 'vendor/three/build'), { recursive: true });
for (const file of ['controls/OrbitControls.js', 'tsl/display/BloomNode.js']) {
  const dest = path.join(out, 'vendor/three/examples/jsm', file); await mkdir(path.dirname(dest), { recursive: true });
  await cp(path.join(root, 'node_modules/three/examples/jsm', file), dest);
}
await cp(path.join(root, 'node_modules/@dimforge/rapier3d-compat/rapier.es.js'), path.join(out, 'vendor/rapier/rapier.es.js'));
for (const [source, dest] of [['three/LICENSE', 'vendor/three/LICENSE'], ['@dimforge/rapier3d-compat/LICENSE', 'vendor/rapier/LICENSE']]) {
  if (existsSync(path.join(root, 'node_modules', source))) await cp(path.join(root, 'node_modules', source), path.join(out, dest));
}
for (const name of ['LICENSE-APACHE', 'LICENSE-MIT', 'NOTICE']) {
  const source = path.join(root, 'node_modules/@dimforge/rapier3d-compat', name);
  if (existsSync(source)) await cp(source, path.join(out, 'vendor/rapier', name));
}
// Use the upstream minified builds. No source transformation is needed.
const html = await readFile(path.join(out, 'index.html'), 'utf8');
await writeFile(path.join(out, 'index.html'), html.replaceAll('three.webgpu.js', 'three.webgpu.min.js').replaceAll('three.tsl.js', 'three.tsl.min.js'));
await cp(path.join(root, 'LICENSE'), path.join(out, 'LICENSE'));
await writeFile(path.join(out, 'build-info.json'), JSON.stringify({ engine: '0.2.0', three: '0.180.0', rapier: '0.17.3', builtAt: new Date().toISOString() }, null, 2));
console.log('Built dist/. Serve it on HTTPS. No runtime CDN, external model, or external texture is required.');
