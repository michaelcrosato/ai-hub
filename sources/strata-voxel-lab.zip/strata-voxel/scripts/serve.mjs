import http from 'node:http';
import https from 'node:https';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const project = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const dist = process.argv.includes('--dist'), cdn = process.argv.includes('--cdn');
const root = dist ? path.join(project, 'dist') : project;
const portArg = process.argv.indexOf('--port');
const port = Number(process.env.PORT || (portArg >= 0 ? process.argv[portArg + 1] : 5173));
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Invalid port.');
const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json', '.wasm': 'application/wasm', '.svg': 'image/svg+xml' };
function route(request, response) {
  try {
    if (!['GET', 'HEAD'].includes(request.method)) { response.writeHead(405); response.end(); return; }
    const url = new URL(request.url, 'http://localhost'); let name = decodeURIComponent(url.pathname);
    if (name === '/') name = '/index.html';
    if (name.includes('\0') || name.includes('\\') || name.split('/').includes('..')) throw new Error('Invalid path.');
    let base = root, relative = name.slice(1);
    if (name.startsWith('/vendor/') && !dist) {
      if (cdn) {
        let target;
        if (name.startsWith('/vendor/three/')) target = `https://cdn.jsdelivr.net/npm/three@0.180.0/${name.slice('/vendor/three/'.length)}`;
        if (name === '/vendor/rapier/rapier.es.js') target = 'https://cdn.jsdelivr.net/npm/@dimforge/rapier3d-compat@0.17.3/rapier.es.js';
        if (!target) throw new Error('Unknown vendor module.');
        response.writeHead(307, { Location: target }); response.end(); return;
      }
      if (name.startsWith('/vendor/three/')) { base = path.join(project, 'node_modules/three'); relative = name.slice('/vendor/three/'.length); }
      else if (name.startsWith('/vendor/rapier/')) { base = path.join(project, 'node_modules/@dimforge/rapier3d-compat'); relative = name.slice('/vendor/rapier/'.length); }
      else throw new Error('Unknown vendor module.');
    } else if (!(name === '/index.html' || name === '/styles.css' || name.startsWith('/src/') || (dist && name.startsWith('/vendor/')))) {
      response.writeHead(404); response.end('Not found.'); return;
    }
    const file = path.resolve(base, relative);
    if (!file.startsWith(base + path.sep)) throw new Error('Invalid path.');
    if (!fs.existsSync(file) || !fs.statSync(file).isFile()) {
      response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      response.end(name.startsWith('/vendor/') ? 'Missing dependency. Run npm install, or start with --cdn.' : 'Not found.'); return;
    }
    response.writeHead(200, { 'Content-Type': types[path.extname(file)] || 'application/octet-stream', 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-cache' });
    if (request.method === 'HEAD') response.end(); else fs.createReadStream(file).pipe(response);
  } catch { response.writeHead(400); response.end('Bad request.'); }
}
const secure = !!(process.env.HTTPS_CERT && process.env.HTTPS_KEY);
const server = secure ? https.createServer({ cert: fs.readFileSync(process.env.HTTPS_CERT), key: fs.readFileSync(process.env.HTTPS_KEY) }, route) : http.createServer(route);
server.on('error', error => { console.error(error.message); process.exitCode = 1; });
server.listen(port, '0.0.0.0', () => {
  console.log(`Strata: ${secure ? 'https' : 'http'}://localhost:${port}`);
  console.log(cdn ? 'Pinned CDN modules are enabled. The browser needs internet access.' : 'Modules are served from local installed dependencies.');
  if (!secure) console.log('Phone WebGPU: use HTTPS, or USB port reversal to phone localhost. LAN HTTP uses the WebGL fallback.');
});
