# STRATA 0.2

A mobile-first voxel physics engine starter with manual graphics controls and four areas.

Primary target: Samsung Galaxy S26. Secondary target: a desktop with an RTX 4070 Super. These are intended targets, not verified device results.

**Status:** All 57 core tests passed. The offline browser test checked all 27 graphics slider handlers and six screen layouts. The real three.js renderer and Rapier solver could not run in this authoring environment because the dependency download failed. See [validation](docs/VALIDATION.md).

## Start

Use Node.js 20 or later. Extract the ZIP. Run these commands in the `strata-voxel` folder:

```sh
npm install
npm run dev
```

Open `http://localhost:5173`. Do not open the HTML file directly.

The project uses native ES modules. The development server serves local npm packages. There is no required development build step.

An optional CDN mode is available:

```sh
npm run dev -- --cdn
```

This mode needs internet access in the browser. It uses the same pinned package versions. Use local installed packages for a controlled build.

## Changes in 0.2

There are now only **Mobile** and **Desktop** profiles. The Battery profile, application FPS targets, application frame limiter, automatic resolution changes, profile pixel limits, and profile DPR limits are removed.

A profile is a saved set of starting values. Both profiles expose the same graphics controls. Each profile keeps its own changes in browser storage when storage is available. A storage error does not stop the engine. Settings then apply only to the current session.

The render loop follows browser animation callbacks. There is no engine-selected render rate. Physics still uses its fixed time step. This is a simulation rule, not a render-rate target.

## Four areas

Use the **Small**, **Medium**, **Large**, and **Massive** buttons at the top left.

| Area | Area bounds | Gardens | Path links | Occupied static voxels |
| --- | ---: | ---: | ---: | ---: |
| Small | 24 × 24 m | 1 | 0 | 207,735 |
| Medium | 64 × 64 m | 5 | 4 | 1,095,745 |
| Large | 128 × 128 m | 13 | 12 | 2,891,962 |
| Massive | 256 × 256 m | 41 | 40 | 9,248,985 |

These bounds include the empty spaces between islands. They do not describe solid squares of terrain. The Small area keeps the original garden. Larger areas add real voxel terrain, towers, courts, pools, and supported stone paths. They do not enlarge the Small area's voxels or scale up its mesh.

Each voxel is **0.125 m** wide in every area. Chunks contain **16 × 16 × 16 cells**. All four areas start with no unsupported cells.

Use **Go to a garden** to move to a named location. Use **Overview** to move the camera above the current area. Use the Home button to return to the central ruin. The view-distance slider can hide distant terrain, including terrain in an overview.

**Switching areas resets scene edits and loose bodies.** The engine loads one area at a time. It keeps graphics settings during the switch. Reset restores the current area; it does not switch back to Small. Scene edits are not saved to disk.

Each selected area is fully loaded. There is no terrain streaming or level of detail in this release. Large areas require more memory and more collision data even when the render scale is low.

## Manual graphics controls

Open Engine Settings on a phone. On a wide desktop screen, the panel is visible by default. Expand a settings group to see its sliders.

| Group | Sliders |
| --- | --- |
| Image | Render scale, view distance, field of view |
| Light | Exposure, sun strength, sun height, sun direction, ambient light, environment light, lamp strength, local lamp count |
| Shadows | Shadow-map size, coverage, strength, softness, surface offset |
| Surface | Corner occlusion, roughness scale, metalness scale, surface detail, voxel glow |
| Atmosphere | Bloom strength, bloom spread, bloom threshold, fog density |
| Water | Roughness, ripple strength |

There are **27 graphics sliders**. They update the renderer or shader uniforms without rebuilding voxel geometry. Zero shadow-map size disables sun shadows. Zero bloom strength disables the bloom pass. Zero fog density removes the fog effect. Zero local lamps disables pooled local lamps.

Render scale ranges from **25% to 200% of native screen resolution**. At 100%, the requested pixel ratio is the browser's device pixel ratio. The engine does not reduce this value in response to slow frames. A reported hardware texture or renderbuffer limit can still restrict the drawing-buffer size. The diagnostics show this condition.

The shadow-map slider uses these steps: **Off, 256, 512, 1024, 2048, 4096, and 8192** pixels per side. A device hardware limit can restrict the selected size. The device report includes the actual shadow-map size.

Shadow coverage is the width of the sun's shadow region. It follows the camera's orbit target. A wider region covers more terrain but gives each metre fewer shadow-map pixels at the same map size. This is one shadow region, not cascaded shadows.

Local lamps use a pool. The local-lamp slider sets its size from 0 to 32. The engine assigns the pool to the nearest intact light sources around the camera target. It does not create one point light for every glowing voxel. Emission and lamp strength are separate controls.

The Mobile profile starts at 65% render scale, a 1024-pixel shadow map, and no bloom. Desktop starts at 100%, a 2048-pixel shadow map, and 0.15 bloom strength. These are editable defaults, not quality ceilings. **Restore this profile's defaults** resets only the selected profile.

The current renderer keeps its original multisample antialiasing setup. The sky colours and water base colour are fixed. This release does not add path tracing, live global illumination, screen-space reflections, or an antialiasing-mode selector.

## Physics and editing

Voxel data, visible surfaces, and collision shapes remain separate. Adjacent visible faces are merged where material and local occlusion permit. Static solids use merged collision boxes. Each loose voxel group uses one rigid body with several boxes. The boxes keep holes in structures.

Physics uses Rapier with gravity, contact response, friction, density-based mass, sleeping, impulses, and continuous collision detection. The fixed simulation step is 1/60 second. Render poses interpolate between simulation states. Catch-up steps remain bounded to protect simulation stability after a long pause.

The support check now works across **sparse chunks**. It does not allocate a dense buffer for all the empty space between islands. It checks all loaded chunks and all six neighbour directions. It is still a complete loaded-world connectivity check, not an incremental stress solver.

Mesh work is sent in batches of 24 chunks. This bounds the queued temporary mesh data. It does not set a render-rate target. Physics stays paused until an edit's visible surfaces and collision shapes are both ready.

The Physics section has separate controls for impact damage, break radius, maximum loose bodies, and debris lifetime. These controls do not change when the graphics profile changes. They remain unchanged during area switches, but are not saved across page reloads.

A zero debris lifetime means no time-based expiry. The maximum-body limit still applies. When the limit is reached, the engine removes a sleeping piece first, or the oldest piece otherwise. Matter is not preserved indefinitely. Bodies below the lower safety boundary are also removed.

**Support is a connectivity rule, not a structural stress model.** The engine does not calculate bending, compression failure, fatigue, or material cracks. Impact damage is a game rule. Water is a visual surface, not a fluid solver.

## Controls

| Action | Touch | Mouse or keyboard |
| --- | --- | --- |
| Turn the view | One-finger drag | Left drag |
| Pan or zoom | Two-finger gesture | Right drag or wheel |
| Select a tool | Tap its button | Keys 1 to 4 |
| Break or add voxels | Select the tool, then tap | Select the tool, then click |
| Push loose matter | Select Push, then tap a piece | Select Push, then click a piece |
| Drop a copper block | Tap Drop | Space |
| Pause physics | Tap Pause | P |
| Reset the current area | Tap Reset scene | R |

A drag does not count as a tap. Keyboard shortcuts do not take control from a focused form field. Camera movement remains available when physics is paused.

The Add tool places a 3-cell limestone cube outside a selected fixed surface. It respects the selected area's build bounds and rejects overlap with moving bodies. On a moving body, Break splits the selected body into smaller groups; it does not cut only the selected sphere.

## Open it on the phone

WebGPU needs a secure context. Use HTTPS with a certificate the phone trusts, or use a USB localhost connection.

For USB, install Android Platform Tools on the desktop. Enable USB debugging on the phone. Connect the phone and approve the computer. Then run:

```sh
adb reverse tcp:5173 tcp:5173
```

Keep the development server open. Open `http://localhost:5173` on the phone.

For local HTTPS, set `HTTPS_CERT` and `HTTPS_KEY` before starting the server. Do not disable browser security checks.

Examples:

```text
http://localhost:5173/?profile=mobile&area=small
http://localhost:5173/?profile=desktop&area=large
http://localhost:5173/?area=massive
http://localhost:5173/?backend=webgl&area=medium
```

The former `quality=desktop` query is still accepted. There is no Battery profile.

## Test and build

The core tests do not need npm dependencies:

```sh
npm test
npm run check
npm run report:areas
```

The offline control test needs Python, Playwright, and Chromium, but does not need engine packages:

```sh
python -m pip install playwright
python -m playwright install chromium
npm run test:ui
```

After a successful dependency install, run the real solver tests:

```sh
npm run test:physics
```

With the development server open, the optional real-browser smoke test is:

```sh
npm run test:browser
```

It checks the renderer, all four area switches, graphics-profile values, and loose-body creation. It was not run for this release. Set `STRATA_URL` to test another local server or backend.

For a static build:

```sh
npm run build
npm run preview
```

Deploy the resulting `dist/` folder on HTTPS. The procedural scene does not need external models, textures, or fonts.

Direct dependencies remain pinned to `three@0.180.0` and `@dimforge/rapier3d-compat@0.17.3`. These are fixed API targets, not claims about the latest releases. This source ZIP does not include a lock file, dependencies, or a tested production build. Commit the lock file after the first successful install.

## Test API

After startup:

```js
window.strata.stats();
window.strata.setProfile('mobile');
window.strata.setGraphics({ renderScale: 0.85, exposure: 1.2, shadowSize: 2048 });
await window.strata.setArea('massive');
window.strata.overview();
await window.strata.drop();
window.strata.pause(true);
await window.strata.reset();
```

The report records the selected area, actual voxel and triangle counts, all graphics settings, shadow-map size, drawing-buffer size, and diagnostic timings. It has no FPS-target field.

## Code map

`src/scene/areas.js` defines the four areas and their path networks. `src/scene/garden.js` keeps the original Small scene. `src/engine/settings.js` defines all slider ranges and saved values. `src/ui/graphics-panel.js` creates the controls from that schema. `src/voxel/support.js` contains both dense fragment support and sparse world support.

See [architecture](docs/ARCHITECTURE.md), [validation](docs/VALIDATION.md), and the [device check guide](docs/DEVICE_TEST.md).

## Primary API references

The implementation keeps the r180 API target. Current documentation can differ from that version.

- [three.js r180 source](https://github.com/mrdoob/three.js/tree/r180)
- [Renderer API](https://threejs.org/docs/pages/Renderer.html)
- [r180 shadow implementation](https://github.com/mrdoob/three.js/blob/r180/src/nodes/lighting/ShadowNode.js)
- [r180 bloom implementation](https://github.com/mrdoob/three.js/blob/r180/examples/jsm/tsl/display/BloomNode.js)
- [Rapier JavaScript setup](https://rapier.rs/docs/user_guides/javascript/getting_started_js/)
- [Rapier colliders](https://rapier.rs/docs/user_guides/javascript/colliders/)
- [WebGPU secure context](https://developer.mozilla.org/en-US/docs/Web/API/WebGPU_API)

## License

The project source uses the MIT license. three.js and Rapier keep their own licenses.
