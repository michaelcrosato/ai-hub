# Strata 0.2 architecture

## World scale

World positions use metres. The voxel width remains 0.125 m in all four areas. Each chunk holds 16 × 16 × 16 material bytes. A cell is data, not a mesh object or a rigid body.

`VoxelWorld` stores chunks in a map. Negative world coordinates use floor division, not truncation. Cell edits mark nearby existing chunks dirty. The dirty set includes corner neighbours because vertex occlusion reads a one-cell border.

The area definitions use square bounds of 24, 64, 128, and 256 metres. Empty gaps between islands are part of those bounds. The gardens, towers, courts, and paths are actual voxel data. The ground presentation plane, water surfaces, sky, and cursor are separate rendering objects.

## Generation and area changes

`src/scene/areas.js` builds one central garden and zero to four square rings. The ring site counts are 4, 8, 12, and 16. This gives 1, 5, 13, and 41 total sites.

Each new site has a path connection to an earlier site. Paths use two axis-aligned segments and fixed foundation piers. The generator makes paths first. It then creates each garden and its local changes. Pool cuts remain open. The geometry tests check that no generated cell lies outside the area bounds.

The asynchronous generator yields between path links and gardens. Large areas do not require a single uninterrupted generation task. The mesh worker still performs surface and collision-data work.

An area change uses the edit transaction barrier. The engine stops physics, removes loose bodies, disposes old chunk meshes and fixed colliders, creates the new voxel world, and builds new chunk data. It then replaces water surfaces, emitter records, navigation locations, camera bounds, and the safety floor. The loading overlay hides partial builds.

Only one area is loaded. There is no cache of edited areas. Switching away from an area loses its edits. Graphics settings and current physics controls remain unchanged. The selected area's reset command rebuilds that area.

## Surfaces and collisions

The surface mesher removes hidden faces and joins compatible faces. Vertex attributes contain material colour, roughness, metalness, emission, and local occlusion. Local fragment geometry uses its own cell coordinates so surface variation stays attached to moving pieces.

Fixed terrain uses merged collision boxes. It can merge material boundaries because fixed terrain does not need material-derived mass. Loose fragments retain material boundaries in their boxes. Each fragment has one rigid body and several colliders. Density controls its computed mass and inertia.

The worker queue holds at most one mesh batch of 24 chunks at a time. Completed data is committed in batches while the caller keeps physics paused. This avoids a pending snapshot and promise for every chunk in Massive. Batch size is a temporary-memory rule, not a render-rate target.

A failed edit stops the application. It does not resume physics with incomplete collision data.

## Sparse support

The old dense world snapshot remains available for bounded algorithm tests and small fragment operations. Live world destruction now calls `snapshotSparse()` and the `support-sparse` worker job.

A sparse snapshot contains independent copies of occupied chunk buffers and their integer chunk coordinates. The worker can receive transferred snapshot buffers without detaching the live world's data.

The support solver builds six-neighbour chunk adjacency. It stores visited state in typed arrays and cell IDs in one integer queue. It starts from material-defined foundation cells and visits every connected occupied cell. It then separates unvisited cells into bounded fragments.

Empty gaps between islands do not need a dense bounding-box buffer. Support crosses chunk boundaries in all six directions. A missing neighbour is empty space, not an anchor. The solver handles negative coordinates.

Fragment limits remain 768 cells, a 16-cell span on each axis, and 96 colliders. Irregular fragments are split again when needed. These are rigid-body shape limits, not a computed crack model.

The support check still scans all loaded occupied chunks. It is not incremental. It is a connectivity test, not a solver for stress, bending, compression, or fatigue. Temporary data still scales with loaded chunks and occupied cells.

## Manual graphics

`src/engine/settings.js` is the single schema for 27 controls. It supplies slider ranges, display labels, value validation, and saved per-profile values. `src/ui/graphics-panel.js` builds the panel from that schema.

There are only two profiles. Mobile and Desktop provide starting values for the same controls. They do not restrict slider ranges. Browser storage keeps separate values for each profile. Missing, corrupt, or blocked storage falls back to valid defaults or session-only values.

The application has no FPS target, frame-rate limiter, adaptive resolution controller, maximum-pixel budget, or profile DPR ceiling. It renders on browser animation callbacks. The diagnostics can display measured FPS, but this measurement never changes quality.

Render scale multiplies the device pixel ratio. A reported texture or renderbuffer size limit can restrict the resulting drawing-buffer dimensions. The report records this condition. Shadow-map size also respects the reported device dimension limit.

Graphics changes update uniforms, camera values, lights, fog, render-target size, or bloom parameters. They do not change voxel size or collision geometry. Shader variants can still compile when lights or shadow state change.

## Lighting

The renderer uses three.js WebGPURenderer with a WebGL 2 fallback. The direct dependencies remain pinned to three.js r180 and Rapier 0.17.3.

A directional sun supplies the main light and one shadow region. Sun direction and height are editable. Shadow coverage follows the orbit target, not the camera position. It does not automatically expand for larger areas. Use the coverage slider for a wider shadow region.

A hemisphere light and a generated environment map supply indirect-looking light. The environment is a static sky gradient. It does not capture the live scene. It has no baked sun highlight that could conflict with the editable sun direction.

The material uniforms control corner occlusion, surface variation, roughness, metalness, and emission. Water uses shared roughness and ripple uniforms. Bloom strength zero bypasses post-processing. The bloom node is reused after it is created.

Local point lights come from a user-sized pool of 0 to 32 lamps. The engine selects nearby intact emitter cells around the orbit target. This is an explicit local-light count, not a hidden frame-time controller. Detached glowing fragments do not acquire point lights.

There is no ray tracing, live global illumination, screen-space reflection pass, or fluid simulation. The antialiasing setup and base sky colours remain fixed.

## Simulation and body lifetime

The physics step is 1/60 second. The fixed-step clock limits catch-up work after long browser pauses and reports dropped simulation time. This is independent of the display rate.

The graphics profile does not control the body limit. Physics controls expose a maximum loose-body count and debris lifetime. Zero lifetime means no age-based removal, but the body count and lower safety boundary still apply. Old body removal is not conservation of matter.

The safety floor follows the selected area's presentation-plane extent. Camera and Add-tool bounds also follow the selected area. Grid picking uses the current manual view distance rather than the original small-scene picking range.

## Main source files

| File | Purpose |
| --- | --- |
| `src/main.js` | Application lifecycle, controls, edit barrier, area changes |
| `src/scene/areas.js` | Area plans, paths, towers, courts, async generation |
| `src/scene/garden.js` | Original seeded garden |
| `src/engine/config.js` | World scale, simulation rules, two profiles |
| `src/engine/settings.js` | Slider schema, validation, browser storage |
| `src/ui/graphics-panel.js` | Accessible slider controls |
| `src/engine/renderer.js` | Render setup, manual settings, pooled lights |
| `src/engine/materials.js` | Shared shader uniforms, sky, water |
| `src/engine/chunks.js` | Bounded mesh jobs and collision commits |
| `src/voxel/support.js` | Dense fragment and sparse world connectivity |
| `src/engine/physics.js` | Rapier integration and loose bodies |
| `scripts/area-report.mjs` | Reproducible area geometry counts |

## Not included

There is no infinite-world streaming, mesh level of detail, saved world state, editor undo, character controller, multiplayer state, GPU physics, structural stress solver, joint editor, or soft-body solver. The real renderer and solver still need runtime and target-device checks for this release.
