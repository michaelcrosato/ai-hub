# Strata 0.2 validation

Validation date: 19 September 2026.

## Results

| Check | Result | Scope |
| --- | --- | --- |
| `npm test` | 57 passed; 0 failed | Voxel data, geometry, collision data, support, areas, settings, and fixed-step clock |
| `npm run check` | 33 JavaScript files passed | JavaScript syntax only |
| `npm run report:areas` | All four areas completed | CPU scene generation, support, triangle data, and merged collider data |
| `npm run test:ui` | 27 slider handlers and 6 layouts passed | Real control modules and HTML/CSS in an offline browser |
| Real Rapier runtime | Not run | Dependency package unavailable in the authoring environment |
| Full three.js renderer | Not run | Dependency package unavailable in the authoring environment |
| `npm run test:browser` | Not run | Requires the real engine packages and a running local server |
| Production build | Not run | Requires installed dependencies |
| S26 or RTX 4070 Super device run | Not run | No physical target-device measurement |

The package install was attempted. npm returned `EAI_AGAIN` for the package registry. This release must not be described as a verified WebGPU or target-device demo.

## Core test coverage

The original 32 tests still pass. They check meshing, winding, chunk borders, collision-box coverage, material mass calculations, grid picking, edit bounds, support, and fixed-step timing.

The 25 additional tests check:

- All four generated areas: stable cell counts, fixed voxel width, valid bounds, and no unsupported starting cells. They also check deterministic generation, asynchronous progress, and area selection.
- Sparse support: negative chunk borders in all six directions, agreement with dense support on 24 seeded random volumes, far-separated islands, safe snapshot copies, fragment limits, arch detachment, and invalid input.
- Settings: exactly two profiles, one slider for each graphics setting, valid defaults, range limits, saved per-profile values, blocked or corrupt storage, clear labels, and removal of the adaptive controller and FPS limiter.

The sparse-vs-dense checks compare detached cell coordinates and materials, not just the number of fragments. Fragment partition order can differ.

## Verified area data

| Area | Bounds | Gardens | Occupied voxels | Allocated chunks | Static voxel triangles | Static voxel collision boxes |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| Small | 24 × 24 m | 1 | 207,735 | 161 | 35,060 | 1,337 |
| Medium | 64 × 64 m | 5 | 1,095,745 | 1,072 | 191,842 | 7,347 |
| Large | 128 × 128 m | 13 | 2,891,962 | 3,165 | 505,754 | 19,821 |
| Massive | 256 × 256 m | 41 | 9,248,985 | 10,204 | 1,624,732 | 64,141 |

All four areas contain **zero unsupported cells at startup**. The voxel width is **0.125 m** throughout.

Bounds include spaces between terrain islands. Triangle counts exclude the sky, presentation plane, water surfaces, cursor, and loose bodies. Collision-box counts exclude the safety floor and loose bodies. These are generated data counts, not draw-call counts or solver performance results.

The raw material buffers for Massive total 41,795,584 bytes. This is not total engine memory. It excludes object metadata, visible meshes, worker copies, support state, collision data, GPU resources, and the Rapier runtime. No total-memory claim is made.

## Offline browser scope

The offline browser test loaded the real config, settings, and graphics-panel modules from local source into in-memory module URLs. It used the real HTML and CSS, with the application boot script removed. It did not load three.js, initialize WebGPU, or run Rapier.

Every graphics slider was moved to both ends of its range. The test checked the resulting numeric setting and accessible value label. It also checked that only Mobile and Desktop appear in the profile control and that all four area buttons exist.

The area controls, tool controls, and open settings panel fit at these sizes:

| Width | Height |
| ---: | ---: |
| 1440 | 900 |
| 1280 | 720 |
| 390 | 844 |
| 360 | 780 |
| 320 | 568 |
| 844 | 390 |

No browser script errors occurred in this offline scope. This does not validate shader compilation, visible slider effects, full application event wiring, real area switching, or the physics integration.

## Remaining runtime checks

Run the real browser and solver tests after a successful dependency install. Check both renderer backends, shadow-map changes, bloom, water shaders, light-pool resizing, repeated area changes, and graphics-profile persistence. Check terrain destruction and moving-body response on the target devices.

There is no FPS target in this release. Correct control behaviour, valid geometry, reliable area changes, and clear failure states are the relevant checks.

## Raw records

- [Core test output](core-tests.txt)
- [Syntax check output](syntax-check.txt)
- [Area data report](area-report.json)
- [Offline controls and layout report](ui-layout-results.json)
- [Device check procedure](DEVICE_TEST.md)
