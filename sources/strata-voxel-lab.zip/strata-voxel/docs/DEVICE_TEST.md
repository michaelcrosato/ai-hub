# Strata 0.2 device checks

These checks concern correct operation and manual control. They do not set FPS targets or pass/fail frame-time budgets.

## Prepare

Install the pinned npm dependencies. Start the development server. Use trusted HTTPS on the phone, or USB port reversal to localhost. Start with `?profile=mobile&area=small`. Check that the backend label is correct. Export the initial report.

The authoring environment did not run the real renderer, Rapier solver, or a target-device build. Perform these checks before treating this release as a working device demo.

## Graphics controls

Open the settings panel. Confirm that Mobile and Desktop are the only profiles. Confirm that all six graphics groups are available: Image, Light, Shadows, Surface, Atmosphere, and Water.

Move each slider. Check the displayed number and the visible effect. Set shadow-map size, bloom strength, fog density, and local lamp count to zero in separate checks. Confirm that the intended effect turns off. Restore it and check that the effect returns without a scene reset.

Change exposure, sun direction, sun height, corner occlusion, roughness, and emission. Check fixed terrain and loose pieces. The surface pattern must stay attached to a moving piece. Water controls must affect every pool in the selected area.

Change render scale. Check the drawing-buffer dimensions in Diagnostics. Leave the scene active and confirm that the scale does not change by itself. Change the browser size or phone orientation and confirm that the selected percentage stays the same.

Use a large shadow-map value with care. The application only limits it to a reported hardware dimension. A valid dimension does not guarantee sufficient memory. Check the actual map size in the exported report.

Check shadow coverage while you pan between gardens. The region follows the orbit target. Distant terrain outside that region can remain unshadowed. Increase coverage manually for wider shadows.

## Profile state

Set a distinct exposure in Mobile and a different exposure in Desktop. Switch between profiles. Each profile must restore its own value. Change the profile's other controls and repeat.

Reload the page with no profile query. Check that saved profile values return when browser storage is available. Use Restore defaults and confirm that only the selected profile changes. Check session-only behaviour when storage is blocked.

## Area state

Load Small, Medium, Large, and Massive. Expected occupied static voxel counts are 207,735; 1,095,745; 2,891,962; and 9,248,985. These counts apply before edits and moving-body damage.

Confirm that each area has 1, 5, 13, or 41 locations in the navigation list. Select distant gardens. Test Overview and Home. A short manual view distance can clip the overview; raise that value when necessary.

Break an arch and drop a block. Switch areas while the scene contains loose pieces. The old pieces and edits must be removed. Water surfaces and lamps must not accumulate from the previous area. Graphics settings and current physics controls must stay the same.

Reset Large or Massive. The engine must reset that area, not Small. Check repeated Small-to-Massive-to-Small switches for stale colliders, old water surfaces, and a growing resource count. A fully loaded Massive area requires much more memory than Small; render scale does not change the voxel data size.

## Physics

Break both sides of an arch. The upper section must detach. Test structures across chunk borders and at distant sites. The support check must not treat an empty gap or unloaded neighbour as an anchor.

Place a block near the map edge. The Add tool must respect that area's bounds. Try a placement near a moving body. It must not create a fixed block inside the body.

Set debris lifetime to zero. Confirm that age alone does not remove pieces. Then lower the body limit and confirm that the engine removes excess bodies. Return to a nonzero lifetime and check age-based removal. These controls must not change when the graphics profile changes.

Pause physics. Camera and graphics controls must remain available. Resume, hide the browser briefly, and return. The fixed-step clock must recover without an unbounded catch-up loop.

## Backends and errors

Repeat the main controls in WebGPU and with `?backend=webgl`. Check shader compilation, bloom, water, shadow-size changes, and lamp-count changes on both backends. The offline controls test cannot establish that these GPU paths work.

Check a blocked dependency request and a lost graphics device. The error panel must show a useful message instead of leaving a working-looking frozen scene.

## Record

Export a device report after each area. Record the device, browser, backend, chosen graphics settings, visible defects, and any crash. Diagnostic timings are useful observations, but there is no required FPS value in this release.
