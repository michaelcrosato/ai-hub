# Changes from 0.1 to 0.2

## User controls

Removed the Battery profile, FPS targets, render-rate gate, adaptive resolution controller, maximum-pixel limits, and profile DPR ceilings.

Added 27 graphics sliders and separate saved values for Mobile and Desktop. Added manual loose-body and debris-lifetime controls. Graphics profiles no longer control the physics body limit.

## Areas

Kept the original garden as Small. Added Medium, Large, and Massive with real voxel sites, towers, courts, pools, and supported paths. Kept the 12.5 cm voxel size.

Added area buttons, garden navigation, Overview, area-specific build bounds, a larger picking range, camera bounds, and matching safety-floor extents. Area switching clears old geometry, colliders, water, emitter records, edits, and loose bodies.

## World support

Added sparse chunk support and independent transferable snapshots. Large empty gaps no longer consume a dense world support buffer. Mesh work now uses bounded batches of 24 chunks.

## Validation

Added 25 core tests, bringing the total to 57. Expanded the offline browser check to all 27 slider handlers and six screen sizes. Added a reproducible area report and an optional real-browser smoke test.

The full three.js and Rapier runtime remains unverified in the authoring environment because dependencies could not be downloaded.
