# The Hush CLI — semantic arcade presentation

## North star

**Fiction stays quiet. The system hits hard.**

The prose is the world and remains the largest, calmest surface. The interface borrows the impact grammar of a versus-game broadcast—rails, meters, hit banners, phase calls, compact badges—but spends that energy only when the player-visible state changes.

The UI is not allowed to infer game truth from prose. It reads the masked player observation before and after a command, then presents the difference. The engine still decides; the narrator still reports; the CLI only stages what the player is permitted to know.

## Semantic palette

| Channel              |        Colour |         Symbol | Used for                                         |
| -------------------- | ------------: | -------------: | ------------------------------------------------ |
| Space / navigation   | electric cyan |      `◆` / `➜` | location, exits, clock, neutral system structure |
| Anomaly / law        |   hot magenta |           `⚡` | law contact, drift, night-law pressure           |
| Evidence / knowledge |   acid yellow |            `✦` | tells, codex progress, clarification             |
| Danger / cost        |    signal red |            `⚠` | nerve loss, exposure, item failure, alert, loss  |
| Boon / clearance     |  arcade green |            `✓` | recovery, acquired gear, open route, victory     |
| Metadata             |  neutral grey | compact labels | seed, turn, help, non-diegetic status            |

Colour is always redundant with a word, icon, or meter. `NO_COLOR`, `LOOM_NOCOLOR`, `--no-color`, `--ascii`, and `--plain` remain first-class modes.

## Intensity budget

A normal turn gets prose plus the compact HUD. A consequential turn may get **one** major impact banner. Additional changes become small badges beneath it. This prevents every command from shouting and preserves contrast for the moments that matter.

Priority order:

1. outcome or condition change;
2. nerve/exposure cost;
3. law contact, law mastered, or drift;
4. phase shift, patrol alert, route clearance;
5. item failure/loss and new evidence;
6. economy, inventory, and parser feedback.

Movement alone does not receive a hit banner; the new location is already clear in the HUD and scene heading.

## HUD contract

The persistent state strip contains only immediately actionable, player-visible information:

- location, phase, clock, turn;
- **NERVE**, derived as `5 - unsettled`, using the module's existing 0–5 clamp;
- exposure and survival/outcome;
- codex laws read/known and signs collected;
- gear count, coins, and visible exits.

The HUD deliberately does not show whether an undiscovered rotating law is live, private scheduler state, module-native values, or author-role facts.

## Parser onboarding

`help` teaches safe, universal verbs. `hint` is contextual and filters the current legal-action surface to navigation, looking, examining, listening, searching, and talking.

Dangerous or discovery-bearing verbs are not auto-advertised. The interface therefore improves first-contact usability without dissolving the game's hidden-verb dread.

## Terminal behaviour

- Width is clamped to 48–116 columns and prose is reflowed before the terminal can split words.
- Existing narrative ANSI is normalized into scene headings, quiet regional texture, affordance lines, and outcome lines.
- The terminal tab title tracks visible location and time.
- Interactive runs clear the screen once; `--no-clear` and `LOOM_NO_CLEAR` preserve shell scrollback.
- Redirected output is plain by default, so transcripts and CI logs remain clean.
- No animation, bell, or cursor choreography is used on ordinary turns. Those effects consume attention and would flatten the meaning hierarchy.

## Acceptance checks

- No UI code writes game state or imports kernel internals.
- An unknown law cannot appear merely because `law.<id>.live` exists in author state.
- A rejected command produces no fake cost and explicitly says no time passed.
- A turn with several changes renders at most one major banner.
- Safe hints never volunteer `look back`, `say <name>`, `wait`, or `rest`.
- Plain mode contains no ANSI escape sequences.
