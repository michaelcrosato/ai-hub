/**
 * The playable CLI — a forgiving free-text REPL over a deterministic Session.
 * Game state remains owned by Session; the electric HUD is a presentation-only
 * diff over the masked player observation.
 *
 *   npm run play
 *   npm run play -- --seed cordon-7
 *   npm run play -- --load saves/run.json
 *   npm run play -- --plain        # no colour, symbols, or screen clear
 *   npm run play -- --ascii        # colour, ASCII symbols
 */
import { createInterface } from 'node:readline';
import { readFileSync, writeFileSync, mkdirSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { HUSH_PACK } from '../../content/hush/index.js';
import { createGame } from '../game/assemble.js';
import { Session } from '../game/session.js';
import { ArcadeUi, diffSnapshots, snapshotOf } from './ui.js';

function arg(name: string): string | undefined {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? process.argv[i + 1] : undefined;
}

function makeSession(): Session {
  const loadPath = arg('load');
  if (loadPath) {
    const data = JSON.parse(readFileSync(loadPath, 'utf8')) as { seed: string };
    const game = createGame(HUSH_PACK, data.seed);
    const session = new Session(game);
    // (replaying the saved golden tape to restore state is wired in M8; for now re-seed fresh)
    return session;
  }
  const seed = arg('seed') ?? 'cordon-1';
  return new Session(createGame(HUSH_PACK, seed));
}

async function main() {
  const session = makeSession();
  const ui = new ArcadeUi();
  const out = (text = '') => process.stdout.write(text + '\n');
  let current = snapshotOf(session);

  if (ui.config.clearOnStart) ui.clear();
  out(ui.intro(current, session.opening()));
  ui.setTerminalTitle(current);

  const rl = createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: ui.prompt(current),
    historySize: 100,
    removeHistoryDuplicates: true,
  });

  const reprompt = () => {
    rl.setPrompt(ui.prompt(current));
    rl.prompt();
  };

  reprompt();

  rl.on('line', (raw) => {
    const line = raw.trim();
    const lower = line.toLowerCase();
    if (!line) return reprompt();

    if (lower === 'quit' || lower === 'exit' || lower === 'q') {
      out('');
      out(ui.quit());
      rl.close();
      return;
    }
    if (lower === 'help' || lower === '?') {
      out('');
      out(ui.help());
      return reprompt();
    }
    if (lower === 'hint') {
      out('');
      out(ui.hint(current));
      return reprompt();
    }
    if (lower === 'status' || lower === 'hud') {
      out('');
      out(ui.status(current));
      return reprompt();
    }
    if (lower === 'codex') {
      out('');
      out(ui.codex(session.codex()));
      return reprompt();
    }
    if (lower === 'inventory' || lower === 'i' || lower === 'inv') {
      out('');
      out(ui.inventory(current));
      return reprompt();
    }
    if (lower === 'map') {
      out('');
      out(ui.map(current));
      return reprompt();
    }
    if (lower === 'seed') {
      out('');
      out(ui.seed(session.game.seed));
      return reprompt();
    }
    if (lower === 'clear' || lower === 'cls') {
      ui.clear();
      out(ui.status(current));
      return reprompt();
    }
    if (lower.startsWith('save')) {
      const file = line.split(/\s+/)[1] ?? 'saves/run.json';
      const dir = resolve(file, '..');
      if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
      writeFileSync(file, session.save());
      out('');
      out(ui.saved(file));
      return reprompt();
    }

    const before = current;
    const result = session.act(line);
    current = snapshotOf(session);
    const beats = diffSnapshots(before, current, result);

    out('');
    out(ui.turn(result.text, beats, current));
    ui.setTerminalTitle(current);
    reprompt();
  });

  rl.on('close', () => process.exit(0));
}

main().catch((error: unknown) => {
  console.error(error);
  process.exit(1);
});
