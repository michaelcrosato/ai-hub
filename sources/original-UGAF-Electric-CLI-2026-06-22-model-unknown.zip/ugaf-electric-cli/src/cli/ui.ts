/**
 * The human CLI presentation layer.
 *
 * The kernel and Session remain authoritative. This file reads only the masked
 * player observation, takes a before/after snapshot, and turns visible changes
 * into an arcade-style HUD. Colour and symbols are semantic: prose stays quiet;
 * the interface becomes loud only when a law, cost, clue, phase, or outcome lands.
 */
import type { Session, TurnResult } from '../game/session.js';

export type UiTone = 'info' | 'law' | 'clue' | 'danger' | 'boon' | 'neutral';

export interface UiConfig {
  readonly color?: boolean;
  readonly unicode?: boolean;
  readonly width?: number;
  readonly clearOnStart?: boolean;
}

export interface UiAction {
  readonly label: string;
  readonly intent: string;
}

export interface UiItemState {
  readonly id: string;
  readonly label: string;
  readonly condition?: string;
}

export interface UiLawState {
  readonly id: string;
  readonly title: string;
  readonly stage: string;
  readonly witnessed: boolean;
  readonly contacts: number;
  readonly driftWarned: boolean;
  readonly tellCount: number;
  readonly tellGoal: number;
  readonly latestTell?: string;
}

export interface UiSignals {
  readonly hidden: boolean;
  readonly interceptClear: boolean;
  readonly awareness: Readonly<Record<string, string>>;
}

export interface UiSnapshot {
  readonly seed: string;
  readonly turn: number;
  readonly ended: boolean;
  readonly outcome: 'active' | 'won' | 'lost' | 'ended';
  readonly location: string;
  readonly phase: string;
  readonly time: string;
  readonly survival: string;
  readonly unsettled: number;
  readonly nerve: number;
  readonly exposure: number;
  readonly coins: number;
  readonly objective?: string;
  readonly exits: readonly string[];
  readonly actions: readonly UiAction[];
  readonly inventory: readonly UiItemState[];
  readonly laws: readonly UiLawState[];
  readonly signals: UiSignals;
}

export interface UiBeat {
  readonly tone: UiTone;
  readonly label: string;
  readonly detail: string;
  readonly priority: number;
}

type TurnPresentation = Pick<TurnResult, 'status' | 'rejected' | 'clarify'>;

const ANSI_RE = /\x1b\[[0-?]*[ -/]*[@-~]/g;
const NERVE_MAX = 5;
const STAGE_RANK: Readonly<Record<string, number>> = {
  unknown: 0,
  referenced: 1,
  approximate: 2,
  surveyed: 3,
};

const TONE_FG: Readonly<Record<UiTone, number>> = {
  info: 51,
  law: 201,
  clue: 226,
  danger: 196,
  boon: 46,
  neutral: 250,
};

const TONE_BG: Readonly<Record<UiTone, number>> = {
  info: 45,
  law: 201,
  clue: 226,
  danger: 196,
  boon: 46,
  neutral: 250,
};

interface Glyphs {
  readonly bolt: string;
  readonly clue: string;
  readonly danger: string;
  readonly heart: string;
  readonly exposure: string;
  readonly location: string;
  readonly clock: string;
  readonly codex: string;
  readonly bag: string;
  readonly coin: string;
  readonly arrow: string;
  readonly target: string;
  readonly check: string;
  readonly death: string;
  readonly prompt: string;
  readonly objective: string;
  readonly separator: string;
  readonly rail: string;
  readonly fill: string;
  readonly empty: string;
  readonly bullet: string;
}

const UNICODE_GLYPHS: Glyphs = {
  bolt: '⚡',
  clue: '✦',
  danger: '⚠',
  heart: '♥',
  exposure: '☣',
  location: '◆',
  clock: '◷',
  codex: '⌁',
  bag: '▣',
  coin: '●',
  arrow: '➜',
  target: '◎',
  check: '✓',
  death: '☠',
  prompt: '❯',
  objective: '◈',
  separator: ' // ',
  rail: '━',
  fill: '■',
  empty: '·',
  bullet: '•',
};

const ASCII_GLYPHS: Glyphs = {
  bolt: '*',
  clue: '+',
  danger: '!',
  heart: 'HP',
  exposure: 'EX',
  location: '@',
  clock: 'T',
  codex: '#',
  bag: '[]',
  coin: 'o',
  arrow: '->',
  target: 'O',
  check: 'OK',
  death: 'X',
  prompt: '>',
  objective: '*',
  separator: ' // ',
  rail: '=',
  fill: '#',
  empty: '.',
  bullet: '-',
};

class Painter {
  constructor(private readonly enabled: boolean) {}

  fg(tone: UiTone, text: string): string {
    return this.enabled ? `\x1b[38;5;${TONE_FG[tone]}m${text}\x1b[0m` : text;
  }

  bold(text: string): string {
    return this.enabled ? `\x1b[1m${text}\x1b[0m` : text;
  }

  dim(text: string): string {
    return this.enabled ? `\x1b[2m${text}\x1b[0m` : text;
  }

  badge(tone: UiTone, text: string): string {
    if (!this.enabled) return `[ ${text} ]`;
    return `\x1b[1;38;5;16;48;5;${TONE_BG[tone]}m ${text} \x1b[0m`;
  }

  gradient(text: string): string {
    if (!this.enabled) return text;
    const colors = [51, 201, 226, 201] as const;
    let visibleIndex = 0;
    let out = '';
    for (const char of Array.from(text)) {
      if (/\s/.test(char)) {
        out += char;
      } else {
        out += `\x1b[1;38;5;${colors[visibleIndex % colors.length]}m${char}\x1b[0m`;
        visibleIndex += 1;
      }
    }
    return out;
  }
}

export function detectUiConfig(
  argv: readonly string[] = process.argv.slice(2),
  env: NodeJS.ProcessEnv = process.env,
): Required<UiConfig> {
  const plain = argv.includes('--plain') || env.LOOM_UI === 'plain';
  const tty = process.stdout.isTTY === true;
  const color =
    !plain &&
    tty &&
    !argv.includes('--no-color') &&
    env.NO_COLOR === undefined &&
    env.LOOM_NOCOLOR === undefined &&
    env.TERM !== 'dumb';
  const unicode = !plain && !argv.includes('--ascii') && env.LOOM_ASCII === undefined && env.TERM !== 'dumb';
  const requestedWidth = Number(env.LOOM_COLUMNS);
  const terminalWidth = Number.isFinite(requestedWidth) && requestedWidth > 0 ? requestedWidth : process.stdout.columns;
  const width = clamp(Math.floor(terminalWidth || 92), 48, 116);
  const clearOnStart =
    !plain && tty && !argv.includes('--no-clear') && env.LOOM_NO_CLEAR === undefined && env.TERM !== 'dumb';
  return { color, unicode, width, clearOnStart };
}

/** Build a presentation snapshot from the MASKED player observation only. */
export function snapshotOf(session: Session): UiSnapshot {
  const obs = session.obs('player');
  const facts: Readonly<Record<string, unknown>> = obs.facts;
  const self: Readonly<Record<string, unknown>> = obs.self;
  const pack = session.game.pack;

  const inventory: UiItemState[] = Object.keys(facts)
    .filter(
      (key) =>
        key.startsWith('possession.pc.') &&
        !key.endsWith('.class') &&
        !key.endsWith('.condition') &&
        facts[key] === true,
    )
    .map((key) => key.slice('possession.pc.'.length))
    .map((id) => {
      const item = pack.items.find((candidate) => candidate.id === id);
      const condition = stringAt(facts, `possession.pc.${id}.condition`);
      return {
        id,
        label: item?.names[0] ?? humanize(id),
        ...(condition ? { condition } : {}),
      };
    })
    .sort((a, b) => a.label.localeCompare(b.label));

  const tellById = new Map(pack.tellLibrary.map((tell) => [tell.id, tell]));
  const laws: UiLawState[] = [];
  for (const law of pack.laws) {
    const witnessed = boolAt(facts, `law.${law.id}.witnessed`);
    const contacts = numberAt(facts, `law.${law.id}.contacts`) ?? 0;
    const driftWarned = boolAt(facts, `law.${law.id}.drift_warned`);
    const tellIds = law.tells.filter((tell) => boolAt(facts, `known.tell.${tell.id}`)).map((tell) => tell.id);
    const rawStage = stringAt(facts, `known.law.${law.id}`);
    const stage = rawStage ?? (witnessed || contacts > 0 ? 'referenced' : 'unknown');
    const visible = stage !== 'unknown' || witnessed || contacts > 0 || driftWarned || tellIds.length > 0;
    if (!visible) continue;
    const latestTellId = tellIds.at(-1);
    const latestTell = latestTellId ? tellById.get(latestTellId)?.cue : undefined;
    laws.push({
      id: law.id,
      title: law.title,
      stage,
      witnessed,
      contacts,
      driftWarned,
      tellCount: tellIds.length,
      tellGoal: law.discovery.minTellsToSurvey,
      ...(latestTell ? { latestTell } : {}),
    });
  }

  const awareness: Record<string, string> = {};
  for (const [key, value] of Object.entries(facts)) {
    if (key.startsWith('awareness.') && typeof value === 'string') awareness[key] = value;
  }

  const unsettled = clamp(
    Math.floor(numberAt(self, 'unsettled') ?? numberAt(facts, 'survival.pc.unsettled') ?? 0),
    0,
    NERVE_MAX,
  );
  const minutes = numberAt(facts, 'clock.minutes') ?? 0;
  const time = stringAt(facts, 'clock.tod') ?? formatClock(minutes);
  const objective = stringAt(facts, 'objective.lead');

  return {
    seed: session.game.seed,
    turn: obs.turn,
    ended: session.isEnded(),
    outcome: session.outcome(),
    location: obs.scene.title,
    phase: stringAt(facts, 'phase.now') ?? obs.scene.phase ?? 'unknown',
    time,
    survival: stringAt(self, 'survival') ?? stringAt(facts, 'survival.pc') ?? 'alive',
    unsettled,
    nerve: clamp(NERVE_MAX - unsettled, 0, NERVE_MAX),
    exposure: Math.max(0, Math.floor(numberAt(self, 'exposure') ?? numberAt(facts, 'survival.pc.exposure') ?? 0)),
    coins: Math.max(0, Math.floor(numberAt(facts, 'meta.coins') ?? 0)),
    ...(objective ? { objective } : {}),
    exits: obs.scene.exits.map((exit) => exit.label),
    actions: obs.legalActions.map((action) => ({
      label: action.label,
      intent: action.intent,
    })),
    inventory,
    laws,
    signals: {
      hidden: boolAt(facts, 'flag.hidden'),
      interceptClear: boolAt(facts, 'flag.intercept_clear'),
      awareness,
    },
  };
}

/** Translate visible before/after changes into a small number of semantic UI beats. */
export function diffSnapshots(before: UiSnapshot, after: UiSnapshot, result: TurnPresentation): UiBeat[] {
  const beats: UiBeat[] = [];
  const add = (tone: UiTone, label: string, detail: string, priority: number) =>
    beats.push({ tone, label, detail, priority });

  if (result.status === 'won') add('boon', 'VICTORY', 'THE CORE CROSSED THE WIRE', 120);
  if (result.status === 'lost') add('danger', 'RUN OVER', 'THE HUSH KEPT ITS LAW', 120);
  if (after.survival !== before.survival && after.survival !== 'alive') {
    add('danger', 'CONDITION', after.survival.toUpperCase(), 115);
  }

  const nerveDelta = after.nerve - before.nerve;
  if (nerveDelta < 0) {
    add('danger', 'NERVE HIT', `${signed(nerveDelta)} // ${after.nerve}/${NERVE_MAX} REMAINS`, 96);
  } else if (nerveDelta > 0) {
    add('boon', 'NERVE RECOVERED', `${signed(nerveDelta)} // ${after.nerve}/${NERVE_MAX}`, 62);
  }

  const exposureDelta = after.exposure - before.exposure;
  if (exposureDelta > 0) add('danger', 'EXPOSURE', `+${exposureDelta} // TOTAL ${after.exposure}`, 94);
  if (exposureDelta < 0) add('boon', 'EXPOSURE CLEARED', `${signed(exposureDelta)} // TOTAL ${after.exposure}`, 60);

  const beforeLaws = new Map(before.laws.map((law) => [law.id, law]));
  for (const law of after.laws) {
    const prior = beforeLaws.get(law.id);
    const priorContacts = prior?.contacts ?? 0;
    if (law.contacts > priorContacts) {
      add('law', 'LAW CONTACT', `${law.title.toUpperCase()} // CONTACT ${law.contacts}`, 92);
    }

    const priorRank = STAGE_RANK[prior?.stage ?? 'unknown'] ?? 0;
    const nextRank = STAGE_RANK[law.stage] ?? priorRank;
    if (nextRank > priorRank) {
      const label =
        law.stage === 'surveyed' ? 'LAW READ TRUE' : law.stage === 'approximate' ? 'PATTERN LOCKING' : 'SIGN LOGGED';
      const tone: UiTone = law.stage === 'surveyed' ? 'boon' : 'clue';
      add(tone, label, `${law.title.toUpperCase()} // ${law.stage.toUpperCase()}`, law.stage === 'surveyed' ? 91 : 78);
    }

    const priorTells = prior?.tellCount ?? 0;
    if (law.tellCount > priorTells) {
      const cue = law.latestTell ? truncate(law.latestTell, 66) : `${law.tellCount}/${law.tellGoal} SIGNS`;
      add('clue', 'SIGN READ', `${law.title.toUpperCase()} // ${cue}`, 76);
    }

    if (law.driftWarned && !prior?.driftWarned) {
      add('law', 'READING UNSTABLE', `${law.title.toUpperCase()} // VERIFY AGAIN`, 89);
    }
  }

  if (before.phase !== after.phase) {
    const dangerous = after.phase === 'dusk' || after.phase === 'night';
    add(dangerous ? 'danger' : 'info', 'PHASE SHIFT', `${after.phase.toUpperCase()} // ${after.time}`, 84);
  } else if (after.phase === 'day') {
    const beforeMinute = parseClock(before.time);
    const afterMinute = parseClock(after.time);
    if (beforeMinute !== undefined && afterMinute !== undefined && afterMinute >= beforeMinute) {
      const beforeLeft = 18 * 60 - beforeMinute;
      const afterLeft = 18 * 60 - afterMinute;
      if (beforeLeft > 25 && afterLeft <= 25) {
        add('danger', 'DAYLIGHT CRITICAL', `${Math.max(0, afterLeft)} MINUTES TO DUSK`, 87);
      } else if (beforeLeft > 60 && afterLeft <= 60) {
        add('danger', 'DAYLIGHT LOW', `${Math.max(0, afterLeft)} MINUTES TO DUSK`, 80);
      }
    }
  }

  const beforeItems = new Map(before.inventory.map((item) => [item.id, item]));
  const afterItems = new Map(after.inventory.map((item) => [item.id, item]));
  for (const item of before.inventory) {
    if (!afterItems.has(item.id)) add('danger', 'GEAR LOST', item.label.toUpperCase(), 72);
  }
  for (const item of after.inventory) {
    const prior = beforeItems.get(item.id);
    if (!prior) add('boon', 'GEAR ACQUIRED', item.label.toUpperCase(), 58);
    if (prior && prior.condition !== item.condition && item.condition) {
      add(
        item.condition === 'ore' ? 'danger' : 'clue',
        'GEAR CONDITION',
        `${item.label.toUpperCase()} // ${item.condition.toUpperCase()}`,
        74,
      );
    }
  }

  const coinDelta = after.coins - before.coins;
  if (coinDelta < 0) add('danger', 'COINS SPENT', `${signed(coinDelta)} // ${after.coins} LEFT`, 48);
  if (coinDelta > 0) add('boon', 'COINS GAINED', `${signed(coinDelta)} // ${after.coins} HELD`, 48);

  if (!before.signals.hidden && after.signals.hidden) add('boon', 'VANISHED', 'THE WATCH LOST YOU', 82);
  if (!before.signals.interceptClear && after.signals.interceptClear)
    add('boon', 'WAY OPEN', 'THE WIRE IS BEHIND YOU', 88);

  const awarenessRank: Readonly<Record<string, number>> = {
    unaware: 0,
    suspicious: 1,
    alert: 2,
    searching: 3,
  };
  for (const [key, value] of Object.entries(after.signals.awareness)) {
    const prior = before.signals.awareness[key] ?? 'unaware';
    if ((awarenessRank[value] ?? 0) > (awarenessRank[prior] ?? 0)) {
      add('danger', 'PATROL ALERT', value.toUpperCase(), 86);
    }
  }

  if (before.objective !== after.objective && after.objective) {
    add('info', 'OBJECTIVE UPDATED', truncate(after.objective, 72), 68);
  }

  if (result.clarify) add('clue', 'TARGET REQUIRED', result.clarify.question, 52);
  if (result.rejected && beats.length === 0)
    add('neutral', 'INPUT NOT COMMITTED', 'NO TIME PASSED // TRY ANOTHER PHRASING', 24);

  return uniqueBeats(beats).sort((a, b) => b.priority - a.priority);
}

export class ArcadeUi {
  readonly config: Required<UiConfig>;
  private readonly paint: Painter;
  private readonly glyph: Glyphs;

  constructor(config: UiConfig = detectUiConfig()) {
    const detected = detectUiConfig();
    this.config = {
      color: config.color ?? detected.color,
      unicode: config.unicode ?? detected.unicode,
      width: clamp(Math.floor(config.width ?? detected.width), 48, 116),
      clearOnStart: config.clearOnStart ?? detected.clearOnStart,
    };
    this.paint = new Painter(this.config.color);
    this.glyph = this.config.unicode ? UNICODE_GLYPHS : ASCII_GLYPHS;
  }

  clear(): void {
    if (process.stdout.isTTY) process.stdout.write('\x1b[2J\x1b[H');
  }

  setTerminalTitle(snapshot: UiSnapshot): void {
    if (!process.stdout.isTTY || process.env.TERM === 'dumb') return;
    const title = `The Hush — ${snapshot.location} — ${snapshot.phase} ${snapshot.time}`.replace(
      /[\x00-\x1f\x7f]/g,
      '',
    );
    process.stdout.write(`\x1b]0;${title}\x07`);
  }

  intro(snapshot: UiSnapshot, openingText: string): string {
    const versus = `${this.paint.fg('info', 'PLAYER')} ${this.paint.badge('danger', 'VS')} ${this.paint.fg('law', 'THE ZONE')}`;
    const runMeta = `RUN 01${this.glyph.separator}SEED ${snapshot.seed}${this.glyph.separator}DETERMINISTIC`;
    const lines = [
      this.rail(`${this.glyph.bolt} LOOM // THE HUSH`, 'law'),
      '',
      this.center(this.paint.gradient(`T H E   H U S H`)),
      this.center(versus),
      this.center(this.paint.dim(runMeta)),
      '',
    ];
    if (snapshot.objective) lines.push(this.objective(snapshot.objective), '');
    lines.push(this.renderNarrative(openingText), '', this.hud(snapshot), '', this.commandFooter());
    return lines.join('\n');
  }

  turn(text: string, beats: readonly UiBeat[], snapshot: UiSnapshot): string {
    const sections = [this.renderNarrative(text)];
    const beatBlock = this.beats(beats);
    if (beatBlock) sections.push(beatBlock);
    sections.push(this.hud(snapshot));
    if (snapshot.ended) sections.push(this.paint.dim('END OF RUN // type `quit` to leave'));
    return sections.filter(Boolean).join('\n\n');
  }

  help(): string {
    const rows: readonly [string, string][] = [
      ['MOVE', 'go <way> · a direction · back'],
      ['READ', 'look · examine <thing> · listen · search'],
      ['HANDLE', 'take <thing> · drop <thing> · use <thing> · give <thing>'],
      ['SPEAK', 'talk to <name> · ask <name> about <topic>'],
      ['THINK', 'deduce <law> · codex'],
      ['SYSTEM', 'inventory · map · status · hint · save [file] · seed · clear · quit'],
    ];
    const lines = [
      this.rail(`${this.glyph.target} COMMAND LIST`, 'info'),
      this.paint.dim(
        'Type intent in plain words. The examples below are safe, universal verbs — not the whole verb-space.',
      ),
      '',
    ];
    for (const [label, commands] of rows) {
      const prefix = this.paint.badge(label === 'THINK' ? 'clue' : 'info', label);
      lines.push(...this.wrapStyled(`${prefix}  ${commands}`, 0));
    }
    lines.push(
      '',
      this.paint.fg('law', `${this.glyph.bolt} The Hush is lawful.`) +
        ' Read its tells, name the pattern, and trust observed evidence over rumour.',
      this.paint.dim(
        'Some actions are dangerous precisely because the world can hear or answer them. The world will teach those verbs.',
      ),
    );
    return lines.join('\n');
  }

  hint(snapshot: UiSnapshot): string {
    const safe = unique(
      snapshot.actions
        .filter((action) => isSafeSuggestion(action))
        .map((action) => action.label)
        .filter((label) => !/\b(look back|say|wait|rest|name)\b/i.test(label)),
    ).slice(0, 6);
    const options = safe.length ? safe : ['look around', 'examine something named in the scene', 'check the map'];
    return [
      this.rail(`${this.glyph.clue} SAFE READ`, 'clue'),
      this.paint.dim('Useful now; deliberately not exhaustive.'),
      '',
      ...options.map((option) => `  ${this.paint.fg('clue', this.glyph.arrow)} ${option}`),
    ].join('\n');
  }

  map(snapshot: UiSnapshot): string {
    const lines = [this.rail(`${this.glyph.location} ROUTES // ${snapshot.location.toUpperCase()}`, 'info')];
    if (!snapshot.exits.length) lines.push(this.paint.dim('  No obvious way out.'));
    for (const exit of snapshot.exits) lines.push(`  ${this.paint.fg('info', this.glyph.arrow)} ${exit}`);
    return lines.join('\n');
  }

  inventory(snapshot: UiSnapshot): string {
    const lines = [this.rail(`${this.glyph.bag} LOADOUT`, 'info')];
    if (!snapshot.inventory.length) {
      lines.push(this.paint.dim('  Nothing of note.'));
    } else {
      for (const item of snapshot.inventory) {
        const condition = item.condition
          ? ` ${this.paint.fg(item.condition === 'ore' ? 'danger' : 'clue', `[${item.condition.toUpperCase()}]`)}`
          : '';
        lines.push(`  ${this.paint.fg('info', this.glyph.bullet)} ${item.label}${condition}`);
      }
    }
    lines.push('', `  ${this.paint.fg('clue', this.glyph.coin)} COINS // ${snapshot.coins}`);
    return lines.join('\n');
  }

  codex(raw: string): string {
    const lines = stripAnsi(raw).split(/\r?\n/);
    const out = [this.rail(`${this.glyph.codex} LAW CODEX`, 'clue')];
    for (const source of lines) {
      const line = source.trimEnd();
      if (!line || /^THE LAW CODEX$/i.test(line.trim())) continue;
      const trimmed = line.trimStart();
      if (trimmed.startsWith('⚠') || trimmed.startsWith('!')) {
        out.push(...this.wrapPlain(trimmed, 2).map((part) => this.paint.fg('danger', part)));
      } else if (trimmed.startsWith('✓') || trimmed.startsWith('OK')) {
        out.push(...this.wrapPlain(trimmed, 2).map((part) => this.paint.fg('boon', part)));
      } else if (/^[•*-]\s/.test(trimmed)) {
        out.push(...this.wrapPlain(trimmed, 2).map((part) => this.paint.fg('clue', part)));
      } else if (/^Rumours/i.test(trimmed)) {
        out.push('', this.paint.fg('law', this.paint.bold(trimmed)));
      } else if (/^[–-]\s/.test(trimmed)) {
        out.push(...this.wrapPlain(trimmed, 2).map((part) => this.paint.dim(part)));
      } else {
        out.push(...this.wrapPlain(trimmed, 2).map((part) => this.paint.dim(part)));
      }
    }
    return out.join('\n');
  }

  status(snapshot: UiSnapshot): string {
    return this.hud(snapshot);
  }

  seed(seed: string): string {
    return `${this.paint.badge('neutral', 'WORLD SEED')}  ${this.paint.fg('info', seed)}`;
  }

  saved(file: string): string {
    return `${this.paint.badge('boon', `${this.glyph.check} RUN SAVED`)}  ${file}`;
  }

  quit(): string {
    return this.paint.dim('The wire gate bangs shut behind you. The Hush keeps its laws without you.');
  }

  prompt(snapshot: UiSnapshot): string {
    const ended = snapshot.ended;
    const tone: UiTone = ended
      ? snapshot.outcome === 'won'
        ? 'boon'
        : 'danger'
      : snapshot.nerve <= 1 || snapshot.exposure > 0
        ? 'danger'
        : snapshot.phase === 'night'
          ? 'law'
          : 'info';
    const icon = ended
      ? snapshot.outcome === 'won'
        ? this.glyph.check
        : this.glyph.death
      : tone === 'danger'
        ? this.glyph.danger
        : tone === 'law'
          ? this.glyph.bolt
          : this.glyph.prompt;
    return `${this.paint.dim(ended ? 'END' : 'ACTION')} ${this.paint.fg(tone, this.paint.bold(icon))} `;
  }

  private objective(text: string): string {
    const label = /\bcore\b/i.test(text) ? 'MISSION // RECOVER THE CORE' : 'MISSION UPDATE';
    return [
      `${this.paint.badge('clue', `${this.glyph.objective} ${label}`)}`,
      ...this.wrapPlain(text, 2).map((line) => this.paint.fg('clue', line)),
    ].join('\n');
  }

  private hud(snapshot: UiSnapshot): string {
    const phaseTone: UiTone = snapshot.phase === 'night' ? 'law' : snapshot.phase === 'dusk' ? 'danger' : 'info';
    const nerveTone: UiTone = snapshot.nerve <= 1 ? 'danger' : snapshot.nerve <= 3 ? 'clue' : 'boon';
    const known = snapshot.laws.length;
    const surveyed = snapshot.laws.filter((law) => law.stage === 'surveyed').length;
    const signs = snapshot.laws.reduce((sum, law) => sum + law.tellCount, 0);
    const itemCount = snapshot.inventory.length;
    const top = `${this.paint.fg('info', this.glyph.location)} ${this.paint.bold(snapshot.location.toUpperCase())}${this.glyph.separator}${this.paint.fg(phaseTone, snapshot.phase.toUpperCase())} ${this.paint.fg(phaseTone, this.glyph.clock)} ${snapshot.time}${this.glyph.separator}TURN ${snapshot.turn}`;
    const nerve = `${this.paint.fg(nerveTone, this.glyph.heart)} NERVE ${this.paint.fg(nerveTone, this.meter(snapshot.nerve, NERVE_MAX))} ${snapshot.nerve}/${NERVE_MAX}`;
    const exposure = `${this.paint.fg(snapshot.exposure > 0 ? 'danger' : 'neutral', this.glyph.exposure)} EXPOSURE ${snapshot.exposure}`;
    const knowledge = `${this.paint.fg('clue', this.glyph.codex)} CODEX ${surveyed} READ · ${known} KNOWN · ${signs} SIGNS`;
    const loadout = `${this.paint.fg('info', this.glyph.bag)} GEAR ${itemCount}  ${this.paint.fg('clue', this.glyph.coin)} COINS ${snapshot.coins}`;
    const condition = snapshot.ended
      ? this.paint.fg(snapshot.outcome === 'won' ? 'boon' : 'danger', snapshot.outcome.toUpperCase())
      : snapshot.survival === 'alive'
        ? this.paint.fg('boon', 'ALIVE')
        : this.paint.fg('danger', snapshot.survival.toUpperCase());

    const lines = [this.rail('LIVE STATE', 'neutral')];
    if (this.config.width < 72) {
      lines.push(
        ...this.wrapStyled(top, 0),
        `${nerve}${this.glyph.separator}${exposure}`,
        `${knowledge}`,
        `${loadout}${this.glyph.separator}${condition}`,
      );
    } else {
      lines.push(top, `${nerve}    ${exposure}    ${condition}`, `${knowledge}    ${loadout}`);
    }
    if (snapshot.exits.length) {
      const routeSeparator = this.config.unicode ? '  ·  ' : '  |  ';
      const routeText = `${this.paint.fg('info', this.glyph.arrow)} ${snapshot.exits.join(routeSeparator)}`;
      lines.push(...this.wrapStyled(routeText, 0).map((line) => this.paint.dim(line)));
    }
    return lines.join('\n');
  }

  private beats(beats: readonly UiBeat[]): string {
    if (!beats.length) return '';
    const major = beats.find((beat) => beat.priority >= 70);
    const minor = beats.filter((beat) => beat !== major).slice(0, major ? 3 : 4);
    const lines: string[] = [];
    if (major) lines.push(this.heroBeat(major));
    if (minor.length) {
      if (major) lines.push('');
      for (const beat of minor) {
        const icon = this.iconFor(beat);
        const prefix = this.paint.badge(beat.tone, `${icon} ${beat.label}`);
        lines.push(...this.wrapStyled(`${prefix}  ${beat.detail}`, 0));
      }
    }
    return lines.join('\n');
  }

  private heroBeat(beat: UiBeat): string {
    const icon = this.iconFor(beat);
    const rail = this.paint.fg(beat.tone, this.glyph.rail.repeat(this.config.width));
    const badge = this.paint.badge(beat.tone, `${icon} ${beat.label}`);
    const detailLines = this.wrapPlain(beat.detail, 0).map((line) => this.paint.fg(beat.tone, this.paint.bold(line)));
    return [rail, `${badge}`, ...detailLines.map((line) => `  ${line}`), rail].join('\n');
  }

  private iconFor(beat: UiBeat): string {
    if (beat.label === 'VICTORY') return this.glyph.check;
    if (beat.label === 'RUN OVER') return this.glyph.death;
    if (beat.tone === 'law') return this.glyph.bolt;
    if (beat.tone === 'clue') return this.glyph.clue;
    if (beat.tone === 'danger') return this.glyph.danger;
    if (beat.tone === 'boon') return this.glyph.check;
    return this.glyph.target;
  }

  private commandFooter(): string {
    return this.paint.dim(`COMMAND INPUT // plain words    help [?] · safe hint [hint] · codex · map · inventory`);
  }

  private rail(label: string, tone: UiTone): string {
    const text = ` ${label} `;
    const remaining = Math.max(2, this.config.width - displayWidth(text) - 2);
    return this.paint.fg(tone, `${this.glyph.rail}${text}${this.glyph.rail.repeat(remaining)}${this.glyph.rail}`);
  }

  private center(text: string): string {
    const padding = Math.max(0, Math.floor((this.config.width - displayWidth(text)) / 2));
    return ' '.repeat(padding) + text;
  }

  private meter(value: number, max: number): string {
    const safe = clamp(Math.floor(value), 0, max);
    return this.glyph.fill.repeat(safe) + this.glyph.empty.repeat(max - safe);
  }

  private renderNarrative(raw: string): string {
    const out: string[] = [];
    for (const rawLine of raw.split(/\r?\n/)) {
      const dimmed = /\x1b\[2m/.test(rawLine);
      const bolded = /\x1b\[1m/.test(rawLine);
      const line = stripAnsi(rawLine).trimEnd();
      if (!line.trim()) {
        if (out.at(-1) !== '') out.push('');
        continue;
      }
      const trimmed = line.trim();
      if (isSceneHeading(trimmed)) {
        out.push(`${this.paint.fg('info', this.glyph.rail)} ${this.paint.fg('info', this.paint.bold(trimmed))}`);
      } else if (/^Ways from here:/i.test(trimmed)) {
        out.push(...this.wrapPlain(`${this.glyph.arrow} ${trimmed}`, 2).map((part) => this.paint.fg('info', part)));
      } else if (/^You could look closer at:/i.test(trimmed)) {
        out.push(...this.wrapPlain(`${this.glyph.clue} ${trimmed}`, 2).map((part) => this.paint.fg('clue', part)));
      } else if (/^[✦]/.test(trimmed)) {
        out.push(...this.wrapPlain(trimmed, 0).map((part) => this.paint.fg('boon', this.paint.bold(part))));
      } else if (/^[†]/.test(trimmed)) {
        out.push(...this.wrapPlain(trimmed, 0).map((part) => this.paint.fg('danger', this.paint.bold(part))));
      } else if (dimmed) {
        out.push(...this.wrapPlain(trimmed, 2).map((part) => this.paint.dim(part)));
      } else if (bolded) {
        out.push(...this.wrapPlain(trimmed, 0).map((part) => this.paint.bold(part)));
      } else {
        out.push(...this.wrapPlain(trimmed, 2));
      }
    }
    while (out.at(-1) === '') out.pop();
    return out.join('\n');
  }

  private wrapPlain(text: string, indent: number): string[] {
    return wrapText(text, Math.max(24, this.config.width - indent), ' '.repeat(indent));
  }

  private wrapStyled(text: string, indent: number): string[] {
    const plain = stripAnsi(text);
    if (displayWidth(plain) <= this.config.width - indent) return [' '.repeat(indent) + text];
    // Styled rows are short labels followed by ordinary text. Keep the label on the
    // first line, then wrap the detail without attempting to split ANSI sequences.
    const split = text.match(/^(.*?\x1b\[0m|\[[^\]]+\])\s{2}(.*)$/);
    if (!split) return wrapText(plain, this.config.width - indent, ' '.repeat(indent));
    const prefix = split[1] ?? '';
    const detail = split[2] ?? '';
    const prefixWidth = displayWidth(prefix) + 2;
    const firstWidth = Math.max(12, this.config.width - indent - prefixWidth);
    const detailLines = wrapText(detail, firstWidth, '');
    if (!detailLines.length) return [' '.repeat(indent) + prefix];
    const out = [' '.repeat(indent) + prefix + '  ' + detailLines[0]!];
    const continuation = ' '.repeat(indent + prefixWidth);
    for (const line of detailLines.slice(1)) out.push(continuation + line);
    return out;
  }
}

function isSafeSuggestion(action: UiAction): boolean {
  return ['go', 'look', 'examine', 'listen', 'search', 'talk'].includes(action.intent);
}

function isSceneHeading(text: string): boolean {
  if (text.length > 72 || !/[A-Z]/.test(text)) return false;
  return text === text.toUpperCase() && !/[.!?]$/.test(text);
}

function uniqueBeats(beats: readonly UiBeat[]): UiBeat[] {
  const seen = new Set<string>();
  const out: UiBeat[] = [];
  for (const beat of beats) {
    const key = `${beat.label}\0${beat.detail}`;
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(beat);
  }
  return out;
}

function unique(values: readonly string[]): string[] {
  return [...new Set(values)];
}

function stringAt(record: Readonly<Record<string, unknown>>, key: string): string | undefined {
  const value = record[key];
  return typeof value === 'string' ? value : undefined;
}

function numberAt(record: Readonly<Record<string, unknown>>, key: string): number | undefined {
  const value = record[key];
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}

function boolAt(record: Readonly<Record<string, unknown>>, key: string): boolean {
  return record[key] === true;
}

function formatClock(minutes: number): string {
  const normalized = ((Math.floor(minutes) % 1440) + 1440) % 1440;
  const hours = Math.floor(normalized / 60);
  const remainder = normalized % 60;
  return `${String(hours).padStart(2, '0')}:${String(remainder).padStart(2, '0')}`;
}

function parseClock(value: string): number | undefined {
  const match = /^(\d{1,2}):(\d{2})$/.exec(value);
  if (!match) return undefined;
  const hours = Number(match[1]);
  const minutes = Number(match[2]);
  if (!Number.isInteger(hours) || !Number.isInteger(minutes) || hours < 0 || hours > 23 || minutes < 0 || minutes > 59)
    return undefined;
  return hours * 60 + minutes;
}

function humanize(id: string): string {
  return id.replace(/[._-]+/g, ' ').replace(/\b\w/g, (char) => char.toUpperCase());
}

function signed(value: number): string {
  return value > 0 ? `+${value}` : String(value);
}

function clamp(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function stripAnsi(text: string): string {
  return text.replace(ANSI_RE, '');
}

function displayWidth(text: string): number {
  return Array.from(stripAnsi(text)).length;
}

function truncate(text: string, max: number): string {
  const clean = text.replace(/\s+/g, ' ').trim();
  if (displayWidth(clean) <= max) return clean;
  return (
    Array.from(clean)
      .slice(0, Math.max(1, max - 1))
      .join('')
      .trimEnd() + '…'
  );
}

function wrapText(text: string, width: number, prefix: string): string[] {
  const clean = text.replace(/\s+/g, ' ').trim();
  if (!clean) return [prefix.trimEnd()];
  const words = clean.split(' ');
  const out: string[] = [];
  let line = prefix;
  let lineWidth = displayWidth(prefix);
  for (const originalWord of words) {
    let word = originalWord;
    while (displayWidth(word) > width) {
      const available = Math.max(1, width - lineWidth - (lineWidth > displayWidth(prefix) ? 1 : 0));
      if (available <= 1 && lineWidth > displayWidth(prefix)) {
        out.push(line.trimEnd());
        line = prefix;
        lineWidth = displayWidth(prefix);
        continue;
      }
      const chunk = Array.from(word).slice(0, available).join('');
      const needsSpace = lineWidth > displayWidth(prefix);
      line += (needsSpace ? ' ' : '') + chunk;
      lineWidth += (needsSpace ? 1 : 0) + displayWidth(chunk);
      word = Array.from(word).slice(Array.from(chunk).length).join('');
      if (lineWidth >= width) {
        out.push(line.trimEnd());
        line = prefix;
        lineWidth = displayWidth(prefix);
      }
    }
    if (!word) continue;
    const needsSpace = lineWidth > displayWidth(prefix);
    const projected = lineWidth + (needsSpace ? 1 : 0) + displayWidth(word);
    if (projected > width && lineWidth > displayWidth(prefix)) {
      out.push(line.trimEnd());
      line = prefix + word;
      lineWidth = displayWidth(prefix) + displayWidth(word);
    } else {
      line += (needsSpace ? ' ' : '') + word;
      lineWidth = projected;
    }
  }
  if (line.trim()) out.push(line.trimEnd());
  return out;
}
