import { describe, expect, it } from 'vitest';
import type { Session } from '../../src/game/session.js';
import { ArcadeUi, diffSnapshots, snapshotOf, type UiSnapshot } from '../../src/cli/ui.js';

function snapshot(overrides: Partial<UiSnapshot> = {}): UiSnapshot {
  return {
    seed: 'ui-test',
    turn: 1,
    ended: false,
    outcome: 'active',
    location: 'The Cordon Waystation',
    phase: 'day',
    time: '16:00',
    survival: 'alive',
    unsettled: 0,
    nerve: 5,
    exposure: 0,
    coins: 3,
    objective: 'Recover the core.',
    exits: ['the checkpoint'],
    actions: [],
    inventory: [],
    laws: [],
    signals: { hidden: false, interceptClear: false, awareness: {} },
    ...overrides,
  };
}

describe('semantic arcade CLI', () => {
  it('classifies visible costs and law contact without parsing prose', () => {
    const before = snapshot();
    const after = snapshot({
      turn: 2,
      unsettled: 2,
      nerve: 3,
      laws: [
        {
          id: 'mile_road',
          title: 'The Mile Road',
          stage: 'referenced',
          witnessed: true,
          contacts: 1,
          driftWarned: false,
          tellCount: 0,
          tellGoal: 2,
        },
      ],
    });

    const beats = diffSnapshots(before, after, { status: 'active' });
    expect(beats.map((beat) => beat.label)).toEqual(
      expect.arrayContaining(['NERVE HIT', 'LAW CONTACT', 'SIGN LOGGED']),
    );
    expect(beats[0]?.label).toBe('NERVE HIT');
  });

  it('keeps plain mode free of ANSI and dangerous automatic suggestions', () => {
    const ui = new ArcadeUi({
      color: false,
      unicode: false,
      width: 72,
      clearOnStart: false,
    });
    const state = snapshot({
      actions: [
        { label: 'go to the checkpoint', intent: 'go' },
        { label: 'look back', intent: 'look' },
        { label: 'wait', intent: 'wait' },
        { label: 'talk to Holt', intent: 'talk' },
      ],
    });

    const hint = ui.hint(state);
    expect(hint).toContain('go to the checkpoint');
    expect(hint).toContain('talk to Holt');
    expect(hint).not.toContain('look back');
    expect(hint).not.toContain('wait');
    expect(hint).not.toMatch(/\x1b\[/);
  });

  it('does not reveal a law from a live flag alone', () => {
    const fakeSession = {
      game: {
        seed: 'masked',
        pack: {
          items: [],
          tellLibrary: [],
          laws: [
            {
              id: 'hidden_law',
              title: 'The Hidden Law',
              tells: [],
              discovery: { minTellsToSurvey: 2 },
            },
          ],
        },
      },
      obs: () => ({
        turn: 0,
        facts: {
          'loc.pc': 'waystation',
          'phase.now': 'day',
          'clock.minutes': 960,
          'survival.pc': 'alive',
          'law.hidden_law.live': true,
        },
        self: { survival: 'alive', unsettled: 0, exposure: 0 },
        scene: { title: 'Waystation', phase: 'day', exits: [] },
        legalActions: [],
      }),
      isEnded: () => false,
      outcome: () => 'active' as const,
    } as unknown as Session;

    expect(snapshotOf(fakeSession).laws).toEqual([]);
  });

  it('turns visible clock thresholds into daylight pressure without reading hidden law state', () => {
    const beats = diffSnapshots(snapshot({ time: '16:55' }), snapshot({ turn: 2, time: '17:10' }), {
      status: 'active',
    });

    expect(beats.map((beat) => beat.label)).toContain('DAYLIGHT LOW');
  });

  it('renders one major impact rail for a multi-change turn', () => {
    const ui = new ArcadeUi({
      color: false,
      unicode: false,
      width: 64,
      clearOnStart: false,
    });
    const rendered = ui.turn(
      'The road moves under you.',
      [
        {
          tone: 'danger',
          label: 'NERVE HIT',
          detail: '-1 // 4/5 REMAINS',
          priority: 96,
        },
        {
          tone: 'law',
          label: 'LAW CONTACT',
          detail: 'THE MILE ROAD // CONTACT 1',
          priority: 92,
        },
      ],
      snapshot({ nerve: 4, unsettled: 1 }),
    );

    expect(rendered.match(/NERVE HIT/g)).toHaveLength(1);
    expect(rendered.match(/LAW CONTACT/g)).toHaveLength(1);
    expect(rendered).not.toMatch(/\x1b\[/);
  });
});
