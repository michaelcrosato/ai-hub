# Apply the electric CLI

From the root of `michaelcrosato/ugaf` at the current `main` revision:

```powershell
git apply path\to\ugaf-electric-cli.patch
npm run gate
npm run play
```

The bundle mirrors the four changed repository paths if you prefer to copy files manually.

Launch modes:

```powershell
npm run play                         # full colour + Unicode HUD
npm run play -- --no-clear          # preserve shell scrollback
npm run play -- --ascii             # colour with ASCII glyphs
npm run play -- --plain             # transcript/CI-safe plain output
```

Validation performed before delivery:

- patch applies cleanly to the current `src/cli/main.ts` blob (`b400920...`);
- Prettier 3.8.4 check passes using the repository configuration;
- strict TypeScript validation passes against the repository-facing interfaces used by the change;
- five focused Vitest UI tests pass;
- a representative render was executed in plain and colour modes.

Run the repository's full `npm run gate` after applying; the complete repository was not available in the local execution container.
