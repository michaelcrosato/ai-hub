import { clamp, moveToward } from './math.js';
export interface MotorSettings {
    walkSpeed: number;
    sprintSpeed: number;
    crouchSpeed: number;
    acceleration: number;
    airAcceleration: number;
    friction: number;
    jumpSpeed: number;
    gravity: number;
    coyoteTime: number;
    jumpBuffer: number;
    stepHeight: number;
    maxSlope: number;
    fov: number;
    sensitivity: number;
    headBob: number;
}
export const defaultMotor: MotorSettings = {
    walkSpeed: 5.5, sprintSpeed: 9, crouchSpeed: 2.6, acceleration: 38,
    airAcceleration: 12, friction: 30, jumpSpeed: 8, gravity: 24,
    coyoteTime: .11, jumpBuffer: .14, stepHeight: .32, maxSlope: 46,
    fov: 78, sensitivity: .002, headBob: .35,
};
export interface MoveInput {
    x: number;
    z: number;
    sprint: boolean;
    crouch: boolean;
    jump: boolean;
}
/** Pure movement policy. Collision response is supplied by the physics adapter. */
export class Motor {
    vx = 0;
    vy = 0;
    vz = 0;
    grounded = false;
    crouched = false;
    private coyote = 0;
    private buffer = 0;
    private jumped = false;
    constructor(readonly settings: MotorSettings) { }
    update(dt: number, input: MoveInput, yaw: number): {
        x: number;
        y: number;
        z: number;
    } {
        this.coyote = this.grounded && !this.jumped ? this.settings.coyoteTime : Math.max(0, this.coyote - dt);
        if (this.grounded && this.vy <= 0)
            this.jumped = false;
        this.buffer = input.jump ? this.settings.jumpBuffer : Math.max(0, this.buffer - dt);
        const length = Math.hypot(input.x, input.z);
        const nx = input.x / Math.max(1, length), nz = input.z / Math.max(1, length);
        const speed = this.crouched ? this.settings.crouchSpeed : input.sprint ? this.settings.sprintSpeed : this.settings.walkSpeed;
        const tx = (nx * Math.cos(yaw) + nz * Math.sin(yaw)) * speed;
        const tz = (-nx * Math.sin(yaw) + nz * Math.cos(yaw)) * speed;
        const rate = this.grounded ? (length > 0 ? this.settings.acceleration : this.settings.friction) : this.settings.airAcceleration;
        // Limit vector acceleration, not each axis, to avoid diagonal acceleration gains.
        const dx = tx - this.vx, dz = tz - this.vz, distance = Math.hypot(dx, dz);
        const factor = distance > 0 ? Math.min(1, rate * dt / distance) : 0;
        this.vx += dx * factor;
        this.vz += dz * factor;
        if (this.buffer > 0 && this.coyote > 0 && !this.jumped) {
            this.vy = this.settings.jumpSpeed;
            this.buffer = 0;
            this.coyote = 0;
            this.grounded = false;
            this.jumped = true;
        }
        else if (this.grounded && this.vy <= 0)
            this.vy = -2;
        else
            this.vy = clamp(this.vy - this.settings.gravity * dt, -50, 30);
        return { x: this.vx * dt, y: this.vy * dt, z: this.vz * dt };
    }
    launch(speed: number): void { this.vy = speed; this.grounded = false; this.coyote = 0; this.jumped = true; }
    reset(): void { this.vx = this.vy = this.vz = this.coyote = this.buffer = 0; this.grounded = this.jumped = this.crouched = false; }
    brake(dt: number): void { this.vx = moveToward(this.vx, 0, 40 * dt); this.vz = moveToward(this.vz, 0, 40 * dt); }
}
