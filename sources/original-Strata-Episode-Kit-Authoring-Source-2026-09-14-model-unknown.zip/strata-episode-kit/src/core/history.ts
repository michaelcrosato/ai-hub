/** Immutable document history. Runtime bodies never become the authoring source. */
export class History<T> {
    private entries: T[];
    private cursor = 0;
    constructor(initial: T, readonly capacity = 80) { this.entries = [structuredClone(initial)]; }
    get current(): T { return structuredClone(this.entries[this.cursor]!); }
    get canUndo(): boolean { return this.cursor > 0; }
    get canRedo(): boolean { return this.cursor < this.entries.length - 1; }
    commit(value: T): boolean {
        if (JSON.stringify(value) === JSON.stringify(this.entries[this.cursor]))
            return false;
        this.entries.splice(this.cursor + 1);
        this.entries.push(structuredClone(value));
        if (this.entries.length > this.capacity)
            this.entries.shift();
        this.cursor = this.entries.length - 1;
        return true;
    }
    undo(): T {
        if (this.canUndo)
            this.cursor--;
        return this.current;
    }
    redo(): T {
        if (this.canRedo)
            this.cursor++;
        return this.current;
    }
}
