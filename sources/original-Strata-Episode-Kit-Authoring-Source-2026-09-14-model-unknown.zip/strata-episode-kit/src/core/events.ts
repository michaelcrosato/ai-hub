export type Unsubscribe = () => void;
/** Typed, synchronous engine events. Snapshot listeners so removal is safe during dispatch. */
export class Events<T extends object> {
    private readonly listeners = new Map<keyof T, Set<(value: never) => void>>();
    on<K extends keyof T>(type: K, callback: (value: T[K]) => void): Unsubscribe {
        let set = this.listeners.get(type);
        if (!set)
            this.listeners.set(type, set = new Set());
        set.add(callback as (value: never) => void);
        return () => { set.delete(callback as (value: never) => void); };
    }
    emit<K extends keyof T>(type: K, value: T[K]): void {
        for (const callback of [...(this.listeners.get(type) ?? [])])
            callback(value as never);
    }
    clear(): void { this.listeners.clear(); }
}
export interface Signal {
    channel: string;
    value: boolean;
    source: string;
}
/** Level signals are queued. A bad feedback loop cannot overflow the call stack. */
export class Signals {
    private readonly queue: Signal[] = [];
    private readonly listeners = new Map<string, Set<(s: Signal) => void>>();
    readonly values = new Map<string, boolean>();
    on(channel: string, callback: (signal: Signal) => void): Unsubscribe {
        let set = this.listeners.get(channel);
        if (!set)
            this.listeners.set(channel, set = new Set());
        set.add(callback);
        return () => { set.delete(callback); };
    }
    send(channel: string, value = true, source = 'level'): void {
        if (!channel.trim())
            return;
        if (this.queue.length >= 4096)
            throw new Error('Signal queue limit exceeded. Check the level rules.');
        this.queue.push({ channel, value, source });
    }
    flush(limit = 256): number {
        let count = 0;
        while (this.queue.length) {
            if (count >= limit) {
                this.queue.length = 0;
                throw new Error('Signal limit exceeded. Check for a cycle or too many events.');
            }
            const signal = this.queue.shift()!;
            this.values.set(signal.channel, signal.value);
            for (const listener of [...(this.listeners.get(signal.channel) ?? [])])
                listener(signal);
            count++;
        }
        return count;
    }
    clear(): void { this.queue.length = 0; this.listeners.clear(); this.values.clear(); }
}
