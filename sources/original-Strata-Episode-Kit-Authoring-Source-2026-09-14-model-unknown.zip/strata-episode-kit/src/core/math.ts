export type Vec3 = [
    number,
    number,
    number
];
export const clamp = (x: number, low: number, high: number): number => Math.max(low, Math.min(high, x));
export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;
export const damp = (a: number, b: number, rate: number, dt: number): number => lerp(a, b, 1 - Math.exp(-rate * dt));
export const radians = (degrees: number): number => degrees * Math.PI / 180;
export const degrees = (radians: number): number => radians * 180 / Math.PI;
export const tuple = (v: {
    x: number;
    y: number;
    z: number;
}): Vec3 => [v.x, v.y, v.z];
export const vector = (v: Vec3): {
    x: number;
    y: number;
    z: number;
} => ({ x: v[0], y: v[1], z: v[2] });
export function moveToward(current: number, target: number, amount: number): number {
    return current + clamp(target - current, -amount, amount);
}
/** Deterministic decoration. Do not use Math.random for level generation. */
export function random(seed: number): () => number {
    return () => {
        seed |= 0;
        seed = seed + 0x6D2B79F5 | 0;
        let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
        t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
    };
}
