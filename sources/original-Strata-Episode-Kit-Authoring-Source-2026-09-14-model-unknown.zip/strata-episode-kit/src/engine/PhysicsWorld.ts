import RAPIER from '@dimforge/rapier3d-compat';
import * as THREE from 'three';
import type { Blueprint } from '../level/prefabs.js';
import type { EntityData } from '../level/schema.js';
import { radians, vector } from '../core/math.js';
export { RAPIER };
export interface PhysicsEntity {
    data: EntityData;
    root: THREE.Group;
    body: RAPIER.RigidBody;
    colliders: RAPIER.Collider[];
    previous: THREE.Vector3;
    current: THREE.Vector3;
    previousRotation: THREE.Quaternion;
    currentRotation: THREE.Quaternion;
}
export class PhysicsWorld {
    static ready: Promise<void> | undefined;
    static async init(): Promise<void> { await (this.ready ??= RAPIER.init()); }
    readonly world: RAPIER.World;
    readonly entities = new Map<string, PhysicsEntity>();
    readonly owners = new Map<number, string>();
    readonly deltas = new Map<number, THREE.Vector3>();
    constructor(gravity = { x: 0, y: -24, z: 0 }) {
        if (![gravity.x, gravity.y, gravity.z].every(Number.isFinite)) throw new Error('Invalid gravity.');
        this.world = new RAPIER.World(gravity);
        this.world.timestep = 1 / 60; this.world.numSolverIterations = 6;
    }
    create(data: EntityData, blueprint: Blueprint, root: THREE.Group, playing: boolean): PhysicsEntity {
        const desc = blueprint.body === 'dynamic' && playing ? RAPIER.RigidBodyDesc.dynamic() : blueprint.body === 'kinematic' && playing ? RAPIER.RigidBodyDesc.kinematicPositionBased() : RAPIER.RigidBodyDesc.fixed();
        const rotation = new THREE.Quaternion().setFromEuler(new THREE.Euler(...data.rotation.map(radians) as [
            number,
            number,
            number
        ]));
        desc.setTranslation(...data.position).setRotation(rotation);
        if (blueprint.body === 'dynamic') {
            desc.setCcdEnabled(true).setLinearDamping(.25).setAngularDamping(.8);
        }
        const body = this.world.createRigidBody(desc), colliders: RAPIER.Collider[] = [];
        for (const c of blueprint.colliders) {
            const size = c.size.map((v, i) => v * data.scale[i]! / 2) as [
                number,
                number,
                number
            ];
            const offset = c.position.map((v, i) => v * data.scale[i]!) as [
                number,
                number,
                number
            ];
            const radius = Math.max(size[0], size[2]);
            const cd = c.shape === 'ball' ? RAPIER.ColliderDesc.ball(radius) : c.shape === 'capsule' ? RAPIER.ColliderDesc.capsule(Math.max(0, size[1] - radius), radius) : c.shape === 'cylinder' ? RAPIER.ColliderDesc.cylinder(size[1], radius) : RAPIER.ColliderDesc.cuboid(...size);
            cd.setTranslation(...offset).setFriction(c.friction ?? .75).setRestitution(c.restitution ?? .03).setDensity(c.density ?? 2);
            if (c.groups !== undefined)
                cd.setCollisionGroups(c.groups);
            if (c.sensor)
                cd.setSensor(true).setActiveCollisionTypes(RAPIER.ActiveCollisionTypes.ALL);
            const collider = this.world.createCollider(cd, body);
            colliders.push(collider);
            this.owners.set(collider.handle, data.id);
        }
        const position = new THREE.Vector3(...data.position);
        const entity = { data, root, body, colliders, previous: position.clone(), current: position.clone(), previousRotation: rotation.clone(), currentRotation: rotation.clone() };
        this.entities.set(data.id, entity);
        return entity;
    }
    beginStep(): void {
        this.deltas.clear();
        for (const e of this.entities.values()) {
            e.previous.copy(e.current);
            e.previousRotation.copy(e.currentRotation);
        }
    }
    move(entity: PhysicsEntity, position: THREE.Vector3): void {
        const p = entity.body.translation();
        this.deltas.set(entity.body.handle, position.clone().sub(new THREE.Vector3(p.x, p.y, p.z)));
        entity.body.setNextKinematicTranslation(position);
    }
    step(dt: number): void {
        this.world.timestep = dt;
        this.world.step();
        for (const e of this.entities.values()) {
            const p = e.body.translation(), q = e.body.rotation();
            e.current.set(p.x, p.y, p.z);
            e.currentRotation.set(q.x, q.y, q.z, q.w);
            if (e.body.isDynamic() && p.y < -15) {
                e.body.setTranslation(vector(e.data.position), true);
                e.body.setLinvel({ x: 0, y: 0, z: 0 }, true);
                e.body.setAngvel({ x: 0, y: 0, z: 0 }, true);
                e.current.fromArray(e.data.position);
                e.previous.copy(e.current);
            }
        }
    }
    interpolate(alpha: number): void {
        for (const e of this.entities.values()) {
            e.root.position.lerpVectors(e.previous, e.current, alpha);
            e.root.quaternion.slerpQuaternions(e.previousRotation, e.currentRotation, alpha);
        }
    }
    dispose(): void { this.entities.clear(); this.owners.clear(); this.deltas.clear(); this.world.free(); }
}
