import * as THREE from 'three';
import { FixedClock } from '../core/clock.js';
import { Events } from '../core/events.js';
import { History } from '../core/history.js';
import { createPrefabs } from '../level/prefabs.js';
import { builtinSchemas, validateLevel, type LevelData } from '../level/schema.js';
import { RenderWorld } from './RenderWorld.js';
import { Input } from './Input.js';
import { Assets } from './Assets.js';
import { PhysicsWorld } from './PhysicsWorld.js';
import { Behaviors, registerBuiltins } from './BehaviorSystem.js';
import { Runtime } from './Runtime.js';
export type EngineMode = 'edit' | 'play' | 'paused';
export interface EngineEvents {
    mode: EngineMode;
    document: LevelData;
    notice: string;
    stats: {
        fps: number;
        draws: number;
        triangles: number;
        bodies: number;
        speed: number;
        grounded: boolean;
        dropped: number;
    };
}
export interface EnginePlugin {
    id: string;
    install: (engine: Engine) => (() => void) | void;
}
export class Engine {
    readonly events = new Events<EngineEvents>();
    readonly prefabs = createPrefabs();
    readonly schemas = builtinSchemas();
    readonly behaviors = new Behaviors(this.schemas);
    readonly assets = new Assets();
    readonly clock = new FixedClock(60, 5);
    readonly view: RenderWorld;
    readonly input: Input;
    readonly plugins = new Map<string, (() => void) | void>();
    runtime!: Runtime;
    mode: EngineMode = 'edit';
    document!: LevelData;
    history!: History<LevelData>;
    private frame = 0;
    private lastTime = 0;
    private statTime = 0;
    private statFrames = 0;
    private debugElapsed = 0;
    private debugLines: THREE.LineSegments | null = null;
    private readonly abort = new AbortController();
    private readonly hooks = new Set<(dt: number) => void>();
    private savedCamera: {
        position: THREE.Vector3;
        rotation: THREE.Quaternion;
        fov: number;
    } | null = null;
    private running = false;
    constructor(host: HTMLElement) {
        this.view = new RenderWorld(host);
        this.input = new Input(this.view.renderer.domElement);
        registerBuiltins(this.behaviors);
        document.addEventListener('pointerlockchange', () => {
            if (this.mode === 'play' && document.pointerLockElement !== this.input.canvas)
                this.pause();
        }, { signal: this.abort.signal });
        document.addEventListener('pointerlockerror', () => { this.pause(); this.notice('Mouse capture was denied. Select Play to try again.'); }, { signal: this.abort.signal });
        window.addEventListener('blur', () => this.pause(), { signal: this.abort.signal });
        document.addEventListener('visibilitychange', () => {
            if (document.hidden)
                this.pause();
            this.lastTime = 0;
            this.clock.reset();
        }, { signal: this.abort.signal });
        this.input.canvas.addEventListener('webglcontextlost', e => { e.preventDefault(); this.pause(); this.notice('The graphics context was lost. Reload the page to recover.'); }, { signal: this.abort.signal });
    }
    async start(data: LevelData): Promise<void> { await PhysicsWorld.init(); this.load(data); this.running = true; this.frame = requestAnimationFrame(this.tick); }
    use(plugin: EnginePlugin): void {
        if (this.plugins.has(plugin.id))
            throw new Error(`Plugin already installed: ${plugin.id}`);
        this.plugins.set(plugin.id, plugin.install(this));
    }
    onFrame(callback: (dt: number) => void): () => void { this.hooks.add(callback); return () => { this.hooks.delete(callback); }; }
    notice(message: string): void { this.events.emit('notice', message); }
    load(raw: unknown): void {
        const candidate = validateLevel(raw, this.prefabs.ids, this.schemas);
        const next = new Runtime(candidate, false, this.view, this.input, this.prefabs, this.behaviors, this.assets, m => this.notice(m));
        this.runtime?.dispose();
        this.runtime = next;
        this.document = candidate;
        this.history = new History(candidate);
        this.mode = 'edit';
        this.input.enabled = false;
        if (document.pointerLockElement)
            document.exitPointerLock();
        this.view.environment(candidate.environment);
        this.view.editorHelpers.visible = true;
        this.events.emit('document', structuredClone(candidate));
        this.events.emit('mode', this.mode);
        this.save();
    }
    commit(edit: (draft: LevelData) => void): boolean {
        if (this.mode !== 'edit')
            return false;
        try {
            const draft = structuredClone(this.document);
            edit(draft);
            const valid = validateLevel(draft, this.prefabs.ids, this.schemas);
            if (JSON.stringify(valid) === JSON.stringify(this.document))
                return false;
            this.replace(valid);
            this.history.commit(valid);
            this.save();
            return true;
        }
        catch (error) {
            this.notice(error instanceof Error ? error.message : String(error));
            return false;
        }
    }
    private replace(data: LevelData): void {
        const next = new Runtime(data, false, this.view, this.input, this.prefabs, this.behaviors, this.assets, m => this.notice(m));
        this.runtime.dispose();
        this.runtime = next;
        this.document = structuredClone(data);
        this.view.environment(data.environment);
        this.events.emit('document', structuredClone(data));
    }
    undo(): void {
        if (this.mode === 'edit' && this.history.canUndo) {
            this.replace(this.history.undo());
            this.save();
        }
    }
    redo(): void {
        if (this.mode === 'edit' && this.history.canRedo) {
            this.replace(this.history.redo());
            this.save();
        }
    }
    private save(): void {
        try {
            localStorage.setItem('strata.level.v1', JSON.stringify(this.document));
        }
        catch {
            this.notice('Local save is unavailable. Export the level to keep your changes.');
        }
    }
    play(): void {
        if (this.mode === 'paused') {
            this.resume();
            return;
        }
        if (this.mode !== 'edit')
            return;
        this.savedCamera = { position: this.view.camera.position.clone(), rotation: this.view.camera.quaternion.clone(), fov: this.view.camera.fov };
        // Start pointer lock within the user gesture. Do not wait for an async level load.
        if (!this.captureMouse())
            return;
        try {
            const next = new Runtime(structuredClone(this.document), true, this.view, this.input, this.prefabs, this.behaviors, this.assets, m => this.notice(m));
            this.runtime.dispose();
            this.runtime = next;
            this.mode = 'play';
            this.input.enabled = true;
            this.input.clear();
            this.clock.reset();
            this.view.editorHelpers.visible = false;
            this.events.emit('mode', this.mode);
        }
        catch (error) {
            document.exitPointerLock();
            this.notice(String(error));
        }
    }
    private captureMouse(): boolean {
        try {
            const request = this.input.canvas.requestPointerLock();
            void Promise.resolve(request).catch(() => { this.pause(); this.notice('Mouse capture was blocked. Open the page in its own tab, then press Resume.'); });
            return true;
        }
        catch (error) {
            this.notice(`Mouse capture is not available: ${String(error)}`);
            return false;
        }
    }
    pause(): void {
        if (this.mode !== 'play')
            return;
        this.mode = 'paused';
        if (document.pointerLockElement === this.input.canvas) document.exitPointerLock();
        this.input.enabled = false;
        this.input.clear();
        this.clock.reset();
        this.events.emit('mode', this.mode);
    }
    resume(): void {
        if (this.mode !== 'paused')
            return;
        this.mode = 'play';
        this.input.enabled = true;
        this.input.clear();
        this.clock.reset();
        this.lastTime = 0;
        this.events.emit('mode', this.mode);
        if (!this.captureMouse())
            this.pause();
    }
    stop(): void {
        if (this.mode === 'edit')
            return;
        this.mode = 'edit';
        this.input.enabled = false;
        this.input.clear();
        document.exitPointerLock();
        this.replace(this.document);
        this.clock.reset();
        this.view.editorHelpers.visible = true;
        if (this.savedCamera) {
            this.view.camera.position.copy(this.savedCamera.position);
            this.view.camera.quaternion.copy(this.savedCamera.rotation);
            this.view.camera.fov = this.savedCamera.fov;
            this.view.camera.updateProjectionMatrix();
        }
        this.events.emit('mode', this.mode);
    }
    setDebug(show: boolean): void {
        if (!this.debugLines) {
            this.debugLines = new THREE.LineSegments(new THREE.BufferGeometry(), new THREE.LineBasicMaterial({ vertexColors: true, depthTest: false, transparent: true, opacity: .65 }));
            this.debugLines.frustumCulled = false;
            this.view.scene.add(this.debugLines);
        }
        this.debugLines.visible = show;
        this.debugElapsed = 1;
    }
    private readonly tick = (now: number): void => {
        if (!this.running)
            return;
        const dt = this.lastTime ? Math.min((now - this.lastTime) / 1000, .25) : 0;
        this.lastTime = now;
        try {
            let alpha = 1;
            if (this.mode === 'play') {
                this.runtime.player?.look();
                alpha = this.clock.advance(dt, step => this.runtime.fixedStep(step, this.input));
            }
            if (this.mode !== 'paused')
                this.runtime.render(alpha, dt);
            for (const hook of this.hooks)
                hook(dt);
            this.debugElapsed += dt;
            if (this.debugLines?.visible && this.debugElapsed > .1) {
                this.debugElapsed = 0;
                const data = this.runtime.physics.world.debugRender();
                const geometry = new THREE.BufferGeometry();
                geometry.setAttribute('position', new THREE.BufferAttribute(data.vertices, 3));
                geometry.setAttribute('color', new THREE.BufferAttribute(data.colors, 4));
                this.debugLines.geometry.dispose();
                this.debugLines.geometry = geometry;
            }
            this.view.draw();
            this.statTime += dt;
            this.statFrames++;
            if (this.statTime > .5) {
                const info = this.view.renderer.info;
                this.events.emit('stats', { fps: Math.round(this.statFrames / this.statTime), draws: info.render.calls, triangles: info.render.triangles, bodies: this.runtime.physics.world.bodies.len(), speed: Math.hypot(this.runtime.player?.motor.vx ?? 0, this.runtime.player?.motor.vz ?? 0), grounded: this.runtime.player?.motor.grounded ?? false, dropped: this.clock.droppedTime });
                this.statTime = 0;
                this.statFrames = 0;
            }
        }
        catch (error) {
            console.error(error);
            this.pause();
            this.notice(`Runtime stopped: ${String(error)}`);
        }
        this.frame = requestAnimationFrame(this.tick);
    };
    dispose(): void {
        this.running = false;
        cancelAnimationFrame(this.frame);
        this.abort.abort();
        this.input.dispose();
        this.runtime?.dispose();
        for (const dispose of [...this.plugins.values()].reverse())
            dispose?.();
        this.plugins.clear();
        this.hooks.clear();
        if (this.debugLines) {
            this.debugLines.geometry.dispose();
            (this.debugLines.material as THREE.Material).dispose();
            this.debugLines.removeFromParent();
        }
        this.assets.dispose();
        this.events.clear();
        this.view.dispose();
    }
}
