import { Engine } from './engine/Engine.js';
import { Editor } from './editor/Editor.js';
import { Panel } from './editor/Panel.js';
import { demoLevel } from './level/demo.js';
import { validateLevel } from './level/schema.js';
let engine: Engine | undefined, editor: Editor | undefined, panel: Panel | undefined;
async function main(): Promise<void> {
    const host = document.getElementById('viewport')!;
    engine = new Engine(host);
    // Install project plugins here, before start(). See docs/EXTENDING.md.
    let level = demoLevel();
    try {
        const saved = localStorage.getItem('strata.level.v1');
        if (saved)
            level = validateLevel(JSON.parse(saved), engine.prefabs.ids, engine.schemas);
    }
    catch (error) {
        console.warn('Saved level was not loaded:', error);
    }
    if (matchMedia('(prefers-reduced-motion: reduce)').matches)
        level.player.headBob = 0;
    await engine.start(level);
    editor = new Editor(engine);
    panel = new Panel(engine, editor);
    document.getElementById('project-name')!.textContent = level.name;
    document.querySelector('.scene-title h1')!.textContent = level.name + '.';
    document.getElementById('loading')!.classList.add('hidden');
    // Local development API. No network service or telemetry is present.
    Object.assign(window, { strata: { engine, editor, exportLevel: () => structuredClone(engine!.document) } });
}
window.addEventListener('pagehide', event => {
    if (!event.persisted) {
        panel?.dispose();
        editor?.dispose();
        engine?.dispose();
    }
});
main().catch(error => {
    console.error(error);
    document.getElementById('loading-message')!.textContent = `Could not start: ${error instanceof Error ? error.message : String(error)}. Use npm install, then npm run dev. This app needs WebGL 2 and WebAssembly.`;
});
