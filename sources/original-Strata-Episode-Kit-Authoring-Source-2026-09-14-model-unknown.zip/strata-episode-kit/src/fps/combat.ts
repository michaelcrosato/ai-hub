/** Optional FPS rules. No rendering, physics, DOM, AI, or campaign dependency. */
function positive(value: number, name: string, zero = false): number {
    if (!Number.isFinite(value) || (zero ? value < 0 : value <= 0)) throw new Error(`Invalid ${name}.`);
    return value;
}
export interface DamageResult { healthLost: number; armorLost: number; killed: boolean; }
export class Vitals {
    health: number;
    armor = 0;
    private grace = 0;
    constructor(readonly maxHealth = 100, readonly maxArmor = 100) {
        this.health = positive(maxHealth, 'maximum health'); positive(maxArmor, 'maximum armor', true);
    }
    get alive(): boolean { return this.health > 0; }
    tick(dt: number): void { this.grace = Math.max(0, this.grace - positive(dt, 'delta', true)); }
    damage(amount: number, graceSeconds = 0): DamageResult {
        positive(amount, 'damage', true); positive(graceSeconds, 'damage grace', true);
        if (!this.alive || this.grace > 0 || amount === 0) return { healthLost: 0, armorLost: 0, killed: false };
        const armorLost = Math.min(this.armor, amount * .6), healthLost = Math.min(this.health, amount - armorLost);
        this.armor -= armorLost; this.health -= healthLost; this.grace = graceSeconds;
        return { armorLost, healthLost, killed: !this.alive };
    }
    heal(amount: number): void { positive(amount, 'healing', true); if (this.alive) this.health = Math.min(this.maxHealth, this.health + amount); }
    reset(): void { this.health = this.maxHealth; this.armor = 0; this.grace = 0; }
    restore(raw: { health: number; armor: number }): void {
        positive(raw.health, 'health', true); positive(raw.armor, 'armor', true);
        if (raw.health > this.maxHealth || raw.armor > this.maxArmor) throw new Error('Vitals exceed their limits.');
        this.health = raw.health; this.armor = raw.armor; this.grace = 0;
    }
}
export interface WeaponSpec { capacity: number; reserve: number; interval: number; reloadTime: number; damage: number; range: number; automatic: boolean; }
export const rifleSpec: WeaponSpec = { capacity: 12, reserve: 60, interval: .16, reloadTime: 1.25, damage: 34, range: 70, automatic: true };
export class Weapon {
    readonly spec: Readonly<WeaponSpec>;
    ammo: number;
    reserve: number;
    private cooldown = 0;
    private reloadLeft = 0;
    constructor(spec: WeaponSpec = rifleSpec) {
        for (const key of ['capacity', 'reserve'] as const) if (!Number.isSafeInteger(spec[key]) || spec[key] < (key === 'capacity' ? 1 : 0)) throw new Error(`Invalid ${key}.`);
        for (const key of ['interval', 'reloadTime', 'damage', 'range'] as const) positive(spec[key], key);
        if (typeof spec.automatic !== 'boolean') throw new Error('Invalid fire mode.');
        this.spec = Object.freeze({ ...spec }); this.ammo = spec.capacity; this.reserve = spec.reserve;
    }
    get reloading(): boolean { return this.reloadLeft > 0; }
    get reloadProgress(): number { return this.reloading ? 1 - this.reloadLeft / this.spec.reloadTime : 0; }
    tick(dt: number): void {
        positive(dt, 'delta', true); this.cooldown = Math.max(0, this.cooldown - dt);
        if (this.reloadLeft > 0) {
            this.reloadLeft = Math.max(0, this.reloadLeft - dt);
            if (this.reloadLeft < 1e-9) this.reloadLeft = 0;
            if (this.reloadLeft === 0) { const count = Math.min(this.spec.capacity - this.ammo, this.reserve); this.ammo += count; this.reserve -= count; }
        }
    }
    fire(pressed: boolean, held: boolean): boolean {
        if (!(pressed || this.spec.automatic && held) || this.cooldown > 1e-9 || this.reloading || this.ammo <= 0) return false;
        this.ammo--; this.cooldown = this.spec.interval; return true;
    }
    reload(): boolean {
        if (this.reloading || this.ammo === this.spec.capacity || this.reserve === 0) return false;
        this.reloadLeft = this.spec.reloadTime; return true;
    }
    cancelReload(): void { this.reloadLeft = 0; }
    reset(): void { this.ammo = this.spec.capacity; this.reserve = this.spec.reserve; this.cooldown = this.reloadLeft = 0; }
    restore(raw: { ammo: number; reserve: number }): void {
        if (!Number.isSafeInteger(raw.ammo) || raw.ammo < 0 || raw.ammo > this.spec.capacity || !Number.isSafeInteger(raw.reserve) || raw.reserve < 0 || raw.reserve > 100000)
            throw new Error('Invalid weapon save.');
        this.ammo = raw.ammo; this.reserve = raw.reserve; this.cooldown = this.reloadLeft = 0;
    }
}
