import type { Engine } from '../engine/Engine.js';
import type { Editor } from './Editor.js';
import type { EntityData } from '../level/schema.js';
import type { MotorSettings } from '../core/motor.js';
import { defaultMotor } from '../core/motor.js';
const $ = <T extends HTMLElement = HTMLElement>(id: string): T => {
    const element = document.getElementById(id);
    if (!element)
        throw new Error(`Missing UI element: ${id}`);
    return element as T;
};
const escape = (value: unknown): string => String(value).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
const icons: Record<string, string> = { block: '◇', column: '▥', stairs: '▤', crate: '⬡', switch: '⊙', door: '▥', platform: '▱', trigger: '▧', pickup: '◈', checkpoint: '◎', pad: '⇧', hazard: '△', goal: 'Π', tree: '♧', rock: '⬡', spawn: '↗' };
export class Panel {
    private tab: 'scene' | 'assets' = 'scene';
    private search = '';
    private noticeTimer = 0;
    private debug = false;
    private highQuality = true;
    private readonly abort = new AbortController();
    private readonly cleanups: (() => void)[] = [];
    constructor(readonly engine: Engine, readonly editor: Editor) {
        const signal = this.abort.signal;
        const click = (id: string, fn: () => void) => $(id).addEventListener('click', fn, { signal });
        click('play', () => engine.play());
        click('stop', () => engine.stop());
        click('resume', () => engine.resume());
        click('return-editor', () => engine.stop());
        click('undo', () => engine.undo());
        click('redo', () => engine.redo());
        click('focus', () => editor.focus());
        click('home', () => editor.home());
        click('grid', () => { engine.view.grid.visible = !engine.view.grid.visible; $('grid').classList.toggle('active', engine.view.grid.visible); });
        click('debug', () => { this.debug = !this.debug; engine.setDebug(this.debug); $('debug').classList.toggle('active', this.debug); });
        click('snap', () => { editor.setSnap(!editor.snapping); this.toggle($('snap'), editor.snapping); });
        click('quality', () => { this.highQuality = !this.highQuality; engine.view.quality(this.highQuality); this.toggle($('quality'), this.highQuality); });
        click('add-object', () => this.switchTab('assets'));
        document.querySelectorAll<HTMLButtonElement>('[data-tab]').forEach(button => button.addEventListener('click', () => this.switchTab(button.dataset.tab as 'scene' | 'assets'), { signal }));
        document.querySelectorAll<HTMLButtonElement>('[data-tool]').forEach(button => button.addEventListener('click', () => editor.setTool(button.dataset.tool as 'translate' | 'rotate' | 'scale'), { signal }));
        $('search').addEventListener('input', () => { this.search = $<HTMLInputElement>('search').value.toLowerCase(); this.renderList(); }, { signal });
        $('scene-list').addEventListener('click', e => {
            const button = (e.target as HTMLElement).closest<HTMLButtonElement>('[data-entity]');
            if (button)
                editor.select(button.dataset.entity!);
        }, { signal });
        $('asset-list').addEventListener('click', e => {
            const button = (e.target as HTMLElement).closest<HTMLButtonElement>('[data-prefab]');
            if (button)
                editor.add(button.dataset.prefab!);
        }, { signal });
        $('inspector').addEventListener('change', e => this.changeInspector(e.target as HTMLInputElement), { signal });
        $('inspector').addEventListener('click', e => {
            const action = (e.target as HTMLElement).closest<HTMLElement>('[data-action]')?.dataset.action;
            if (action === 'duplicate')
                editor.duplicate();
            if (action === 'delete')
                editor.remove();
            if (action === 'components') {
                try {
                    const components: unknown = JSON.parse($<HTMLTextAreaElement>('component-json').value);
                    if (!Array.isArray(components))
                        throw new Error('Components must be an array.');
                    const id = editor.selected;
                    engine.commit(d => {
                        const entity = d.entities.find(e => e.id === id);
                        if (entity)
                            entity.components = components;
                    });
                }
                catch (error) {
                    engine.notice(error instanceof Error ? error.message : String(error));
                }
            }
        }, { signal });
        $('player-settings').addEventListener('input', e => {
            const input = e.target as HTMLInputElement;
            if (input.dataset.setting)
                $(`value-${input.dataset.setting}`).textContent = this.formatSetting(input.dataset.setting, Number(input.value));
        }, { signal });
        $('player-settings').addEventListener('change', e => {
            const input = e.target as HTMLInputElement, key = input.dataset.setting as keyof MotorSettings;
            if (key)
                engine.commit(d => { d.player[key] = Number(input.value); });
        }, { signal });
        document.querySelectorAll<HTMLButtonElement>('[data-preset]').forEach(button => button.addEventListener('click', () => {
            const name = button.dataset.preset;
            const settings: Partial<MotorSettings> = name === 'quick' ? { walkSpeed: 7, sprintSpeed: 11, acceleration: 65, friction: 50, airAcceleration: 22, jumpSpeed: 9, gravity: 27, fov: 86 } : name === 'heavy' ? { walkSpeed: 4, sprintSpeed: 6.5, acceleration: 18, friction: 19, airAcceleration: 4, jumpSpeed: 7, gravity: 25, fov: 74 } : defaultMotor;
            engine.commit(d => { Object.assign(d.player, settings); });
            document.querySelectorAll('[data-preset]').forEach(el => el.classList.toggle('active', el === button));
        }, { signal }));
        $('sun').addEventListener('input', () => { const value = Number($<HTMLInputElement>('sun').value); $('sun-value').textContent = value.toFixed(1); engine.view.sun.intensity = value; }, { signal });
        $('sun').addEventListener('change', () => engine.commit(d => { d.environment.sun = Number($<HTMLInputElement>('sun').value); }), { signal });
        click('export', () => this.export());
        click('import', () => $<HTMLInputElement>('file-input').click());
        $('file-input').addEventListener('change', () => { void this.import(); }, { signal });
        this.cleanups.push(editor.events.on('selection', entity => { this.inspector(entity); this.highlight(); }), engine.events.on('document', data => {
            $('project-name').textContent = data.name;
            document.querySelector('.scene-title h1')!.textContent = data.name + '.';
            this.renderList();
            this.playerSettings();
            $<HTMLInputElement>('sun').value = String(data.environment.sun);
            $('sun-value').textContent = data.environment.sun.toFixed(1);
        }), engine.events.on('mode', mode => {
            document.body.classList.toggle('playing', mode !== 'edit');
            $('play-hud').classList.toggle('hidden', mode === 'edit');
            $('pause').classList.toggle('hidden', mode !== 'paused');
            $('play').classList.toggle('hidden', mode !== 'edit');
            $('stop').classList.toggle('hidden', mode === 'edit');
            $('mode-status').textContent = mode === 'edit' ? 'Editor ready' : mode === 'play' ? 'Play test' : 'Paused';
            $<HTMLButtonElement>('import').disabled = mode !== 'edit';
            $<HTMLButtonElement>('export').disabled = mode !== 'edit';
        }), engine.events.on('notice', message => this.notice(message)), engine.events.on('stats', stats => {
            $('fps').textContent = `${stats.fps} fps`;
            $('draws').textContent = `${stats.draws} draws`;
            $('triangles').textContent = `${(stats.triangles / 1000).toFixed(1)}k triangles`;
            if (engine.mode === 'play')
                $('mode-status').textContent = `${stats.speed.toFixed(1)} m/s · ${stats.grounded ? 'Grounded' : 'Airborne'}`;
        }), engine.onFrame(() => {
            if (engine.mode !== 'edit') {
                $('interaction').textContent = engine.runtime.prompt;
                $('objective-text').textContent = engine.runtime.complete ? 'Test complete. Make it your own.' : engine.document.objective;
            }
            $<HTMLButtonElement>('undo').disabled = !engine.history.canUndo || engine.mode !== 'edit';
            $<HTMLButtonElement>('redo').disabled = !engine.history.canRedo || engine.mode !== 'edit';
            document.querySelectorAll<HTMLElement>('[data-tool]').forEach(button => button.classList.toggle('active', button.dataset.tool === editor.transform.mode));
        }));
        window.addEventListener('keydown', event => {
            if (engine.mode === 'edit' && event.key === '/' && !/INPUT|TEXTAREA|SELECT/.test((event.target as HTMLElement)?.tagName)) {
                event.preventDefault();
                $('search').focus();
            }
        }, { signal });
        this.renderList();
        this.inspector(null);
        this.playerSettings();
        $<HTMLInputElement>('sun').value = String(engine.document.environment.sun);
        $('sun-value').textContent = engine.document.environment.sun.toFixed(1);
    }
    private toggle(button: HTMLElement, on: boolean): void { button.classList.toggle('on', on); button.setAttribute('aria-checked', String(on)); }
    notice(message: string): void { window.clearTimeout(this.noticeTimer); $('notice').textContent = message; $('notice').classList.add('show'); this.noticeTimer = window.setTimeout(() => $('notice').classList.remove('show'), 5000); }
    private switchTab(tab: 'scene' | 'assets'): void { this.tab = tab; this.search = ''; $<HTMLInputElement>('search').value = ''; $('scene-list').classList.toggle('hidden', tab !== 'scene'); $('asset-list').classList.toggle('hidden', tab !== 'assets'); document.querySelectorAll<HTMLElement>('[data-tab]').forEach(el => el.classList.toggle('active', el.dataset.tab === tab)); this.renderList(); }
    private renderList(): void {
        const data = this.engine.document;
        $('entity-count').textContent = `${data.entities.length} objects`;
        if (this.tab === 'scene') {
            const filtered = data.entities.filter(e => (e.name + ' ' + e.prefab).toLowerCase().includes(this.search));
            const categories: [
                string,
                (e: EntityData) => boolean
            ][] = [['Gameplay', e => e.components.length > 0 || e.prefab === 'crate'], ['Structures', e => ['block', 'stairs', 'column'].includes(e.prefab)], ['Nature', e => ['tree', 'rock'].includes(e.prefab)], ['Custom', e => !['block', 'stairs', 'column', 'tree', 'rock', 'crate'].includes(e.prefab) && e.components.length === 0]];
            $('scene-list').innerHTML = categories.map(([name, filter]) => {
                const items = filtered.filter(filter);
                if (!items.length)
                    return '';
                return `<div class="group-title">⌄ ${name}<span>${items.length}</span></div>` + items.map(e => `<button class="entity-row ${e.id === this.editor.selected ? 'selected' : ''}" data-entity="${escape(e.id)}" title="${escape(e.name)}"><span class="object-icon">${icons[e.prefab] ?? '◇'}</span><span class="entity-name">${escape(e.name)}</span><span class="entity-dot"></span></button>`).join('');
            }).join('') || '<p class="empty-result">No matching objects.</p>';
        }
        else {
            $('asset-list').innerHTML = this.engine.prefabs.all().filter(p => (p.name + ' ' + p.group).toLowerCase().includes(this.search)).map(p => `<button class="asset-card" data-prefab="${escape(p.id)}" title="${escape(p.summary)}"><span>${icons[p.id] ?? '◇'}</span><div><b>${escape(p.name)}</b><small>${escape(p.group)}</small></div><span>＋</span></button>`).join('') || '<p class="empty-result">No matching prefabs.</p>';
        }
    }
    private highlight(): void { document.querySelectorAll<HTMLElement>('[data-entity]').forEach(button => button.classList.toggle('selected', button.dataset.entity === this.editor.selected)); }
    private inspector(entity: EntityData | null): void {
        $('inspector-mode').textContent = entity ? 'OBJECT' : 'LEVEL';
        if (!entity) {
            $('inspector').innerHTML = `<div class="inspector-intro"><div class="object-badge"><span class="badge-icon">◇</span><div><strong>Level overview</strong><small>Low-poly sandbox</small></div></div><label class="field-label">Level name</label><input class="name-input" data-level-field="name" aria-label="Level name" value="${escape(this.engine.document.name)}"><label class="field-label">Play-test objective</label><input class="name-input" data-level-field="objective" aria-label="Play-test objective" value="${escape(this.engine.document.objective)}"><p class="inspector-description">Select an object to change its shape, position, and behavior. Add parts from the object library.</p><div class="level-facts"><div><strong>${this.engine.document.entities.length}</strong><span>LEVEL OBJECTS</span></div><div><strong>${this.engine.prefabs.all().length}</strong><span>MODULAR PREFABS</span></div></div></div>`;
            return;
        }
        const prefab = this.engine.prefabs.get(entity.prefab);
        $('inspector').innerHTML = `<div class="object-badge"><span class="badge-icon">${icons[entity.prefab] ?? '◇'}</span><div><strong>${escape(prefab.name)}</strong><small>${escape(prefab.group)} / ${escape(entity.id)}</small></div></div><input class="name-input" data-field="name" aria-label="Object name" value="${escape(entity.name)}">${(['position', 'rotation', 'scale'] as const).map(key => `<div class="transform-group"><span class="transform-label">${key === 'rotation' ? 'Rotation · degrees' : key === 'position' ? 'Position · meters' : 'Scale'}</span><div class="vector-fields">${entity[key].map((value, i) => `<label class="vector-field"><span>${['X', 'Y', 'Z'][i]}</span><input type="number" step="${key === 'rotation' ? 15 : key === 'scale' ? .25 : .5}" value="${Number(value.toFixed(3))}" data-field="${key}" data-index="${i}" aria-label="${key} ${['X', 'Y', 'Z'][i]}"></label>`).join('')}</div></div>`).join('')}<label class="color-row">Base color<input type="color" data-field="color" value="${escape(entity.color ?? prefab.build(entity).visuals[0]?.color ?? '#e5d7bd')}"></label><div class="object-actions"><button data-action="duplicate">Duplicate</button><button data-action="delete">Delete</button></div><span class="field-label">Components · JSON</span><textarea id="component-json" class="component-area" spellcheck="false" aria-label="Component data">${escape(JSON.stringify(entity.components, null, 2))}</textarea><button class="apply-components" data-action="components">Apply components</button>`;
    }
    private changeInspector(input: HTMLInputElement): void {
        const levelField = input.dataset.levelField;
        if (levelField === 'name' || levelField === 'objective') {
            this.engine.commit(d => { d[levelField] = input.value; });
            return;
        }
        const key = input.dataset.field, id = this.editor.selected;
        if (!key || !id)
            return;
        this.engine.commit(d => {
            const e = d.entities.find(e => e.id === id);
            if (!e)
                return;
            if (key === 'name')
                e.name = input.value;
            else if (key === 'color')
                e.color = input.value;
            else if (key === 'position' || key === 'rotation' || key === 'scale')
                e[key][Number(input.dataset.index)] = Number(input.value);
        });
    }
    private formatSetting(key: string, value: number): string {
        if (key === 'fov')
            return `${value}°`;
        if (key === 'sensitivity')
            return value.toFixed(4);
        if (['coyoteTime', 'jumpBuffer'].includes(key))
            return `${Math.round(value * 1000)} ms`;
        return `${Number(value.toFixed(2))}`;
    }
    private playerSettings(): void {
        const settings: {
            key: keyof MotorSettings;
            label: string;
            min: number;
            max: number;
            step: number;
        }[] = [
            { key: 'walkSpeed', label: 'Walk speed · m/s', min: .5, max: 15, step: .1 }, { key: 'jumpSpeed', label: 'Jump speed · m/s', min: 1, max: 18, step: .1 },
            { key: 'airAcceleration', label: 'Air control · m/s²', min: 0, max: 40, step: 1 }, { key: 'fov', label: 'Field of view', min: 50, max: 110, step: 1 },
            { key: 'sprintSpeed', label: 'Sprint speed · m/s', min: .5, max: 25, step: .1 }, { key: 'crouchSpeed', label: 'Crouch speed · m/s', min: .1, max: 10, step: .1 },
            { key: 'acceleration', label: 'Ground acceleration · m/s²', min: 1, max: 100, step: 1 }, { key: 'friction', label: 'Braking · m/s²', min: 0, max: 100, step: 1 },
            { key: 'gravity', label: 'Gravity · m/s²', min: 1, max: 60, step: 1 }, { key: 'stepHeight', label: 'Step height · m', min: 0, max: .5, step: .01 },
            { key: 'maxSlope', label: 'Maximum slope · degrees', min: 1, max: 65, step: 1 }, { key: 'coyoteTime', label: 'Late jump allowance', min: 0, max: .4, step: .01 },
            { key: 'jumpBuffer', label: 'Early jump allowance', min: 0, max: .4, step: .01 }, { key: 'sensitivity', label: 'Mouse sensitivity', min: .0002, max: .006, step: .0001 },
            { key: 'headBob', label: 'Head movement', min: 0, max: 1, step: .05 },
        ];
        const slider = (s: typeof settings[number]) => `<label class="slider-row"><span>${s.label}<output id="value-${s.key}">${this.formatSetting(s.key, this.engine.document.player[s.key])}</output></span><input type="range" data-setting="${s.key}" min="${s.min}" max="${s.max}" step="${s.step}" value="${this.engine.document.player[s.key]}"></label>`;
        $('player-settings').innerHTML = settings.slice(0, 4).map(slider).join('') + `<details><summary class="field-label" style="cursor:pointer">More movement settings</summary>${settings.slice(4).map(slider).join('')}</details>`;
    }
    private export(): void {
        const blob = new Blob([JSON.stringify(this.engine.document, null, 2)], { type: 'application/json' }), url = URL.createObjectURL(blob), a = document.createElement('a');
        a.href = url;
        a.download = this.engine.document.name.toLowerCase().replace(/[^a-z0-9]+/g, '-') + '.json';
        a.click();
        window.setTimeout(() => URL.revokeObjectURL(url), 1000);
        this.notice('Level exported. The play state is not included.');
    }
    private async import(): Promise<void> {
        const input = $<HTMLInputElement>('file-input'), file = input.files?.[0];
        if (!file)
            return;
        try {
            if (file.size > 2000000)
                throw new Error('The level file must be smaller than 2 MB.');
            const data: unknown = JSON.parse(await file.text());
            this.engine.load(data);
            this.editor.select(null);
            this.editor.home();
            this.notice('Level imported.');
        }
        catch (error) {
            this.notice(error instanceof Error ? error.message : String(error));
        }
        finally {
            input.value = '';
        }
    }
    dispose(): void {
        this.abort.abort();
        for (const off of this.cleanups)
            off();
        window.clearTimeout(this.noticeTimer);
    }
}
