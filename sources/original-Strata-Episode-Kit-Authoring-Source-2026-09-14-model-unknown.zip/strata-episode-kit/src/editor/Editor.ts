import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { Events } from '../core/events.js';
import { degrees, tuple } from '../core/math.js';
import type { Engine } from '../engine/Engine.js';
import type { EntityData } from '../level/schema.js';
export class Editor {
    readonly orbit: OrbitControls;
    readonly transform: TransformControls;
    readonly events = new Events<{
        selection: EntityData | null;
    }>();
    selected: string | null = null;
    snapping = true;
    private readonly abort = new AbortController();
    private readonly cleanups: (() => void)[] = [];
    private readonly box = new THREE.BoxHelper(undefined, 0xd3f4ae);
    private pointerStart = new THREE.Vector2();
    private dragHappened = false;
    constructor(readonly engine: Engine) {
        const { camera, renderer, editorHelpers } = engine.view, canvas = renderer.domElement;
        this.orbit = new OrbitControls(camera, canvas);
        this.orbit.enableDamping = true;
        this.orbit.dampingFactor = .09;
        this.orbit.maxPolarAngle = Math.PI * .49;
        this.orbit.minDistance = 2;
        this.orbit.maxDistance = 130;
        this.transform = new TransformControls(camera, canvas);
        this.transform.setSize(.8);
        this.transform.setSpace('world');
        this.setSnap(true);
        editorHelpers.add(this.transform.getHelper(), this.box);
        this.box.visible = false;
        this.transform.addEventListener('dragging-changed', event => {
            this.orbit.enabled = !event.value && engine.mode === 'edit';
            if (event.value)
                this.dragHappened = true;
        });
        this.transform.addEventListener('objectChange', () => this.box.update());
        this.transform.addEventListener('mouseUp', () => {
            const object = this.transform.object;
            if (!object || !this.selected)
                return;
            const id = this.selected, position = tuple(object.position), rotation = [degrees(object.rotation.x), degrees(object.rotation.y), degrees(object.rotation.z)] as [
                number,
                number,
                number
            ], scale = tuple(object.scale).map(n => Math.max(.05, n)) as [
                number,
                number,
                number
            ];
            const committed = engine.commit(d => {
                const e = d.entities.find(e => e.id === id);
                if (e) {
                    e.position = position;
                    e.rotation = rotation;
                    e.scale = scale;
                }
            });
            if (!committed) {
                const source = engine.document.entities.find(e => e.id === id);
                if (source) {
                    object.position.fromArray(source.position);
                    object.rotation.set(...source.rotation.map(value => value * Math.PI / 180) as [
                        number,
                        number,
                        number
                    ]);
                    object.scale.fromArray(source.scale);
                    this.box.update();
                }
            }
        });
        const signal = this.abort.signal;
        canvas.addEventListener('pointerdown', e => { this.pointerStart.set(e.clientX, e.clientY); this.dragHappened = false; }, { signal });
        canvas.addEventListener('pointerup', e => {
            if (engine.mode !== 'edit' || e.button !== 0 || this.dragHappened || this.transform.axis || this.pointerStart.distanceTo(new THREE.Vector2(e.clientX, e.clientY)) > 5)
                return;
            const rect = canvas.getBoundingClientRect(), point = new THREE.Vector2((e.clientX - rect.left) / rect.width * 2 - 1, -(e.clientY - rect.top) / rect.height * 2 + 1);
            const ray = new THREE.Raycaster();
            ray.setFromCamera(point, camera);
            const hit = ray.intersectObjects(engine.view.entities.children, true).find(h => h.object.visible);
            this.select(hit ? String(hit.object.userData.entityId) : null);
        }, { signal });
        window.addEventListener('keydown', e => {
            if (engine.mode !== 'edit' || /INPUT|TEXTAREA|SELECT/.test((e.target as HTMLElement)?.tagName))
                return;
            if ((e.ctrlKey || e.metaKey) && e.code === 'KeyZ') {
                e.preventDefault();
                if (e.shiftKey)
                    engine.redo();
                else
                    engine.undo();
                return;
            }
            if ((e.ctrlKey || e.metaKey) && e.code === 'KeyD') {
                e.preventDefault();
                this.duplicate();
                return;
            }
            if (e.ctrlKey || e.metaKey || e.altKey)
                return;
            if (e.code === 'Delete' || e.code === 'Backspace') {
                e.preventDefault();
                this.remove();
            }
            if (e.code === 'KeyF')
                this.focus();
            if (e.code === 'KeyG')
                engine.view.grid.visible = !engine.view.grid.visible;
            if (e.code === 'KeyW')
                this.setTool('translate');
            if (e.code === 'KeyE')
                this.setTool('rotate');
            if (e.code === 'KeyR')
                this.setTool('scale');
        }, { signal });
        this.cleanups.push(engine.events.on('document', () => this.select(this.selected)), engine.events.on('mode', mode => {
            this.orbit.enabled = mode === 'edit';
            this.transform.enabled = mode === 'edit';
            if (mode === 'edit')
                this.select(this.selected);
            else {
                this.transform.detach();
                this.box.visible = false;
            }
        }), engine.onFrame(() => {
            if (engine.mode === 'edit') {
                this.orbit.update();
                if (this.selected)
                    this.box.update();
            }
        }));
        this.home();
    }
    select(id: string | null): void {
        this.selected = id && this.engine.runtime.physics.entities.has(id) ? id : null;
        const entity = this.selected ? this.engine.runtime.physics.entities.get(this.selected) : undefined;
        this.transform.detach();
        this.box.visible = !!entity && this.engine.mode === 'edit';
        if (entity && this.engine.mode === 'edit') {
            this.transform.attach(entity.root);
            this.box.setFromObject(entity.root);
        }
        this.events.emit('selection', entity ? structuredClone(entity.data) : null);
    }
    setTool(mode: 'translate' | 'rotate' | 'scale'): void { this.transform.setMode(mode); }
    setSnap(on: boolean): void { this.snapping = on; this.transform.setTranslationSnap(on ? .5 : null); this.transform.setRotationSnap(on ? Math.PI / 12 : null); this.transform.setScaleSnap(on ? .25 : null); }
    home(): void { this.engine.view.camera.fov = 48; this.engine.view.camera.position.set(31, 26, 35); this.orbit.target.set(0, 1, 0); this.orbit.update(); this.engine.view.camera.updateProjectionMatrix(); }
    focus(): void {
        const entity = this.selected ? this.engine.runtime.physics.entities.get(this.selected) : undefined;
        if (!entity) {
            this.home();
            return;
        }
        const box = new THREE.Box3().setFromObject(entity.root), center = box.getCenter(new THREE.Vector3()), size = box.getSize(new THREE.Vector3()).length();
        const direction = this.engine.view.camera.position.clone().sub(this.orbit.target).normalize();
        this.orbit.target.copy(center);
        this.engine.view.camera.position.copy(center).addScaledVector(direction, Math.max(4, size * 1.8));
        this.orbit.update();
    }
    add(prefab: string): void {
        if (this.engine.mode !== 'edit')
            return;
        const point = this.orbit.target.clone();
        point.x = Math.round(point.x * 2) / 2;
        point.z = Math.round(point.z * 2) / 2;
        const ray = new THREE.Raycaster(new THREE.Vector3(point.x, 50, point.z), new THREE.Vector3(0, -1, 0));
        const surface = ray.intersectObjects(this.engine.view.entities.children, true).find(h => !this.engine.runtime.physics.entities.get(String(h.object.userData.entityId))?.data.components.some(c => ['trigger', 'spawn', 'pickup'].includes(c.type)));
        const entity = this.engine.prefabs.create(prefab, [point.x, (surface?.point.y ?? 0) + .04, point.z]);
        if (this.engine.commit(d => { d.entities.push(entity); })) {
            this.select(entity.id);
            this.engine.notice(`${entity.name} added. Use the handles to move it.`);
        }
    }
    duplicate(): void {
        const source = this.engine.document.entities.find(e => e.id === this.selected);
        if (!source)
            return;
        const copy = structuredClone(source);
        copy.id = `${copy.prefab}-${crypto.randomUUID().slice(0, 8)}`;
        copy.name += ' copy';
        copy.position[0] += 1.5;
        if (this.engine.commit(d => { d.entities.push(copy); }))
            this.select(copy.id);
    }
    remove(): void {
        if (!this.selected)
            return;
        const id = this.selected;
        if (this.engine.commit(d => { d.entities = d.entities.filter(e => e.id !== id); }))
            this.select(null);
    }
    dispose(): void {
        this.abort.abort();
        for (const off of this.cleanups)
            off();
        this.orbit.dispose();
        this.transform.dispose();
        this.transform.getHelper().removeFromParent();
        this.box.geometry.dispose();
        (this.box.material as THREE.Material).dispose();
        this.box.removeFromParent();
        this.events.clear();
    }
}
