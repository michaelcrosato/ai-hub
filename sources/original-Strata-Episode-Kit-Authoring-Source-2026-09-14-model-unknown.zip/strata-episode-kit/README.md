# Strata Episode Kit 0.2

Independent HTML episodes. A small shared data contract. An optional Three.js/Rapier FPS starter.

This version changes the direction of Strata. The collection is not one large game runtime. Each episode owns its document, controls, simulation, art, and local rules. A page transition carries only checked JSON.

## Verification status

**126 unit tests, six local HTTP checks, and seven native browser input checks passed.** The dependency-free TypeScript subset passed strict checking. All 33 application modules passed syntax checks. Static import checks confirm that driving does not import FPS code or Rapier, and that the result page imports no rendering package.

**The 3D game is not release-verified.** Package downloads failed with `EAI_AGAIN`. The managed browser blocked HTTP navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`. Full third-party type checking, the ten Rapier tests, full browser play, and a local-vendor release build could not complete. The native input checks used local script injection on `about:blank`; they do not prove rendering, page navigation, or storage. See [the verification record](docs/VERIFICATION.md).

## Start development

Use Node.js 22 or later. From this folder:

```sh
npm install
npm run dev
```

Open `http://localhost:5173/`. The development server binds to loopback. Reload after a code change. The TypeScript watcher reports errors in the terminal; it is not a live-reload server.

Select an episode card for a direct test. Select **New run** to clear this tab's progress. Select **Resume run** to return to its last page. The previous spatial editor is at `/workbench.html`; it is not the game launcher.

Three.js is pinned to 0.180.0. Rapier compatibility is pinned to 0.19.3. The declared TypeScript version is 5.9.3. These are explicit pins, not claims that they are the newest versions. The offline authoring environment could not create a reviewed dependency lockfile. Commit `package-lock.json` after the first successful install and use `npm ci` thereafter.

## The three-page example

| Page | Owns | Shared runtime dependencies |
| --- | --- | --- |
| Loading Bay | First-person controls, rifle, health, fixed sentries, props, a gate, an escape car | Three.js, Rapier, optional FPS starter |
| Coast Road | Arcade vehicle controls, road collision, car integrity, road checkpoints | Three.js only; no FPS or Rapier |
| Result | Story summary, saved results, return exit | Page kit only; no graphics or physics library |

The intended route is **Loading Bay → Coast Road → Result**. Clear the three sentries. Use the escape car to load the driving page. Drive through the finish gate to load the result page. The full route has not been played in this environment.

All three pages can be opened directly within the served collection. A direct launch does not require completion of the previous episode. This is not access control for a linear campaign.

## Controls

| FPS | Action |
| --- | --- |
| W/A/S/D or arrows | Move |
| Mouse | Look after selecting Enter loading bay |
| Shift | Sprint |
| Space | Jump |
| C or left Control | Crouch |
| Left mouse button | Fire; throw while carrying a crate |
| E | Use, pick up, drop, or board the escape car |
| R | Reload |
| T | Return to the safe start |
| Escape | Pause and release the mouse |

The FPS pause menu has field of view, sensitivity, head movement, invert-Y, quality, volume, and keyboard binding controls. Preferences use local storage. Avoid assigning one key to incompatible actions; the current binding editor does not resolve conflicts for you.

Driving uses W/S for throttle and reverse, A/D to steer, Space to brake, V to change camera, R to return to the last road checkpoint, and Escape to pause. Arrow keys also work. Controls and physics are local to that page.

## What belongs in the reusable FPS starter

The starter provides a fixed-step host, configurable movement, jump buffering, a late-jump allowance, crouch clearance, static and dynamic collision, translating platform support, object use, pause handling, and cleanup. Separate small modules provide health/armor, a magazine weapon with reload timing, and procedural sound.

The example adds hitscan aiming, damage feedback, a low-poly weapon model, a settings menu, and local sentry behavior. There is no universal enemy framework, inventory hierarchy, quest graph, networking layer, vehicle simulator, or animation system. A different FPS can replace these example rules without changing the page kit.

The original movement presets and editor test yard remain available. Current movement values are starting values, not a human-tested final tune. See the movement acceptance plan in the verification record.

## Add an episode

For a close variation of the FPS example:

```sh
npm run clone:episode -- yard hangar
```

This creates `src/episodes/hangar/` and `episodes/hangar/`, and adds a manifest entry. It changes the connection ID and HTML script path. It does not invent new story results, replace art, or change exit meanings. Add `--start` to make the clone the collection's starting page.

For a separately built contribution:

```sh
npm run add:episode -- examples/contributor
```

The example is an independent DOM choice page. It has no TypeScript source in the engine and no FPS inheritance. The command copies its folder and registers its `episode.json`. This route also supports nested entry pages and public assets. See [the contributor guide](docs/CONTRIBUTOR.md).

The build does not inspect arbitrary prebuilt code for safety or find all its imports. A contributor must supply its assets and declare its dependencies. Treat all installed page code as trusted.

## Build the product

```sh
npm run build
npm run preview
```

The normal build checks types and writes `dist/`. The local server uses port 4173. Starter library modules are copied locally. The build follows reachable JavaScript imports rather than copying the complete Three.js add-on folder. It also copies each episode's explicit public assets. It excludes the spatial editor by default.

Use `npm run build:workbench` for an authoring distribution with the editor. The editor is a tool, not a required game dependency.

The game product is a directory with several HTML entry files and shared asset/module files. It is **not** a set of large HTML files with all libraries repeated inline. Serve the directory over HTTP or HTTPS. Do not double-click the files with `file://`.

### CDN preview

```sh
npm run preview:cdn
npm run serve:cdn
```

This creates `web-preview/` through syntax transpilation. It requires a TypeScript compiler; the tool can also use an available global compiler. It uses pinned CDN imports for Three.js and Rapier. Internet is required for the two 3D pages. This is not a fully type-checked build or an offline release. A pre-generated copy is provided as a separate preview archive.

`build-report.json` records per-page application imports and raw/gzip size estimates. Preview counts exclude external CDN library bytes. They are not measured network transfer or frame-rate results.

## Save rules

A run uses same-origin `sessionStorage` in one browser tab. Use **Export run** for a file that lasts beyond that tab. Import the file from the launcher. Checkpoints save small logical facts, not a dump of the world.

FPS saves keep defeated sentries, health, armor, and ammunition. Reload enters at the safe start. Death restores health and ammunition and keeps defeated sentries. Driving saves resume at the last road checkpoint, not at an arbitrary position. The result page's return action preserves episode progress. **New run** is the explicit full reset.

If session storage is blocked, an episode can run with memory-only state. Page-to-page completion is blocked rather than silently losing progress. Its export button still allows a file save. Unsupported API or private-state versions fail explicitly; automatic save migration is not implemented.

## Test and release

```sh
npm test
npm run test:server
npm run typecheck
npm run test:physics
npm run build
npm run audit

# Python is needed only for browser development tests.
python -m pip install -r requirements-test.txt
python -m playwright install chromium
npm run test:input
npm run test:browser:full
```

`npm run verify` runs the automated release gate. `.github/workflows/verify.yml` supplies a CI job. Neither the CI job nor the full release gate has succeeded in the authoring environment. Do not treat their presence as test evidence.

## Map of the source

```text
src/kit/                  The renderer-independent page contract
src/fps/                  Optional play-only FPS host, combat, and sound
src/episodes/yard/         The FPS example and its local sentries
src/episodes/drive/        The separate car model and renderer
src/episodes/debrief/      The DOM-only result page
src/core/                 Small reusable pure functions
src/engine/               Three.js/Rapier adapters and legacy host
src/level/                JSON data, prefab definitions, validation
src/editor/               Optional spatial authoring tools
episodes/                 HTML and episode-owned public assets
campaign.json             Installed pages and named exit routes
examples/contributor/     A prebuilt contribution without FPS code
tests/                    Pure, adapter, and browser checks
tools/                    Local server, build, graph audit, import, clone
```

Read [ARCHITECTURE](docs/ARCHITECTURE.md) for the boundaries, [CONTRIBUTOR](docs/CONTRIBUTOR.md) for parallel work, and [DECISIONS](docs/DECISIONS.md) for the reuse policy. `AGENTS.md` is a short entry guide for a coding assistant. Prior-version records are in `docs/legacy/`.

MIT license. There is no account service, telemetry, cloud save, or game server in this project.
