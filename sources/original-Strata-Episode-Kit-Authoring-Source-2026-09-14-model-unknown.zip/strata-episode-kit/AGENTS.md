# Coding guide

This is an episode kit, not a universal engine. Read `docs/CONTRIBUTOR.md` and `src/kit/` for an integration task. Read only the episode and starter modules relevant to the change.

- Put special AI, controls, physics, and story rules under `src/episodes/<id>/` or in a prebuilt episode folder.
- The page kit must not import Three.js, Rapier, FPS code, or editor code.
- Driving must not import FPS or Rapier. Debrief must not import a renderer.
- Never import `src/engine/Engine.ts` in a play-only page. It is the legacy editor host.
- Use named exits and bounded JSON. Preserve unrelated shared keys. Do not transfer scene objects or physics handles.
- Register owned listeners and resources for cleanup. Do not assume that a previous page's runtime still exists.
- Use a fixed simulation step for physics and gameplay timers. Render separately. Clear input and pause on focus loss.
- Do not add a new framework, package, shared abstraction, or global event protocol merely for one mechanic.
- Use explicit dependency pins. Do not fabricate a lockfile or declare unrun tests passed.

Commands: `npm test`, `npm run test:server`, `npm run typecheck`, `npm run test:physics`, `npm run build`, `npm run audit`, `npm run test:input`, `npm run test:browser:full`. `npm run verify` runs the release gate. Python/Playwright are test-only dependencies.

The authoring environment passed 126 pure unit tests and seven locally injected browser input checks. Full dependency installation and HTTP browser navigation were blocked. See `docs/VERIFICATION.md` before repeating any claim about 3D operation.

Use `npm run clone:episode -- yard new-id` for a source variation. Use `npm run add:episode -- folder` for a built contribution. A designer still owns its dependency, license, story-schema, and performance review.
