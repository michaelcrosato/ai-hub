import { connectEpisode } from '../../build/kit/browser.js';
const status=document.querySelector('#status');
try {
  const {session,scope}=await connectEpisode('alternate-route',new URL('../../campaign.json',location.href));
  const choose=route=>{try{session.complete('done',{shared:{...session.shared,'route-choice':route}});}catch(error){status.textContent=String(error);}};
  scope.listen(document.querySelector('#roof'),'click',()=>choose('roof'));
  scope.listen(document.querySelector('#tunnel'),'click',()=>choose('tunnel'));
  scope.listen(window,'keydown',event=>{if(event.code==='Digit1')choose('roof');if(event.code==='Digit2')choose('tunnel');});
  status.textContent='Use a button or press 1 or 2.';
}catch(error){status.textContent=String(error);}
