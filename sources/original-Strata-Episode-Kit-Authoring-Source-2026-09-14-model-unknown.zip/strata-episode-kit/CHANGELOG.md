# Changelog

## 0.2.0 — 2026-09-14

### Direction

Replaced the default editor landing page with an episode collection. Preserved the spatial editor at `workbench.html`. Added a small renderer-independent page contract rather than expanding the shared runtime to cover every game type.

### Added

- Versioned campaign manifests, relative same-origin entries, named exits, checked JSON state, revision ownership, bounded saves, idempotent completion, and explicit storage failure handling.
- Independent FPS, driving, and DOM result pages. Added a source-clone tool and a prebuilt contributor-folder tool.
- Optional play-only FPS host, health/armor, magazine weapon/reload, procedural sound, settings, and keyboard rebinding. Kept sentry AI local to the yard.
- Separate arcade vehicle model with barriers, camera switch, checkpoint restore, and car integrity.
- Reachable-import packaging, editor-free game output, lazy GLTFLoader import, dependency reports, and a separate CDN preview mode.
- Expanded pure and tool tests to 126; seven native input browser checks; ten supplied Rapier checks; full browser navigation and 3D smoke checks; CI release workflow.

### Fixed

- Crouched respawn now resets the collision capsule and eye height as well as the motor state.
- Held props restore their prior gravity scale rather than an assumed value of one.
- FPS throw input is consumed only while holding an object.
- Runtime prop gravity now follows the episode's configured gravity.
- Pause, focus loss, startup-failure cleanup, graphics-resource cleanup, and back/forward page restore handling received explicit paths.
- Weapon reload completion allows fixed-step floating-point tolerance.

### Verification limits

126 pure unit tests and seven locally injected input checks passed. Syntax and static import checks passed. Full library-aware type checking, Rapier integration, 3D browser operation, and a local-vendor release build remain unverified because package downloads and browser HTTP navigation were blocked. A generated CDN preview is not evidence that the 3D route passed.
