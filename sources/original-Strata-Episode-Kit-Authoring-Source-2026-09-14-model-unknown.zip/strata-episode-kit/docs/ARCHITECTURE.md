# Architecture: pages first, shared code second

## Decision

The product is a collection of independent HTML entry pages. A page may use Three.js, another renderer, or only the DOM. It may use Rapier, a local collision function, or no physics. Controls and AI belong to the page unless they are deliberately reused.

The collection does not maintain one scene, one physics world, or one global entity store. The contract standardizes the boundary, not the internal design.

## Three layers

| Layer | Contents | Required? |
| --- | --- | --- |
| Page kit | Manifest, state validation, save ownership, named exits, lifecycle scope | Required for these connected pages; it has no renderer import |
| Starter | FPS loop, input, movement, rendering/physics adapters, optional combat and sound | No; use, clone, or replace it |
| Episode | Scene, AI, objectives, special controls, art, local save schema | Always local to the episode |

`FpsGame.ts` does not import the campaign session. `CarModel` does not import the FPS motor. The result page does not import Three.js. The dependency audit checks these particular starter boundaries. It is not a security analysis of arbitrary contributed code.

## The integration surface

```ts
const { session, scope } = await connectEpisode(
  'yard',
  new URL('../../campaign.json', location.href),
  showStatus,
);

const inputFacts = session.shared;  // A cloned JSON object.
const localSave = session.local;    // Only this episode's saved data.

session.checkpoint({ checkpoint: 'loading-bay' });

session.complete('drive', {
  local: { defeated: ['guard-a', 'guard-b', 'guard-c'] },
  shared: { ...inputFacts, 'yard-cleared': true, health: 72 },
});
```

The example assumes an entry two directories below the campaign manifest. A nested contribution adjusts that relative path. `showStatus` is an episode-owned function. The actual declarations are in `src/kit/`.

`checkpoint(local, shared?)` replaces this episode's private record. It does not shallow-merge nested local fields. `complete(exit, result?)` stores the result before it requests navigation. The collection maps the exit name to a target page. A designer does not hard-code the next page URL in game logic.

## Manifest and versions

```json
{
  "api": 1,
  "id": "my-collection",
  "title": "My collection",
  "start": "yard",
  "episodes": [
    {"id":"yard","title":"Loading Bay","entry":"episodes/yard/index.html","stateVersion":1,"exits":{"drive":"drive"}},
    {"id":"drive","title":"Coast Road","entry":"episodes/drive/index.html","stateVersion":1,"exits":{"arrive":"debrief"}},
    {"id":"debrief","title":"Result","entry":"episodes/debrief/index.html","stateVersion":1,"exits":{}}
  ]
}
```

API version describes the collection envelope. Each private record also has a `stateVersion`. Unknown API versions, incompatible private versions, duplicate IDs, unsafe entry paths, and unknown exit targets are rejected. No silent migration or data deletion occurs. A breaking private-schema change requires a written migration or a new run. A shared result's meaning also needs a collection-level agreement; JSON shape alone cannot enforce narrative meaning.

A collection must have a valid start and known exits. Loops and branches are allowed. Direct entry is allowed. Variant selection is a manifest change, not a built-in story editor.

## State ownership and failure rules

The run envelope contains API version, campaign ID, revision, active page ID, shared facts, private records, and the last completed exit. It contains no renderer object, callback, entity pointer, collider handle, or DOM node.

The JSON validator rejects cycles, non-finite numbers, class instances, accessors, sparse arrays, functions, and unsafe keys. It bounds depth, nodes, strings, and the whole UTF-8 save. The total save limit is 64 KiB. Put large art and level data in files, not in the run envelope.

Getters return clones. A checkpoint verifies revision ownership before writing. A stale page cannot overwrite a newer session through this API. This is protection against accidental stale writes, not protection against malicious same-origin JavaScript.

A repeated completion is ignored. Invalid results and storage-write failures do not navigate. A synchronous navigation exception attempts to restore the previous save. An HTTP error at the destination is asynchronous and cannot be rolled back by `location.assign`; the saved target remains resumable from the launcher. Page existence and destination startup must be tested before release.

Session storage provides a tab-local run. Browser reload keeps it. A new tab is not a synchronized copy; a tab with an opener may start with a copied session. Export/import is the explicit long-term save path. Local storage holds FPS preferences only. A blocked session store uses a memory adapter for local play and disables completion. [Reference: MDN sessionStorage.]

## Lifecycle and navigation

`Scope` owns listeners, AbortController cancellation, and LIFO disposal functions. Disposal is idempotent and attempts every cleanup before reporting aggregate errors. The FPS host cancels its animation frame, releases input, disposes the runtime and asset cache, and then disposes the renderer. The driving page owns its own renderer and resources.

Pages pause on focus loss or hidden-document state. Pointer capture starts only after a player action. A new FPS page can require another click. This is not a seamless persistent controller across documents. Browser permission rules still apply. [Reference: MDN requestPointerLock.]

The page kit disposes on `pagehide`. A page restored from the browser's back/forward cache reloads from saved state rather than using disposed runtime objects. This behavior is supplied in the full browser checks but was not executable in the managed authoring browser.

Normal HTML navigation is an ownership boundary, not a guarantee of a dedicated operating-system process or immediate GPU memory reclamation. Do not use it as a security sandbox. Explicit Three.js disposal remains useful for repeated in-page starts, failure paths, and authoring tools. [Reference: Three.js cleanup guide.]

## Packaging and size

The normal build produces several HTML entry files, one copy of each reachable starter module, local vendor modules, and explicit episode assets. It does not inline a full engine into every page. Identical shared module URLs can use the browser's normal HTTP cache policy on a production host. The included development server uses `no-store` for editing; no cache savings were measured here.

`Assets.staticModel()` imports GLTFLoader only when a model is requested. Procedural levels do not eagerly load that add-on. A local release still includes the reachable optional loader so it can work offline after deployment. Draco and KTX2 decoders and animated-character adapters are not configured.

The build follows literal static and dynamic module imports through an AST. It does not infer dynamic URL strings, CSS asset graphs, shader imports, or arbitrary third-party loaders. Keep explicit assets with the episode, and extend mappings deliberately. A prebuilt contribution is copied as supplied and needs its own import, license, and network review.

The default game excludes `Engine.ts`, editor modules, and the workbench from play-page import graphs. `build:workbench` is separate. Dependency reports contain raw module sizes and summed per-file gzip estimates, not measured download totals or runtime memory.

## Trust and deployment

All installed pages are trusted code on one origin. The JSON validator prevents malformed data; it does not isolate scripts. A malicious page can read same-origin browser storage outside the kit. For untrusted user code, use separate origins, a restricted message protocol, and a security design. That feature is not included.

Use HTTP or HTTPS. Module scripts and manifest fetches are not supported by double-clicking `file://` entries. All linked entries stay within the collection's deployment root. Subdirectory hosting is supported by relative paths. A compatible file host is sufficient; no application server is required. [References: MDN modules and same-origin policy.]

## Source references

- MDN JavaScript modules: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Guide/Modules
- MDN sessionStorage: https://developer.mozilla.org/en-US/docs/Web/API/Window/sessionStorage
- MDN requestPointerLock: https://developer.mozilla.org/en-US/docs/Web/API/Element/requestPointerLock
- MDN same-origin policy: https://developer.mozilla.org/en-US/docs/Web/Security/Same-origin_policy
- Three.js cleanup: https://threejs.org/manual/en/cleanup.html
- Rapier character controller: https://rapier.rs/docs/user_guides/javascript/character_controller/

The design decisions above are project choices. The references describe browser and library behavior, not evidence that this particular 3D implementation passed its blocked tests.
