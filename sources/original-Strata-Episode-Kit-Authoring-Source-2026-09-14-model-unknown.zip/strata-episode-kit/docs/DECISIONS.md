# Reuse decisions for AI-assisted game work

## The thing to reuse is tested behavior

Writing a movement loop again is not the same as proving its collision behavior, input timing, pause rules, and cleanup again. Keep a shared implementation where its tests and stable behavior save more work than its interface costs.

Do not create a large abstraction only because a model can write it. Cheap code generation can also create cheap duplication, larger review scope, and more untested branches. The design target is a small surface that a designer can understand without loading the whole source tree.

There is no measured token-saving percentage for this project. A reusable library can reduce prompt context when the assistant can rely on its documented interface and tests. It can increase context when every local change requires reading a generic framework. Treat token reduction as a hypothesis to measure across completed tasks, not as a reason to add layers.

## The working rule

Keep the page contract stable. Keep common, verified FPS operations in small optional modules. Let episode-specific mechanics start as local code. Promote a mechanic only after multiple real episodes use substantially the same behavior and its shared interface is smaller than its implementations.

This is not an arbitrary rule that the third use always requires extraction. Two similar pieces of code can have different design pressures. A small amount of deliberate duplication can keep experiments independent. Fixes to genuinely shared safety or correctness rules should remain shared and regression-tested.

## What not to build now

Do not add a universal entity system, universal AI behavior tree, universal vehicle controller, project-wide quest language, dependency-injection container, generic event service, or persistent renderer shell merely to prepare for unknown ideas. The existing signal mechanism is useful inside the FPS prefab world; it is not the transport for every episode in the collection.

Do not put combat in the page kit. Do not force the driving episode to disable an FPS player that it never needed. Do not let editor widgets become play-time imports.

The current FPS starter aims at a useful common subset, not a researched claim that it covers 80% of all FPS games. It includes movement, use, simple firing, health, pause, settings, and restart. Inventory, multiplayer, animation, aim-down-sights, navigation, advanced enemies, and realistic vehicles are deliberately absent.

## HTML is a useful boundary, not an absolute requirement

An HTML document gives each sequence its own startup and input lifecycle. This fits a collection of distinct stories and game types. Separate files do not automatically make all assets small; the actual import and asset graph still matters.

One shared renderer shell can be better for continuous sound, instant transitions, cross-scene camera motion, or a vehicle entered with no break. It also requires stronger lifecycle coordination and more shared conventions. This version chooses full-page cuts. A persistent shell should be a later product requirement, not the default.

Do not insist on a single physical HTML file per episode. Use an HTML entry plus its code and assets. Shared local modules avoid repeating the same library in every file. A separately downloadable episode package can vendor its own dependencies when true distribution independence matters; its size tradeoff is then explicit.

## A practical authoring loop

Start from a small starter or a built-folder example. Place ordinary geometry with the workbench when its format applies. Implement the special rule locally. Run a direct-page check. Connect named exits and small result data. Run the connection tests. Record performance on the target device. Share code only after that work exposes a useful stable boundary.

For a coding assistant, provide the episode brief, the contract declarations, the chosen starter's API, and the relevant tests first. Read the internals only when the change requires them. `AGENTS.md` supports that approach. It does not guarantee that a model will write correct code or avoid reviewing dependencies.
