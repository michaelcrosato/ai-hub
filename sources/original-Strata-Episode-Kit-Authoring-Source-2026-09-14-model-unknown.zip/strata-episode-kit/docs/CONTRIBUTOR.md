# Contributor and AI-designer guide

## The brief a designer needs

Give each designer an episode ID, an entry condition, named exits, accepted shared facts, produced shared facts, private-save version, target device, controls, asset budget, and a completion test. Give them this guide and `src/kit/` declarations. They do not need to read the whole FPS engine to make a driving, puzzle, or DOM episode.

Example brief:

> Build episode `hangar`. It may start without prior progress. Read `health` only when it is a finite number in 0–100; otherwise use 100. On success, emit `yard-cleared: true` and a `health` value in 0–100, then complete exit `drive`. Use private save version 1. Preserve unrelated shared keys. Keep all special AI and controls in the episode. Do not add an AI framework to the shared kit. Include a direct-launch and completion test.

A shared key is an API. Do not redefine `health` from a 0–100 number to a string or a 0–1 ratio in one variant. Two visually different episodes can be substitutable only when their inputs and outputs have compatible meaning.

## Path A: clone a tested starter shape

```sh
npm run clone:episode -- yard hangar
npm run dev
```

Edit `src/episodes/hangar/level.ts` for placement and art. Edit `local-ai.ts` for behavior. Edit `main.ts` for controls, presentation, and exit conditions. Edit `episodes/hangar/index.html` for the page UI. The command updates the connection ID and compiled script path. It does not rename every object, story key, or label for you.

The clone shares the FPS starter implementation. You can replace it. A change in `src/fps/` affects other users of that module, so it needs regression checks. Copy an unstable mechanic into the episode first. Extract it only after reuse makes its boundary clear.

Start by importing the smallest useful layer. Do not import `src/engine/Engine.ts` in a play page; it is the legacy authoring host. Use `FpsGame` or your own loop.

## Path B: deliver a built folder

A contributor can use another build system or write JavaScript directly. Deliver a folder such as:

```text
my-episode/
  episode.json
  index.html
  main.js
  art/
  tests/
```

`episode.json`:

```json
{
  "api": 1,
  "id": "alternate-route",
  "title": "Alternate route",
  "entry": "index.html",
  "stateVersion": 1,
  "exits": {"done": "debrief"}
}
```

The contribution must be built before installation. Exit targets must already exist in the collection, or be added in the same reviewed manifest edit. IDs and destinations must be unique. Folder symlinks are rejected. Relative entries may be nested; references to the campaign and shared kit must account for that depth.

```sh
npm run add:episode -- path/to/my-episode
npm run build
```

The command validates the descriptor, copies the folder to `episodes/<id>/`, and appends its route to `campaign.json`. It does not install contributor npm dependencies, execute build scripts, or make foreign game code safe. A prebuilt page must bring its own files or use an agreed shared URL.

`examples/contributor/` is a working source example of this format. It imports only `../../build/kit/browser.js`, uses normal DOM buttons and keys 1/2, and emits a branch choice. It is not registered in the default three-page campaign. Install it with the command above to add a fourth page.

## Rules at the connection

Use `connectEpisode(id, manifestURL, notice)` once per document. Treat returned shared and private values as data to validate. Provide defaults for direct entry. Use `scope.listen()` for owned listeners and `scope.own()` for other disposal work.

Complete named exits through `session.complete()`. Do not write the storage envelope directly from gameplay. Include `{...session.shared}` when you preserve unrelated shared keys. Save only a bounded logical snapshot. A level-owned mesh, AI object, or physics body is not valid shared state.

`stateVersion` must change when the meaning of saved private data breaks. Automatic migrations are not provided. Do not raise the global API version for a harmless local visual change.

## Use the workbench without inheriting it

`workbench.html` remains available for the original JSON prefab format. Use it to place geometry, tune supported movement fields, and test basic signals. Export JSON as an episode asset. A custom FPS bootstrap can fetch that file, validate it, and pass it to `FpsGame.create()`.

The new yard is authored in `level.ts`; it does not silently share the workbench's autosave. To edit custom yard objects in the workbench, register the same custom prefabs and component validators there before loading their data. A behavior that depends on episode-local AI needs a suitable editor test adapter. There is no automatic visual editor for arbitrary contributed game code.

The FPS prefab convention uses meters, Y up, and camera forward along -Z. The vehicle example follows it for convenient art reuse. The page contract does not force every contributor to use those internal coordinates. Convert values at the boundary if they become shared data.

## Acceptance checklist

Test direct entry, missing optional input facts, checkpoint/reload, each exit, pause/resume, focus loss, cleanup, bad saved data, and state-version changes. Keep input inactive while a menu or text field owns focus. Keep simulation timers on simulation time, not unrelated wall-clock timers.

Record the actual target hardware, viewport, frame time, cold-start transfer, retained memory after repeated entry/exit, and input latency. Do not label a module-byte report as a performance measurement. No target frame rate or memory budget has yet been proven for this kit.

Keep the editor, unused AI libraries, optional decoders, and other episodes out of a page's import graph. Supply asset licenses and an explicit list of external requests. The existing audit checks starter boundaries, not arbitrary prebuilt contributions.

## Joining variants into one collection

Keep distinct IDs and private save records for distinct versions. Give substitutable variants the same exit meanings and result schema. Select one through the manifest's start or another page's named exit. A choice page may select between named exits. No shared inheritance chain is needed.

The current kit provides the routing mechanism, not a content marketplace or automatic semantic merger. Someone still reviews story meaning, licenses, controls, performance, and integration tests. That small review is the cost of reliable compatibility.
