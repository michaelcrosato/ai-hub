# Verification record

Date: September 14, 2026.

This record separates executed checks from checks that are supplied but were not executed.

## Executed checks

| Check | Result |
| --- | --- |
| Compile `src/core/` and `src/level/` with the available TypeScript compiler | Passed |
| Run `tests/core.test.mjs` with Node's test runner | 50 passed, 0 failed |
| Transpile all 19 application TypeScript modules | No syntax diagnostics |
| Resolve each internal import in the preview generator | Passed |
| Parse all 19 emitted modules with `node --check` | Passed |
| Parse all four Node tool scripts | Passed |
| Validate the complete signal-yard document | Passed; 82 entities |
| Validate the blank-level document | Passed; 3 entities |
| Validate the two-cell-gate document | Passed; 81 entities |
| Serve the single-file preview over the local HTTP server | HTTP 200; application import found |
| Serve CSS with the correct MIME type | Passed |
| Handle a missing local file | HTTP 404 |

The core checks used Node.js 22.16.0 and TypeScript 5.8.3, which were available in the build environment. The project declares TypeScript 5.9.3 for a normal installation.

The raw core test output is in `core-tests.txt`.

## Not executed

External package downloads were not available in the container. Three.js and Rapier could not be installed. Therefore the following checks have **not** passed or failed; they were not run:

- Full TypeScript checking with the actual third-party declarations.
- The four supplied Rapier integration tests.
- Browser startup and rendering.
- Pointer-lock movement and interaction.
- Visual inspection at different screen sizes.
- Frame-rate, memory, or cross-browser measurements.
- A complete static distribution build with locally installed vendor files.

The single-file preview is generated from the source. It still needs an internet connection to fetch its pinned library files. It is not evidence that a browser run succeeded.

The declared runtime dependencies are Three.js 0.180.0 and Rapier compatibility package 0.19.3. The browser entry file for the latter is `rapier.mjs`. These are explicit version pins, not a claim that they are the newest releases.

## Run the missing automated checks

From the project root:

```sh
npm install
npm run typecheck
npm test
npm run test:physics
npm run build
npm run preview
```

The physics test file covers a crate resting on a floor, a character stopping at a wall, a fixed sensor detecting a kinematic character, and a ray returning the first obstruction. These tests do not cover every player or platform edge case.

## Manual acceptance checks

### Startup and modes

Start the local source server. Confirm that the workbench appears with no console errors. Select Play test and confirm that the mouse is captured. Press Esc and confirm that movement, signals, and timers pause. Resume. Stop the test and confirm that crates, doors, pickups, and the player return to authored state.

Repeat Play and Stop at least ten times. Check for growth in retained physics worlds, event listeners, and GPU resources. Deliberately block mouse capture and confirm that the error is visible and that the editor remains usable.

### Movement

Walk and sprint in straight and diagonal directions. Check that diagonal speed is not greater. Climb all six test steps. Walk up and down the slope. Jump from an edge. Press jump just before landing. Confirm that jump input does not permit repeated mid-air jumps.

Crouch under a low solid block. Release crouch while still under it. Confirm that the player stays crouched. Leave the obstruction and stand. Set head movement to zero and check that camera height stays stable while walking.

Ride the lift upward and downward. Step onto it while it is moving. Jump from it. This implementation supports translating platforms only; do not treat rotating platforms as an acceptance case.

### Interaction and physics

Push a crate. Pick it up, carry it beside a wall, drop it, and throw it. Confirm that it is not teleported through the wall. Move far enough from a held crate to confirm that the carry constraint releases it.

Aim at a switch through a wall. Confirm that E does not use it. Open and close the signal door. Put a crate in its closing path. Check the closing overlap guard. Repeat with the player in the path. This guard is not a general swept crushing solver.

Use a jump pad. Enter a checkpoint, then a hazard. Confirm that respawn preserves level rule state while a Stop/Play cycle resets it.

### Level rules and authoring

Import `examples/two-cell-gate.json`. Collect one cell; the gate should stay closed. Collect the second; the gate should open. Confirm that the on-screen objective matches this level.

Add, move, rotate, scale, duplicate, and delete objects. Undo and redo those changes. Test one invalid component field and one duplicate spawn. Confirm that the document remains valid after rejection.

Export a level, reload, and import it. Compare the exported document with the imported document. Confirm that physics motion from a play test is absent.

### Visual checks

Check a desktop window and a narrow window. Verify that controls are not hidden behind panels. Check the low-quality setting and shadow toggle. Record performance on the intended device; no performance target has been verified here.
