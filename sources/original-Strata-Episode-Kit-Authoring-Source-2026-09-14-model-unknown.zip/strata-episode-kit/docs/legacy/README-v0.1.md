# STRATA / first-person engine workbench

**Version 0.1.0 — source release**

Strata is a small, modular engine for low-poly first-person games. It includes a level editor, a configurable player controller, a Rapier physics adapter, and a component system for level rules.

The main design rule is simple: **level data does not contain engine code, and a play test does not change the level document.**

## Start

Use Node.js 22 or later. From this folder, run:

```sh
npm install
npm run dev
```

Open `http://localhost:5173`. The first TypeScript build must finish before the page can start. Reload the page after the compiler reports no errors.

The development script uses the TypeScript compiler and a small local HTTP server. It does not need a framework or a bundler. Source changes compile in watch mode. Reload the browser to see a code change. Editor changes appear without a reload.

Use a desktop browser with WebGL 2, WebAssembly, a keyboard, and a mouse. Open the page in its own tab. A browser frame can block mouse capture.

### Single-file preview

Open `strata-preview.html` in a browser. This file contains the engine application code and CSS. It loads Three.js and Rapier from a CDN, so it **needs an internet connection**. The full source project is the correct place to add plugins and local GLB models.

The preview is a convenience build, not a verified browser test result. See the verification status below.

## What is included

| Area | Implementation |
| --- | --- |
| Rendering | Three.js; faceted meshes; shared geometry and materials; directional shadows; sky, fog, and exposure controls |
| Player | Capsule controller; walking; sprinting; crouching with an overhead check; jump buffer; late-jump allowance; air control; step and slope settings |
| Physics | Fixed 60 Hz updates; bounded catch-up; position interpolation; fixed, dynamic, and kinematic bodies; compound collider parts |
| Objects | Pushable crates; spring-based carrying; dropping and throwing; blocked interaction rays |
| Level rules | Switches; doors; moving platforms; trigger volumes; pickups; checkpoints; jump pads; hazards; exits; delays; counters; AND/OR gates |
| Editor | Orbit view; object selection; transform handles; snapping; numeric transforms; duplication; deletion; object search; component JSON editor |
| Documents | JSON validation; import/export; local autosave; bounded undo/redo; isolated play state |
| Extension | Prefab registry; behavior registry; plugin entry point; frame hooks; typed engine events; static GLB visual adapter |

There are 16 built-in prefabs. All local level objects in the demo use the same prefab and document interfaces that a new level uses. The sea and distant rocks are an optional renderer backdrop. Set `environment.backdrop` to `false` to hide them.

## First play test

Select **Play test**. The browser captures the mouse.

Move forward through the courtyard. The signal switch is left of the main path. Aim at it and press **E**. The door rises. Walk through the exit behind it to complete the test.

The side areas test steps, a slope, a moving lift, a jump pad, physics crates, collectible cells, and a hazard. The start marker is also a checkpoint. Press **R** to return to the last checkpoint. Press **Esc** to pause. Select **Stop test** to restore the authored document.

| Play control | Action |
| --- | --- |
| W, A, S, D or arrow keys | Move |
| Mouse | Look |
| Space | Jump |
| Shift | Sprint |
| C or left Control | Crouch |
| E | Use, collect, pick up, or drop |
| Left mouse button | Throw a held crate |
| R | Return to the checkpoint |
| Esc | Release the mouse and pause |

## Make a level

Select **Add objects**, then select a prefab. It appears at the current orbit target, on the surface below that target. Move it with the handles or with the inspector fields. This first version uses click-to-add placement; it does not have a brush or a placement preview.

| Editor control | Action |
| --- | --- |
| Left drag | Orbit |
| Right drag | Pan |
| Mouse wheel | Zoom |
| Click an object | Select |
| W / E / R | Move / rotate / scale tool |
| F | Focus the selected object |
| G | Show or hide the grid |
| Ctrl/Cmd + D | Duplicate |
| Delete or Backspace | Delete |
| Ctrl/Cmd + Z | Undo |
| Ctrl/Cmd + Shift + Z | Redo |
| / | Focus object search |

The grid snap is 0.5 m for position, 15 degrees for rotation, and 0.25 for scale. Each level must have exactly one spawn component. The editor rejects a change that removes or duplicates that spawn.

Deselect the object to edit the level name and play-test objective. The **Player feel** panel changes the settings for the next play test. Open **More movement settings** for acceleration, gravity, slope limits, jump timing, mouse sensitivity, and head movement.

Select **Export** to save a JSON file. Import validates the entire document before it replaces the active level. A local browser save is also made after each valid change. Browser storage can be cleared, restricted, or tied to a different local URL. Use exported files for durable saves.

Three example documents are in `examples/`:

- `signal-yard.json`: the complete test yard.
- `blank-level.json`: a floor and one player start.
- `two-cell-gate.json`: collect both cells to open the exit. This uses the same engine and different component data.

## Connect level rules

Each entity has a `components` array. A component can send or receive a named signal. The component editor uses JSON so custom components do not require a new inspector form.

A switch sends `gate`:

```json
[{ "type": "switch", "channel": "gate", "label": "Gate switch" }]
```

A door receives `gate`:

```json
[{ "type": "door", "channel": "gate", "axis": "y", "distance": 3.6, "speed": 2 }]
```

To require two different signal cells, put this component on a normal entity, such as the exit gate:

```json
[{ "type": "counter", "channel": "cell", "output": "all-cells", "count": 2, "unique": true }]
```

Point the door and exit at `all-cells`. Each pickup already sends `cell` with its own entity ID as the source. The counter accepts each source once by default. See `examples/two-cell-gate.json` for the complete document.

A delayed signal uses `relay`. A gate that requires several active channels uses `logic`. See `docs/LEVELS.md` for the component reference.

## Project structure

```text
src/
  core/       Clock, signals, events, history, and movement policy
  level/      Document validation, prefab definitions, and demo data
  engine/     Render, physics, player, runtime, assets, and behavior adapters
  editor/     Orbit controls, transform tools, and workbench panels
  app.ts      Application startup and plugin installation
examples/     Importable level documents
tests/       Core tests and physics integration tests
tools/       Development server, build script, and preview generator
docs/        Architecture, extension guide, and test status
```

`src/core/` and `src/level/` do not import Three.js or Rapier. They can be tested without a browser or a graphics device.

Read `docs/ARCHITECTURE.md` before changing update order or resource ownership. Read `docs/EXTENDING.md` to add a mechanic or a prefab.

## Build and test

```sh
npm test                 # Core tests
npm run typecheck        # Full TypeScript check, after dependency installation
npm run test:physics     # Rapier integration tests, after dependency installation
npm run build            # Build a static distribution into dist/
npm run preview          # Serve dist/ at http://localhost:4173
npm run preview:html     # Regenerate the single-file CDN preview
```

The normal distribution uses local vendor files. It makes no CDN request. Serve `dist/` with an HTTP server; do not open its `index.html` through `file://`. Put custom models in `assets/` before the build. The build preserves third-party license files.

This first build does not minify or bundle the distribution. It copies ESM modules and their required vendor files. Dependency versions are pinned in `package.json`. Run `npm install` to create a local lockfile, then commit that lockfile with your project.

## Verification status

**50 core tests passed in the build environment.** The core TypeScript compilation also passed. All 19 application modules passed the preview generator's syntax and internal-import checks.

The environment could not download the Three.js and Rapier dependencies. As a result, the full dependency-aware type check, the Rapier integration tests, browser rendering, and pointer-lock gameplay were **not run here**. No frame-rate or cross-browser result is claimed. The single-file preview was generated, but was not run in a browser here.

The tested core used Node.js 22.16.0 and the available TypeScript 5.8.3 compiler. The project pins TypeScript 5.9.3 for a local installation. See `docs/VERIFICATION.md` and `docs/core-tests.txt` for details.

## Current limits

This is an engine foundation, not a complete commercial engine. It has no networking, AI navigation, combat system, animation state machine, audio system, terrain brush, gamepad input, or touch controls. Custom GLB loading supports static visuals only. Collision still comes from the prefab's explicit shapes.

The player is a position-based kinematic capsule, not a fully dynamic body. Moving-platform carry supports translation, not rotating platforms. Door closing uses a next-pose overlap guard, not a general swept crushing solver. Ladders, swimming, wall-running, and vaulting need additional movement policies.

Document changes rebuild the editor's small physics world. This makes ownership and undo clear, but it is not the final approach for very large levels. Large scenes need incremental rebuilding, instancing, spatial streaming, and measured performance budgets.

Core tests are not a substitute for physical gameplay tests. Run the integration tests and the manual checks before you use this version as a release base.

## License

The new engine code uses the MIT license in `LICENSE`. Third-party packages keep their own licenses. No external art or font files are included. The low-poly demo assets are generated from primitive mesh data.
