# Architecture

## Design boundary

Strata keeps three kinds of state separate.

**Authoring state** is a validated `LevelData` document. It contains only JSON values. A `History` object stores copies for undo and redo. Import and editing go through the same validator.

**Simulation state** belongs to `Runtime`. It contains the Rapier world, player body, behavior instances, signal values, timers, and object poses. Starting a play test creates fresh simulation state. Stopping the test discards that state. It does not copy moved crates or open doors back into the document.

**View state** belongs to the renderer and editor. The orbit camera, selected object, transform tool, grid, and viewport quality are not game rules.

This separation is intentional. A physics body must never become the source of a level file.

## Modules

| Module | Responsibility | Does not own |
| --- | --- | --- |
| `core/clock.ts` | Fixed-step accumulation and simulation-time tasks | Browser input or rendering |
| `core/motor.ts` | Desired player movement and jump timing | Collider queries or camera objects |
| `core/events.ts` | Engine events and queued level signals | Entity lookup or game rules |
| `core/history.ts` | Independent document snapshots | Runtime body state |
| `level/schema.ts` | Bounds, identifiers, schema version, and component validation | Object creation |
| `level/prefabs.ts` | Plain visual and collider descriptions | GPU or WASM resources |
| `RenderWorld` | Scene, camera, shared geometry, shared materials, and renderer | Collision results |
| `PhysicsWorld` | Rapier world, body creation, collider ownership, and pose interpolation | Input bindings |
| `Player` | Connection between input, movement policy, physics, and camera | Door or quest rules |
| `BehaviorSystem` | Component factories and built-in mechanics | Authoring history |
| `Runtime` | One level simulation and its lifecycle | Browser persistence |
| `Engine` | Mode changes, document replacement, loop, and plugin installation | Editor panel markup |
| `Editor` | Selection, orbit controls, and transform operations | Signal behavior |
| `Panel` | Inspector fields, import/export controls, and status display | Physics step order |

This is a component-oriented engine. It is not an archetype ECS. A map of entities and a small set of component instances are easier to inspect at this scale. The contract can later support a batched system without changing the level file.

## Fixed-step order

The render loop reads mouse look once per display frame. It then advances the fixed clock. Each simulation step has this order:

1. Store previous poses and clear planned platform movement.
2. Advance simulation-time tasks and deliver queued signals.
3. Consume one interaction edge and deliver its signals.
4. Run behavior `beforeStep` functions. Doors and platforms plan their next pose here.
5. Calculate the player's requested movement. Add support-platform translation. Ask the character controller for permitted movement.
6. Step Rapier once with the fixed interval.
7. Read the player and entity poses.
8. Run behavior `afterStep` functions. Sensors, checkpoints, counters, and hazards belong here.
9. Deliver the remaining queued signals and select the current interaction target.

The renderer interpolates between previous and current poses. It does not change body positions.

The clock uses 60 Hz and permits at most five catch-up steps for one frame. Excess time is dropped and counted. This prevents a long browser stall from creating an unbounded update loop. It does not make the simulation deterministic across all devices.

## Movement policy

`Motor` calculates horizontal acceleration, braking, gravity, and jumping. It has no import from a graphics or physics package. It can therefore be tested as a pure policy.

`Player` supplies the actual grounded state and collider response. It uses a 1.85 m standing capsule and a 1.15 m crouching capsule. An overhead overlap query prevents standing inside a low ceiling. The body origin is at the feet; the capsule is offset above it.

Jump buffering stores a jump edge briefly before landing. The late-jump allowance permits a jump briefly after leaving an edge. Horizontal acceleration is limited as a vector so diagonal movement does not get a separate acceleration advantage.

The default body is kinematic. This gives the movement policy direct control of its requested motion. Dynamic crates still receive impulses. A translating platform publishes its planned displacement before the player moves. Rotating support surfaces are not supported by the carry calculation.

Camera head movement and sprint field-of-view changes are visual effects. They do not move the collider. A reduced-motion preference disables head movement on startup.

## Signals

A signal has a channel, a boolean value, and a source entity ID.

Signals are queued. A listener that sends another signal does not recurse through the JavaScript stack. A delivery limit rejects an excessive chain. The `values` map stores the latest value for each channel. It is fresh for each play test.

Use engine `Events` for application notifications. Use `Signals` for authored level rules. The two systems serve different purposes.

A `counter` can count distinct signal sources. A `logic` component can require all or any input channels. A `relay` can delay a value using simulation time. These operations run without evaluating strings as JavaScript.

## Collision and visuals

A prefab returns visual parts and collider parts separately. Visual detail does not define the collision mesh. Low-poly rocks can use simpler proxy colliders. A decorative ring does not require a torus collider.

Collider parts support boxes, balls, capsules, and cylinders. Several parts can attach to one body. A part can be a sensor and can set friction, restitution, density, and collision groups. Shape dimensions are full dimensions in prefab space. Round shapes use the larger X/Z radius when scaled; use equal X/Z scales when an exact circular shape is required.

The built-in visuals use shared geometry and materials. Removing an entity removes its object roots, not the shared GPU resources. `RenderWorld.dispose()` releases those shared resources.

GLB files are optional static visual replacements. They do not create automatic triangle-mesh collision, animation, or behavior. The URL must be a local `assets/*.glb` path. Treat the contents of those local assets as trusted project files.

## Lifecycle

A runtime owns its physics world, character controller, bodies, component subscriptions, and timers. Disposal releases listeners before it frees physics objects. An asset promise checks whether its target runtime still exists before it attaches a model.

`Assets` owns cached GLB templates and their GPU resources. Entity clones borrow those resources. Replacing a level does not clear the global asset cache. Disposing the engine does.

A plugin can return a cleanup callback. The engine calls plugin cleanup functions in reverse installation order when it is disposed. Individual behavior instances must return their own `dispose` function for subscriptions and other per-level resources.

## Editor transactions

An edit starts from a copy of the current document. Validation runs before replacement. The next runtime is built before the old runtime is removed. A valid replacement is then recorded in history and in local storage.

The current implementation rebuilds the small editor physics world for a committed change. This avoids stale collider scale and stale native handles. For a larger editor, replace this with incremental entity transactions that preserve the same validation and ownership rules.

## Source references

The adapters use the public APIs described in these primary references:

- Three.js TransformControls: https://threejs.org/docs/pages/TransformControls.html
- Rapier character controller: https://rapier.rs/docs/user_guides/javascript/character_controller/
- Rapier scene queries: https://rapier.rs/docs/user_guides/javascript/scene_queries/
- Rapier World API: https://rapier.rs/javascript3d/classes/World.html

Documentation can describe a newer release than the packages pinned in this project. Full checks against the pinned packages remain required. See `VERIFICATION.md`.
