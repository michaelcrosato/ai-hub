> Workbench reference, retained from v0.1. This file describes the optional editor and its level documents. For the v0.2 page contract, use ARCHITECTURE.md and CONTRIBUTOR.md. The new FPS episode has key rebinding; the legacy workbench does not.

# Extend the engine

Install project plugins in `src/app.ts`, after `new Engine(host)` and before `engine.start(level)`. Registrations must exist before a saved level is validated.

## Add a behavior

A behavior has a validator and a factory. The validator protects imported data. The factory creates per-entity runtime state.

The following plugin turns a signal into a notification. Save it as `src/project/message-plugin.ts`:

```ts
import type { EnginePlugin } from '../engine/Engine.js';
import { textField } from '../level/schema.js';

export const messagePlugin: EnginePlugin = {
  id: 'project.messages',
  install(engine) {
    engine.behaviors.register(
      'message',
      data => {
        textField(data, 'channel');
        textField(data, 'message');
      },
      (_entity, data, context) => {
        const channel = String(data.channel ?? 'message');
        const message = String(data.message ?? 'Signal received');
        const unsubscribe = context.signals.on(channel, signal => {
          if (signal.value) context.notify(message);
        });
        return { dispose: unsubscribe };
      },
    );
  },
};
```

Import it in `app.ts` and call `engine.use(messagePlugin)`. Then a component can contain:

```json
{ "type": "message", "channel": "cell", "message": "A cell reached the receiver." }
```

Keep timer and subscription state inside the factory. Do not put it in the level document. Return a `dispose` function when the behavior owns a subscription or another resource.

## Add a prefab

Register plain visual and collider data. This example creates a small round bollard:

```ts
engine.prefabs.register({
  id: 'bollard',
  name: 'Round bollard',
  group: 'Structure',
  summary: 'A small round obstacle with a cylinder collider.',
  components: [],
  build: entity => ({
    body: 'fixed',
    visuals: [{
      shape: 'cylinder',
      position: [0, 0.5, 0],
      scale: [0.22, 1, 0.22],
      color: entity.color ?? '#e5d7bd',
    }],
    colliders: [{
      shape: 'cylinder',
      position: [0, 0.5, 0],
      size: [0.44, 1, 0.44],
      friction: 0.7,
    }],
  }),
});
```

The collider `size` uses full dimensions. The visual cylinder's unit radius is one, so its X/Z scale uses the radius. The box visual uses a unit width of one. Check the base geometry convention before adding a new shape.

A prefab can have several visual parts and several collider parts. Keep sensor colliders separate from solid colliders. A body can be `fixed`, `dynamic`, or `kinematic`.

## Behavior update hooks

`beforeStep(dt)` runs before physics. Use it to plan kinematic motion, apply forces, or change a player's requested movement state.

`afterStep(dt)` runs after physics. Use it to read sensor overlaps and contact results.

`render(dt)` runs at display rate. Use it for a visual animation that does not change collision state.

`interact()` is called when the player presses E while aiming at the entity. `prompt()` supplies the text for that action. A wall in front of the entity blocks the interaction ray.

`dispose()` releases per-instance resources. A fresh instance is created for the next play test.

The context exposes `physics`, `player`, `signals`, `timeline`, `notify`, and `complete`. Use `context.timeline.after()` for an action that must pause with the game.

## Change player controls

Bindings are action names, not hard-coded movement decisions:

```ts
engine.input.bindings.jump = ['Space', 'KeyJ'];
engine.input.bindings.interact = ['KeyE', 'KeyF'];
```

Make a binding change before a play test. There is no key-binding editor or persistence layer in this version.

`MotorSettings` holds numeric feel settings. Use document edits to keep them in exports:

```ts
engine.commit(level => {
  level.player.walkSpeed = 6;
  level.player.airAcceleration = 18;
  level.player.headBob = 0;
});
```

New movement modes should keep their policy separate from collision response. A ladder mode, for example, should use a sensor to select the mode, then supply a different desired movement vector. Do not move the camera through geometry and call that a movement mode.

## Use the engine without the editor

The engine does not import the editor modules. A separate application can omit them:

```ts
const engine = new Engine(document.getElementById('game')!);
await engine.start(levelData);
document.getElementById('start')!.addEventListener('click', () => {
  engine.play();
});
```

Give the host a nonzero width and height. Use the same import map as the main application. A Start button is required because the browser needs a user action before it captures the mouse.

## Work that belongs in later modules

A weapon should use a query service, damage events, and a visual view model. It should not add weapon rules to the renderer.

AI should use its own controller and navigation data. It should not fake keyboard input on the player controller.

Audio should listen to gameplay events and own its audio resources. It should not be placed inside individual mesh constructors.

Networking needs a defined authority model, state format, reconciliation policy, and bandwidth budget. A fixed-step clock alone does not supply these features.

For large worlds, add incremental editor updates, instanced visual batches, and streaming before increasing the entity limit. Measure the target scene and target device rather than assuming that a low polygon count guarantees a low frame time.
