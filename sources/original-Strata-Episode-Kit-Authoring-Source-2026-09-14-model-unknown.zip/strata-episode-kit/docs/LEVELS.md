> Workbench reference, retained from v0.1. This file describes the optional editor and its level documents. For the v0.2 page contract, use ARCHITECTURE.md and CONTRIBUTOR.md. The new FPS episode has key rebinding; the legacy workbench does not.

# Level and component reference

## Coordinate rules

One unit is one meter. Y is up. The default player faces negative Z. Document rotations use degrees. Rapier and Three.js use radians internally. Entity positions mark the prefab's origin; built-in floor-standing prefabs have their origin at the base.

Transforms use positive scales. Reflections through a negative scale are rejected. Apply a rotation instead.

## Document

A version 1 document has `name`, `description`, `objective`, `seed`, `environment`, `player`, and `entities`. `objective` is the text shown during a play test. A missing objective gets a safe default.

Each entity has `id`, `name`, `prefab`, `position`, `rotation`, `scale`, and `components`. It can also have a six-digit `color` and a local GLB `model` path.

Import accepts at most 2 MB in the browser UI. Validation accepts at most 3000 entities and 24 components per entity. Component nesting, transform values, player settings, and signal fields have limits. A document must contain exactly one `spawn` component. Only one component of a given type can exist on one entity. `door` and `mover` cannot share one entity.

The current format rejects unknown component and prefab names. Install a custom plugin before loading a document that uses it.

## Built-in components

| Type | Main fields | Behavior |
| --- | --- | --- |
| `spawn` | `yaw` | Player start and facing direction. Exactly one per level. |
| `switch` | `channel`, `label` | Press E to toggle a channel value. |
| `door` | `channel`, `axis`, `distance`, `speed` | Moves on a local axis while the channel is true. Checks the next closing pose for a player or dynamic-body overlap. |
| `mover` | `axis`, `distance`, `period`, optional `channel` | Moves with a cosine cycle. An optional channel starts and pauses its cycle. |
| `trigger` | `channel`, `once` | Sends true when the player enters and false when the player leaves. With `once`, only the first entry sends a signal. |
| `pickup` | `channel`, `label` | Hides and disables its colliders when collected. Sends true with its own entity ID as source. |
| `checkpoint` | `message` | Stores a player return point on first entry. |
| `pad` | `launchSpeed` | Launches the player upward, with a cooldown. |
| `hazard` | None | Returns the player to the checkpoint. |
| `goal` | `channel`, `requiresSignal`, `message` | Completes the play test on entry. Can require an active channel. |
| `relay` | `channel`, `output`, `delay` | Forwards a boolean value after a simulation-time delay. |
| `counter` | `channel`, `output`, `count`, `unique` | Sends true when enough true signals arrive. Counts each source once unless `unique` is false. |
| `logic` | `inputs`, `output`, `mode` | Sends the result of an `all` or `any` test on named input channels. Sends only when that result changes. |

`trigger`, `checkpoint`, `pad`, `hazard`, and `goal` need a sensor collider in the prefab. Adding their component to an ordinary solid block does not add a sensor. Add the collider in a custom prefab or use the supplied sensor prefab.

`door` and `mover` set their body's type to kinematic at runtime. They can therefore move a normal solid prefab. Dynamic crate grabbing is based on body type; it is not a component.

Signals are transient simulation state. The level file stores wiring, not the current channel values. A Stop/Play cycle resets signals, timers, collected cells, and door positions. Player respawn alone does not reset those rules.

## Recipes

### A delay before a lift starts

Put a trigger on the approach path:

```json
[{ "type": "trigger", "channel": "approach", "once": true }]
```

Put a relay on a normal entity:

```json
[{ "type": "relay", "channel": "approach", "output": "lift-ready", "delay": 1.5 }]
```

Set the platform component:

```json
[{ "type": "mover", "axis": "y", "distance": 3, "period": 6, "channel": "lift-ready" }]
```

### Two switches must remain active

Give the switches channels `left-switch` and `right-switch`. Put this component on a separate entity:

```json
[{ "type": "logic", "inputs": ["left-switch", "right-switch"], "output": "gate", "mode": "all" }]
```

A door that listens to `gate` opens only while both channels are true. Set `mode` to `any` to accept either switch.

### Two distinct cells unlock a gate

Each pickup sends `cell`. Add:

```json
[{ "type": "counter", "channel": "cell", "output": "all-cells", "count": 2, "unique": true }]
```

Point the door and goal at `all-cells`. The complete version is in `examples/two-cell-gate.json`.

### Replace an object's visual with a local model

Add a file at `assets/statue.glb`, then set the entity's model field in JSON:

```json
"model": "assets/statue.glb"
```

Use the prefab's `colliders` array to define collision. The model should use meter units, Y-up orientation, and the same base origin as the prefab. Model placement is a document field; this first inspector does not include a model file picker.

## Limits to observe

A zero-delay signal loop is stopped by a delivery limit. Do not wire an output back to the same input without a clear state change. Delays use the simulation timeline, not browser wall time.

A trigger currently detects the player only. A pressure plate that detects crates needs a custom behavior that calls `world.intersectionPairsWith`. A general trigger filter is a useful next extension, but it is not implemented in this release.

The `logic` component evaluates when an input signal arrives. It does not emit an initial false value on level load. Missing channel values are treated as false during evaluation.
