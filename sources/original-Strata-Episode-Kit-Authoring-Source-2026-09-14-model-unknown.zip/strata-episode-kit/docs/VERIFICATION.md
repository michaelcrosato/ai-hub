# Verification record — 0.2.0

Date: September 14, 2026.

This file records executed checks separately from supplied checks. The presence of test code is not evidence that a test passed. The game is not release-verified.

## Executed and passed

| Check | Result | Scope |
| --- | --- | --- |
| Strict TypeScript subset | Passed | Core math, level schema, page kit, combat, input, sound, car model, portal, DOM result. No Three/Rapier declarations required. |
| Unit suite | 126 passed, 0 failed, 0 skipped | 50 prior core cases plus 71 kit/gameplay cases and five tool cases. |
| Local HTTP suite | Six passed, 0 failed | Real loopback requests: HTML/module MIME, HEAD, missing path, rejected writes, encoded traversal, and symlink escape. These are not browser-navigation tests. |
| Native browser input | Seven passed, 0 failed | Actual Chromium key/mouse input on a locally injected DOM: key state, action edges, rebinding, blur clearing, text-field exclusion, pointer lock/fire, and listener disposal. |
| Full source syntax | 33 application modules passed | TypeScript parse/transpile and `node --check`; not external API type checking. Node tools also passed parsing. |
| Import audit | Passed | Play pages exclude the editor/legacy host. Driving excludes FPS/Rapier. Debrief imports no external rendering or physics package. |
| CDN preview package | Generated | 27 reachable application modules, HTML/CSS, and manifest. Pinned external 3D libraries are not included. |
| Static HTML check | Passed | Referenced DOM IDs and local script/style entries exist for the shipped pages. This is not a visual or browser startup check. |
| Contributor package exercise | Passed | A temporary nested HTML contribution retained its public assets and was marked prebuilt in the preview report. This was a filesystem/build exercise, not a browser play test. |

The input check used `page.set_content()` and local script injection on `about:blank`. It did not navigate around the managed browser restriction. No policy was changed. It proves the tested input adapter behavior only; it does not prove the page contract, session storage, 3D rendering, or complete gameplay.

Tests used Node.js 22.16.0, the available TypeScript 5.8.3 compiler, Python 3.13.5, Playwright 1.57.0, and Chromium 144.0.7559.96. The normal project declares TypeScript 5.9.3. Re-run all checks with installed, pinned project dependencies before release.

## Attempts that could not complete

| Check | Observed result | Conclusion |
| --- | --- | --- |
| `npm install` | `EAI_AGAIN` resolving `registry.npmjs.org` | Third-party packages were not installed. |
| Full `npm run typecheck` | Missing Three.js/Rapier declarations and dependent implicit-any errors | Not passed. Full API compatibility remains unknown. |
| `npm run test:physics` | Stops at the required full compile | The ten Rapier cases did not run. Do not count them as passed or as physics assertion failures. |
| `npm run build` | Stops at the required full compile | No verified local-vendor release was produced. The distinct CDN preview was produced by syntax transpilation. |
| Browser navigation suite | First loopback navigation returns `net::ERR_BLOCKED_BY_ADMINISTRATOR` | Zero navigation checks passed; one blocked entry recorded. Later checks did not run. |
| Full 3D browser suite and CI | Dependencies and navigation prerequisites are unavailable | Not executed successfully. No full route, performance, GPU, or cross-browser claim is supported. |

The managed browser has a blanket URL block. The test records it as blocked and exits nonzero. The complete browser suite is supplied for an unrestricted development/CI environment. The release command also exits nonzero when a prerequisite or test fails. No fake type declarations or fake physics implementation were used to turn missing checks green.

`noEmitOnError` is enabled for normal TypeScript builds. A separate, explicitly labeled transpile command creates the CDN preview. The preview still needs internet for Three.js and Rapier, and its successful generation is not evidence of 3D execution.

## Measured application import graph

| Page | Reachable application modules | Raw application JavaScript bytes | Package imports |
| --- | ---: | ---: | --- |
| Loading Bay | 23 | 105,844 | Three.js, Rapier; optional GLTFLoader is a lazy import |
| Coast Road | 8 | 31,824 | Three.js |
| Result | 5 | 16,822 | None |

These sizes exclude external library bytes, HTML, CSS, assets, response headers, and runtime memory. Shared application modules appear in each page's reachable count but are copied only once into the collection. They are not measured cold-start transfers. The development server deliberately disables caching. See `dependency-audit.json` and the preview's `build-report.json` for machine-readable detail.

## Supplied Rapier regression tests

The ten cases cover a falling crate resting on a floor, a character stopped by a wall, a fixed sensor detecting the player, a ray choosing the first obstruction, standing-capsule reset after crouch, blocked standing under a ceiling, low-step climbing, high-step blocking, held-prop gravity restoration, and separate world gravity settings.

These are a starting set, not full coverage of the character controller. Moving-platform handoffs, slopes, edge contacts, stacking, fast objects, and closing doors still need runtime and manual testing. The source fixes are implemented, but collision behavior has not been confirmed by running Rapier here.

## Supplied browser suite

Contract mode covers actual HTML navigation, session storage, reload, Back/BFCache behavior, tab separation, invalid state, action edges, focus loss, and DOM-only pages. Full mode adds FPS startup, movement, fire, pause, a programmatic page-contract handoff, and driving startup/movement/pause. The programmatic handoff does not prove that a player can defeat the sentries and use the car in the complete route.

The native-input-only script is deliberately separate so its limited passing result cannot be confused with the blocked HTTP and 3D suites.

## Release commands

```sh
npm install
npm run typecheck
npm test
npm run test:server
npm run test:physics
npm run build
npm run audit
python -m pip install -r requirements-test.txt
python -m playwright install chromium
npm run test:input
npm run test:browser:full
```

`npm run verify` runs this gate after dependencies and the browser test tool are installed. `.github/workflows/verify.yml` provides a CI job. The workflow was written but was not run on a hosted service in this task.

## Movement tuning and manual acceptance

The current baseline is 5.5 m/s walk, 9 m/s sprint, 2.6 m/s crouch, 24 m/s² gravity, and 8 m/s initial jump velocity. It uses a 0.11 s late-jump allowance and 0.14 s jump buffer. The collider is 1.85 m high standing, 1.15 m crouched, and 0.3 m in radius. Step allowance is 0.32 m and the maximum climb slope setting is 46 degrees. These are code settings, not measured player-performance values.

Before changing feel values, first pass the Rapier checks. Then use the retained Signal Yard workbench level to walk and sprint in straight and diagonal directions, stop on flat ground, climb steps, move across slopes, jump near edges, and test jump input just before landing. Check the same path at different render rates while keeping the fixed simulation step.

Crouch below a low ceiling. Release crouch while obstructed. Exit the ceiling and stand. Respawn while crouched, and verify the restored capsule visually in physics debug mode. Ride a translating lift, walk onto it while it moves, step off, and jump from it. Rotating-platform support is not implemented.

Push, carry, drop, and throw crates near corners and walls. Verify wall-blocked use and shots. Check door closure with a crate and the player in the opening. Check that a held object regains its original gravity.

In the FPS episode, test health loss, reload timing, empty magazines, death, checkpoint export/import, and the actual car-use exit after all sentries are defeated. In driving, test barriers, reverse, checkpoints, loss of integrity, and the finish gate. Reload each page and enter it directly without prior story results.

Repeat entry/exit and workbench play/stop cycles while inspecting retained listeners, physics worlds, and GPU resources. Test hidden-tab pause, denied pointer capture, malformed saves, a missing destination file, and blocked storage. Record real target hardware, frame-time distribution, startup transfer, memory, and input latency before making a performance claim.

No visual inspection of the actual 3D scenes, device benchmark, mobile acceptance, gamepad acceptance, or complete human play test was possible here.

## Logs

Executed logs and blocked-attempt logs are in `docs/test-results/`. Prior 0.1 records in `docs/legacy/` are historical and do not replace this record.
