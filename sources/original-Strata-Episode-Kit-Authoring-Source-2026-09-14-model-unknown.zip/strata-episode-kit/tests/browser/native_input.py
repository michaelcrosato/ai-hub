"""Native input checks with local script injection. No page-navigation or 3D claim."""
from pathlib import Path
import json
import os
import shutil
import sys
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[2]
code = (root / '.test-build/engine/Input.js').read_text().replace('export const ', 'const ').replace('export class ', 'class ')
checks = []

def record(name, operation):
    try:
        operation()
        checks.append({'name': name, 'status': 'passed'})
    except Exception as error:
        checks.append({'name': name, 'status': 'failed', 'error': str(error)})
        raise

def equal(value, expected):
    assert value == expected, f'{value!r} != {expected!r}'

try:
    with sync_playwright() as p:
        executable = os.environ.get('BROWSER_EXECUTABLE') or shutil.which('chromium')
        browser = p.chromium.launch(executable_path=executable, headless=True, args=['--no-sandbox'])
        try:
            page = browser.new_page()
            page.set_content('<button id="start">Start</button><canvas width="500" height="300"></canvas><input id="text">')
            page.add_script_tag(content=code + '\nwindow.input=new Input(document.querySelector("canvas"));window.input.enabled=true;document.querySelector("#start").onclick=()=>document.querySelector("canvas").requestPointerLock();')
            record('Real key press and release', lambda: (page.keyboard.down('w'), equal(page.evaluate('input.down("forward")'), True), page.keyboard.up('w'), equal(page.evaluate('input.down("forward")'), False)))
            record('One-shot action consumption', lambda: (page.keyboard.down('Space'), equal(page.evaluate('input.consume("jump")'), True), equal(page.evaluate('input.consume("jump")'), False), page.keyboard.up('Space')))
            record('Key rebinding', lambda: (page.evaluate('input.bind("forward",["KeyZ"])'), page.keyboard.down('z'), equal(page.evaluate('input.down("forward")'), True), page.keyboard.up('z')))
            record('Focus-loss key clearing', lambda: (page.keyboard.down('z'), page.evaluate('window.dispatchEvent(new Event("blur"))'), equal(page.evaluate('input.down("forward")'), False), page.keyboard.up('z')))
            record('Text-input exclusion', lambda: (page.click('#text'), page.keyboard.type('z'), equal(page.evaluate('input.down("forward")'), False)))
            def capture():
                page.click('#start')
                page.wait_for_function('document.pointerLockElement !== null', timeout=3000)
                page.mouse.down()
                equal(page.evaluate('input.consume("fire")'), True)
                page.mouse.up()
                page.evaluate('document.exitPointerLock()')
                page.wait_for_function('document.pointerLockElement === null')
            record('Native pointer lock and fire input', capture)
            record('Listener disposal', lambda: (page.evaluate('input.dispose()'), page.keyboard.down('z'), equal(page.evaluate('input.down("forward")'), False), page.keyboard.up('z')))
        finally:
            browser.close()
except Exception as error:
    if not checks or checks[-1]['status'] == 'passed':
        checks.append({'name': 'Browser setup', 'status': 'failed', 'error': str(error)})
finally:
    report = {'mode': 'local DOM injection on about:blank; no page navigation, storage, or 3D test', 'checks': checks, 'passed': sum(c['status']=='passed' for c in checks), 'failed': sum(c['status']=='failed' for c in checks)}
    (root/'test-results').mkdir(exist_ok=True)
    (root/'test-results/native-input.json').write_text(json.dumps(report, indent=2))
    print(json.dumps(report, indent=2))
sys.exit(0 if report['failed'] == 0 and report['passed'] == 7 else 1)
