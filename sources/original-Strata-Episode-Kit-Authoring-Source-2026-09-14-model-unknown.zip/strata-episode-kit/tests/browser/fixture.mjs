import { connectEpisode } from '../../.test-build/kit/browser.js';
const id = document.body.dataset.episode;
const status = document.querySelector('#status');
try {
  const { session, scope } = await connectEpisode(id, new URL('./campaign.json', location.href), text => status.textContent = text);
  const update = () => { document.querySelector('#state').textContent = JSON.stringify(session.snapshot); };
  window.fixture = { session, scope };
  document.querySelector('#save').onclick = () => { try { session.checkpoint({ saved: true }, { score: Number(session.shared.score ?? 0) + 1 }); update(); } catch (e) { status.textContent = String(e); } };
  document.querySelector('#next').onclick = () => { try { session.complete('next'); } catch (e) { status.textContent = String(e); } };
  document.querySelector('#invalid').onclick = () => { try { session.checkpoint({ bad: NaN }); } catch (e) { status.textContent = String(e); } };
  update(); document.body.dataset.ready = 'yes';
} catch (e) { status.textContent = String(e); document.body.dataset.ready = 'error'; }
