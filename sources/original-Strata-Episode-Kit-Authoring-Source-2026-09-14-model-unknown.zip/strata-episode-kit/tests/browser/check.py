"""Browser checks. Contract mode needs no Three.js or Rapier. --full requires npm install.
Run: python tests/browser/check.py [--full]
Install test tool: python -m pip install -r requirements-test.txt
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[2]
parser = argparse.ArgumentParser()
parser.add_argument('--full', action='store_true')
parser.add_argument('--screenshots', type=Path, default=ROOT / 'test-results')
args = parser.parse_args()
args.screenshots.mkdir(parents=True, exist_ok=True)
results = []

def check(name, fn):
    start = time.monotonic()
    try:
        fn()
        results.append({'name': name, 'status': 'passed', 'seconds': round(time.monotonic()-start, 3)})
        print('PASS', name, flush=True)
    except Exception as error:
        results.append({'name': name, 'status': 'blocked' if 'ERR_BLOCKED_BY_ADMINISTRATOR' in str(error) else 'failed', 'error': str(error)})
        print('FAIL', name, str(error), flush=True)
        raise

def eq(actual, expected):
    assert actual == expected, f'{actual!r} != {expected!r}'

def truth(value, message='Condition was false'):
    assert value, message

with socket.socket() as sock:
    sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]
server = subprocess.Popen(['node', 'tools/serve.mjs', '.', str(port)], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
base = f'http://127.0.0.1:{port}'
try:
    for _ in range(80):
        try:
            urllib.request.urlopen(base+'/tests/browser/a.html', timeout=.2).close(); break
        except Exception:
            time.sleep(.05)
    with sync_playwright() as p:
        executable = os.environ.get('BROWSER_EXECUTABLE') or shutil.which('chromium') or shutil.which('chromium-browser')
        browser = p.chromium.launch(headless=True, executable_path=executable, args=['--no-sandbox', '--enable-unsafe-swiftshader', '--use-angle=swiftshader'])
        context = browser.new_context(viewport={'width': 1440, 'height': 1000})
        page = context.new_page()
        errors = []
        requests = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.on('request', lambda request: requests.append(request.url))
        def visit(path):
            page.goto(base+path)
            page.wait_for_selector('body[data-ready="yes"]')
        def state():
            return page.evaluate('window.fixture.session.snapshot')
        check('direct page launch creates an empty local session', lambda: (visit('/tests/browser/a.html'), eq(state()['active'], 'alpha'), eq(state()['shared'], {})))
        check('checkpoint uses real tab storage', lambda: (page.click('#save'), eq(state()['shared']['score'], 1), eq(page.evaluate('JSON.parse(sessionStorage.getItem(window.fixture.session.key)).shared.score'), 1)))
        def transition():
            page.click('#next'); page.wait_for_url('**/tests/browser/b.html'); page.wait_for_selector('body[data-ready="yes"]')
            eq(state()['shared']['score'], 1); eq(state()['episodes']['alpha']['data']['saved'], True)
            eq(state()['lastExit'], {'from':'alpha', 'to':'beta', 'exit':'next'})
        check('real HTML navigation preserves shared and private JSON', transition)
        check('reload keeps the tab session', lambda: (page.reload(), page.wait_for_selector('body[data-ready="yes"]'), eq(state()['shared']['score'], 1)))
        def return_page():
            page.go_back(); page.wait_for_url('**/tests/browser/a.html'); page.wait_for_selector('body[data-ready="yes"]')
            eq(state()['active'], 'alpha'); eq(state()['shared']['score'], 1)
            page.click('#save'); eq(state()['shared']['score'], 2)
        check('browser Back re-enters without stale state', return_page)
        def separate_tab():
            other = context.new_page(); other.goto(base+'/tests/browser/a.html'); other.wait_for_selector('body[data-ready="yes"]')
            eq(other.evaluate('window.fixture.session.shared'), {}); other.close()
        check('a separate tab has a separate run', separate_tab)
        check('invalid JSON data is blocked without a write', lambda: (page.click('#invalid'), truth('finite JSON' in page.inner_text('#status')), eq(state()['shared']['score'], 2)))
        def blocked_storage():
            blocked = browser.new_context()
            blocked.add_init_script("Object.defineProperty(window, 'sessionStorage', {get(){throw new DOMException('Blocked', 'SecurityError')}})")
            tab = blocked.new_page(); tab.goto(base+'/tests/browser/a.html'); tab.wait_for_selector('body[data-ready="yes"]'); tab.click('#save'); tab.click('#next')
            truth('storage is unavailable' in tab.inner_text('#status')); truth(tab.url.endswith('/a.html')); blocked.close()
        check('blocked storage permits local play but blocks transition', blocked_storage)
        def old_save():
            page.evaluate("sessionStorage.setItem('strata.campaign.v1.contract-test', '{bad')")
            page.reload(); page.wait_for_selector('body[data-ready="error"]')
            eq(page.evaluate("sessionStorage.getItem('strata.campaign.v1.contract-test')"), '{bad')
        check('corrupt saves are reported and retained', old_save)
        check('all contract traffic stayed on the local server', lambda: truth(all(url.startswith(base) or url.startswith('data:') for url in requests)))
        def input_capture():
            visit('/tests/browser/input.html'); page.click('#play'); page.wait_for_function("document.pointerLockElement === document.querySelector('canvas')")
            page.keyboard.down('w'); truth(page.evaluate("window.fixture.input.down('forward')")); page.keyboard.up('w')
            page.keyboard.down('Space'); eq(page.evaluate("window.fixture.input.consume('jump')"), True); eq(page.evaluate("window.fixture.input.consume('jump')"), False); page.keyboard.up('Space')
        check('mouse capture and real keyboard action edges', input_capture)
        def rebind():
            page.evaluate("window.fixture.input.bind('forward', ['KeyZ'])"); page.keyboard.down('z'); truth(page.evaluate("window.fixture.input.down('forward')")); page.keyboard.up('z')
            page.keyboard.down('w'); eq(page.evaluate("window.fixture.input.down('forward')"), False); page.keyboard.up('w')
        check('rebinding replaces the prior action key', rebind)
        def blur():
            page.keyboard.down('z'); page.evaluate("window.dispatchEvent(new Event('blur'))"); eq(page.evaluate("window.fixture.input.down('forward')"), False); page.keyboard.up('z')
            page.evaluate('document.exitPointerLock()'); page.wait_for_function('document.pointerLockElement === null')
        check('focus loss clears held input', blur)
        def text_input():
            page.click('#text'); page.keyboard.type('z'); eq(page.evaluate("window.fixture.input.down('forward')"), False)
        check('text fields do not trigger movement', text_input)
        def cleanup_input():
            page.evaluate('window.fixture.input.dispose()'); page.click('body', position={'x': 10, 'y': 200}); page.keyboard.down('z'); eq(page.evaluate("window.fixture.input.down('forward')"), False); page.keyboard.up('z')
        check('disposed input removes browser listeners', cleanup_input)
        # These two checks run the production portal and DOM-only episode when compiled files exist.
        if (ROOT/'build/portal.js').exists():
            requests.clear()
            def portal():
                page.goto(base+'/index.html'); page.wait_for_function("!document.getElementById('new').disabled")
                eq(page.locator('.card').count(), len(json.loads((ROOT/'campaign.json').read_text())['episodes']))
                page.screenshot(path=str(args.screenshots/'collection.png'), full_page=True)
            check('collection page lists the installed HTML entries', portal)
            def debrief():
                page.goto(base+'/episodes/debrief/index.html?test=1'); page.wait_for_function('window.strataTest?.session !== undefined')
                truth('Contract v1' in page.inner_text('#status'))
                truth(not any('/node_modules/' in u or 'cdn.jsdelivr' in u or '/engine/' in u or '/fps/' in u for u in requests))
                page.screenshot(path=str(args.screenshots/'debrief.png'), full_page=True)
            check('debrief runs without any renderer, FPS, or physics requests', debrief)
        check('contract and DOM browser flows produced no uncaught errors', lambda: eq(errors, []))
        if args.full:
            required = [ROOT/'node_modules/three/build/three.module.js', ROOT/'node_modules/@dimforge/rapier3d-compat/rapier.mjs']
            if not all(path.exists() for path in required):
                results.append({'name': 'Full 3D dependency readiness', 'status': 'blocked', 'error': 'npm dependencies are missing'})
                raise RuntimeError('Full 3D checks cannot start: npm dependencies are missing. Contract checks above are separate, not a 3D test result.')
            errors.clear(); requests.clear()
            def fps():
                page.goto(base+'/episodes/yard/index.html?test=1'); page.wait_for_function('window.strataTest?.game !== undefined', timeout=60000)
                page.click('#play'); page.wait_for_function('window.strataTest.game.running')
                before = page.evaluate('window.strataTest.game.player.current.z')
                page.keyboard.down('w'); page.wait_for_timeout(650); page.keyboard.up('w')
                truth(page.evaluate('window.strataTest.game.player.current.z') < before - .5)
                ammo = page.evaluate('window.strataTest.weapon.ammo'); page.mouse.click(700, 500); page.wait_for_timeout(100)
                truth(page.evaluate('window.strataTest.weapon.ammo') < ammo)
                page.keyboard.press('Escape'); page.wait_for_function('!window.strataTest.game.running')
                position = page.evaluate('window.strataTest.game.player.current.toArray()'); page.wait_for_timeout(250)
                eq(page.evaluate('window.strataTest.game.player.current.toArray()'), position)
                page.screenshot(path=str(args.screenshots/'fps-paused.png'))
            check('3D FPS draws, captures input, moves, fires, and pauses', fps)
            def fps_handoff():
                page.evaluate("window.strataTest.session.complete('drive', {shared: {'yard-cleared': true, health: 72}})")
                page.wait_for_url('**/episodes/drive/index.html')
                page.wait_for_function("!document.getElementById('play').disabled", timeout=60000)
                truth('Progress arrived' in page.inner_text('#status'))
            check('FPS-to-driving page handoff carries the declared result', fps_handoff)
            def drive():
                requests.clear(); page.goto(base+'/episodes/drive/index.html?test=1'); page.wait_for_function('window.strataTest?.model !== undefined', timeout=60000)
                page.click('#play'); page.keyboard.down('w'); page.wait_for_timeout(700); page.keyboard.up('w')
                truth(page.evaluate('window.strataTest.model.z') < 3.5)
                page.keyboard.press('Escape'); z = page.evaluate('window.strataTest.model.z'); page.wait_for_timeout(200)
                eq(page.evaluate('window.strataTest.model.z'), z)
                truth(not any('rapier' in u or '/fps/' in u or '/engine/' in u for u in requests))
                page.screenshot(path=str(args.screenshots/'driving-paused.png'))
            check('3D driving moves and pauses without FPS or Rapier imports', drive)
            check('full 3D smoke flows produced no uncaught errors', lambda: eq(errors, []))
        browser.close()
finally:
    server.terminate()
    try: server.wait(timeout=3)
    except subprocess.TimeoutExpired: server.kill()
    report = {'mode': 'full' if args.full else 'contract-and-DOM', 'checks': results, 'passed': sum(r['status']=='passed' for r in results), 'failed': sum(r['status']=='failed' for r in results), 'blocked': sum(r['status']=='blocked' for r in results)}
    (args.screenshots/'browser-report.json').write_text(json.dumps(report, indent=2))
print(f"{report['passed']} browser checks passed; {report['failed']} failed. Mode: {report['mode']}")
