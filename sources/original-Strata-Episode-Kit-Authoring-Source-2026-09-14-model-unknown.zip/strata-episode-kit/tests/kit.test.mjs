import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { validateCampaign, initialSave, validateSave, parseSave, jsonObject, episodeURL, storageKey } from '../.test-build/kit/contract.js';
import { EpisodeSession, MemoryStorage } from '../.test-build/kit/session.js';
import { Scope } from '../.test-build/kit/scope.js';
import { Vitals, Weapon, rifleSpec } from '../.test-build/fps/combat.js';
import { CarModel } from '../.test-build/episodes/drive/model.js';
const raw = JSON.parse(await readFile('tests/fixtures/campaign.json', 'utf8'));
const campaign = validateCampaign(raw);
const setup = (overrides = {}) => { const storage = new MemoryStorage(), calls = []; const ports = { storage, baseURL: 'https://example.test/game/campaign.json', navigate: url => calls.push(url), ...overrides }; return { storage: ports.storage, calls, ports, session: new EpisodeSession(campaign, 'yard', ports) }; };
test('contract fixture has three independent HTML entries', () => assert.equal(campaign.episodes.length, 3));
for (const [name, change] of [
 ['unknown API', c => { c.api = 2; }], ['missing start', c => { c.start = 'missing'; }],
 ['duplicate IDs', c => { c.episodes[1].id = 'yard'; }], ['duplicate entries', c => { c.episodes[1].entry = './episodes/yard/index.html'; }],
 ['external entry', c => { c.episodes[0].entry = 'https://evil.test/a.html'; }], ['parent path', c => { c.episodes[0].entry = '../a.html'; }],
 ['dot path', c => { c.episodes[0].entry = 'episodes/./yard/index.html'; }], ['script entry', c => { c.episodes[0].entry = 'javascript:alert(1)'; }],
 ['query entry', c => { c.episodes[0].entry = 'a.html?x=1'; }], ['unknown target', c => { c.episodes[0].exits.drive = 'missing'; }],
 ['unsafe ID', c => { c.episodes[0].id = '__proto__'; }], ['bad state version', c => { c.episodes[0].stateVersion = .5; }],
]) test(`campaign rejects ${name}`, () => { const c = structuredClone(raw); change(c); assert.throws(() => validateCampaign(c)); });
test('episode URLs preserve a subdirectory deployment', () => assert.equal(episodeURL(campaign, 'yard', 'https://site.test/release/a/campaign.json'), 'https://site.test/release/a/episodes/yard/index.html'));
test('episode URLs reject file protocol', () => assert.throws(() => episodeURL(campaign, 'yard', 'file:///game/campaign.json')));
test('direct episode launch starts a valid isolated session', () => { const s = new EpisodeSession(campaign, 'drive', { storage: new MemoryStorage(), baseURL: 'https://test.test/campaign.json', navigate() {} }); assert.equal(s.snapshot.active, 'drive'); assert.deepEqual(s.shared, {}); });
test('checkpoint changes only the current episode namespace', () => { const { session } = setup(); session.checkpoint({ checkpoint: 1 }, { health: 72 }); assert.deepEqual(session.local, { checkpoint: 1 }); assert.deepEqual(session.shared, { health: 72 }); assert.deepEqual(Object.keys(session.snapshot.episodes), ['yard']); });
test('snapshot and getters cannot mutate saved state', () => { const { session } = setup(); session.checkpoint({ x: 1 }, { nested: { x: 2 } }); const s = session.snapshot; s.shared.nested.x = 100; const l = session.local; l.x = 7; assert.equal(session.shared.nested.x, 2); assert.equal(session.local.x, 1); });
test('transition saves before navigation and passes only JSON', () => { const storage = new MemoryStorage(); const s = new EpisodeSession(campaign, 'yard', { storage, baseURL: 'https://test.test/game/campaign.json', navigate(url) { const save = parseSave(storage.getItem(storageKey(campaign)), campaign); assert.equal(save.active, 'drive'); assert.equal(save.shared.health, 64); assert.ok(url.endsWith('/game/episodes/drive/index.html')); } }); assert.equal(s.complete('drive', { shared: { health: 64 } }), true); });
test('completion is idempotent', () => { const { session, calls } = setup(); assert.equal(session.complete('drive'), true); assert.equal(session.complete('drive'), false); assert.equal(calls.length, 1); });
test('unknown exits never navigate', () => { const { session, calls } = setup(); assert.throws(() => session.complete('missing')); assert.equal(calls.length, 0); });
test('storage failure blocks navigation without changing the snapshot', () => { const { session, calls, ports } = setup(); const before = session.snapshot; ports.storage.setItem = () => { throw new Error('Quota exceeded'); }; assert.throws(() => session.complete('drive')); assert.deepEqual(session.snapshot, before); assert.equal(calls.length, 0); assert.equal(session.transitioning, false); });
test('synchronous navigation failure rolls back the committed state', () => { const { session, storage } = setup({ navigate() { throw new Error('Blocked'); } }); const before = session.snapshot; assert.throws(() => session.complete('drive')); assert.deepEqual(session.snapshot, before); assert.deepEqual(parseSave(storage.getItem(session.key), campaign), before); });
test('nonpersistent sessions refuse cross-page completion', () => { const { session, calls } = setup({ persistent: false }); session.checkpoint({ x: 1 }); assert.throws(() => session.complete('drive'), /storage/); assert.equal(calls.length, 0); });
test('stale page instances cannot overwrite a newer page', () => { const { session, ports } = setup(); new EpisodeSession(campaign, 'drive', ports); assert.throws(() => session.checkpoint({ x: 1 }), /old session/); });
test('a two-page journey preserves the first page private data', () => { const { session, ports } = setup(); session.complete('drive', { local: { kills: 3 }, shared: { health: 80 } }); const drive = new EpisodeSession(campaign, 'drive', ports); assert.equal(drive.shared.health, 80); assert.deepEqual(drive.local, {}); drive.checkpoint({ checkpoint: 2 }); assert.equal(drive.snapshot.episodes.yard.data.kills, 3); });
test('export is re-importable', () => { const { session } = setup(); session.checkpoint({ x: 1 }); assert.deepEqual(parseSave(session.export(), campaign), session.snapshot); });
test('large valid exports stay within the compact wire limit', () => { const { session } = setup(); session.checkpoint({ values: Array.from({ length: 2000 }, (_, i) => i) }); assert.deepEqual(parseSave(session.export(), campaign), session.snapshot); });
test('save from another campaign is rejected', () => { const s = initialSave(campaign); s.campaign = 'other'; assert.throws(() => validateSave(s, campaign)); });
test('old private state requires an explicit migration', () => { const s = initialSave(campaign); s.episodes.yard = { version: 99, data: {} }; assert.throws(() => validateSave(s, campaign), /migration/); });
test('a forged saved exit is rejected', () => { const s = initialSave(campaign); s.lastExit = { from: 'yard', to: 'debrief', exit: 'drive' }; assert.throws(() => validateSave(s, campaign)); });
test('invalid saved JSON is not silently cleared', () => { const storage = new MemoryStorage(); storage.setItem(storageKey(campaign), '{broken'); assert.throws(() => new EpisodeSession(campaign, 'yard', { storage, baseURL: 'https://test.test/campaign.json', navigate() {} })); assert.equal(storage.getItem(storageKey(campaign)), '{broken'); });
for (const [name, data] of [['NaN', { x: NaN }], ['infinity', { x: Infinity }], ['undefined', { x: undefined }], ['function', { x() {} }], ['BigInt', { x: 1n }], ['class', { x: new Date() }], ['sparse array', { x: Array(2) }], ['unsafe property', JSON.parse('{"__proto__":{"x":1}}')]]) test(`JSON rejects ${name}`, () => assert.throws(() => jsonObject(data)));
test('JSON rejects cycles', () => { const d = {}; d.self = d; assert.throws(() => jsonObject(d)); });
test('JSON accepts repeated, noncyclic references by value', () => { const x = { value: 1 }; assert.deepEqual(jsonObject({ a: x, b: x }), { a: { value: 1 }, b: { value: 1 } }); });
test('JSON rejects oversized UTF-8 data', () => assert.throws(() => jsonObject({ a: 'é'.repeat(20000), b: 'é'.repeat(20000) }), /64 KiB/));
test('JSON rejects deep nesting', () => { let d = {}; for (let i = 0; i < 15; i++) d = { child: d }; assert.throws(() => jsonObject(d)); });
test('JSON does not invoke an accessor', () => { let invoked = false; const d = {}; Object.defineProperty(d, 'x', { enumerable: true, get() { invoked = true; return 1; } }); assert.throws(() => jsonObject(d)); assert.equal(invoked, false); });
test('JSON rejects symbols and custom array properties', () => { assert.throws(() => jsonObject({ [Symbol('x')]: 1 })); const a = []; a.foo = 1; assert.throws(() => jsonObject({ a })); });
test('scope cleans once in reverse order', () => { const calls = [], scope = new Scope(); scope.own(() => calls.push(1)); scope.own(() => calls.push(2)); scope.dispose(); scope.dispose(); assert.deepEqual(calls, [2, 1]); });
test('scope continues cleanup after a failure', () => { let done = false; const scope = new Scope(); scope.own(() => { done = true; }); scope.own(() => { throw new Error('bad cleanup'); }); assert.throws(() => scope.dispose(), AggregateError); assert.equal(done, true); });
test('scope removes event listeners', () => { const target = new EventTarget(), scope = new Scope(); let count = 0; scope.listen(target, 'test', () => count++); target.dispatchEvent(new Event('test')); scope.dispose(); target.dispatchEvent(new Event('test')); assert.equal(count, 1); });
test('late scope ownership is disposed immediately', () => { const scope = new Scope(); scope.dispose(); let count = 0; scope.own(() => count++); assert.equal(count, 1); });
test('armor absorbs 60 percent while available', () => { const v = new Vitals(); v.restore({ health: 100, armor: 10 }); assert.deepEqual(v.damage(20), { healthLost: 10, armorLost: 10, killed: false }); assert.equal(v.health, 90); });
test('damage grace uses simulation time', () => { const v = new Vitals(); v.damage(10, .2); v.damage(10); assert.equal(v.health, 90); v.tick(.21); v.damage(10); assert.equal(v.health, 80); });
test('death fires once and heal does not revive', () => { const v = new Vitals(); assert.equal(v.damage(150).killed, true); assert.equal(v.damage(150).killed, false); v.heal(100); assert.equal(v.health, 0); v.reset(); assert.equal(v.health, 100); });
test('vitals reject invalid numbers', () => { const v = new Vitals(); for (const value of [-1, NaN, Infinity]) { assert.throws(() => v.damage(value)); assert.throws(() => v.heal(value)); } assert.throws(() => v.restore({ health: 101, armor: 0 })); });
test('weapon applies its fire interval', () => { const w = new Weapon(); assert.equal(w.fire(true, true), true); assert.equal(w.fire(true, true), false); w.tick(.16); assert.equal(w.fire(false, true), true); assert.equal(w.ammo, 10); });
test('semi-auto needs a fresh press', () => { const w = new Weapon({ ...rifleSpec, automatic: false }); assert.equal(w.fire(false, true), false); assert.equal(w.fire(true, true), true); w.tick(1); assert.equal(w.fire(false, true), false); });
test('reload transfers only the required ammo', () => { const w = new Weapon(); w.fire(true, true); assert.equal(w.reload(), true); w.tick(2); assert.equal(w.ammo, 12); assert.equal(w.reserve, 59); });
test('reload completes after exactly 75 fixed ticks', () => { const w = new Weapon(); w.fire(true, true); w.reload(); for (let i = 0; i < 75; i++) w.tick(1 / 60); assert.equal(w.reloading, false); assert.equal(w.ammo, 12); });
test('empty reserve cannot create ammo', () => { const w = new Weapon(); w.restore({ ammo: 0, reserve: 0 }); assert.equal(w.reload(), false); assert.equal(w.fire(true, true), false); });
test('partial reserve produces a partial magazine', () => { const w = new Weapon(); w.restore({ ammo: 1, reserve: 3 }); w.reload(); w.tick(2); assert.equal(w.ammo, 4); assert.equal(w.reserve, 0); });
test('firing is blocked during reload', () => { const w = new Weapon(); w.fire(true, true); w.reload(); w.tick(.3); assert.equal(w.fire(true, true), false); });
test('canceled reload does not transfer ammo', () => { const w = new Weapon(); w.fire(true, true); w.reload(); w.cancelReload(); w.tick(3); assert.equal(w.ammo, 11); });
test('weapon snapshots reject impossible magazines', () => { const w = new Weapon(); assert.throws(() => w.restore({ ammo: 13, reserve: 2 })); assert.throws(() => w.restore({ ammo: 1, reserve: -1 })); });
test('weapon rejects invalid specs and time', () => { assert.throws(() => new Weapon({ ...rifleSpec, interval: 0 })); assert.throws(() => new Weapon({ ...rifleSpec, capacity: 1.5 })); assert.throws(() => new Weapon().tick(NaN)); });
test('car accelerates forward and respects its speed limit', () => { const car = new CarModel(); for (let i = 0; i < 600; i++) car.step(1 / 60, { throttle: 1, steer: 0, brake: false }, []); assert.equal(car.speed, 28); assert.ok(car.z < -200); });
test('car braking reduces speed without reversing', () => { const car = new CarModel(); car.speed = 20; for (let i = 0; i < 120; i++) car.step(1 / 60, { throttle: 0, steer: 0, brake: true }, []); assert.equal(car.speed, 0); });
test('car right input turns toward positive X', () => { const car = new CarModel(); for (let i = 0; i < 60; i++) car.step(1 / 60, { throttle: 1, steer: 1, brake: false }, []); assert.ok(car.x > 0); });
test('stationary car cannot turn in place', () => { const car = new CarModel(); car.step(1 / 60, { throttle: 0, steer: 1, brake: false }, []); assert.equal(car.yaw, 0); });
test('car does not tunnel through a thin barrier', () => { const car = new CarModel(); car.speed = 28; const wall = { x: 0, z: 0, halfX: 10, halfZ: .01 }; for (let i = 0; i < 30; i++) car.step(1 / 60, { throttle: 1, steer: 0, brake: false }, [wall]); assert.ok(car.z > 1.05); assert.ok(car.collisions >= 1); });
test('vehicle reset clears transient motion', () => { const car = new CarModel(); car.x = 5; car.speed = 9; car.reset(); assert.equal(car.x, 0); assert.equal(car.speed, 0); assert.equal(car.z, 4); });
test('vehicle rejects invalid step sizes', () => { const car = new CarModel(); for (const dt of [0, -1, NaN, 1]) assert.throws(() => car.step(dt, { throttle: 0, steer: 0, brake: false }, [])); });
