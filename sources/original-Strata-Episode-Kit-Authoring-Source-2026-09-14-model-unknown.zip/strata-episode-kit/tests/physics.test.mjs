/** Integration tests require npm install. No browser or GPU is needed. */
import test from 'node:test';
import assert from 'node:assert/strict';
import * as THREE from 'three';
import { PhysicsWorld,RAPIER } from '../build/engine/PhysicsWorld.js';
import { Player } from '../build/engine/Player.js';
import { createPrefabs } from '../build/level/prefabs.js';
import { defaultMotor } from '../build/core/motor.js';
await PhysicsWorld.init();
const prefabs=createPrefabs();
const add=(physics,type,position,scale=[1,1,1])=>{const e=prefabs.create(type,position);e.scale=scale;return physics.create(e,prefabs.get(type).build(e),new THREE.Group(),true);};
const fakeInput=()=>({movement:()=>({x:0,z:0,sprint:false,crouch:false,jump:false}),consume:()=>false,down:()=>false,look:()=>[0,0]});
test('a dynamic crate rests on a fixed floor',()=>{
  const physics=new PhysicsWorld();try{
    add(physics,'block',[0,-1,0],[20,1,20]);const crate=add(physics,'crate',[0,4,0]);
    for(let i=0;i<240;i++){physics.beginStep();physics.step(1/60);}
    assert.ok(Math.abs(crate.body.translation().y)<.12);
  }finally{physics.dispose();}
});
test('kinematic capsules stop at a wall',()=>{
  const physics=new PhysicsWorld();let player;
  try{
    add(physics,'block',[0,-1,0],[20,1,20]);add(physics,'block',[0,0,-3],[5,4,.5]);
    const input=fakeInput();input.movement=()=>({x:0,z:-1,sprint:false,crouch:false,jump:false});
    player=new Player(physics,input,new THREE.PerspectiveCamera(),defaultMotor,[0,.1,0],0);
    physics.step(1/60000);
    for(let i=0;i<180;i++){physics.beginStep();player.beforeStep(1/60);physics.step(1/60);player.afterStep();}
    assert.ok(player.current.z>-2.55);assert.ok(player.current.z<-2);assert.ok(player.motor.grounded);
  }finally{player?.dispose();physics.dispose();}
});
test('fixed sensors detect the kinematic player',()=>{
  const physics=new PhysicsWorld();let player;
  try{
    add(physics,'block',[0,-1,0],[20,1,20]);const trigger=add(physics,'trigger',[0,0,0]);
    player=new Player(physics,fakeInput(),new THREE.PerspectiveCamera(),defaultMotor,[0,.1,0],0);
    for(let i=0;i<4;i++){player.beforeStep(1/60);physics.step(1/60);player.afterStep();}
    assert.equal(physics.world.intersectionPair(trigger.colliders[0],player.collider),true);
  }finally{player?.dispose();physics.dispose();}
});
test('ray queries return the first solid obstruction',()=>{
  const physics=new PhysicsWorld();try{
    const wall=add(physics,'block',[0,0,-2],[4,3,.5]);add(physics,'switch',[0,0,-5]);physics.step(1/60000);
    const hit=physics.world.castRay(new RAPIER.Ray({x:0,y:1,z:0},{x:0,y:0,z:-1}),8,true);
    assert.equal(physics.owners.get(hit.collider.handle),wall.data.id);
  }finally{physics.dispose();}
});

test('respawn restores the standing capsule after crouch',()=>{
  const physics=new PhysicsWorld();let player;
  try{
    add(physics,'block',[0,-1,0],[20,1,20]);
    const input=fakeInput();input.movement=()=>({x:0,z:0,sprint:false,crouch:true,jump:false});
    player=new Player(physics,input,new THREE.PerspectiveCamera(),defaultMotor,[0,.1,0],0);
    physics.step(1/60000);player.beforeStep(1/60);physics.step(1/60);player.afterStep();
    assert.equal(player.motor.crouched,true);assert.ok(player.collider.shape.halfHeight<.3);
    player.respawn();assert.equal(player.motor.crouched,false);assert.ok(Math.abs(player.collider.shape.halfHeight-.625)<1e-6);
    assert.equal(player.current.y,.1);assert.equal(player.motor.vy,0);
  }finally{player?.dispose();physics.dispose();}
});
test('standing up is blocked by a low ceiling',()=>{
  const physics=new PhysicsWorld();let player;
  try{
    add(physics,'block',[0,-1,0],[20,1,20]);add(physics,'block',[0,1.35,0],[4,.2,4]);
    let crouch=true;const input=fakeInput();input.movement=()=>({x:0,z:0,sprint:false,crouch,jump:false});
    player=new Player(physics,input,new THREE.PerspectiveCamera(),defaultMotor,[0,.02,0],0);physics.step(1/60000);
    for(let i=0;i<10;i++){player.beforeStep(1/60);physics.step(1/60);player.afterStep();}
    crouch=false;player.beforeStep(1/60);assert.equal(player.motor.crouched,true);
  }finally{player?.dispose();physics.dispose();}
});
test('the controller climbs a low step',()=>{
  const physics=new PhysicsWorld();let player;
  try{
    add(physics,'block',[0,-1,0],[20,1,20]);add(physics,'block',[0,0,-2],[4,.2,.8]);
    const input=fakeInput();input.movement=()=>({x:0,z:-1,sprint:false,crouch:false,jump:false});
    player=new Player(physics,input,new THREE.PerspectiveCamera(),defaultMotor,[0,.05,0],0);physics.step(1/60000);let peak=0;
    for(let i=0;i<100;i++){player.beforeStep(1/60);physics.step(1/60);player.afterStep();peak=Math.max(peak,player.current.y);}
    assert.ok(peak>.18);assert.ok(player.current.z<-3);
  }finally{player?.dispose();physics.dispose();}
});
test('the controller cannot walk through a high step',()=>{
  const physics=new PhysicsWorld();let player;
  try{
    add(physics,'block',[0,-1,0],[20,1,20]);add(physics,'block',[0,0,-2],[4,1,.8]);
    const input=fakeInput();input.movement=()=>({x:0,z:-1,sprint:false,crouch:false,jump:false});
    player=new Player(physics,input,new THREE.PerspectiveCamera(),defaultMotor,[0,.05,0],0);physics.step(1/60000);
    for(let i=0;i<120;i++){player.beforeStep(1/60);physics.step(1/60);player.afterStep();}
    assert.ok(player.current.z>-1.5);assert.ok(player.current.y<.4);
  }finally{player?.dispose();physics.dispose();}
});
test('dropping a held crate restores its original gravity scale',()=>{
  const physics=new PhysicsWorld();let player;
  try{
    const crate=add(physics,'crate',[0,2,-2]);crate.body.setGravityScale(.4,true);
    player=new Player(physics,fakeInput(),new THREE.PerspectiveCamera(),defaultMotor,[0,.1,0],0);
    player.grab(crate);assert.equal(crate.body.gravityScale(),0);player.drop();assert.ok(Math.abs(crate.body.gravityScale()-.4)<1e-6);
  }finally{player?.dispose();physics.dispose();}
});
test('separate physics worlds can use different gravity',()=>{
  const earth=new PhysicsWorld({x:0,y:-24,z:0}),moon=new PhysicsWorld({x:0,y:-4,z:0});
  try{
    const a=add(earth,'crate',[0,8,0]),b=add(moon,'crate',[0,8,0]);
    for(let i=0;i<30;i++){earth.step(1/60);moon.step(1/60);}
    assert.ok(a.body.translation().y<b.body.translation().y-1);
  }finally{earth.dispose();moon.dispose();}
});
