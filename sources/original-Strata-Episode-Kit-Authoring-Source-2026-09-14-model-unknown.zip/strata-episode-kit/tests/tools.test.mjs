import test from 'node:test';
import assert from 'node:assert/strict';
import { cp,mkdtemp,readFile,rm,writeFile,mkdir } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { imports } from '../tools/graph.mjs';
const root=process.cwd();
test('module graph parser handles static, dynamic, and commented imports',()=>{
 const result=imports(`import {x} from './a.js'; export { y } from './b.js'; const z=import('./c.js'); // import 'not-a-module'\n const s="import 'also-not-a-module'";`);
 assert.deepEqual(result,[{specifier:'./a.js',dynamic:false},{specifier:'./b.js',dynamic:false},{specifier:'./c.js',dynamic:true}]);
});
test('episode clone updates its connection and entry without changing the source',async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'strata-clone-'));
 try{
  await cp('tests/fixtures/campaign.json',`${temp}/campaign.json`);await mkdir(`${temp}/episodes`,{recursive:true});await mkdir(`${temp}/src/episodes`,{recursive:true});
  await cp('episodes/yard',`${temp}/episodes/yard`,{recursive:true});await cp('src/episodes/yard',`${temp}/src/episodes/yard`,{recursive:true});
  execFileSync(process.execPath,[path.join(root,'tools/clone-episode.mjs'),'yard','hangar'],{cwd:temp});
  assert.match(await readFile(`${temp}/src/episodes/hangar/main.ts`,'utf8'),/connectEpisode\('hangar',/);
  assert.match(await readFile(`${temp}/episodes/hangar/index.html`,'utf8'),/build\/episodes\/hangar\/main.js/);
  assert.equal(JSON.parse(await readFile(`${temp}/campaign.json`,'utf8')).episodes.at(-1).id,'hangar');
  assert.match(await readFile(`${temp}/src/episodes/yard/main.ts`,'utf8'),/connectEpisode\('yard',/);
  assert.throws(()=>execFileSync(process.execPath,[path.join(root,'tools/clone-episode.mjs'),'yard','hangar'],{cwd:temp,stdio:'pipe'}));
 }finally{await rm(temp,{recursive:true,force:true});}
});
test('clone command rejects traversal IDs before file work',()=>{
 assert.throws(()=>execFileSync(process.execPath,['tools/clone-episode.mjs','yard','../outside'],{stdio:'pipe'}));
});
test('a contributor page can be installed without any TypeScript source',async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'strata-contributor-'));
 try{
  await cp('tests/fixtures/campaign.json',`${temp}/campaign.json`);await mkdir(`${temp}/episodes`);
  execFileSync(process.execPath,[path.join(root,'tools/add-episode.mjs'),path.join(root,'examples/contributor')],{cwd:temp});
  assert.match(await readFile(`${temp}/episodes/alternate-route/main.js`,'utf8'),/connectEpisode/);
  const c=JSON.parse(await readFile(`${temp}/campaign.json`,'utf8'));
  assert.equal(c.episodes.at(-1).entry,'episodes/alternate-route/index.html');
 }finally{await rm(temp,{recursive:true,force:true});}
});
test('contributor install rejects unknown exit targets without a partial install',async()=>{
 const temp=await mkdtemp(path.join(os.tmpdir(),'strata-invalid-'));
 try{
  await cp('tests/fixtures/campaign.json',`${temp}/campaign.json`);await mkdir(`${temp}/episodes`);await mkdir(`${temp}/incoming`);
  await writeFile(`${temp}/incoming/episode.json`,JSON.stringify({api:1,id:'bad-route',title:'Bad route',entry:'index.html',stateVersion:1,exits:{done:'not-installed'}}));
  await writeFile(`${temp}/incoming/index.html`,'<p>Test</p>');
  assert.throws(()=>execFileSync(process.execPath,[path.join(root,'tools/add-episode.mjs'),`${temp}/incoming`],{cwd:temp,stdio:'pipe'}));
  assert.equal(JSON.parse(await readFile(`${temp}/campaign.json`,'utf8')).episodes.length,3);
 }finally{await rm(temp,{recursive:true,force:true});}
});
