import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, mkdir, writeFile, symlink, rm } from 'node:fs/promises';
import path from 'node:path';
import os from 'node:os';
import { once } from 'node:events';
import { serve } from '../tools/serve.mjs';
let temp, server, base;
before(async () => {
  temp = await mkdtemp(path.join(os.tmpdir(), 'strata-http-'));
  await mkdir(`${temp}/public`);
  await writeFile(`${temp}/public/index.html`, '<h1>Test</h1>');
  await writeFile(`${temp}/public/code.mjs`, 'export const ok = true;');
  await writeFile(`${temp}/outside.txt`, 'Not public');
  await symlink(`${temp}/outside.txt`, `${temp}/public/link.txt`);
  server = serve(`${temp}/public`, 0);
  await once(server, 'listening');
  base = `http://127.0.0.1:${server.address().port}`;
});
after(async () => { if (server) await new Promise(resolve => server.close(resolve)); if (temp) await rm(temp, {recursive:true,force:true}); });
test('HTTP serves the default entry and module MIME type', async () => {
  const page = await fetch(base+'/'); assert.equal(page.status, 200); assert.match(page.headers.get('content-type'), /text\/html/); assert.equal(await page.text(), '<h1>Test</h1>');
  const js = await fetch(base+'/code.mjs'); assert.equal(js.status, 200); assert.match(js.headers.get('content-type'), /text\/javascript/); assert.equal(js.headers.get('x-content-type-options'), 'nosniff');
});
test('HTTP HEAD sends no body', async () => { const r = await fetch(base+'/', {method:'HEAD'}); assert.equal(r.status,200); assert.equal(await r.text(),''); });
test('HTTP missing paths return 404', async () => { assert.equal((await fetch(base+'/missing')).status,404); });
test('HTTP writes are rejected', async () => { assert.equal((await fetch(base+'/', {method:'POST',body:'test'})).status,405); });
test('HTTP encoded path traversal is rejected', async () => { assert.equal((await fetch(base+'/%2e%2e%2foutside.txt')).status,403); });
test('HTTP symlinks cannot expose files outside the root', async () => { assert.equal((await fetch(base+'/link.txt')).status,403); });
