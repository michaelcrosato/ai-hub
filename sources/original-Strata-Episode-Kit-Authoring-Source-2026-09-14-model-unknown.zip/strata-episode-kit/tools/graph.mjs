import { readFile, stat } from 'node:fs/promises';
import path from 'node:path';
import { loadTypeScript } from './typescript.mjs';
const ts = loadTypeScript();
export function imports(text, filename = 'module.js') {
  const ast = ts.createSourceFile(filename, text, ts.ScriptTarget.ES2022, true, ts.ScriptKind.JS), result = [];
  function visit(node) {
    if ((ts.isImportDeclaration(node) || ts.isExportDeclaration(node)) && node.moduleSpecifier && ts.isStringLiteral(node.moduleSpecifier)) result.push({ specifier: node.moduleSpecifier.text, dynamic: false });
    if (ts.isCallExpression(node) && node.expression.kind === ts.SyntaxKind.ImportKeyword && node.arguments.length === 1 && ts.isStringLiteral(node.arguments[0])) result.push({ specifier: node.arguments[0].text, dynamic: true });
    ts.forEachChild(node, visit);
  }
  visit(ast); return result;
}
function resolve(specifier, from, vendors) {
  if (specifier.startsWith('.')) return path.resolve(path.dirname(from), specifier);
  if (!vendors) return null;
  if (specifier === 'three') return path.resolve('node_modules/three/build/three.module.js');
  if (specifier.startsWith('three/addons/')) return path.resolve('node_modules/three/examples/jsm', specifier.slice(13));
  if (specifier === '@dimforge/rapier3d-compat') return path.resolve('node_modules/@dimforge/rapier3d-compat/rapier.mjs');
  throw new Error(`Unmapped package import '${specifier}' in ${from}. Add an explicit build mapping.`);
}
export async function graph(entry, { vendors = false, dynamic = true } = {}) {
  const files = new Set(), packages = new Set(); const root = process.cwd();
  async function visit(file) {
    file = path.resolve(file);
    if (files.has(file)) return;
    if (file !== root && !file.startsWith(root + path.sep)) throw new Error(`Module is outside the project: ${file}`);
    const text = await readFile(file, 'utf8'); files.add(file);
    for (const item of imports(text, file)) {
      if (item.dynamic && !dynamic) continue;
      if (!item.specifier.startsWith('.')) packages.add(item.specifier);
      const target = resolve(item.specifier, file, vendors);
      if (target) await visit(target);
    }
  }
  await visit(entry);
  let bytes = 0; for (const file of files) bytes += (await stat(file)).size;
  return { files, packages, bytes };
}
