import { cp, readFile, writeFile, rm, access } from 'node:fs/promises';
import path from 'node:path';
const [source, id, ...extra] = process.argv.slice(2);
const valid = value => typeof value === 'string' && /^[a-z][a-z0-9-]{0,63}$/.test(value) && !['constructor','prototype'].includes(value);
if (!valid(source) || !valid(id) || extra.some(v => v !== '--start')) throw new Error('Usage: npm run clone:episode -- yard hangar [--start]');
const manifest = JSON.parse(await readFile('campaign.json', 'utf8'));
const route = manifest.episodes.find(e => e.id === source);
if (!route || manifest.episodes.some(e => e.id === id)) throw new Error('Source is unknown, or destination ID already exists.');
const publicDest = `episodes/${id}`, sourceDest = `src/episodes/${id}`;
for (const dest of [publicDest, sourceDest]) { try { await access(dest); throw new Error(`Destination already exists: ${dest}`); } catch (error) { if (error.code !== 'ENOENT') throw error; } }
let created = false;
try {
  await access(`src/episodes/${source}/main.ts`);
  await cp(path.dirname(route.entry), publicDest, { recursive: true, errorOnExist: true, force: false }); created = true;
  await cp(`src/episodes/${source}`, sourceDest, { recursive: true, errorOnExist: true, force: false });
  const mainFile = `${sourceDest}/main.ts`, main = await readFile(mainFile, 'utf8');
  const edited = main.replaceAll(`connectEpisode('${source}',`, `connectEpisode('${id}',`).replaceAll(`connectEpisode("${source}",`, `connectEpisode("${id}",`);
  if (edited === main) throw new Error('No known page connection was found. Use the contributor import path for other page layouts.');
  await writeFile(mainFile, edited);
  const htmlFile = `${publicDest}/index.html`;
  await writeFile(htmlFile, (await readFile(htmlFile, 'utf8')).replaceAll(`/episodes/${source}/`, `/episodes/${id}/`));
  manifest.episodes.push({ ...route, id, title: `${route.title} / ${id}`, entry: `${publicDest}/index.html`, exits: { ...route.exits } });
  if (extra.includes('--start')) manifest.start = id;
  await writeFile('campaign.json', JSON.stringify(manifest, null, 2) + '\n');
  console.log(`Created ${sourceDest}/ and ${publicDest}/. The new page is in campaign.json. Shared result keys and exit names are unchanged; edit them deliberately.`);
} catch (error) {
  if (created) { await rm(publicDest, { recursive: true, force: true }); await rm(sourceDest, { recursive: true, force: true }); }
  throw error;
}
