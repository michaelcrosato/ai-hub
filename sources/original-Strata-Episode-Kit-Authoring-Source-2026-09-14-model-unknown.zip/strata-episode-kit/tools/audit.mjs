import { existsSync } from 'node:fs';
import { graph } from './graph.mjs';
import { validateCampaign } from '../build/kit/contract.js';
import { readFile, writeFile } from 'node:fs/promises';
import assert from 'node:assert/strict';
const campaign = validateCampaign(JSON.parse(await readFile('campaign.json', 'utf8'))), result = {};
for (const e of campaign.episodes) {
  if (!existsSync(`build/episodes/${e.id}/main.js`)) { result[e.id] = { prebuilt: true, dependencyAudit: 'Contributor-owned; inspect separately.' }; continue; }
  const g = await graph(`build/episodes/${e.id}/main.js`);
  const paths = [...g.files];
  assert.ok(!paths.some(p => p.includes('/editor/') || p.endsWith('/engine/Engine.js')), `${e.id} imports the workbench`);
  if (e.id === 'drive') assert.ok(!paths.some(p => p.includes('/fps/') || p.includes('/engine/')) && ![...g.packages].some(p => p.includes('rapier')), 'Driving imports FPS or Rapier');
  if (e.id === 'debrief') assert.equal(g.packages.size, 0, 'Debrief imports external packages');
  result[e.id] = { appModuleBytes: g.bytes, packageImports: [...g.packages].sort(), moduleCount: g.files.size };
}
await writeFile('docs/dependency-audit.json', JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
