import { access, cp, lstat, readdir, readFile, writeFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { validateCampaign, identifier } from '../.test-build/kit/contract.js';
const [folder, ...extra] = process.argv.slice(2);
if (!folder || extra.length) throw new Error('Usage: npm run add:episode -- path/to/built-episode');
const source = path.resolve(folder), descriptor = JSON.parse(await readFile(path.join(source, 'episode.json'), 'utf8'));
if (descriptor.api !== 1) throw new Error('Contributor episode must use contract API 1.');
const id = identifier(descriptor.id, 'Episode ID'), destination = path.resolve('episodes', id);
try { await access(destination); throw new Error('Destination already exists. Nothing was replaced.'); } catch (error) { if (error.code !== 'ENOENT') throw error; }
async function rejectLinks(dir) { for (const item of await readdir(dir)) { const file = path.join(dir, item), info = await lstat(file); if (info.isSymbolicLink()) throw new Error('Episode folders must not contain symbolic links.'); if (info.isDirectory()) await rejectLinks(file); } }
await rejectLinks(source);
const current = JSON.parse(await readFile('campaign.json', 'utf8'));
const next = validateCampaign({ ...current, episodes: [...current.episodes, { id, title: descriptor.title, stateVersion: descriptor.stateVersion, entry: `episodes/${id}/${descriptor.entry}`, exits: descriptor.exits }] });
const entry = next.episodes.find(e => e.id === id).entry;
const sourceEntry = path.resolve(source, path.relative(`episodes/${id}`, entry));
if (!sourceEntry.startsWith(source + path.sep)) throw new Error('Entry is outside the episode folder.');
await access(sourceEntry);
try { await cp(source, destination, { recursive: true, errorOnExist: true, force: false }); await writeFile('campaign.json', JSON.stringify(next, null, 2) + '\n'); }
catch (error) { await rm(destination, { recursive: true, force: true }); throw error; }
console.log(`Installed ${id}. No FPS inheritance is required. Review its shared-result meaning and trusted code before release.`);
