import http from 'node:http';
import path from 'node:path';
import { readFile,stat,realpath } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.wasm':'application/wasm','.glb':'model/gltf-binary','.gltf':'model/gltf+json','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.map':'application/json'};
export function serve(root,port=5173){
  const base=path.resolve(root);
  const server=http.createServer(async(req,res)=>{
    try{
      if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405);res.end();return;}
      const requestPath=decodeURIComponent(new URL(req.url??'/', 'http://localhost').pathname);
      const target=path.resolve(base,'.'+requestPath);
      if(target!==base&&!target.startsWith(base+path.sep)){res.writeHead(403);res.end('Forbidden');return;}
      let file=target;const info=await stat(file);if(info.isDirectory())file=path.join(file,'index.html');
      const actual=await realpath(file), allowed=await realpath(base);
      if(actual!==allowed&&!actual.startsWith(allowed+path.sep)){res.writeHead(403);res.end('Forbidden');return;}
      const data=await readFile(actual);res.writeHead(200,{'Content-Type':types[path.extname(file)]??'application/octet-stream','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});res.end(req.method==='HEAD'?undefined:data);
    }catch{res.writeHead(404,{'Content-Type':'text/plain'});res.end('File not found. For the source project, run npm install and npm run dev.');}
  });
  server.on('error',error=>{console.error(error.message);process.exitCode=1;});
  server.listen(port,'127.0.0.1',()=>console.log(`Strata: http://localhost:${port}`));return server;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))serve(process.argv[2]??'.',Number(process.argv[3]??5173));
