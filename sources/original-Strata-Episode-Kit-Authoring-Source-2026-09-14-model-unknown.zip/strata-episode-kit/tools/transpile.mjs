import { readdir, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { loadTypeScript } from './typescript.mjs';
export async function transpile() {
  const ts = loadTypeScript(); let count = 0;
  await rm('build', { recursive: true, force: true });
  async function visit(dir) {
    for (const e of await readdir(dir, { withFileTypes: true })) {
      const source = path.join(dir, e.name);
      if (e.isDirectory()) { await visit(source); continue; }
      if (!source.endsWith('.ts') || source.endsWith('.d.ts')) continue;
      const text = await readFile(source, 'utf8');
      const parsed = ts.createSourceFile(source, text, ts.ScriptTarget.ES2022, true);
      if (parsed.parseDiagnostics.length) throw new Error(ts.formatDiagnosticsWithColorAndContext(parsed.parseDiagnostics, { getCanonicalFileName: p => p, getCurrentDirectory: () => process.cwd(), getNewLine: () => '\n' }));
      const result = ts.transpileModule(text, { fileName: source, reportDiagnostics: true, compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022, verbatimModuleSyntax: true } });
      const errors = result.diagnostics?.filter(d => d.category === ts.DiagnosticCategory.Error) ?? [];
      if (errors.length) throw new Error(errors.map(d => ts.flattenDiagnosticMessageText(d.messageText, '\n')).join('\n'));
      const target = path.join('build', path.relative('src', source)).replace(/\.ts$/, '.js');
      await mkdir(path.dirname(target), { recursive: true }); await writeFile(target, result.outputText); count++;
    }
  }
  await visit('src');
  console.log(`Transpiled ${count} modules. Syntax passed. External API types were NOT checked by this command.`);
  return count;
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) await transpile();
