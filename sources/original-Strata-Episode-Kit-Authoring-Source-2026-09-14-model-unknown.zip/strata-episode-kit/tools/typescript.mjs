import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
const require = createRequire(import.meta.url);
export function loadTypeScript() {
  try { return require('typescript'); }
  catch {
    // This fallback permits syntax checks in a restricted workspace. It is not a type-check substitute.
    const globalRoot = execFileSync('npm', ['root', '-g'], { encoding: 'utf8' }).trim();
    return require(path.join(globalRoot, 'typescript', 'lib', 'typescript.js'));
  }
}
