import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { serve } from './serve.mjs';
if(!existsSync('node_modules/typescript/bin/tsc')){console.error('Dependencies are missing. Run npm install first.');process.exit(1);}
const compiler=spawn(process.execPath,['node_modules/typescript/bin/tsc','--watch','--preserveWatchOutput'],{stdio:'inherit'});
const server=serve('.',5173);
console.log('TypeScript watch is active. Reload the browser after a code change.');
const stop=()=>{compiler.kill();server.close();};
process.on('SIGINT',()=>{stop();process.exit(0);});process.on('SIGTERM',()=>{stop();process.exit(0);});
compiler.on('exit',code=>{if(code&&code!==0){server.close();process.exitCode=code;}});
