import { cp, mkdir, readFile, writeFile, rm, readdir, stat } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { gzipSync } from 'node:zlib';
import { graph } from './graph.mjs';
import { validateCampaign } from '../build/kit/contract.js';
const cdn = process.argv.includes('--cdn'), workbench = process.argv.includes('--workbench');
const out = cdn ? 'web-preview' : 'dist';
const manifest = validateCampaign(JSON.parse(await readFile('campaign.json', 'utf8')));
const entrypoints = [['collection', 'index.html', 'build/portal.js'], ...manifest.episodes.map(e => [e.id, e.entry, `build/episodes/${e.id}/main.js`])];
if (workbench) entrypoints.push(['workbench', 'workbench.html', 'build/app.js']);
await rm(out, { recursive: true, force: true }); await mkdir(out, { recursive: true });
await cp('campaign.json', `${out}/campaign.json`); await cp('episode.css', `${out}/episode.css`);
const allFiles = new Set(), report = { mode: cdn ? 'CDN preview; external libraries not included' : 'local starter release; prebuilt contributor pages require their own network audit', entries: {} };
for (const [id, htmlFile, module] of entrypoints) {
  // A contributed page can be a prebuilt HTML folder. It need not use this TypeScript layout.
  const prebuilt = !existsSync(module);
  if (prebuilt && (id === 'collection' || id === 'workbench')) throw new Error(`Missing compiled entry: ${module}`);
  const full = prebuilt ? { files: new Set(), packages: new Set(), bytes: 0 } : await graph(module, { vendors: !cdn });
  const eager = prebuilt ? full : await graph(module, { vendors: !cdn, dynamic: false });
  for (const f of full.files) allFiles.add(f);
  let text = await readFile(htmlFile, 'utf8');
  if (cdn) {
    text = text.replace(/(?:\.\.\/|\.\/)*node_modules\/three\/build\/three.module.js/g, 'https://cdn.jsdelivr.net/npm/three@0.180.0/build/three.module.js')
      .replace(/(?:\.\.\/|\.\/)*node_modules\/three\/examples\/jsm\//g, 'https://cdn.jsdelivr.net/npm/three@0.180.0/examples/jsm/')
      .replace(/(?:\.\.\/|\.\/)*node_modules\/@dimforge\/rapier3d-compat\/rapier.mjs/g, 'https://cdn.jsdelivr.net/npm/@dimforge/rapier3d-compat@0.19.3/rapier.mjs');
  } else text = text.replaceAll('node_modules/', 'vendor/');
  if (!workbench && id === 'collection') text = text.replace(/<a href="\.\/workbench.html">.*?<\/a>/, '<span class="eyebrow">Play-only release</span>');
  // Copy the whole owning folder first, then write the adjusted entry. Nested entries keep sibling assets.
  if (id !== 'collection' && id !== 'workbench') {
    const dir = htmlFile.startsWith(`episodes/${id}/`) ? `episodes/${id}` : path.dirname(htmlFile);
    await cp(dir, `${out}/${dir}`, { recursive: true });
  }
  await mkdir(path.dirname(`${out}/${htmlFile}`), { recursive: true }); await writeFile(`${out}/${htmlFile}`, text);
  const eagerCode = await Promise.all([...eager.files].map(f => readFile(f)));
  report.entries[id] = { prebuilt, dependencyAudit: prebuilt ? 'Contributor folder copied as supplied. Its imports need separate review.' : 'Reachable imports inspected.', eagerModuleBytes: eager.bytes, eagerGzipBytes: eagerCode.reduce((sum, b) => sum + gzipSync(b).length, 0), allReachableModuleBytes: full.bytes, packages: [...full.packages], appModules: [...full.files].filter(f => !f.includes('/node_modules/')).map(f => path.relative(process.cwd(), f).replaceAll('\\', '/')).sort() };
}
for (const file of allFiles) {
  const relative = path.relative(process.cwd(), file).replace(/^node_modules[\\/]/, 'vendor/');
  const dest = path.join(out, relative); await mkdir(path.dirname(dest), { recursive: true }); await cp(file, dest);
}
if (workbench) await cp('styles.css', `${out}/styles.css`);
if (existsSync('shared-assets')) await cp('shared-assets', `${out}/shared-assets`, { recursive: true });
if (workbench && existsSync('assets')) await cp('assets', `${out}/assets`, { recursive: true });
await cp('LICENSE', `${out}/LICENSE`);
if (!cdn) for (const pkg of ['three', '@dimforge/rapier3d-compat']) {
  const folder = `node_modules/${pkg}`;
  for (const name of (await readdir(folder)).filter(n => /^(LICENSE|COPYING)/i.test(n) || n === 'package.json')) {
    await mkdir(`${out}/licenses/${pkg}`, { recursive: true }); await cp(`${folder}/${name}`, `${out}/licenses/${pkg}/${name}`);
  }
}
async function size(dir) { let bytes = 0; for (const e of await readdir(dir, { withFileTypes: true })) bytes += e.isDirectory() ? await size(path.join(dir, e.name)) : (await stat(path.join(dir, e.name))).size; return bytes; }
report.totalBytesBeforeReport = await size(out);
await writeFile(`${out}/build-report.json`, JSON.stringify(report, null, 2));
await writeFile(`${out}/README.txt`, `${cdn ? 'CDN PREVIEW: internet is required for Three.js and Rapier. The DOM pages work without those libraries. This preview is transpiled, not a substitute for a dependency-aware build.' : 'LOCAL STARTER RELEASE: starter libraries are local. Prebuilt contributor pages are copied as supplied and require their own network audit. This output contains reachable starter JavaScript and explicit public assets.'}\n\nServe this directory with HTTP. For example:\n  python -m http.server 8000 --bind 127.0.0.1\nThen open http://localhost:8000/\nDo not use file://.\nEach episode is an HTML entry under episodes/.\nBuild report bytes are raw module bytes, plus per-file gzip estimates. They exclude CDN packages in preview mode.\n`);
console.log(`Built ${out}/; ${allFiles.size} reachable modules. ${cdn ? 'External package bytes are not included in this report.' : 'Vendor modules are local.'}`);
