# Primary references

Reference date: 2026-08-31. These pages support API and tool choices. They do not prove that this source package runs correctly.

| ID | Primary source | Used for |
| --- | --- | --- |
| P1 | `https://api.playcanvas.com/engine/classes/CameraFrame.html` | Current Engine 2.21.4 frame pipeline. |
| P2 | `https://developer.playcanvas.com/user-manual/graphics/lighting/shadows/` | Shadow modes, supported light types, PCSS, and shadow cost. |
| P3 | `https://developer.playcanvas.com/user-manual/graphics/lighting/clustered-lighting/` | Cluster cells, local light atlas, and limits. |
| P4 | `https://api.playcanvas.com/engine/interfaces/VolumetricFog.html` | Directional volumetric fog and its settings. |
| P5 | `https://api.playcanvas.com/engine/interfaces/Rendering.html` | CameraFrame render scale and sample settings. |
| P6 | `https://api.playcanvas.com/engine/classes/StandardMaterial.html` | Material gloss range, metalness, and GGX. |
| P7 | `https://developer.playcanvas.com/user-manual/scripting/esm-scripts/` | Editor ESM class and module format. |
| P8 | `https://developer.playcanvas.com/user-manual/editor/scripting/vscode-extension/` | Pull/Push workflow for external source changes. |
| P9 | `https://developer.playcanvas.com/user-manual/editor/mcp-server/` | Published MCP server, Node requirement, connection, and verification. |
| P10 | `https://developer.playcanvas.com/user-manual/physics/physics-migration/` | Ammo import and legacy/new physics separation. |
| P11 | `https://raw.githubusercontent.com/playcanvas/engine/v2.21.4/src/framework/app-base.js` | Library and application start sequence. |
| P12 | `https://developer.playcanvas.com/user-manual/editor/interface/settings/rendering/` | Editor device order and rendering options. |
| P13 | `https://developer.playcanvas.com/user-manual/editor/engine-compatibility/` | Engine V2 WebGPU/WebGL2 support. |
| O1 | `https://developers.openai.com/codex/mcp/` | Codex stdio server configuration and timeout. Redirects to current official documentation. |
| A1 | `https://github.com/giniedp/ammojs-typed` | Standalone Ammo package layout and factory. |
| P14 | `https://github.com/playcanvas/engine/releases/tag/v2.21.4` | Pinned engine release. |
| P15 | `https://api.playcanvas.com/engine/classes/LightComponent.html` | Cascade, PCSS, bias, and light settings. |

The standalone build uses the JavaScript/asm.js Ammo file from `ammojs-typed` 1.0.6. It does not use a WASM binary. The Editor route uses its imported Ammo module. Treat physics performance between those routes as a separate test.

Use the current official pages when an API changes. Keep a pinned dependency set and accepted test results before updating the project.
