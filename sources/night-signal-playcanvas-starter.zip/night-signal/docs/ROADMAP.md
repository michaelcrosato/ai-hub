# Work plan and acceptance gates

## Gate 1 — Engine integration

Install the pinned packages. Run full type checking, tests, and both builds. Resolve actual PlayCanvas API errors before adding features. Run the standalone build and Editor Launch with one `nightSignal` script. Confirm the real backend and engine version. Save console logs.

Acceptance: no start error, no null backend, no duplicate application, and no duplicate physics library. Both WebGPU and WebGL2 must show a controllable scene.

## Gate 2 — Physical play

Sweep or drive the actual player capsule through all room doors, stair routes, and floors on fixed seeds. Inspect open and closed door collisions. Test locker entry and exit near moved objects. Verify the gate barrier. Use a stuck detector for threats.

Acceptance: complete an escape run on each city size without a blocked required path, wall crossing, falling through a floor, or an unavoidable start capture. A graph route alone is not sufficient evidence.

Replace direct kinematic threat travel with collision-aware movement, a suitable navmesh, or local avoidance before calling navigation robust. Preserve evidence-only target selection.

## Gate 3 — RTX 3060 budget

Measure the route in `LIGHTING_AND_PERFORMANCE.md`. Profile lights, shadow passes, native physics bodies, streaming, and transparent windows. Tune High first. Keep PCSS and volumetric fog optional.

Acceptance target: 1080p, 60 FPS, with reported tail frame times and no large streaming stalls on the recorded target system. A failed target requires smaller budgets or a different implementation, not a renamed preset.

## Gate 4 — Stronger city variety

Add three distinct floor-plan families, safe connections between rooms, a second exit where appropriate, and alternate stair positions. Add irregular blocks only after all entrance rules have tests. Add semantic room types that change cover and sound.

Acceptance: new layouts remain reproducible, all required routes are physically traversable, and each family changes a useful route choice. Avoid variation that is only a colour change.

## Gate 5 — Full persistence and larger worlds

Version and save threat state, last-known evidence, radio state, velocities where needed, and transient object state. Add floor-level streaming, portal-aware visibility, and asynchronous generation. Keep one shared plan and stable IDs.

Acceptance: save/load does not create a new advantage or trap the player. Repeated loading does not leak GPU or physics resources. A large city must pass the same performance route.

## Gate 6 — Add one new gameplay rule

A good first addition is a local power circuit. The player can disable a lamp group, but the switch makes noise and may disable a useful door. Other candidates are a noisy lift, a lockable stair door with a bypass route, and a second escape objective.

Acceptance: the new rule creates at least two reasonable player choices. It works with captions, pause, save/load, all quality presets, and the current threat memory rules.

## Release boundary

Use external play tests for navigation clarity, hearing accessibility, fear pacing, comfort, and control learning. Add recorded or designed audio only with clear licences. Add controller support separately. The responsive menu does not make the game touch-ready.
