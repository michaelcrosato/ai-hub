# Validation record

Package: Night Signal 0.1.0. Record date: 2026-08-31.

## Checks completed in this environment

| Check | Result | Scope |
| --- | --- | --- |
| Core TypeScript compilation | Passed | Pure data, navigation, acoustics, brain, settings, and session modules. |
| Core test suite | 19 passed, 0 failed | Includes 1,000 seeds across city sizes 3, 5, and 7. |
| UI TypeScript compilation | Passed | UI and its pure data dependencies. No engine code. |
| Browser UI test | 9 passed, 0 page errors | Real Chromium DOM, controls, map canvas, and narrow layout. No game renderer. |
| Source parsing | Passed | All 24 `.mts` source files parse with TypeScript. Parsing is not full engine type checking. |
| Build/server script syntax | Passed | `node --check`; does not prove package availability or a successful build. |

The test environment had Node 22.16.0, global TypeScript 5.8.3, Python 3.13.5, and Chromium. The project pins TypeScript 5.9.3 and asks for Node 22.18 or later. The local core and UI checks do not verify those pinned dependencies.

`validation/core-tests.txt` and `validation/ui-report.json` contain the actual results. The PNG files in that folder show the menu, settings, and map from the UI-only harness. **They are not 3D game screenshots.** The visible backend label is `UI TEST`.

The browser blocked local HTTP navigation in this environment. The UI test instead injects the locally compiled modules into a test document. It uses no network and no engine substitute. It tests the real UI class, not a recreated menu.

## What the core tests establish

The seed process repeats a plan. Every tested walk node connects to the exit. Fuses occupy three separate buildings. Windows do not become walk edges. Sampled routes do not cross the tested wall boxes at the sampled height. Stairs have planned openings. Rooms have cover and lockers.

The tests also check sound loss through a closed door, distance loss, immutable bounded noise events, enemy evidence memory, the three-fuse alarm sequence, save rejection, settings limits, key conflicts, event cleanup, door route-cache invalidation, and radio/fuse placement separation.

These tests do not establish continuous swept-capsule clearance, reliable contact handling, real audio mix quality, or physical threat navigation. They do not test every possible seed.

## Checks not completed

| Required check | Status and reason |
| --- | --- |
| `npm install` | Not completed. Package downloads were blocked. |
| Full `npm run typecheck` | Not completed. PlayCanvas type declarations are absent. The attempted check reports the missing engine module and related inherited types. |
| `npm run build` | Not completed. PlayCanvas, Ammo, and esbuild are absent. |
| Standalone 3D start | Not completed. No engine bundle was built. |
| Native Ammo traversal and contact sounds | Not completed. |
| Editor asset import, parse, and Launch | Not completed. No live Editor was connected. |
| MCP and VS Code account workflow | Documented against current primary sources; not exercised against a project here. |
| Complete escape gameplay | Not completed in the native runtime. Only pure session transitions were tested. |
| RTX 3060 / WebGPU / WebGL2 benchmark | Not completed. No target GPU test was available. |
| Optional DistantSignal runtime module | Source supplied; not engine-tested. |

Do not convert any of these rows to Passed from code inspection alone.

## First local acceptance pass

Start with a 3 × 3 city and a fixed seed. Capture console errors from boot through a return to the menu. Check a closed door, an open door, slow door motion, every floor of one building, both sides of a window, a locker, a falling can, a thrown bottle, and flashlight charge.

Check that a threat follows a noisy last-known position but loses exact tracking behind cover. Check a witnessed hide and an unseen hide. Check that master volume does not alter threat behavior. Check quiet and noisy routes through a closed door.

Collect the three fuses. Start the gate. Survive the alarm. Confirm that the closed gate cannot be bypassed. Pass through the open gate and confirm a win. Confirm that capture stops gameplay.

Pause during movement, a throw, the alarm, and a pursuit. Confirm that game time and physics stop. Resume with no stuck key. Change controls, audio, and quality. Repeat after a page reload.

Save while indoors, outdoors, and hidden. Continue the checkpoint. Confirm the documented limits: threats reset, radio switches reset, and transient bottles are absent. Run at least ten start/return cycles and inspect resource growth.
