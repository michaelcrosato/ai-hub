# PlayCanvas Editor, VS Code, and coding agent

## Boundary

No live Editor project was created or changed for this package. These are local source and setup files. Use the following procedure in your own project.

## Prepare an Editor host scene

Build the source with `npm run build`. The outputs have different purposes:

| Output | Purpose |
| --- | --- |
| `dist/` | Standalone browser game. Includes the engine bundle and standalone Ammo script. |
| `editor-build/night-signal.mjs` | Editor ESM script. Leaves the `playcanvas` import external. |

Create an empty project or a separate test scene. Select **Engine V2**. In Rendering settings, enable WebGPU and WebGL 2.0. Put WebGPU first in Device Order. Use a resizable canvas. Disable back-buffer anti-aliasing because the game frame controls anti-aliasing. Start with device pixel ratio disabled. [P12, P13]

In Physics settings, import Ammo and keep its module assets preloaded. Do not also enable legacy injected physics. Set gravity to `(0, -14, 0)` to match the standalone entry. [P10]

Upload `editor-build/night-signal.mjs` as a script asset. ESM scripts use `.mjs` and a class that extends `Script`. [P7] Add a host entity named `NightSignal`. Add a Script component, parse the asset, and add `nightSignal` once. Disable default scene cameras and lights. The game creates its own camera and lights.

Launch the scene. Check the console, selected backend, and the first city load. The layout is generated in Launch, not in the design viewport. Do not add a second PlayCanvas engine bundle or the standalone Ammo loader to this scene.

The Editor can update its Engine V2 build separately from npm. Check the actual engine version and current API before accepting an update. The source targets 2.21.4. A version guard is not a substitute for a play test.

## VS Code source workflow

Install the official extension, `playcanvas.playcanvas`. Open the chosen project and branch with **PlayCanvas: Open Project**. Use **Pull/Push** mode for compiler or agent changes:

```json
{
  "playcanvas.syncMode": "pullpush"
}
```

Reload VS Code after a mode change. Pull first. Keep the TypeScript source repository outside the extension's mapped asset folder. After a build, copy only `editor-build/night-signal.mjs` into the mapped script asset. Review the diff and Push. Realtime mode does not submit external edits to closed files. [P8]

Do not upload `node_modules`, TypeScript source, tests, `dist`, or configuration files as Editor assets. `.pcignore.example` provides exclusions when those folders are present in an asset workspace. Copy it as `.pcignore` only after you check the workspace layout.

Treat the generated `.mjs` as an output. Edit the `.mts` source, not two copies of game logic. Rebuild before you push a source change. Do not let MCP and the VS Code extension write the same asset at the same time.

## Connect the Editor MCP server

Use Node.js 22.18 or later. Add the published server to Codex:

```sh
codex mcp add playcanvas -- npx -y @playcanvas/editor-mcp-server
```

On Windows:

```powershell
codex mcp add playcanvas -- cmd /c npx -y @playcanvas/editor-mcp-server
```

Keep the client running. In the intended Editor, select **MCP**, check port **52000**, and connect. One Editor connects at a time. Allow the Editor's **Apps on device** permission and Launch pop-ups when needed. [P9]

For a different MCP client, use the stdio command in `.mcp.example.json`. Apply that client's configuration format. On Windows use `cmd` with arguments `/c`, `npx`, `-y`, and `@playcanvas/editor-mcp-server`.

The optional `.codex/config.example.toml` shows the equivalent named server and a longer start timeout. Merge it into the Codex configuration you use. Do not overwrite an existing configuration. Codex supports named stdio servers and `startup_timeout_sec`. [O1]

## First agent task

Give the agent `AGENTS.md` and this source folder. Start with this read-only request:

```text
Read AGENTS.md. Inspect the connected Editor scene, its engine version,
selected branch, current selection, and pending changes. Confirm that
this is the intended Night Signal test project. Do not edit anything.
```

After you confirm the target, ask for one small change and a checkpoint. MCP edits act directly in the Editor; they do not wait for VS Code Push. Ask the agent to capture the result, launch it, inspect logs, exercise the changed control, and stop the test launch. [P9]

Do not approve a reset, asset deletion, branch switch, or checkpoint restore merely to clear an error. First check whether it would remove work. Do not put account tokens, API keys, or personal files in this repository.

## Example bounded task

```text
On the confirmed Night Signal test scene, prepare one host entity for
editor-build/night-signal.mjs. Preserve unrelated scene assets. Do not
upload the standalone engine bundle. Use the imported Ammo module.

Make a checkpoint before changes. After Launch, record the actual engine
version and graphics backend. Test a small city, one door, one stair,
one locker, and pause/resume. Report console errors. Do not report a
physics or graphics check as passed from source inspection alone.
```
