# Game design

## Purpose

Build fear through sound, sight, and route choice. Do not make a large animation system the foundation of the game.

The player enters a closed city district at night. Three fuses can restore the north gate. Each fuse is in a different building, above ground level. The map gives the block and floor. The player must still find the room and a safe route.

There are few threats. One threat should change the player's plan. The player is unarmed. A short sprint can make distance, but it uses stamina and makes more noise.

## Visual style

Use simple solid shapes, a small material palette, dark streets, and clear pools of light. Keep silhouettes distinct. Use windows, open doors, and stairs to frame a threat. Use shadow motion before direct contact where practical.

Listeners are tall, rigid floating shapes. They have a narrow red eye and a small vertical motion. They do not have a human walk cycle. The first-person view has no hands. Doors rotate. The gate rises. Loose objects use physics. This reduces animation work without making all motion invisible.

Head movement and light flicker are off by default. Depth of field and motion blur are not active. Do not remove route visibility merely to make the image darker.

## Run sequence

| Stage | Player task | Pressure |
| --- | --- | --- |
| Arrival | Read the map. Find a route to a marked block. | The first threat has a brief start grace period. |
| Search | Enter rooms and reach upper floors. | Footsteps, doors, radios, and falling props can reveal activity. |
| Escalation | Collect the second and third fuses. | A second threat becomes active after two fuses. |
| Power | Use the north gate switch with all three fuses. | An alarm runs for 35 seconds and attracts threats. |
| Escape | Cross the open gate. | The player must reach the exit, not only wait for the timer. |

The player can pause or read the map without game time advancing. This is a comfort choice. It is not a real-time inventory challenge.

## Sound rules

Game noise has a source, position, time, type, surface, and level. Level is a relative game value. It is not measured sound pressure.

Walking is quieter than running. Carpet is quieter than metal. Crouching reduces step noise and changes door use to slow motion. The flashlight does not make game noise while on. Charging it does. A low stamina value can cause loud breathing.

A door reduces sound; it does not remove sound. Sound can take another route through a window or stairwell. Spatial playback uses the same route data as enemy hearing. Captions use the audible event. They do not show every threat through every wall.

The player starts with four bottle decoys. A bottle impact can draw attention away. A radio repeats its sound while on and while its building is loaded. These tools move a threat's attention; they do not stun it.

## Sight and hiding

Solid walls and furniture block sight rays. Glass does not block sight. The sight range also uses a light-exposure estimate, crouch state, and flashlight state. That estimate uses logical fixtures, not the selected graphics light budget. It is a gameplay heuristic, not a sample of final rendered pixels.

A locker is a hiding volume with a view slit. Entering it moves the viewpoint and disables the player body. It does not use an entry animation. A witness can remember the locker. Strong audible breathing near a locker can also give useful evidence.

Hold breath only while crouched or hidden. This uses stamina. After breath exhaustion, stamina must recover before the player can hold breath again. The same principle prevents repeated sprint starts at zero stamina.

## City scope

The district is open to route choice but has a fixed outer wall. Sizes are 3 × 3, 5 × 5, and 7 × 7 blocks. Every generated building has an entrance, rooms, and two to four floors. One central lot stays open. Other open lots vary by seed.

The current generator varies dimensions, height, use, colour, object placement, and fuse sites. It does not yet create irregular road networks or many distinct floor-plan families. A repeated seed repeats the plan. It does not guarantee bit-identical physics or a repeated player encounter.

All buildings use one entrance and a simple stair layout. This is enough to test the base systems. Add loop routes, rear exits, linked courtyards, and further stair types after the physics test gates pass.

## Scope decisions

There is no hunger, crafting, weapon, combat inventory, or quest tree in the first version. Each of those adds work outside the central sound-and-escape loop.

Good later additions are a circuit that disables a light group, a door held open by an object, a lift that makes noise, a quiet alternate exit, and a threat that responds to a different sound pattern. Add one rule at a time. Each rule must create a useful player choice.

## Fairness checks

A threat must act on evidence. It must not read a hidden player's current position to create a pursuit target. It must lose precise tracking when sight breaks. A known locker is an exception only when there is witness or audible evidence.

A dark image must still support navigation. Never make the only important cue depend on high volume, fast flashing, a high frame rate, or one graphics preset. Preserve captions and control reference access.
