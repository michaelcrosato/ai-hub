# Lighting and performance plan

## Target, not result

The intended baseline is an RTX 3060, 1920 × 1080 output, High settings, and 60 frames per second. No result on that hardware is supplied. Record the actual CPU, RAM, GPU variant, VRAM, driver, browser, canvas size, and engine version when you test.

A low polygon count does not remove shadow rendering, fill, transparency, CPU physics, or draw submission cost. Spend the first budget on useful shadow coverage and readable spaces. Do not turn on every effect without a measurement.

## Current implementation

| Element | Source setting |
| --- | --- |
| Moon | Directional light. 2048 shadow resolution. One to four cascades by quality. |
| Flashlight | Camera-mounted spot. Dynamic shadows. Part of the local shadow atlas, but outside the room/street light-count budget. |
| Room and street lights | Downward spots. Every active local light casts shadows. Nearby lights are selected every 0.25 seconds. |
| Local shadow atlas | 2048 or 4096 square. Shared by active non-directional shadow lights. |
| Local shadow filter | PCF3 by default. PCF5 on Ultra. |
| Moon filter | PCF3 by default. Optional PCSS contact-hardening shadows. |
| Ambient shading | Small cool ambient term plus half-resolution SSAO. This is not global illumination. |
| Materials | Low-poly static meshes grouped by material. StandardMaterial metalness and GGX specular. |
| Camera frame | ACES tone mapping, TAA, restrained bloom, vignette. Four-sample MSAA when TAA is off. |
| Fog | Exponential scene fog. Optional native directional volumetric fog at half resolution. |
| Render scale | 50% to 100%. Device pixel ratio is capped at 1 by the game lighting setup. |

CameraFrame supplies the post-processing pipeline used here. Render target scale is a fraction up to 1, not a supersampling multiplier above 1. StandardMaterial gloss is normalized from 0 to 1. [P1, P5, P6]

## Light-count presets

| Preset | Active room/street shadow lights, maximum | Atlas | Moon cascades | Moon shadow distance | Load / unload radius |
| --- | ---: | ---: | ---: | ---: | ---: |
| Low | 3 | 2048 | 1 | 45 m | 48 / 60 m |
| Medium | 6 | 2048 | 2 | 65 m | 58 / 72 m |
| High | 10 | 4096 | 3 | 85 m | 66 / 82 m |
| Ultra | 16 | 4096 | 4 | 100 m | 75 / 92 m |

The flashlight and moon are additional lights. Not all room fixtures cast light at once. An emissive fixture can remain visible while its local light is disabled. No unshadowed local fill is used because that would pass through walls.

The world uses a 12 × 4 × 12 light-cell grid and a 24-light per-cell cap. These are starting values, not a hardware limit or a measured optimum. The HUD's local light count excludes the flashlight and moon.

## Select compatible techniques

PlayCanvas clustered local lights use a shared shadow atlas and shared PCF mode. Directional PCSS is a different path. VSM has different light and renderer restrictions. These are choices, not effects to stack on one light. Point-light shadows also need six directions; spots are a deliberate choice for this city. [P2, P3]

The optional volumetric fog is driven by the moon's directional light and its shadow maps. It is not local volumetric scattering from every lamp or flashlight. TAA is useful for resolving the fog's temporal noise. [P4]

There is no custom ray tracer, ray-traced shadow path, DLSS, dynamic GI, screen-space reflection pass, or local reflection-probe system in this source. A glossy road without an environment map is not a reflection system. Do not label it as one.

Area lights, cookies, static light baking, image-based lighting, and further shadow choices can be evaluated later. A newly generated city also needs a plan for generating or selecting any baked data. Do not reuse a bake from a different layout.

## Measure the worst case

Use a fixed seed and route. Test a street crossing, a room with many visible lights, two open doorways, upper-floor windows, both threats, moved cans, and the exit alarm. Repeat with the largest city. Test both WebGPU and forced WebGL2.

Record median, 95th-percentile, and 99th-percentile frame time. Record slow frames during streaming. Separate CPU and GPU cost where the browser tools allow it. The HUD FPS value is only a short rolling count, not a GPU profiler.

The 60 FPS target gives about 16.7 ms per frame. Treat that as a total frame budget, not a sum of independent CPU and GPU promises. Record the measurement route and settings with every result.

## Reduction order

First reduce active local shadow lights. Next reduce cascade count and shadow distance. Then disable volumetric fog or PCSS. Reduce SSAO samples or render scale if the GPU is still the limit.

For CPU or memory limits, reduce loaded buildings, dynamic props, or collider count. Improve per-floor visibility and collision merging before increasing the city size. The current source merges visible wall boxes by material but still uses many simple collision bodies.

Do not freeze a shadow map while its door, prop, player, or threat can move. Static shadow caching needs explicit invalidation. Do not change player hearing or threat detection to hide a rendering problem.

## Production upgrades

Add measured reflection data and carefully authored surface variation before large amounts of decoration. Add light-selection fading to reduce visible switching. Add portal or room culling only with tests that preserve window and doorway views. Add worker-based generation and floor-level streaming after stable IDs and persistence are fixed.

Keep a clear difference between visual improvements and changes to stealth rules. A graphics preset must not make an otherwise invisible player visible to the AI.
