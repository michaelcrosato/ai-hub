# Architecture and extension guide

## Ownership

`main.mts` owns the standalone PlayCanvas application. `editor/entry.mts` does not create an application. It receives the Editor application and creates one `Game` instance.

`Game` owns a run. It creates the root entity, city plan, session, player, world, threats, sound, lights, and feature host. It removes them on a new run or return to the main menu. The UI and input live across runs and are removed when `Game.destroy()` runs.

Use an empty host scene. Game settings change the application's time scale, fog, ambient light, and clustered light settings. They are not an isolated layer for a larger existing game scene. The old time scale is restored on destruction. Other scene rendering settings are not fully restored.

## One plan, several systems

```text
seed + generator version
          |
          v
      CityPlan
       /  |  \
 geometry |  map and fuse notes
          |
      portal graph
       /       \
 walk routes   sound routes
       |           |
 enemy travel  hearing + spatial audio
```

`CityPlan` contains stable building, room, door, node, portal, and fuse IDs. It is serializable data. It does not contain engine entities. The generator does not call browser or engine APIs.

`geometry.mts` turns a building plan into boxes, props, and light sites. Visible openings and route nodes use the same room and door definitions. Do not make a second independent random floor layout for collision or sound.

`Navigation` uses A* for walking and weighted routes for sound. Windows can transmit sound but cannot form a walk route. Door revision changes clear the route cache. The graph is not a full geometric navmesh.

## Runtime world

Outer shells are merged by material and remain loaded. Interior meshes, walls, floors, doors, lights, and furniture load by building. The system loads at most one additional building per stream update. It uses separate load and unload distances to reduce repeated loads at an edge.

A building that contains an active threat stays loaded. Nearby moved props can delay unload. Unload stores stable prop transforms and door targets. It removes native physics bodies and local light entries. It does not run a hidden physics simulation for unloaded buildings.

This is building-level streaming. It is not floor-level streaming, portal visibility culling, a worker-based mesh pipeline, or a GPU-driven world renderer.

## Event boundary

The event bus has typed `noise`, `message`, `collected`, `phase`, and `door` events. Keep player intent separate from sound output. The sound system can play a noise or suppress playback. It must not change the noise level used by a threat.

`EnemyBrain` accepts sight, sound, and arrival evidence. It has no player reference. `Enemies` gathers evidence from the world, plans travel, and moves engine entities. This separation allows memory rules to be tested without graphics or physics.

## Add a feature module

`GameModule` has `start`, optional `update`, and `stop`. A factory creates a new module for each run. IDs must be unique. Stop must remove listeners and owned resources.

The optional `DistantSignal` class is in `src/features/distant-signal.mts`. It is not enabled by default. It emits a brief distant signal every 90 seconds during the search stage. To enable it in the standalone entry:

```ts
import { DistantSignal } from './features/distant-signal.mjs';

// Replace the existing Game construction after app.start().
const game = new Game(app, canvas, {
    modules: [() => new DistantSignal()]
});
```

For the Editor entry, use `../features/distant-signal.mjs` and pass the same module factory to `new Game(this.app, canvas, ...)`. `FieldNotes` stays active because `Game` adds it before optional factories.

Example of a small event-driven feature:

```ts
import type { GameContext, GameModule } from './game/modules.mjs';

export class FirstFuseHint implements GameModule {
    readonly id = 'first-fuse-hint';
    private stopListening: (() => void) | null = null;

    start(context: GameContext): void {
        this.stopListening = context.events.on('collected', event => {
            if (event.total !== 1) return;
            context.events.emit('message', {
                text: 'One fuse is secure. Check the next block before you run.',
                duration: 5
            });
        });
    }

    stop(): void {
        this.stopListening?.();
        this.stopListening = null;
    }
}
```

Place that file at `src/first-fuse-hint.mts` for the example import path. A module update runs only while the game runs. Use `dt`, not wall time, for game timers.

## Add an object type

The first version uses a typed object-kind union, not a complete plug-in registry. A new physical object normally needs four edits: add its data type in `geometry.mts`; add placement rules; add runtime creation and registration in `runtime.mts`; add the use response in `game.mts`.

For many object types, replace the use switch with a handler registry. Keep stable IDs and let a handler own its state, display prompt, noise, and save data. Do not hide required system changes behind a claim of no-code modularity.

## Save boundary

`session.mts` validates input before the runtime uses a checkpoint. It rejects unknown save and generator versions. Runtime restore also filters door and prop IDs against the current city.

The save contains player values, fuse state, phase, alarm time, door targets, stable prop transforms, and explored blocks. A hidden player is saved outside the locker. This avoids restoring a disabled capsule inside solid geometry.

Threat memory, radio switches, thrown bottles, and exact physics velocity do not persist. Add these to a versioned schema before calling the save a full snapshot. Increase the generator version when stable layout IDs or their meaning change. Add an explicit migration or reject the old checkpoint.

## Tests for new work

A generation change needs seeded data tests and a physical traversal test. A new sound rule needs open-door and closed-door checks. A new threat needs a memory-loss test. A new menu setting needs validation, persistence, and a browser input check. A new resource needs a destruction and repeated-run check.

Never treat graph connectivity as proof that a capsule fits. Never treat a clean source diff as proof that WebGPU renders the frame.
