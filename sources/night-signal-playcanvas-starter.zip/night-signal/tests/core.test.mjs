import test from 'node:test';
import assert from 'node:assert/strict';
import { createCity, validateCity, locateNode } from '../.test-build/world/plan.mjs';
import { createBuildingGeometry, pointInsideBox } from '../.test-build/world/geometry.mjs';
import { Navigation } from '../.test-build/world/navigation.mjs';
import { propagateSound, NoiseLog } from '../.test-build/audio/acoustics.mjs';
import { EnemyBrain } from '../.test-build/ai/brain.mjs';
import { Session, parseSave } from '../.test-build/game/session.mjs';
import { validateSettings, DEFAULT_BINDINGS, GROUND_Y } from '../.test-build/core/config.mjs';
import { EventBus } from '../.test-build/core/events.mjs';
import { Random } from '../.test-build/core/random.mjs';

test('same seed gives the same world and stable object IDs',()=>{
  assert.deepEqual(createCity('M-01'),createCity('M-01'));
  assert.notEqual(createCity('M-01').fingerprint,createCity('M-02').fingerprint);
});
test('1000 seeds: all rooms, floors, and fuses connect to the exit',()=>{
  for(let i=0;i<1000;i++) {
    const c=createCity(`seed-${i}`,[3,5,7][i%3]);
    assert.deepEqual(validateCity(c),[],`seed ${i}`);
    assert.equal(c.fuses.length,3);
    assert.ok(c.fuses.every(f=>c.buildings.find(b=>b.id===f.building).rooms.find(r=>r.id===f.room).floor>0));
  }
});
test('city size and seed limits are enforced',()=>{
  assert.throws(()=>createCity('x',4));
  assert.equal(createCity('x'.repeat(300),3).seed.length,80);
  assert.equal(createCity('  ',3).seed,'NIGHT-001');
});
test('walk routes never use window portals',()=>{
  const c=createCity('route',3),nav=new Navigation(c);
  for(const f of c.fuses){ const p=nav.route(c.exitNode,f.node); assert.ok(p); assert.ok(p.portals.every(p=>p.walk&&p.kind!=='window')); }
});
test('route samples clear wall solids and upper floor ceilings',()=>{
  for(let seed=0;seed<5;seed++) {
    const c=createCity(`geometry-${seed}`,3),byId=new Map(c.nodes.map(n=>[n.id,n]));
    for(const b of c.buildings) {
      const geo=createBuildingGeometry(c,b);
      const blockers=geo.boxes.filter(x=>x.solid && !x.glass && !x.id.includes('ramp-collision') && !x.id.includes('slab') && !x.id.includes('stair-landing'));
      for(const p of c.portals.filter(p=>p.walk && byId.get(p.a)?.building===b.id && byId.get(p.b)?.building===b.id)) {
        const a=byId.get(p.a).position,e=byId.get(p.b).position;
        for(let j=0;j<=12;j++) {
          const t=j/12,point=[a[0]+(e[0]-a[0])*t,a[1]+(e[1]-a[1])*t+1.5,a[2]+(e[2]-a[2])*t];
          const hit=blockers.find(box=>pointInsideBox(point,box,.12));
          assert.ok(!hit,`${p.id} intersects ${hit?.id} at ${point}`);
        }
      }
    }
  }
});
test('every building has real facade openings, stair holes, and hide objects',()=>{
  const c=createCity('solid',3);
  for(const b of c.buildings){ const g=createBuildingGeometry(c,b); assert.equal(g.objects.filter(o=>o.kind==='locker').length,b.rooms.length); assert.equal(g.boxes.filter(o=>o.id.includes('ramp-collision')).length,b.floors-1); assert.ok(g.boxes.some(o=>o.glass)); }
});
test('a closed door reduces sound without changing the source position',()=>{
  const c=createCity('sound',3),nav=new Navigation(c),b=c.buildings[0],room=b.rooms[0],door=b.doors.find(d=>d.id===room.door),node=nav.nodes.get(door.nodeA);
  const event={id:1,time:0,position:[...room.center],node:room.node,level:65,kind:'impact',source:'test'};
  nav.doorOpen.set(door.id,false); const closed=propagateSound(nav,event,node.id,node.position);
  nav.doorOpen.set(door.id,true); const open=propagateSound(nav,event,node.id,node.position);
  assert.ok(open.level>closed.level+10); assert.ok(open.lowpass>closed.lowpass); assert.deepEqual(event.position,room.center);
});
test('sound falls with distance even inside one acoustic region',()=>{
  const c=createCity('s',3),nav=new Navigation(c),node=c.nodes[0];
  const e={id:1,time:0,position:node.position,node:node.id,level:70,kind:'impact',source:'x'};
  const close=propagateSound(nav,e,node.id,[node.position[0]+1,node.position[1],node.position[2]]);
  const far=propagateSound(nav,e,node.id,[node.position[0]+20,node.position[1],node.position[2]]);
  assert.ok(close.level>far.level+20);
});
test('noise log is bounded and keeps immutable source positions',()=>{
  const log=new NoiseLog(),p=[1,2,3];
  const e=log.emit({time:0,position:p,node:'x',level:30,kind:'step',source:'player'}); p[0]=999; assert.equal(e.position[0],1);
  for(let i=0;i<200;i++)log.emit({time:i,position:[0,0,0],node:'x',level:30,kind:'step',source:'player'});
  assert.ok(log.events.length<=96); log.prune(204); assert.equal(log.events.length,0);
});
test('enemy follows evidence, then loses sight and searches',()=>{
  const b=new EnemyBrain(),position=[1,0,2];
  b.update(.1,{reached:false,sight:{position,node:'a'}}); assert.equal(b.state,'chase'); position[0]=999; assert.equal(b.target.position[0],1);
  b.update(4,{reached:false}); assert.equal(b.state,'investigate'); assert.equal(b.target.position[0],1);
  b.update(.1,{reached:true}); assert.equal(b.state,'search');
  b.update(14,{reached:false}); assert.equal(b.state,'roam'); assert.equal(b.target,null);
});
test('enemy hearing uses the last source position, not a live target',()=>{
  const b=new EnemyBrain(); b.update(.1,{reached:false,sound:{position:[4,0,4],node:'r',strength:20}});
  assert.equal(b.state,'investigate'); b.update(1,{reached:false}); assert.deepEqual(b.target.position,[4,0,4]);
});
test('power needs three distinct fuses and the alarm must finish',()=>{
  const s=new Session(); assert.equal(s.startPower(),false); s.collect('fuse:0'); assert.equal(s.collect('fuse:0'),false); s.collect('fuse:1'); s.collect('fuse:2');
  assert.equal(s.startPower(),true); s.update(34); assert.equal(s.phase,'powering'); s.update(2); assert.equal(s.phase,'escape');
});
test('save parser rejects corrupt data and obsolete generators',()=>{
  assert.equal(parseSave('{bad'),null); assert.equal(parseSave('{}'),null);
  const s={version:1,generator:1,seed:'test',size:3,time:30,phase:'scavenge',alarmLeft:35,collected:[],battery:80,stamina:90,decoys:4,player:[0,GROUND_Y,0],yaw:180,pitch:0,doors:{},props:{},explored:[]};
  assert.ok(parseSave(JSON.stringify(s))); assert.equal(parseSave(JSON.stringify({...s,generator:2})),null); assert.equal(parseSave(JSON.stringify({...s,phase:'escape'})),null);
  assert.equal(parseSave(JSON.stringify({...s,player:[999999,0,0]})),null);
});
test('settings reject bad numbers and duplicate key bindings',()=>{
  const s=validateSettings({resolution:99,fov:NaN,volume:-3,bindings:{...DEFAULT_BINDINGS,forward:'KeyS'}});
  assert.equal(s.resolution,1); assert.equal(s.fov,82); assert.equal(s.volume,0); assert.deepEqual(s.bindings,DEFAULT_BINDINGS);
});
test('event bus unsubscribe and deterministic random stream',()=>{
  const b=new EventBus(); let n=0; const off=b.on('a',()=>n++); b.emit('a',1); off(); b.emit('a',2); assert.equal(n,1);
  const a=new Random('repeat'),c=new Random('repeat'); for(let i=0;i<100;i++)assert.equal(a.next(),c.next());
});

test('sound route cache changes when a door state changes',()=>{
  const c=createCity('cache',3),nav=new Navigation(c),b=c.buildings[0],d=b.doors[1];
  nav.doorOpen.set(d.id,false);const a=nav.route(d.nodeA,d.nodeB,'sound');assert.equal(nav.route(d.nodeA,d.nodeB,'sound'),a);
  nav.doorOpen.set(d.id,true);const next=nav.route(d.nodeA,d.nodeB,'sound');assert.notEqual(next,a);assert.ok(next.cost<a.cost);
});
test('radio and fuse pickups do not overlap',()=>{
  for(let i=0;i<100;i++){const city=createCity(`item-${i}`,3);for(const f of city.fuses){const b=city.buildings.find(b=>b.id===f.building),geometry=createBuildingGeometry(city,b);for(const o of geometry.objects.filter(o=>o.kind==='radio'&&o.room===f.room)){assert.ok(Math.abs(o.position[0]-f.position[0])>(o.size[0]+.17)/2);}}}
});
test('session rejects unknown fuses and invalid time steps',()=>{
  const s=new Session();assert.equal(s.collect('not-a-fuse'),false);assert.equal(s.collect('fuse:7'),false);s.update(-1);s.update(NaN);assert.equal(s.time,0);
});
test('settings do not accept object prototype names as quality levels',()=>{
  assert.equal(validateSettings({quality:'toString'}).quality,'high');assert.equal(validateSettings({quality:'__proto__'}).quality,'high');
});
