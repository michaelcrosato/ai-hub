"""Test the DOM menu, not the PlayCanvas renderer.

Run `npx tsc -p tsconfig.ui.json`, then run this file with Python and
Playwright installed. The test uses local source; it makes no network requests.
"""
import json
import os
import re
import shutil
from pathlib import Path
from playwright.sync_api import sync_playwright

root = Path(__file__).resolve().parents[1]
out = Path(os.environ.get('NIGHT_UI_OUTPUT', str(root / '.ui-test-results')))
modules = ['core/math', 'core/random', 'core/config', 'world/plan', 'ui/styles', 'ui/ui']
parts = []
for name in modules:
    text = (root / '.ui-test-build' / (name + '.mjs')).read_text()
    text = re.sub(r'^import .*?;\s*$', '', text, flags=re.M)
    text = re.sub(r'^export ', '', text, flags=re.M)
    parts.append(text)
harness = (root / 'tests/ui-harness.html').read_text().split('<script type="module">', 1)[1].split('</script>', 1)[0]
parts.append(re.sub(r'^import .*?;\s*$', '', harness, flags=re.M))
bundle = '\n'.join(parts)
out.mkdir(parents=True, exist_ok=True)
checks = []
errors = []
with sync_playwright() as p:
    browser = p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or shutil.which('google-chrome'), headless=True, args=['--no-sandbox'])
    page = browser.new_page(viewport={'width': 1440, 'height': 900}, device_scale_factor=1)
    page.on('pageerror', lambda error: errors.append(str(error)))
    page.set_content('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Night Signal UI test</title></head><body style="margin:0;background:#081011"></body></html>')
    page.add_script_tag(content=bundle, type='module')
    page.wait_for_selector('[data-action="new"]')
    assert page.locator('[data-action="continue"]').is_disabled()
    assert re.fullmatch(r'NIGHT-[0-9A-Z]+', page.locator('#city-seed').input_value())
    page.screenshot(path=str(out/'main-menu.png'), full_page=True)
    checks.append('Main menu renders with a fresh seed. Continue is disabled without a save.')

    page.locator('#city-seed').fill('MICA-27')
    page.locator('#city-size').select_option('7')
    page.locator('[data-action="new"]').click()
    assert page.evaluate('window.report.calls[0]') == {'type': 'new', 'seed': 'MICA-27', 'size': 7}
    checks.append('New run passes the exact seed and city size to its handler.')

    page.locator('[data-action="settings"]').click()
    page.locator('[data-setting="quality"]').select_option('medium')
    page.locator('[data-setting="volume"]').focus()
    page.keyboard.press('Home')
    page.locator('[data-setting="volumetric"]').check()
    page.locator('[data-setting="hints"]').uncheck()
    settings = page.evaluate('window.report.settings')
    assert settings['quality'] == 'medium' and settings['volume'] == 0
    assert settings['volumetric'] and not settings['hints']
    page.screenshot(path=str(out/'settings.png'), full_page=True)
    checks.append('Quality, volume, fog, and hint settings reach the settings handler.')
    page.locator('[data-action="back"]').click()
    assert page.evaluate('window.ui.screen') == 'pause'

    page.locator('[data-action="controls"]').click()
    page.locator('[data-bind="forward"]').click()
    page.keyboard.press('s')
    assert 'used for' in page.locator('[data-bind-status]').inner_text()
    page.keyboard.press('i')
    assert page.evaluate('window.report.settings.bindings.forward') == 'KeyI'
    page.locator('[data-action="reset"]').click()
    assert page.evaluate('window.report.settings.bindings.forward') == 'KeyW'
    checks.append('Key changes reject conflicts. A valid key and reset both work.')
    page.keyboard.press('Escape')
    assert page.evaluate('window.ui.screen') == 'pause'
    page.locator('[data-action="resume"]').click()
    assert page.locator('.overlay').is_hidden() and page.locator('.hud').is_visible()
    assert page.locator('[data-hud="hints"]').is_hidden()
    assert page.locator('[data-hud="prompt"]').inner_text() == '[E] Open door'
    checks.append('Resume shows the HUD and respects the hint setting.')

    page.evaluate('window.showTestJournal()')
    assert page.locator('canvas.map').is_visible()
    assert 'TEST-<CITY>' in page.locator('.dialog').inner_text()
    assert page.locator('.dialog city').count() == 0
    page.screenshot(path=str(out/'map-and-notes.png'), full_page=True)
    checks.append('Map and notes render. Seed text does not become HTML.')
    page.keyboard.press('Tab')
    assert page.evaluate('window.ui.screen') == 'play'
    checks.append('The journal key closes the map through the resume handler.')

    page.evaluate('window.ui.main(true)')
    page.set_viewport_size({'width': 390, 'height': 844})
    page.screenshot(path=str(out/'mobile-menu.png'), full_page=True)
    assert page.evaluate('document.querySelector(".overlay").scrollWidth <= window.innerWidth')
    assert page.locator('[data-action="continue"]').is_enabled()
    checks.append('Narrow menu has no horizontal overflow. Continue enables with a save.')
    assert not errors, errors
    checks.append('No browser page errors occurred in the UI test.')
    browser.close()
report = {'scope': 'UI only. No PlayCanvas, Ammo, WebGPU, or GPU performance test.', 'checks': checks, 'passed': len(checks), 'page_errors': errors}
(out/'report.json').write_text(json.dumps(report, indent=2))
print(json.dumps(report, indent=2))
