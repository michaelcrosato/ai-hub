# Night Signal agent rules

## Start

Read README.md, docs/VALIDATION.md, and docs/ARCHITECTURE.md. Treat this as prototype source. Do not claim a graphics, physics, or target-hardware test passed unless you ran it and recorded evidence.

Use the pinned PlayCanvas Engine V2 dependency first. Do not migrate the project, update dependencies, or replace physics as an incidental fix. Report required changes and their scope.

## Source rules

Author TypeScript in `.mts` files. Use relative `.mjs` imports. The Editor output is a bundled `.mjs` asset with `playcanvas` external. Do not bundle a second engine into that asset.

Keep generation, graph navigation, acoustics, and threat memory independent of the renderer. Use stable IDs and seeded random values for layout. Do not create separate random floor layouts for graphics, collision, and sound.

Do not give EnemyBrain a player reference. It accepts evidence. Do not use master sound volume as a multiplier for AI noise. Do not disable stealth checks with a graphics preset.

New feature modules need a unique ID, a fresh per-run factory, and cleanup in stop(). New resources need cleanup. Change save or generator versions when their meaning changes.

Do not add an AI API key, telemetry, remote game service, or paid asset without a clear task requirement. The game does not need an AI service at runtime.

## Editor safety

First inspect the connected Editor, branch, scene, engine, and pending changes without mutation. Confirm the intended target. Create a checkpoint before a substantial change. Preserve unrelated user assets.

MCP scene writes are direct. VS Code asset changes use Pull/Push. Do not edit one asset through both paths at the same time. Never reset a project, delete assets, switch branches, or restore a checkpoint unless that destructive operation is explicitly intended.

After a scene or behavior edit, verify Launch, logs, input, and relevant state. Stop only the test Launch you own. A screenshot of the design viewport is not proof of gameplay.

## Local checks

```sh
npm run typecheck
npm test
npm run build
```

Run the optional UI test for menu changes. Run the native traversal check for geometry changes. Run the fixed-route performance test for lighting or streaming changes. Record failures and skipped checks separately.

Do not replace a real engine import with a stub to make release type checks pass. Do not remove an assertion because it exposes a generator failure. Keep failed seeds and add regression tests.

## Completion report

State changed files, behavior changes, tests actually run, unresolved faults, and measurements. Do not convert a target into a result. Do not alter docs/validation results unless a new run produced them.
