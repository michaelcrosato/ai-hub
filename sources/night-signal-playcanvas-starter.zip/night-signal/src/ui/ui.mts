import { DEFAULT_BINDINGS, keyLabel, validateSettings, type Action, type Settings } from '../core/config.mjs';
import type { CityPlan } from '../world/plan.mjs';
import type { Phase } from '../game/session.mjs';
import type { V3 } from '../core/math.mjs';
import { styles } from './styles.mjs';
const escape = (s: string): string => s.replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]!));
const freshSeed = (): string => `NIGHT-${crypto.getRandomValues(new Uint32Array(1))[0]!.toString(36).toUpperCase()}`;
const labels: Record<Action, string> = { forward: 'Move forward', back: 'Move back', left: 'Move left', right: 'Move right', interact: 'Use / open / hide', sprint: 'Run (hold)', crouch: 'Crouch (toggle)', flashlight: 'Flashlight', throw: 'Throw bottle', crank: 'Charge light (hold)', breath: 'Hold breath', journal: 'Map and notes', hints: 'Show / hide control hints' };
export interface UIHandlers {
    newGame: (seed: string, size: number) => void;
    continueGame: () => void;
    resume: () => void;
    saveMenu: () => void;
    settings: (value: Settings) => void;
}
export interface HudData {
    phase: Phase;
    fuses: number;
    alarm: number;
    battery: number;
    stamina: number;
    noise: number;
    decoys: number;
    location: string;
    prompt: string;
    hidden: boolean;
    breath: boolean;
    crank: boolean;
    fps: number;
    lights: number;
}
export interface JournalData {
    city: CityPlan;
    player: V3;
    explored: Set<string>;
    collected: Set<string>;
}
export class UI {
    readonly root: HTMLDivElement;
    private readonly overlay: HTMLDivElement;
    private readonly hud: HTMLDivElement;
    private settings: Settings;
    private hasSave = false;
    private parentPage: 'main' | 'pause' = 'main';
    private pauseReason = 'The city is paused.';
    screen = 'main';
    private captionUntil = 0;
    private toastUntil = 0;
    private readonly abort = new AbortController();
    private binding: Action | null = null;
    constructor(settings: Settings, readonly handlers: UIHandlers, readonly backend: string) {
        this.settings = settings;
        this.root = document.createElement('div');
        this.root.id = 'night-signal-ui';
        const style = document.createElement('style');
        style.textContent = styles;
        this.root.append(style);
        this.hud = document.createElement('div');
        this.hud.className = 'hud';
        this.hud.hidden = true;
        this.root.append(this.hud);
        this.hud.innerHTML = `<div class="hud-top"><div><div class="objective" data-hud="objective"></div><div class="location" data-hud="location"></div></div><div class="hud-info" data-hud="info"></div></div><div class="crosshair"></div><div class="prompt" data-hud="prompt" hidden></div><div class="meters">${['battery', 'stamina', 'noise'].map(k => `<div><div class="meter-label"><span>${k.toUpperCase()}</span><span data-hud="${k}-text"></span></div><div class="meter ${k}"><i data-hud="${k}"></i></div></div>`).join('')}</div><div class="hints" data-hud="hints"></div><div class="hidden-state" data-hud="state"></div><div class="caption" role="status" aria-live="polite" data-hud="caption" hidden></div><div class="toast" role="status" data-hud="toast" hidden></div>`;
        this.overlay = document.createElement('div');
        this.overlay.className = 'overlay';
        this.overlay.setAttribute('role', 'dialog');
        this.overlay.setAttribute('aria-modal', 'true');
        this.root.append(this.overlay);
        document.body.append(this.root);
        window.addEventListener('keydown', e => this.key(e), { signal: this.abort.signal });
        this.apply(settings);
    }
    private el<T extends HTMLElement = HTMLElement>(selector: string): T { const e = this.root.querySelector<T>(selector); if (!e)
        throw new Error(`UI element not found: ${selector}`); return e; }
    private click(id: string, fn: () => void): void { this.el<HTMLButtonElement>(`[data-action="${id}"]`).addEventListener('click', fn); }
    private paint(screen: string, html: string): void { this.screen = screen; this.binding = null; this.overlay.hidden = false; this.hud.hidden = true; this.overlay.innerHTML = html; this.overlay.scrollTop = 0; this.overlay.setAttribute('aria-label', screen === 'main' ? 'Night Signal main menu' : screen); queueMicrotask(() => this.overlay.querySelector<HTMLElement>('button:not(:disabled),input')?.focus()); }
    main(hasSave = this.hasSave): void {
        this.hasSave = hasSave;
        this.parentPage = 'main';
        this.paint('main', `<main class="main-layout"><section class="intro"><div class="eyebrow">A CITY WITHOUT AN ANSWER / 01</div><h1 class="title"><span>NIGHT</span><span>SIGNAL</span></h1><p class="strap">Find a way out.<br>Leave as little sound as possible.</p><div class="rule"></div><div class="tags"><span class="tag">FIRST PERSON</span><span class="tag">PROCEDURAL CITY</span><span class="tag">SOUND-LED HORROR</span></div></section><section class="panel"><div class="panel-top"><h3>Enter the city</h3><span class="status">${escape(this.backend.toUpperCase())}</span></div><label class="field"><span>City seed</span><div class="row"><input id="city-seed" type="text" maxlength="80" value="${freshSeed()}" aria-label="City seed" autocomplete="off" spellcheck="false"><button data-action="seed" style="flex:0" aria-label="Make a new seed">↻</button></div></label><label class="field"><span>City size</span><select id="city-size"><option value="3">Small — 3 × 3 blocks</option><option value="5" selected>Standard — 5 × 5 blocks</option><option value="7">Large — 7 × 7 blocks</option></select></label><div class="stack"><button class="primary wide" data-action="new">Start a new run →</button><button class="wide" data-action="continue" ${hasSave ? '' : 'disabled'}>Continue saved run</button><div class="row"><button data-action="settings">Settings</button><button data-action="controls">Controls</button></div></div><p class="note">Find three fuses. Restore power at the north exit.<br>Listen before you move. Doors can slow a threat.</p></section></main><footer class="footer"><span>PROTOTYPE 0.1 / PLAYCANVAS ENGINE V2</span><span>KEYBOARD + MOUSE / HEADPHONES ADVISED</span></footer>`);
        this.click('seed', () => { this.el<HTMLInputElement>('#city-seed').value = freshSeed(); });
        this.click('new', () => { const seed = this.el<HTMLInputElement>('#city-seed').value.trim() || 'NIGHT-001'; const size = Number(this.el<HTMLSelectElement>('#city-size').value); this.handlers.newGame(seed, size); });
        this.click('continue', () => this.handlers.continueGame());
        this.click('settings', () => this.showSettings());
        this.click('controls', () => this.showControls());
    }
    pause(reason = 'The city is paused.'): void {
        this.parentPage = 'pause';
        this.pauseReason = reason;
        this.paint('pause', `<section class="dialog narrow panel"><div class="eyebrow">NIGHT SIGNAL / SAFE TO PAUSE</div><h2>${reason.startsWith('City ready') ? 'City ready' : 'Paused'}</h2><p class="muted">${escape(reason)}</p><div class="stack"><button class="primary" data-action="resume">Enter the city →</button><button data-action="journal-note" disabled>Press Tab in the city for your map and notes</button><div class="row"><button data-action="settings">Settings</button><button data-action="controls">Controls</button></div><button data-action="save-menu">Save and return to menu</button></div><p class="note">The game clock, threats, and physics stop while this menu is open.</p></section>`);
        this.click('resume', () => this.handlers.resume());
        this.click('settings', () => this.showSettings());
        this.click('controls', () => this.showControls());
        this.click('save-menu', () => this.handlers.saveMenu());
    }
    loading(text: string): void { this.paint('loading', `<section class="dialog narrow panel"><div class="eyebrow">NIGHT SIGNAL</div><h2>Build the city</h2><div class="loading"></div><p class="muted">${escape(text)}</p></section>`); }
    error(text: string): void { this.paint('error', `<section class="dialog narrow panel"><div class="eyebrow">START FAILED</div><h2>The city did not load.</h2><p>${escape(text)}</p><p class="muted">Read the browser console for details. Use the build and setup steps in README.md.</p><button data-action="back">Return to menu</button></section>`); this.click('back', () => this.main()); }
    end(won: boolean, seed: string, time: number): void {
        this.parentPage = 'main';
        this.paint('end', `<section class="dialog narrow panel"><div class="eyebrow">${won ? 'EXIT REACHED' : 'SIGNAL LOST'}</div><h2>${won ? 'You got out.' : 'It found you.'}</h2><p class="muted">${won ? 'Behind you, the alarm still sounds.' : 'A closed door is not a guarantee. Make distance, break sight, then hide.'}</p><div class="rule"></div><p>Seed: <strong>${escape(seed)}</strong><br>Time: ${Math.floor(time / 60)}:${String(Math.floor(time % 60)).padStart(2, '0')}</p><button class="primary wide" data-action="back">Return to menu →</button></section>`);
        this.click('back', () => this.handlers.saveMenu());
    }
    private back(): void { if (this.parentPage === 'pause')
        this.pause(this.pauseReason);
    else
        this.main(); }
    showSettings(): void {
        const s = this.settings;
        const slider = (key: keyof Settings, label: string, min: number, max: number, step: number, format: (v: number) => string): string => `<label class="field"><span class="slider-label">${label}<output data-output="${key}">${format(s[key] as number)}</output></span><input type="range" data-setting="${key}" aria-label="${label}" min="${min}" max="${max}" step="${step}" value="${s[key]}"></label>`;
        const check = (key: keyof Settings, label: string): string => `<label class="check"><input type="checkbox" data-setting="${key}" ${s[key] ? 'checked' : ''}><span>${label}</span></label>`;
        this.paint('settings', `<section class="dialog panel"><header class="dialog-head"><div><div class="eyebrow">TUNE THE EXPERIENCE</div><h2>Settings</h2><p class="muted">Changes apply at once. Settings stay on this device.</p></div><button data-action="back">Back</button></header><div class="settings-grid"><section><h3>Graphics</h3><label class="field"><span>Quality / shadow light budget</span><select data-setting="quality">${['low', 'medium', 'high', 'ultra'].map(q => `<option value="${q}" ${s.quality === q ? 'selected' : ''}>${q[0]!.toUpperCase() + q.slice(1)}</option>`).join('')}</select></label>${slider('resolution', 'Render scale', .5, 1, .05, v => `${Math.round(v * 100)}%`)}${slider('fov', 'Field of view', 60, 110, 1, v => `${v}°`)}${check('taa', 'Temporal anti-aliasing')}${check('ssao', 'Ambient contact shadows (SSAO)')}${check('bloom', 'Bloom on bright surfaces')}${check('pcss', 'Soft moon shadows (PCSS)')}${check('volumetric', 'Moonlit volumetric fog')}<p class="note">PCSS and fog cost GPU time. Local lights use a shared shadow atlas. Ultra is not a frame-rate promise.</p></section><section><h3>Sound and input</h3>${slider('volume', 'Master volume', 0, 1, .01, v => `${Math.round(v * 100)}%`)}<label class="field"><span>Sound range</span><select data-setting="range"><option value="full" ${s.range === 'full' ? 'selected' : ''}>Full range</option><option value="night" ${s.range === 'night' ? 'selected' : ''}>Night — softer loud sounds</option></select></label>${slider('sensitivity', 'Mouse sensitivity', .025, .5, .005, v => v.toFixed(3))}${check('invertY', 'Invert vertical look')}${check('captions', 'Directional sound captions')}<section class="settings-group"><h3>Comfort and display</h3>${check('hud', 'Show status display')}${check('hints', 'Show control hints')}${check('headBob', 'Small head movement while walking')}${check('flicker', 'Slow light flicker')}</section><p class="note">No camera shake or motion blur. Head movement and flicker are off by default. Sound volume does not change enemy hearing.</p></section></div></section>`);
        this.click('back', () => this.back());
        this.overlay.querySelectorAll<HTMLInputElement | HTMLSelectElement>('[data-setting]').forEach(input => input.addEventListener(input instanceof HTMLInputElement && input.type === 'range' ? 'input' : 'change', () => {
            const key = input.dataset.setting!;
            let value: string | number | boolean = input.value;
            if (input instanceof HTMLInputElement)
                value = input.type === 'checkbox' ? input.checked : Number(input.value);
            this.settings = validateSettings({ ...this.settings, [key]: value });
            const out = this.overlay.querySelector<HTMLOutputElement>(`[data-output="${key}"]`);
            if (out)
                out.value = key === 'volume' || key === 'resolution' ? `${Math.round(Number(value) * 100)}%` : key === 'fov' ? `${value}°` : Number(value).toFixed(3);
            this.handlers.settings(this.settings);
        }));
    }
    showControls(): void {
        this.paint('controls', `<section class="dialog panel"><header class="dialog-head"><div><div class="eyebrow">KEYBOARD + MOUSE</div><h2>Controls</h2><p class="muted">Select a key to change it. Press Escape to cancel.</p></div><button data-action="back">Back</button></header><div class="settings-grid"><div><table class="key-table"><tbody>${(Object.keys(DEFAULT_BINDINGS) as Action[]).map(action => `<tr><td>${labels[action]}</td><td><button data-bind="${action}" aria-label="Change key: ${labels[action]}">${escape(keyLabel(this.settings.bindings[action]))}</button></td></tr>`).join('')}<tr><td>Pause / release mouse</td><td><kbd>Escape</kbd></td></tr></tbody></table><p data-bind-status class="muted" role="status" style="margin-top:16px"></p><button data-action="reset">Reset controls</button></div><section><h3>Stay quiet</h3><p>Walk on carpet when you can. Running and metal floors make more noise.</p><p>Crouch before you move a door to move it slowly. A threat can push a door open.</p><p>Use a locker to hide. Hold your breath when a threat is close. Low stamina can make you breathe loudly.</p><p>A threat that sees you hide can find your locker. A thrown bottle or a radio can draw it away.</p><h3 style="margin-top:25px">Keep the light working</h3><p>Hold the charge key to turn the crank. The light goes off, and the crank makes noise.</p><p class="muted">There is no jump, gun, or hand animation. Use the stairs. Move and listen.</p></section></div></section>`);
        this.click('back', () => this.back());
        this.click('reset', () => { this.settings = validateSettings({ ...this.settings, bindings: { ...DEFAULT_BINDINGS } }); this.handlers.settings(this.settings); this.showControls(); });
        this.overlay.querySelectorAll<HTMLButtonElement>('[data-bind]').forEach(b => b.addEventListener('click', () => { this.binding = b.dataset.bind as Action; this.el('[data-bind-status]').textContent = `Press a key for: ${labels[this.binding]}.`; b.textContent = 'Press a key…'; }));
    }
    private key(e: KeyboardEvent): void {
        if (this.overlay.hidden)
            return;
        if (this.binding) {
            e.preventDefault();
            e.stopImmediatePropagation();
            if (e.code === 'Escape') {
                this.showControls();
                return;
            }
            const valid = /^(Key[A-Z]|Digit[0-9]|ShiftLeft|ControlLeft|AltLeft|Space|Tab|Arrow(Up|Down|Left|Right))$/.test(e.code);
            const conflict = (Object.keys(this.settings.bindings) as Action[]).find(a => a !== this.binding && this.settings.bindings[a] === e.code);
            if (!valid || conflict) {
                this.el('[data-bind-status]').textContent = conflict ? `That key is used for: ${labels[conflict]}.` : 'Use a letter, number, arrow, Shift, Ctrl, Alt, Space, or Tab.';
                return;
            }
            this.settings = validateSettings({ ...this.settings, bindings: { ...this.settings.bindings, [this.binding]: e.code } });
            this.handlers.settings(this.settings);
            this.showControls();
            return;
        }
        if (e.code === 'Escape' && ['settings', 'controls'].includes(this.screen)) {
            e.preventDefault();
            this.back();
            return;
        }
        if ((e.code === 'Escape' || e.code === this.settings.bindings.journal) && this.screen === 'journal') {
            e.preventDefault();
            this.handlers.resume();
            return;
        }
        if (e.code === 'Tab') {
            const focus = [...this.overlay.querySelectorAll<HTMLElement>('button:not(:disabled),input,select,[tabindex="0"]')];
            if (!focus.length)
                return;
            const first = focus[0]!, last = focus[focus.length - 1]!;
            if (e.shiftKey && document.activeElement === first) {
                e.preventDefault();
                last.focus();
            }
            else if (!e.shiftKey && document.activeElement === last) {
                e.preventDefault();
                first.focus();
            }
        }
    }
    journal(data: JournalData): void {
        this.parentPage = 'pause';
        const b = (id: string) => data.city.buildings.find(x => x.id === id)!;
        this.paint('journal', `<section class="dialog panel"><header class="dialog-head"><div><div class="eyebrow">FIELD NOTES / GAME PAUSED</div><h2>Find a signal out</h2><p class="muted">Seed ${escape(data.city.seed)} / ${escape(data.city.fingerprint)}</p></div><button data-action="resume">Close map</button></header><div class="journal-grid"><section><canvas class="map" width="480" height="480" aria-label="City map. Your marker is a circle. North exit is at the top."></canvas><p class="muted" style="margin-top:10px">Circle: you. Solid blocks: places you entered.<br>North is at the top. The map does not show threats.</p></section><section><h3>Fuse locations</h3>${data.city.fuses.map(f => { const place = b(f.building), r = place.rooms.find(x => x.id === f.room)!; return `<div class="clue ${data.collected.has(f.id) ? 'done' : ''}"><strong>Block ${String.fromCharCode(65 + place.lotX)}${place.lotZ + 1}</strong><br>${place.kind[0]!.toUpperCase() + place.kind.slice(1)} / floor ${r.floor + 1}${data.collected.has(f.id) ? ' / collected' : ''}</div>`; }).join('')}<div class="rule"></div><h3>The exit</h3><p>Use the switch at the north gate after you find all three fuses.</p><p>The alarm will run for 35 seconds. Stay alive until the gate opens. Then go through it.</p><p class="note">Glass does not stop sight. Doors reduce sound, but they do not remove it.</p></section></div></section>`);
        this.click('resume', () => this.handlers.resume());
        this.drawMap(this.el<HTMLCanvasElement>('.map'), data);
    }
    private drawMap(canvas: HTMLCanvasElement, data: JournalData): void {
        const ctx = canvas.getContext('2d');
        if (!ctx)
            return;
        const city = data.city, pad = 26, scale = (480 - pad * 2) / (city.extent * 2), map = (p: V3): [
            number,
            number
        ] => [240 + p[0] * scale, 240 - p[2] * scale];
        ctx.fillStyle = '#0c1717';
        ctx.fillRect(0, 0, 480, 480);
        ctx.strokeStyle = '#32453e';
        ctx.lineWidth = 1;
        for (const link of city.portals.filter(x => x.kind === 'open')) {
            const a = city.nodes.find(n => n.id === link.a), b = city.nodes.find(n => n.id === link.b);
            if (!a || !b || a.kind !== 'street' || b.kind !== 'street')
                continue;
            ctx.beginPath();
            ctx.moveTo(...map(a.position));
            ctx.lineTo(...map(b.position));
            ctx.stroke();
        }
        ctx.textAlign = 'center';
        ctx.font = '10px monospace';
        for (const b of city.buildings) {
            const [x, y] = map(b.center);
            ctx.fillStyle = data.explored.has(b.id) ? '#83997a' : '#273b33';
            ctx.fillRect(x - b.width / 2 * scale, y - b.depth / 2 * scale, b.width * scale, b.depth * scale);
            ctx.fillStyle = '#cdd9c9';
            ctx.fillText(`${String.fromCharCode(65 + b.lotX)}${b.lotZ + 1}`, x, y + 3);
        }
        const exit = map(city.exit);
        ctx.fillStyle = '#e4b47b';
        ctx.fillRect(exit[0] - 8, exit[1] - 3, 16, 5);
        ctx.fillText('EXIT / N', exit[0], exit[1] - 10);
        const [x, y] = map(data.player);
        ctx.fillStyle = '#e1efd5';
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#e1efd566';
        ctx.beginPath();
        ctx.arc(x, y, 9, 0, Math.PI * 2);
        ctx.stroke();
    }
    play(): void { this.screen = 'play'; this.overlay.hidden = true; this.hud.hidden = false; this.apply(this.settings); }
    apply(s: Settings): void {
        this.settings = s;
        const hints = this.hud.querySelector<HTMLElement>('[data-hud="hints"]');
        if (hints) {
            hints.hidden = !s.hints;
            hints.innerHTML = (['interact', 'crouch', 'flashlight', 'throw', 'journal', 'hints'] as Action[]).map(k => `<span><kbd>${escape(keyLabel(s.bindings[k]))}</kbd> ${k === 'hints' ? 'Hide hints' : k === 'interact' ? 'Use' : k === 'journal' ? 'Map' : k === 'throw' ? 'Bottle' : labels[k].split(' (')[0]}</span>`).join('');
        }
        for (const sel of ['.hud-top', '.meters', '.crosshair']) {
            const node = this.hud.querySelector<HTMLElement>(sel);
            if (node)
                node.hidden = !s.hud;
        }
        if (!s.captions)
            this.el('[data-hud="caption"]').hidden = true;
    }
    update(d: HudData): void {
        const text = (key: string, value: string) => { this.el(`[data-hud="${key}"]`).textContent = value; };
        text('objective', d.phase === 'scavenge' ? `FIND THREE FUSES / ${d.fuses} OF 3` : d.phase === 'powering' ? `STAY ALIVE / GATE POWER IN ${Math.ceil(d.alarm)}s` : d.phase === 'escape' ? 'THE GATE IS OPEN / GO NORTH' : '');
        text('location', d.location);
        text('info', `${this.backend.toUpperCase()} / ${d.fps} FPS\n${d.lights} LOCAL LIGHTS / ${d.decoys} BOTTLES`);
        this.el('[data-hud="info"]').style.whiteSpace = 'pre-line';
        for (const [key, value] of [['battery', d.battery], ['stamina', d.stamina], ['noise', d.noise * 100]] as const) {
            this.el(`[data-hud="${key}"]`).style.width = `${Math.max(0, Math.min(100, value))}%`;
            text(`${key}-text`, `${Math.round(value)}`);
        }
        const prompt = this.el('[data-hud="prompt"]');
        prompt.hidden = !d.prompt;
        prompt.textContent = d.prompt;
        text('state', d.hidden ? (d.breath ? 'HIDDEN / BREATH HELD' : 'HIDDEN / LISTEN') : d.crank ? 'CHARGING / CRANK MAKES NOISE' : '');
        const now = performance.now();
        if (now > this.captionUntil)
            this.el('[data-hud="caption"]').hidden = true;
        if (now > this.toastUntil)
            this.el('[data-hud="toast"]').hidden = true;
    }
    caption(text: string): void { if (!this.settings.captions)
        return; const e = this.el('[data-hud="caption"]'); e.textContent = text; e.hidden = false; this.captionUntil = performance.now() + 2300; }
    toast(text: string, duration = 4): void { const e = this.el('[data-hud="toast"]'); e.textContent = text; e.hidden = false; this.toastUntil = performance.now() + duration * 1000; }
    destroy(): void { this.abort.abort(); this.root.remove(); }
}

