import * as pc from 'playcanvas';
import { add, distance, dot, flatDistance, normalize, rotateXYZ, sub, type V3 } from '../core/math.mjs';
import { Random } from '../core/random.mjs';
import type { NoiseLog } from '../audio/acoustics.mjs';
import { propagateSound } from '../audio/acoustics.mjs';
import { EnemyBrain, type Evidence } from './brain.mjs';
import { fromPc, Resources } from '../render/resources.mjs';
import { locateNode, type NavNode } from '../world/plan.mjs';
import type { Navigation, Route } from '../world/navigation.mjs';
import type { World } from '../world/runtime.mjs';
import type { Player } from '../game/player.mjs';
import type { Session } from '../game/session.mjs';
import type { ObjectSpec } from '../world/geometry.mjs';
interface Enemy {
    id: string;
    body: pc.Entity;
    visual: pc.Entity;
    brain: EnemyBrain;
    rng: Random;
    route: Route | null;
    index: number;
    end: string | null;
    decision: number;
    hum: number;
    heard: Set<number>;
    active: boolean;
}
export class Enemies {
    readonly list: Enemy[] = [];
    constructor(readonly world: World, readonly nav: Navigation, readonly resources: Resources, readonly session: Session, readonly noise: NoiseLog, parent: pc.Entity, readonly onCatch: () => void) {
        const streets = world.city.nodes.filter(n => n.kind === 'street' && distance(n.position, world.city.spawn) > 48);
        const r = new Random(`${world.city.seed}:enemies`);
        for (let i = 0; i < 2; i++) {
            const spawn = r.pick(streets), id = `enemy:${i}`, body = new pc.Entity(id);
            parent.addChild(body);
            body.tags.add('enemy');
            body.setPosition(spawn.position[0], spawn.position[1] + 1.1, spawn.position[2]);
            body.addComponent('collision', { type: 'capsule', radius: .36, height: 2.2 });
            body.addComponent('rigidbody', { type: 'kinematic', mass: 0 });
            const visual = new pc.Entity(`${id}:shape`);
            body.addChild(visual);
            resources.box(visual, `${id}:spine`, [0, 0, 0], [.46, 1.7, .42], 'metal');
            resources.box(visual, `${id}:shoulders`, [0, .52, 0], [.95, .24, .44], 'trim', null, [0, 0, 12]);
            resources.box(visual, `${id}:head`, [0, .92, 0], [.45, .52, .4], 'trim', null, [0, 0, -8]);
            resources.box(visual, `${id}:eye`, [0, .96, -.216], [.26, .035, .035], 'red');
            resources.box(visual, `${id}:shard`, [.42, -.45, 0], [.16, .9, .18], 'metal', null, [0, 0, 18]);
            body.enabled = i === 0;
            this.list.push({ id, body, visual, brain: new EnemyBrain(), rng: new Random(`${world.city.seed}:${id}`), route: null, index: 0, end: null, decision: 0, hum: i + 1, heard: new Set(), active: i === 0 });
        }
    }
    positions(): V3[] { return this.list.filter(e => e.active).map(e => this.feet(e)); }
    private feet(e: Enemy): V3 { const p = fromPc(e.body.getPosition()); p[1] -= 1.1; return p; }
    canSee(e: Enemy, player: Player): boolean {
        if (!e.active || player.hidden)
            return false;
        const origin = add(this.feet(e), [0, 1.8, 0]), target = add(player.position, [0, player.crouched ? .65 : 1.2, 0]), d = distance(origin, target);
        const range = (10 + player.exposure * 18 + (player.lightOn ? 10 : 0)) * (player.crouched ? .72 : 1);
        if (d > range)
            return false;
        if (d > 3 && dot(normalize(sub(target, origin)), fromPc(e.body.forward)) < .24)
            return false;
        return !this.world.ray(origin, target, true, e.body);
    }
    private locker(id: string): ObjectSpec | undefined { for (const g of this.world.geometry.values()) {
        const o = g.objects.find(o => o.id === id && o.kind === 'locker');
        if (o)
            return o;
    } return undefined; }
    private lockerFront(o: ObjectSpec): V3 { return add(o.position, rotateXYZ([0, 0, -1.1], [0, o.yaw, 0])); }
    witnessHide(player: Player, id: string): void {
        const locker = this.locker(id);
        if (!locker)
            return;
        for (const e of this.list)
            if (this.canSee(e, player)) {
                const evidence = { position: this.lockerFront(locker), node: locker.node };
                e.brain.update(0, { sight: evidence, reached: false });
                e.brain.witnessLocker = id;
            }
    }
    update(dt: number, player: Player): void {
        const second = this.list[1]!;
        if (!second.active && (this.session.collected.size >= 2 || this.session.phase !== 'scavenge')) {
            // Do not enable a threat next to the player's current route.
            const far = this.world.city.nodes.filter(node => node.kind === 'street' && distance(node.position, player.position) > 40);
            if (far.length) {
                const spawn = second.rng.pick(far);
                second.body.setPosition(spawn.position[0], spawn.position[1] + 1.1, spawn.position[2]);
            }
            second.active = true;
            second.body.enabled = true;
        }
        for (const e of this.list) {
            if (!e.active)
                continue;
            e.visual.setLocalPosition(0, Math.sin(this.session.time * 2.5 + e.id.length) * .04, 0);
            e.decision -= dt;
            e.hum -= dt;
            if (e.hum <= 0) {
                e.hum = e.brain.state === 'chase' ? 1.4 : 4.5;
                this.world.emit(this.feet(e), e.brain.state === 'chase' ? 65 : 54, 'enemy', e.id);
            }
            if (e.decision <= 0) {
                e.decision = .12;
                const pos = this.feet(e), node = locateNode(this.world.city, pos), sight = this.session.time > 12 && this.canSee(e, player) ? { position: [...player.position] as V3, node: locateNode(this.world.city, player.position).id } : undefined;
                let sound: (Evidence & {
                    strength: number;
                }) | undefined;
                let soundLocker: string | null = null;
                for (const event of this.noise.events) {
                    if (e.heard.has(event.id) || event.source.startsWith('enemy:') || distance(event.position, pos) > 110)
                        continue;
                    const heard = propagateSound(this.nav, event, node.id, pos);
                    if (!heard || this.session.time < event.time + heard.delay)
                        continue;
                    e.heard.add(event.id);
                    if (heard.level > 22 && (!sound || heard.level > sound.strength)) {
                        sound = { position: [...event.position], node: event.node, strength: heard.level };
                        soundLocker = null;
                        // This inference uses the audible event, not the player's live hidden state.
                        if (event.kind === 'breath')
                            for (const g of this.world.geometry.values()) {
                                const o = g.objects.find(o => o.kind === 'locker' && distance(o.position, event.position) < .8);
                                if (o) {
                                    soundLocker = o.id;
                                    break;
                                }
                            }
                    }
                }
                const liveIds = new Set(this.noise.events.map(n => n.id));
                for (const id of e.heard)
                    if (!liveIds.has(id))
                        e.heard.delete(id);
                const goal = e.brain.witnessLocker ? e.brain.target?.position : this.nav.nodes.get(e.brain.target?.node ?? '')?.position;
                const reached = !!goal && !!e.brain.target && (!e.route || e.index >= e.route.nodes.length) && flatDistance(pos, goal) < 1.2;
                const before = e.brain.state;
                e.brain.update(.12, { sight, sound, reached });
                if (sound && (!sight) && (before !== 'chase' || e.brain.unseenTime > 1.5))
                    e.brain.witnessLocker = soundLocker;
                if (e.brain.witnessLocker && !sight) {
                    const locker = this.locker(e.brain.witnessLocker);
                    if (locker)
                        e.brain.setTarget({ position: this.lockerFront(locker), node: locker.node });
                }
                if (!e.brain.target || (reached && e.brain.state !== 'chase' && !e.brain.witnessLocker)) {
                    let next: NavNode;
                    if (e.brain.state === 'search' && e.brain.memory) {
                        const near = this.world.city.nodes.filter(n => distance(n.position, e.brain.memory!.position) < 13 && n.kind !== 'stair');
                        next = e.rng.pick(near.length ? near : [node]);
                    }
                    else {
                        const streets = this.world.city.nodes.filter(n => n.kind === 'street');
                        next = e.rng.pick(streets);
                    }
                    e.brain.setTarget({ position: [...next.position], node: next.id });
                }
                if (e.end !== e.brain.target?.node || before !== e.brain.state || !e.route) {
                    e.end = e.brain.target?.node ?? null;
                    e.route = e.end ? this.nav.route(node.id, e.end) : null;
                    e.index = 0;
                }
            }
            this.move(e, dt, player);
            const close = distance(this.feet(e), player.position) < 1.2;
            if (close && this.session.time > 12 && (!player.hidden || e.brain.witnessLocker === player.hidden.id)) {
                this.onCatch();
                return;
            }
            if (player.hidden && e.brain.witnessLocker === player.hidden.id && distance(this.feet(e), player.hidden.position) < 2.2) {
                this.onCatch();
                return;
            }
        }
    }
    private move(e: Enemy, dt: number, player: Player): void {
        if (!e.route || !e.brain.target)
            return;
        const pos = this.feet(e);
        let target: V3;
        if (e.index >= e.route.nodes.length) {
            if (e.brain.witnessLocker)
                target = e.brain.target.position;
            else if (e.brain.state === 'chase' && this.canSee(e, player) && locateNode(this.world.city, pos).id === locateNode(this.world.city, player.position).id)
                target = [...player.position];
            else
                return;
        }
        else {
            target = this.nav.nodes.get(e.route.nodes[e.index]!)!.position;
            const portal = e.index > 0 ? e.route.portals[e.index - 1] : undefined;
            if (portal?.door && !this.nav.doorOpen.get(portal.door) && distance(pos, portal.position) < 2.5) {
                this.world.setDoor(portal.door, true, false, e.id);
                return;
            }
            if (distance(pos, target) < .35) {
                e.index++;
                return;
            }
        }
        const delta = sub(target, pos), d = distance(target, pos), speed = e.brain.state === 'chase' ? 4.3 : e.brain.state === 'investigate' ? 2.5 : e.brain.state === 'search' ? 1.9 : 1.4, t = Math.min(1, speed * dt / Math.max(.001, d));
        e.body.setPosition(pos[0] + delta[0] * t, pos[1] + delta[1] * t + 1.1, pos[2] + delta[2] * t);
        if (Math.hypot(delta[0], delta[2]) > .01)
            e.body.setEulerAngles(0, Math.atan2(-delta[0], -delta[2]) * 180 / Math.PI, 0);
    }
    destroy(): void { for (const e of this.list)
        e.body.destroy(); this.list.length = 0; }
}

