import type { V3 } from '../core/math.mjs';
export type EnemyState = 'roam' | 'investigate' | 'search' | 'chase';
export interface Evidence {
    position: V3;
    node: string;
}
export interface Perception {
    sight?: Evidence;
    sound?: Evidence & {
        strength: number;
    };
    reached: boolean;
}
/** No player reference is allowed here. The brain only knows supplied evidence. */
export class EnemyBrain {
    state: EnemyState = 'roam';
    target: Evidence | null = null;
    memory: Evidence | null = null;
    stateTime = 0;
    unseenTime = 0;
    witnessLocker: string | null = null;
    update(dt: number, input: Perception): void {
        this.stateTime += dt;
        if (input.sight) {
            this.target = copy(input.sight);
            this.memory = copy(input.sight);
            this.unseenTime = 0;
            if (this.state !== 'chase')
                this.change('chase');
            return;
        }
        this.unseenTime += dt;
        if (input.sound && (this.state !== 'chase' || this.unseenTime > 1.5)) {
            this.target = copy(input.sound);
            this.memory = copy(input.sound);
            if (this.state !== 'investigate')
                this.change('investigate');
        }
        if (this.state === 'chase' && this.unseenTime > 3.5) {
            this.target = this.memory ? copy(this.memory) : null;
            this.change('investigate');
        }
        else if (this.state === 'investigate' && input.reached) {
            this.change('search');
            this.target = null;
        }
        else if (this.state === 'search' && this.stateTime > 13) {
            this.change('roam');
            this.target = null;
            this.witnessLocker = null;
        }
    }
    setTarget(target: Evidence): void { this.target = copy(target); }
    private change(state: EnemyState): void { this.state = state; this.stateTime = 0; }
}
function copy(value: Evidence): Evidence { return { node: value.node, position: [...value.position] }; }

