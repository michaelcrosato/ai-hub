import { clamp } from './math.mjs';
export const GENERATOR_VERSION = 1;
export const ENGINE_VERSION = '2.21.4';
export const FLOOR_HEIGHT = 3.4;
export const GROUND_Y = 0.12;
export const LOT_SPACING = 34;
export type Quality = 'low' | 'medium' | 'high' | 'ultra';
export interface RenderPreset {
    shadowLights: number;
    atlas: number;
    cascades: number;
    shadowDistance: number;
    loadRadius: number;
    unloadRadius: number;
    ssaoSamples: number;
    fogSteps: number;
}
export const PRESETS: Record<Quality, RenderPreset> = {
    low: { shadowLights: 3, atlas: 2048, cascades: 1, shadowDistance: 45, loadRadius: 48, unloadRadius: 60, ssaoSamples: 8, fogSteps: 8 },
    medium: { shadowLights: 6, atlas: 2048, cascades: 2, shadowDistance: 65, loadRadius: 58, unloadRadius: 72, ssaoSamples: 8, fogSteps: 12 },
    high: { shadowLights: 10, atlas: 4096, cascades: 3, shadowDistance: 85, loadRadius: 66, unloadRadius: 82, ssaoSamples: 12, fogSteps: 16 },
    ultra: { shadowLights: 16, atlas: 4096, cascades: 4, shadowDistance: 100, loadRadius: 75, unloadRadius: 92, ssaoSamples: 16, fogSteps: 24 }
};
export const DEFAULT_BINDINGS = {
    forward: 'KeyW', back: 'KeyS', left: 'KeyA', right: 'KeyD', interact: 'KeyE',
    sprint: 'ShiftLeft', crouch: 'KeyC', flashlight: 'KeyF', throw: 'KeyG',
    crank: 'KeyR', breath: 'Space', journal: 'Tab', hints: 'KeyH'
} as const;
export type Action = keyof typeof DEFAULT_BINDINGS;
export interface Settings {
    quality: Quality;
    resolution: number;
    fov: number;
    sensitivity: number;
    invertY: boolean;
    volume: number;
    range: 'full' | 'night';
    captions: boolean;
    hints: boolean;
    hud: boolean;
    bloom: boolean;
    ssao: boolean;
    taa: boolean;
    volumetric: boolean;
    pcss: boolean;
    headBob: boolean;
    flicker: boolean;
    bindings: Record<Action, string>;
}
export const DEFAULT_SETTINGS: Settings = {
    quality: 'high', resolution: 1, fov: 82, sensitivity: 0.12, invertY: false,
    volume: 0.65, range: 'full', captions: true, hints: true, hud: true,
    bloom: true, ssao: true, taa: true, volumetric: false, pcss: false,
    headBob: false, flicker: false, bindings: { ...DEFAULT_BINDINGS }
};
export function validateSettings(input: unknown): Settings {
    const out: Settings = { ...DEFAULT_SETTINGS, bindings: { ...DEFAULT_BINDINGS } };
    if (!input || typeof input !== 'object')
        return out;
    const x = input as Record<string, unknown>;
    if (typeof x.quality === 'string' && Object.hasOwn(PRESETS, x.quality))
        out.quality = x.quality as Quality;
    for (const [key, min, max] of [['resolution', 0.5, 1], ['fov', 60, 110], ['sensitivity', 0.025, 0.5], ['volume', 0, 1]] as const) {
        if (typeof x[key] === 'number' && Number.isFinite(x[key]))
            out[key] = clamp(x[key] as number, min, max);
    }
    for (const key of ['invertY', 'captions', 'hints', 'hud', 'bloom', 'ssao', 'taa', 'volumetric', 'pcss', 'headBob', 'flicker'] as const)
        if (typeof x[key] === 'boolean')
            out[key] = x[key];
    if (x.range === 'night')
        out.range = 'night';
    if (x.bindings && typeof x.bindings === 'object') {
        const b = x.bindings as Record<string, unknown>;
        const used = new Set<string>();
        for (const key of Object.keys(DEFAULT_BINDINGS) as Action[]) {
            const candidate = b[key];
            if (typeof candidate === 'string' && /^(Key[A-Z]|Digit[0-9]|ShiftLeft|ControlLeft|AltLeft|Space|Tab|Arrow(Up|Down|Left|Right))$/.test(candidate) && !used.has(candidate)) {
                out.bindings[key] = candidate;
                used.add(candidate);
            }
        }
        // Reject a conflicting set as a whole. Every action must remain available.
        if (new Set(Object.values(out.bindings)).size !== Object.keys(out.bindings).length)
            out.bindings = { ...DEFAULT_BINDINGS };
    }
    return out;
}
export const keyLabel = (code: string): string => code.replace(/^Key/, '').replace(/^Digit/, '').replace('ShiftLeft', 'Shift').replace('ControlLeft', 'Ctrl').replace('AltLeft', 'Alt');

