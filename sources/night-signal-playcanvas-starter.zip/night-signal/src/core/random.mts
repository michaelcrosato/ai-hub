/** Stable seed hashing. Do not use Math.random for world data. */
export function hashSeed(text: string): number {
    let hash = 2166136261;
    for (let i = 0; i < text.length; i++)
        hash = Math.imul(hash ^ text.charCodeAt(i), 16777619);
    return hash >>> 0;
}
export class Random {
    private state: number;
    constructor(seed: string | number) { this.state = typeof seed === 'string' ? hashSeed(seed) : seed >>> 0; }
    next(): number {
        let t = this.state += 0x6D2B79F5;
        t = Math.imul(t ^ (t >>> 15), t | 1);
        t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
        return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    }
    int(min: number, max: number): number { return min + Math.floor(this.next() * (max - min + 1)); }
    range(min: number, max: number): number { return min + (max - min) * this.next(); }
    chance(p: number): boolean { return this.next() < p; }
    pick<T>(values: readonly T[]): T {
        if (!values.length)
            throw new Error('Cannot select from an empty list.');
        return values[this.int(0, values.length - 1)]!;
    }
    shuffle<T>(values: readonly T[]): T[] {
        const a = [...values];
        for (let i = a.length - 1; i > 0; i--) {
            const j = this.int(0, i);
            [a[i], a[j]] = [a[j]!, a[i]!];
        }
        return a;
    }
}

