import type { V3 } from './math.mjs';
export type SoundKind = 'step' | 'door' | 'impact' | 'glass' | 'radio' | 'breath' | 'crank' | 'enemy' | 'alarm' | 'pickup';
export interface NoiseEvent {
    id: number;
    time: number;
    position: V3;
    node: string;
    level: number;
    kind: SoundKind;
    source: string;
    surface?: string;
}
export interface GameEvents {
    noise: NoiseEvent;
    message: {
        text: string;
        duration?: number;
    };
    collected: {
        id: string;
        total: number;
    };
    phase: {
        value: string;
    };
    door: {
        id: string;
        open: boolean;
    };
}
export class EventBus<Events extends object> {
    private readonly listeners = new Map<keyof Events, Set<(value: never) => void>>();
    on<K extends keyof Events>(key: K, callback: (value: Events[K]) => void): () => void {
        let set = this.listeners.get(key);
        if (!set)
            this.listeners.set(key, set = new Set());
        set.add(callback as (value: never) => void);
        return () => { set!.delete(callback as (value: never) => void); };
    }
    emit<K extends keyof Events>(key: K, value: Events[K]): void {
        for (const callback of [...(this.listeners.get(key) ?? [])])
            callback(value as never);
    }
    clear(): void { this.listeners.clear(); }
}

