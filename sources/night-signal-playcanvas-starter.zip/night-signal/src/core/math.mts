export type V3 = [
    number,
    number,
    number
];
export const v3 = (x = 0, y = 0, z = 0): V3 => [x, y, z];
export const add = (a: V3, b: V3): V3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
export const sub = (a: V3, b: V3): V3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
export const scale = (a: V3, s: number): V3 => [a[0] * s, a[1] * s, a[2] * s];
export const dot = (a: V3, b: V3): number => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
export const length = (a: V3): number => Math.hypot(...a);
export const distance = (a: V3, b: V3): number => length(sub(a, b));
export const flatDistance = (a: V3, b: V3): number => Math.hypot(a[0] - b[0], a[2] - b[2]);
export const normalize = (a: V3): V3 => scale(a, 1 / (length(a) || 1));
export const clamp = (n: number, min: number, max: number): number => Math.max(min, Math.min(max, n));
export const lerp = (a: number, b: number, t: number): number => a + (b - a) * t;
export const approach = (a: number, b: number, amount: number): number => a < b ? Math.min(a + amount, b) : Math.max(a - amount, b);
export const radians = (degrees: number): number => degrees * Math.PI / 180;
export const degrees = (radians: number): number => radians * 180 / Math.PI;
export const finiteV3 = (x: unknown): x is V3 => Array.isArray(x) && x.length === 3 && x.every(Number.isFinite);
export function rotateXYZ(p: V3, angles: V3): V3 {
    const [x, y, z] = angles.map(radians) as V3;
    let a = p[0], b = p[1] * Math.cos(x) - p[2] * Math.sin(x), c = p[1] * Math.sin(x) + p[2] * Math.cos(x);
    [a, c] = [a * Math.cos(y) + c * Math.sin(y), -a * Math.sin(y) + c * Math.cos(y)];
    return [a * Math.cos(z) - b * Math.sin(z), a * Math.sin(z) + b * Math.cos(z), c];
}
export function closestOnSegment(p: V3, a: V3, b: V3): V3 {
    const d = sub(b, a);
    return add(a, scale(d, clamp(dot(sub(p, a), d) / (dot(d, d) || 1), 0, 1)));
}

