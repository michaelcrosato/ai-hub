import { FLOOR_HEIGHT, GENERATOR_VERSION, GROUND_Y, LOT_SPACING } from '../core/config.mjs';
import { distance, type V3 } from '../core/math.mjs';
import { hashSeed, Random } from '../core/random.mjs';
export type RoomKind = 'apartment' | 'office' | 'workshop';
export interface NavNode {
    id: string;
    position: V3;
    building?: string;
    floor?: number;
    room?: string;
    kind: 'street' | 'hall' | 'room' | 'stair';
}
export interface Portal {
    id: string;
    a: string;
    b: string;
    position: V3;
    kind: 'open' | 'door' | 'window' | 'stair';
    walk: boolean;
    door?: string;
}
export interface RoomPlan {
    id: string;
    floor: number;
    side: -1 | 1;
    half: -1 | 1;
    center: V3;
    size: V3;
    node: string;
    door: string;
    kind: RoomKind;
}
export interface DoorPlan {
    id: string;
    position: V3;
    yaw: number;
    width: number;
    nodeA: string;
    nodeB: string;
}
export interface BuildingPlan {
    id: string;
    lotX: number;
    lotZ: number;
    center: V3;
    width: number;
    depth: number;
    floors: number;
    kind: RoomKind;
    tint: number;
    rooms: RoomPlan[];
    doors: DoorPlan[];
    stairX: number;
    stairStart: number;
    stairEnd: number;
}
export interface FusePlan {
    id: string;
    building: string;
    room: string;
    node: string;
    position: V3;
}
export interface CityPlan {
    version: number;
    seed: string;
    size: number;
    spacing: number;
    extent: number;
    buildings: BuildingPlan[];
    nodes: NavNode[];
    portals: Portal[];
    fuses: FusePlan[];
    spawn: V3;
    exit: V3;
    exitNode: string;
    fingerprint: string;
}
export function createCity(seedInput: string, size = 5): CityPlan {
    const seed = seedInput.trim().slice(0, 80) || 'NIGHT-001';
    if (![3, 5, 7].includes(size))
        throw new Error('City size must be 3, 5, or 7.');
    const rng = new Random(`${seed}:city:v${GENERATOR_VERSION}`), spacing = LOT_SPACING, mid = (size - 1) / 2;
    const nodes: NavNode[] = [], portals: Portal[] = [], buildings: BuildingPlan[] = [];
    const node = (id: string, position: V3, extra: Partial<NavNode> = {}): string => { nodes.push({ id, position, kind: 'street', ...extra }); return id; };
    const edge = (a: string, b: string, position: V3, kind: Portal['kind'] = 'open', door?: string): void => { portals.push({ id: `p:${a}:${b}`, a, b, position, kind, walk: kind !== 'window', ...(door ? { door } : {}) }); };
    const corner = (x: number, z: number): string => `road:${x}:${z}`;
    const roadPos = (x: number, z: number): V3 => [(x - mid - .5) * spacing, GROUND_Y, (z - mid - .5) * spacing];
    for (let z = 0; z <= size; z++)
        for (let x = 0; x <= size; x++)
            node(corner(x, z), roadPos(x, z));
    for (let z = 0; z <= size; z++)
        for (let x = 0; x < size; x++) {
            const p = roadPos(x, z);
            p[0] += spacing / 2;
            const id = node(`road-mid:${x}:${z}`, p);
            edge(corner(x, z), id, p);
            edge(id, corner(x + 1, z), p);
        }
    for (let z = 0; z < size; z++)
        for (let x = 0; x <= size; x++)
            edge(corner(x, z), corner(x, z + 1), roadPos(x, z));
    for (let z = 0; z < size; z++)
        for (let x = 0; x < size; x++) {
            // Keep the centre square clear. Other empty lots vary with the seed.
            if ((x === mid && z === mid) || (rng.chance(.09) && !(x === 0 && z === 0)))
                continue;
            const id = `b:${x}:${z}`, r = new Random(`${seed}:${id}:v${GENERATOR_VERSION}`);
            const cx = (x - mid) * spacing, cz = (z - mid) * spacing;
            const w = r.pick([17, 18, 19]), d = r.pick([19, 20, 21]), floors = r.int(2, 4);
            const kind = r.pick<RoomKind>(['apartment', 'office', 'workshop']);
            const b: BuildingPlan = { id, lotX: x, lotZ: z, center: [cx, GROUND_Y, cz], width: w, depth: d, floors, kind, tint: r.int(0, 3), rooms: [], doors: [], stairX: cx + w / 2 - 1.7, stairStart: cz - d / 2 + 2, stairEnd: cz + d / 2 - 2 };
            const frontId = `road-mid:${x}:${z}`, backId = `road-mid:${x}:${z + 1}`;
            for (let f = 0; f < floors; f++) {
                const fy = GROUND_Y + f * FLOOR_HEIGHT;
                const rowZ = [-d / 2 + 1, -(d / 2 - 3) / 2, 0, (d / 2 - 3) / 2, d / 2 - 1];
                const hall: string[] = [];
                rowZ.forEach((zz, i) => hall.push(node(`${id}:f${f}:h${i}`, [cx, fy, cz + zz], { building: id, floor: f, kind: 'hall' })));
                for (let i = 0; i < hall.length - 1; i++)
                    edge(hall[i]!, hall[i + 1]!, [cx, fy, cz + rowZ[i]!]);
                if (f === 0) {
                    const doorId = `${id}:entry`;
                    b.doors.push({ id: doorId, position: [cx, fy, cz - d / 2], yaw: 0, width: 2, nodeA: frontId, nodeB: hall[0]! });
                    edge(frontId, hall[0]!, [cx, fy, cz - d / 2], 'door', doorId);
                }
                for (const side of [-1, 1] as const)
                    for (const half of [-1, 1] as const) {
                        const minX = side === -1 ? cx - w / 2 + .35 : cx + 1.65;
                        const maxX = side === -1 ? cx - 1.65 : cx + w / 2 - 3.4;
                        const z0 = half === -1 ? cz - d / 2 + 3 : cz + .1;
                        const z1 = half === -1 ? cz - .1 : cz + d / 2 - 3;
                        const roomId = `${id}:f${f}:r${side}:${half}`, center: V3 = [(minX + maxX) / 2, fy, (z0 + z1) / 2];
                        const roomNode = node(`${roomId}:node`, center, { building: id, floor: f, room: roomId, kind: 'room' });
                        const hallNode = hall[half === -1 ? 1 : 3]!;
                        const doorId = `${roomId}:door`, doorPos: V3 = [cx + side * 1.65, fy, center[2]];
                        b.rooms.push({ id: roomId, floor: f, side, half, center, size: [maxX - minX, FLOOR_HEIGHT, z1 - z0], node: roomNode, door: doorId, kind });
                        b.doors.push({ id: doorId, position: doorPos, yaw: 90, width: 1.65, nodeA: hallNode, nodeB: roomNode });
                        edge(hallNode, roomNode, doorPos, 'door', doorId);
                        edge(roomNode, half === -1 ? frontId : backId, [side === -1 ? cx - w / 2 : cx + w / 2, fy + 1.5, center[2]], 'window');
                    }
                if (f < floors - 1) {
                    const a = node(`${id}:f${f}:stair-a`, [b.stairX, fy, b.stairStart - .35], { building: id, floor: f, kind: 'stair' });
                    const e = node(`${id}:f${f}:stair-b`, [b.stairX, fy + FLOOR_HEIGHT, b.stairEnd + .35], { building: id, floor: f + 1, kind: 'stair' });
                    edge(hall[0]!, a, [b.stairX, fy, b.stairStart - .35]);
                    edge(a, e, [b.stairX, fy + FLOOR_HEIGHT / 2, cz], 'stair');
                    edge(e, `${id}:f${f + 1}:h4`, [b.stairX, fy + FLOOR_HEIGHT, b.stairEnd + .35]);
                }
            }
            buildings.push(b);
        }
    const selected = rng.shuffle(buildings).slice(0, 3);
    const fuses: FusePlan[] = selected.map((b, i) => {
        const upper = b.rooms.filter(room => room.floor > 0);
        const room = rng.pick(upper), [x, y, z] = room.center;
        return { id: `fuse:${i}`, building: b.id, room: room.id, node: room.node, position: [x + room.side * .8, y + .95, z + room.half * 1.1] };
    });
    const spawn: V3 = [0, GROUND_Y, -(size / 2) * spacing];
    const exitNode = `road-mid:${Math.floor(size / 2)}:${size}`;
    const exit: V3 = [0, GROUND_Y, (size / 2) * spacing];
    const fingerprint = hashSeed(JSON.stringify({ version: GENERATOR_VERSION, seed, size, buildings, fuses })).toString(16).padStart(8, '0');
    return { version: GENERATOR_VERSION, seed, size, spacing, extent: size / 2 * spacing + 8, buildings, nodes, portals, fuses, spawn, exit, exitNode, fingerprint };
}
export function buildingAt(city: CityPlan, position: V3): BuildingPlan | undefined {
    return city.buildings.find(b => Math.abs(position[0] - b.center[0]) < b.width / 2 && Math.abs(position[2] - b.center[2]) < b.depth / 2 && position[1] < GROUND_Y + b.floors * FLOOR_HEIGHT);
}
export function locateNode(city: CityPlan, position: V3): NavNode {
    const b = buildingAt(city, position);
    let pool: NavNode[];
    if (b) {
        const floor = Math.max(0, Math.min(b.floors - 1, Math.floor((position[1] - GROUND_Y + .2) / FLOOR_HEIGHT)));
        const room = b.rooms.find(r => r.floor === floor && Math.abs(position[0] - r.center[0]) < r.size[0] / 2 && Math.abs(position[2] - r.center[2]) < r.size[2] / 2);
        pool = room ? city.nodes.filter(n => n.id === room.node) : city.nodes.filter(n => n.building === b.id && n.floor === floor && n.kind !== 'room');
    }
    else
        pool = city.nodes.filter(n => n.kind === 'street');
    if (!pool.length)
        pool = city.nodes;
    return pool.reduce((a, n) => distance(a.position, position) < distance(n.position, position) ? a : n);
}
export function validateCity(city: CityPlan): string[] {
    const errors: string[] = [], ids = new Set<string>();
    for (const n of city.nodes) {
        if (ids.has(n.id))
            errors.push(`Duplicate node: ${n.id}`);
        ids.add(n.id);
    }
    const adjacency = new Map<string, string[]>();
    for (const p of city.portals) {
        if (!ids.has(p.a) || !ids.has(p.b))
            errors.push(`Missing portal endpoint: ${p.id}`);
        if (p.walk) {
            adjacency.set(p.a, [...(adjacency.get(p.a) ?? []), p.b]);
            adjacency.set(p.b, [...(adjacency.get(p.b) ?? []), p.a]);
        }
    }
    const seen = new Set<string>(), queue = [city.exitNode];
    for (let i = 0; i < queue.length; i++) {
        const n = queue[i]!;
        if (seen.has(n))
            continue;
        seen.add(n);
        queue.push(...(adjacency.get(n) ?? []).filter(x => !seen.has(x)));
    }
    for (const n of city.nodes)
        if (!seen.has(n.id))
            errors.push(`No exit route: ${n.id}`);
    if (city.fuses.length !== 3 || new Set(city.fuses.map(f => f.building)).size !== 3)
        errors.push('Fuses need three separate buildings.');
    for (const b of city.buildings) {
        if (b.floors < 2)
            errors.push(`Missing upper floor: ${b.id}`);
        if (!b.doors.some(d => d.id === `${b.id}:entry`))
            errors.push(`Missing entry: ${b.id}`);
    }
    return errors;
}

