import * as pc from 'playcanvas';
import { GROUND_Y, PRESETS, type Settings } from '../core/config.mjs';
import { add, approach, clamp, distance, flatDistance, rotateXYZ, type V3 } from '../core/math.mjs';
import type { SoundKind } from '../core/events.mjs';
import type { PropState } from '../game/session.mjs';
import { Resources, fromPc, toPc } from '../render/resources.mjs';
import type { Lighting } from '../render/lighting.mjs';
import { createBuildingGeometry, type BoxSpec, type BuildingGeometry, type ObjectSpec } from './geometry.mjs';
import { buildingAt, locateNode, type BuildingPlan, type CityPlan, type DoorPlan } from './plan.mjs';
import type { Navigation } from './navigation.mjs';
export type EmitNoise = (position: V3, level: number, kind: SoundKind, source: string, surface?: string) => void;
export interface Interactable {
    id: string;
    kind: 'door' | 'locker' | 'radio' | 'prop' | 'fuse' | 'exit';
    entity: pc.Entity;
    node: string;
    object?: ObjectSpec;
}
interface DoorInstance {
    spec: DoorPlan;
    root: pc.Entity;
    panel: pc.Entity;
    angle: number;
    target: number;
    speed: number;
}
interface Chunk {
    building: BuildingPlan;
    root: pc.Entity;
    lights: string[];
    bodies: pc.Entity[];
    interactions: pc.Entity[];
}
export interface RayHit {
    entity: pc.Entity;
    point: pc.Vec3;
    normal: pc.Vec3;
}
export class World {
    readonly root: pc.Entity;
    readonly interactions = new Map<pc.Entity, Interactable>();
    readonly chunks = new Map<string, Chunk>();
    readonly doorState = new Map<string, boolean>();
    readonly propState = new Map<string, PropState>();
    readonly radios = new Map<string, boolean>();
    readonly activeDoors = new Map<string, DoorInstance>();
    readonly objects = new Map<string, pc.Entity>();
    readonly geometry = new Map<string, BuildingGeometry>();
    readonly gate: pc.Entity;
    private time = 0;
    private streamTimer = 0;
    private radioTimer = 0;
    private protectedPositions: V3[] = [];
    private readonly ephemeral: {
        entity: pc.Entity;
        expires: number;
    }[] = [];
    constructor(readonly app: pc.AppBase, readonly city: CityPlan, readonly nav: Navigation, readonly resources: Resources, readonly lighting: Lighting, readonly collected: Set<string>, readonly emit: EmitNoise, parent: pc.Entity) {
        this.root = new pc.Entity('Streamed city');
        parent.addChild(this.root);
        resources.box(this.root, 'Ground', [0, GROUND_Y - .2, 0], [city.extent * 2, .4, city.extent * 2], 'road', 'static');
        const streetBoxes: BoxSpec[] = [];
        let serial = 0;
        const box = (position: V3, size: V3, material: BoxSpec['material'], solid = false): void => { const b: BoxSpec = { id: `street:${serial++}`, position, size, material, shell: true, solid, angles: [0, 0, 0] }; streetBoxes.push(b); if (solid)
            resources.solid(this.root, b); };
        for (let z = 0; z < city.size; z++)
            for (let x = 0; x < city.size; x++) {
                const cx = (x - (city.size - 1) / 2) * city.spacing, cz = (z - (city.size - 1) / 2) * city.spacing;
                box([cx, GROUND_Y - .005, cz], [city.spacing - 11, .012, city.spacing - 11], 'concrete');
                for (const sign of [-1, 1])
                    box([cx, GROUND_Y + .014, cz + sign * city.spacing / 2], [5, .016, .12], 'paint');
                if ((x + z) % 2 === 0) {
                    const px = cx + 12.8, pz = cz - 12.8;
                    box([px, GROUND_Y + 2.8, pz], [.14, 5.6, .14], 'metal', true);
                    box([px, GROUND_Y + 5.5, pz + .5], [.5, .15, 1.1], 'emissive');
                    lighting.add({ id: `street-light:${x}:${z}`, position: [px, GROUND_Y + 5.4, pz + .55], warm: true, intensity: 3, range: 16 }, this.root);
                }
                if ((x * 3 + z) % 3 === 0) {
                    box([cx - 9, GROUND_Y + .58, cz - 12.5], [3.4, 1.15, 1.65], 'metal', true);
                    box([cx - 9, GROUND_Y + 1.38, cz - 12.5], [1.9, .68, 1.4], 'trim', true);
                }
            }
        for (const side of [-1, 1]) {
            box([side * city.extent, 4, 0], [.6, 8, city.extent * 2], 'concrete', true);
            box([0, 4, side * city.extent], [city.extent * 2, 8, .6], 'concrete', true);
        }
        resources.batch(this.root, 'Road furniture', streetBoxes);
        for (const b of city.buildings) {
            const geo = createBuildingGeometry(city, b);
            this.geometry.set(b.id, geo);
            resources.batch(this.root, `${b.id}:shell`, geo.boxes.filter(x => x.shell));
            resources.sign(this.root, `${String.fromCharCode(65 + b.lotX)}${b.lotZ + 1} / ${b.kind.toUpperCase()}`, [b.center[0], GROUND_Y + 2.94, b.center[2] - b.depth / 2 - .18]);
            for (const d of b.doors) {
                this.doorState.set(d.id, false);
                nav.doorOpen.set(d.id, false);
            }
        }
        const ez = city.exit[2] + 2;
        // The only path to the escape yard is through the powered gate.
        // Join both gate posts to the city wall so the player cannot walk around it.
        for (const side of [-1, 1]) {
            const width = city.extent - 3.9;
            resources.box(this.root, `Exit barrier:${side}`, [side * (3.9 + width / 2), GROUND_Y + 2.5, ez], [width, 5, .6], 'concrete', 'static');
        }
        resources.box(this.root, 'Gate left', [-3.6, GROUND_Y + 2.5, ez], [.6, 5, 1], 'concrete', 'static');
        resources.box(this.root, 'Gate right', [3.6, GROUND_Y + 2.5, ez], [.6, 5, 1], 'concrete', 'static');
        resources.box(this.root, 'Gate beam', [0, GROUND_Y + 5, ez], [7.8, .6, 1], 'concrete', 'static');
        this.gate = resources.box(this.root, 'Escape gate', [0, GROUND_Y + 2.3, ez], [6.6, 4.6, .35], 'metal', 'kinematic');
        resources.sign(this.root, 'NORTH EXIT', [0, GROUND_Y + 4.45, ez - .24], 4, .5);
        const control = resources.box(this.root, 'Exit switch', [-4.8, GROUND_Y + 1.05, ez - .8], [.55, 1.5, .45], 'red', 'static');
        this.interactions.set(control, { id: 'exit', kind: 'exit', entity: control, node: city.exitNode });
        resources.sign(this.root, 'POWER / 3 FUSES', [-4.8, GROUND_Y + 2, ez - 1.04], 2, .4);
        lighting.add({ id: 'exit-light', position: [0, GROUND_Y + 4.7, ez - 2], warm: false, intensity: 4, range: 18 }, this.root);
    }
    prime(position: V3): void {
        const nearest = [...this.city.buildings].sort((a, b) => flatDistance(a.center, position) - flatDistance(b.center, position)).slice(0, 2);
        for (const b of nearest)
            this.load(b);
    }
    update(dt: number, position: V3, settings: Settings, pins: V3[], gateOpen: boolean): void {
        this.time += dt;
        this.protectedPositions = [position, ...pins];
        this.streamTimer -= dt;
        const p = PRESETS[settings.quality];
        if (this.streamTimer <= 0) {
            this.streamTimer = .12;
            const mustKeep = new Set(pins.map(x => buildingAt(this.city, x)?.id).filter((x): x is string => !!x));
            const candidates = this.city.buildings.filter(b => !this.chunks.has(b.id) && (flatDistance(b.center, position) < p.loadRadius || mustKeep.has(b.id))).sort((a, b) => flatDistance(a.center, position) - flatDistance(b.center, position));
            if (candidates[0])
                this.load(candidates[0]);
            for (const [id, c] of this.chunks)
                if (flatDistance(c.building.center, position) > p.unloadRadius && !mustKeep.has(id) && !c.bodies.some(e => flatDistance(fromPc(e.getPosition()), position) < 10))
                    this.unload(id);
        }
        for (const d of this.activeDoors.values()) {
            const next = approach(d.angle, d.target, d.speed * dt);
            if (next !== d.angle) {
                d.angle = next;
                d.root.setLocalEulerAngles(0, d.spec.yaw + d.angle, 0);
                this.nav.doorOpen.set(d.spec.id, d.angle > 72);
            }
        }
        const gp = this.gate.getPosition();
        this.gate.setPosition(gp.x, approach(gp.y, GROUND_Y + 2.3 + (gateOpen ? 4.7 : 0), dt * 1.2), gp.z);
        this.radioTimer -= dt;
        if (this.radioTimer <= 0) {
            this.radioTimer = 2.2;
            for (const [id, on] of this.radios)
                if (on) {
                    const e = this.objects.get(id);
                    if (e)
                        this.emit(fromPc(e.getPosition()), 68, 'radio', id);
                }
        }
        for (let i = this.ephemeral.length - 1; i >= 0; i--)
            if (this.ephemeral[i]!.expires < this.time) {
                const e = this.ephemeral[i]!.entity;
                this.interactions.delete(e);
                e.destroy();
                this.ephemeral.splice(i, 1);
            }
    }
    load(b: BuildingPlan): void {
        if (this.chunks.has(b.id))
            return;
        const geo = this.geometry.get(b.id)!;
        const root = new pc.Entity(`${b.id}:detail`);
        this.root.addChild(root);
        const chunk: Chunk = { building: b, root, lights: [], bodies: [], interactions: [] };
        this.chunks.set(b.id, chunk);
        this.resources.batch(root, 'Interior', geo.boxes.filter(x => !x.shell));
        for (const spec of geo.boxes)
            if (spec.solid)
                this.resources.solid(root, spec);
        for (const spec of geo.lights) {
            this.lighting.add(spec, root);
            chunk.lights.push(spec.id);
        }
        for (const spec of b.doors)
            this.makeDoor(spec, chunk);
        for (const spec of geo.objects)
            this.makeObject(spec, chunk);
        for (const fuse of this.city.fuses.filter(f => f.building === b.id && !this.collected.has(f.id))) {
            const e = this.resources.box(root, fuse.id, fuse.position, [.17, .27, .17], 'emissive', 'static');
            this.register(e, { id: fuse.id, kind: 'fuse', entity: e, node: fuse.node }, chunk);
            this.objects.set(fuse.id, e);
        }
    }
    private register(e: pc.Entity, item: Interactable, chunk: Chunk): void { this.interactions.set(e, item); chunk.interactions.push(e); }
    private makeDoor(spec: DoorPlan, c: Chunk): void {
        const root = new pc.Entity(`${spec.id}:hinge`);
        c.root.addChild(root);
        root.setPosition(...add(spec.position, rotateXYZ([-spec.width / 2, 0, 0], [0, spec.yaw, 0])));
        const open = this.doorState.get(spec.id) ?? false;
        root.setEulerAngles(0, spec.yaw + (open ? 100 : 0), 0);
        const panel = this.resources.box(root, spec.id, [spec.width / 2, 1.28, 0], [spec.width - .07, 2.56, .13], 'wood', 'kinematic');
        this.resources.box(panel, `${spec.id}:handle`, [spec.width * .32, 0, -.09], [.09, .06, .07], 'metal');
        this.activeDoors.set(spec.id, { spec, root, panel, angle: open ? 100 : 0, target: open ? 100 : 0, speed: 140 });
        this.nav.doorOpen.set(spec.id, open);
        this.register(panel, { id: spec.id, kind: 'door', entity: panel, node: spec.nodeB }, c);
    }
    private makeObject(o: ObjectSpec, c: Chunk): void {
        if (o.kind === 'locker') {
            const root = new pc.Entity(o.id);
            c.root.addChild(root);
            root.setPosition(...o.position);
            root.setEulerAngles(0, o.yaw, 0);
            const pieces: {
                pos: V3;
                size: V3;
            }[] = [
                { pos: [-.57, 1.075, 0], size: [.10, 2.15, 1] }, { pos: [.57, 1.075, 0], size: [.10, 2.15, 1] },
                { pos: [0, 1.075, .46], size: [1.15, 2.15, .08] }, { pos: [0, 2.10, 0], size: [1.15, .10, 1] },
                { pos: [0, .71, -.46], size: [1.05, 1.42, .08] }, { pos: [0, 1.925, -.46], size: [1.05, .45, .08] }
            ];
            for (let i = 0; i < pieces.length; i++) {
                const p = pieces[i]!, e = this.resources.box(root, `${o.id}:part${i}`, p.pos, p.size, 'metal', 'static');
                this.register(e, { id: o.id, kind: 'locker', entity: root, node: o.node, object: o }, c);
            }
            this.objects.set(o.id, root);
            return;
        }
        const dynamic = o.kind === 'prop', e = this.resources.box(c.root, o.id, o.position, o.size, o.kind === 'radio' ? 'trim' : o.kind === 'table' ? 'wood' : 'metal', dynamic ? 'dynamic' : 'static', [0, o.yaw, 0]);
        this.objects.set(o.id, e);
        if (o.kind === 'prop') {
            const saved = this.propState.get(o.id);
            if (saved)
                e.rigidbody!.teleport(toPc(saved.position), new pc.Quat(...saved.rotation));
            c.bodies.push(e);
            this.impactSound(e, o.id);
            this.register(e, { id: o.id, kind: 'prop', entity: e, node: o.node, object: o }, c);
        }
        else if (o.kind === 'radio') {
            this.register(e, { id: o.id, kind: 'radio', entity: e, node: o.node, object: o }, c);
            this.resources.box(e, `${o.id}:dial`, [0, .02, -.1], [.15, .08, .018], 'emissive');
        }
    }
    private impactSound(e: pc.Entity, id: string, settleDelay = .4): void {
        let last = -10;
        const born = this.time;
        e.collision!.on('collisionstart', (result: {
            contacts?: {
                impulse?: number;
            }[];
        }) => {
            const impulse = (result.contacts ?? []).reduce((sum, p) => sum + Math.max(0, p.impulse ?? 0), 0);
            const speed = Math.max(e.rigidbody!.linearVelocity.length(), impulse / Math.max(.1, e.rigidbody!.mass));
            if (this.time - born >= settleDelay && this.time - last > .35 && speed > .45) {
                last = this.time;
                this.emit(fromPc(e.getPosition()), clamp(53 + 18 * Math.log10(Math.max(.2, speed)), 40, 82), 'impact', id, id.startsWith('decoy:') ? 'glass' : 'metal');
            }
        });
    }
    setDoor(id: string, open: boolean, quiet = false, source = 'player'): boolean {
        if (!this.activeDoors.has(id)) {
            const b = this.city.buildings.find(b => b.doors.some(d => d.id === id));
            if (b)
                this.load(b);
        }
        const d = this.activeDoors.get(id);
        if (!d)
            return false;
        if (!open && this.protectedPositions.some(p => distance(p, d.spec.position) < 1.35))
            return false;
        const target = open ? 100 : 0;
        if (d.target === target)
            return true;
        d.target = target;
        d.speed = quiet ? 38 : 140;
        this.doorState.set(id, open);
        this.emit(d.spec.position, quiet ? 36 : 65, 'door', source);
        return true;
    }
    takeFuse(id: string): void { const e = this.objects.get(id); if (e) {
        this.interactions.delete(e);
        e.destroy();
        this.objects.delete(id);
    } }
    toggleRadio(id: string): boolean { const on = !this.radios.get(id); this.radios.set(id, on); this.radioTimer = 0; return on; }
    throwDecoy(position: V3, forward: V3): void {
        const id = `decoy:${this.time}`;
        const e = this.resources.box(this.root, id, position, [.14, .32, .14], 'glass', 'dynamic');
        e.rigidbody!.mass = .3;
        e.rigidbody!.linearVelocity = toPc([forward[0] * 10, forward[1] * 10 + 1.5, forward[2] * 10]);
        e.rigidbody!.angularVelocity = new pc.Vec3(7, 3, 11);
        this.impactSound(e, id, 0);
        this.ephemeral.push({ entity: e, expires: this.time + 35 });
    }
    ray(from: V3, to: V3, vision = false, ignore?: pc.Entity): RayHit | null {
        const a = toPc(from), b = toPc(to);
        const hits = this.app.systems.rigidbody.raycastAll(a, b) as RayHit[];
        const valid = hits.filter(h => h.entity !== ignore && !h.entity.tags.has('player') && !(vision && h.entity.tags.has('glass')));
        valid.sort((x, y) => x.point.distance(a) - y.point.distance(a));
        return valid[0] ?? null;
    }
    /** Use logical fixtures, not the graphics preset's active-light budget. */
    exposure(position: V3): number {
        let value = buildingAt(this.city, position) ? .08 : .38;
        const target: V3 = [position[0], position[1] + 1, position[2]];
        for (const l of this.lighting.lamps.values())
            if (distance(l.spec.position, target) < l.spec.range) {
                if (!this.ray(l.spec.position, target, true))
                    value += Math.max(0, 1 - distance(l.spec.position, target) / l.spec.range) * .7;
            }
        return clamp(value, .08, 1);
    }
    snapshotProps(): Record<string, PropState> {
        for (const c of this.chunks.values())
            for (const e of c.bodies) {
                const q = e.getRotation();
                this.propState.set(e.name, { position: fromPc(e.getPosition()), rotation: [q.x, q.y, q.z, q.w] });
            }
        return Object.fromEntries(this.propState);
    }
    unload(id: string): void {
        const c = this.chunks.get(id);
        if (!c)
            return;
        for (const e of c.bodies) {
            const q = e.getRotation();
            this.propState.set(e.name, { position: fromPc(e.getPosition()), rotation: [q.x, q.y, q.z, q.w] });
        }
        for (const e of c.interactions)
            this.interactions.delete(e);
        for (const o of this.geometry.get(id)!.objects)
            this.objects.delete(o.id);
        for (const f of this.city.fuses.filter(f => f.building === id))
            this.objects.delete(f.id);
        for (const d of c.building.doors)
            this.activeDoors.delete(d.id);
        for (const l of c.lights)
            this.lighting.remove(l);
        c.root.destroy();
        this.chunks.delete(id);
    }
    destroy(): void { for (const id of [...this.chunks.keys()])
        this.unload(id); this.interactions.clear(); this.root.destroy(); }
}

