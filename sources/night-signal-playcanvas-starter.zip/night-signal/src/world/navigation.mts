import { distance } from '../core/math.mjs';
import type { CityPlan, NavNode, Portal } from './plan.mjs';
export interface Route {
    nodes: string[];
    portals: Portal[];
    cost: number;
}
/** Track state changes. A route cache must not use an old door state. */
class DoorStates extends Map<string, boolean> {
    revision = 0;
    override set(id: string, value: boolean): this { if (this.get(id) !== value)
        this.revision++; return super.set(id, value); }
    override delete(id: string): boolean { if (this.has(id))
        this.revision++; return super.delete(id); }
    override clear(): void { if (this.size)
        this.revision++; super.clear(); }
}
interface QueueItem {
    id: string;
    g: number;
    score: number;
    order: number;
}
class MinQueue {
    private heap: QueueItem[] = [];
    get size(): number { return this.heap.length; }
    private less(a: QueueItem, b: QueueItem): boolean { return a.score < b.score || (a.score === b.score && a.order < b.order); }
    push(item: QueueItem): void { const h = this.heap; h.push(item); let i = h.length - 1; while (i > 0) {
        const p = (i - 1) >> 1;
        if (!this.less(item, h[p]!))
            break;
        h[i] = h[p]!;
        i = p;
    } h[i] = item; }
    pop(): QueueItem {
        const h = this.heap, top = h[0]!, tail = h.pop()!;
        if (h.length) {
            let i = 0;
            while (true) {
                let c = i * 2 + 1;
                if (c >= h.length)
                    break;
                if (c + 1 < h.length && this.less(h[c + 1]!, h[c]!))
                    c++;
                if (!this.less(h[c]!, tail))
                    break;
                h[i] = h[c]!;
                i = c;
            }
            h[i] = tail;
        }
        return top;
    }
}
/** One portal graph serves A* movement and Dijkstra sound paths. Windows never serve movement. */
export class Navigation {
    readonly nodes: Map<string, NavNode>;
    readonly edges = new Map<string, {
        to: string;
        portal: Portal;
    }[]>();
    readonly doorOpen = new DoorStates();
    private cache = new Map<string, Route | null>();
    private cacheRevision = -1;
    constructor(readonly city: CityPlan) {
        this.nodes = new Map(city.nodes.map(n => [n.id, n]));
        for (const p of city.portals) {
            this.edges.set(p.a, [...(this.edges.get(p.a) ?? []), { to: p.b, portal: p }]);
            this.edges.set(p.b, [...(this.edges.get(p.b) ?? []), { to: p.a, portal: p }]);
        }
    }
    route(start: string, end: string, mode: 'walk' | 'sound' = 'walk'): Route | null {
        if (!this.nodes.has(start) || !this.nodes.has(end))
            return null;
        if (start === end)
            return { nodes: [start], portals: [], cost: 0 };
        if (this.cacheRevision !== this.doorOpen.revision) {
            this.cache.clear();
            this.cacheRevision = this.doorOpen.revision;
        }
        const key = `${mode}|${start}|${end}`;
        if (this.cache.has(key))
            return this.cache.get(key)!;
        const route = this.find(start, end, mode);
        if (this.cache.size >= 512)
            this.cache.delete(this.cache.keys().next().value!);
        this.cache.set(key, route);
        return route;
    }
    private find(start: string, end: string, mode: 'walk' | 'sound'): Route | null {
        const open = new MinQueue(), costs = new Map([[start, 0]]), from = new Map<string, {
            id: string;
            portal: Portal;
        }>();
        let order = 0;
        const h = (id: string) => mode === 'walk' ? distance(this.nodes.get(id)!.position, this.nodes.get(end)!.position) : 0;
        open.push({ id: start, g: 0, score: h(start), order: order++ });
        while (open.size) {
            const current = open.pop();
            if (current.g !== costs.get(current.id))
                continue;
            if (current.id === end) {
                const nodes = [end], portals: Portal[] = [];
                let id = end;
                while (id !== start) {
                    const p = from.get(id)!;
                    nodes.push(p.id);
                    portals.push(p.portal);
                    id = p.id;
                }
                return { nodes: nodes.reverse(), portals: portals.reverse(), cost: current.g };
            }
            for (const e of this.edges.get(current.id) ?? []) {
                if (mode === 'walk' && !e.portal.walk)
                    continue;
                const barrier = e.portal.door && !this.doorOpen.get(e.portal.door) ? (mode === 'walk' ? 3 : 36) : e.portal.kind === 'window' ? 28 : 0;
                const g = current.g + distance(this.nodes.get(current.id)!.position, this.nodes.get(e.to)!.position) + barrier;
                if (g < (costs.get(e.to) ?? Infinity)) {
                    costs.set(e.to, g);
                    from.set(e.to, { id: current.id, portal: e.portal });
                    open.push({ id: e.to, g, score: g + h(e.to), order: order++ });
                }
            }
        }
        return null;
    }
    neighbours(id: string): string[] { return (this.edges.get(id) ?? []).filter(e => e.portal.walk).map(e => e.to); }
}

