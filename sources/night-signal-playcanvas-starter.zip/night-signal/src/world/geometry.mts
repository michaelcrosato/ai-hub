import { FLOOR_HEIGHT as H, GROUND_Y } from '../core/config.mjs';
import { degrees, rotateXYZ, sub, type V3 } from '../core/math.mjs';
import { Random } from '../core/random.mjs';
import type { BuildingPlan, CityPlan, RoomPlan } from './plan.mjs';
export type MaterialKey = 'wall0' | 'wall1' | 'wall2' | 'wall3' | 'concrete' | 'trim' | 'floor' | 'metal' | 'wood' | 'glass' | 'emissive' | 'red' | 'road' | 'paint' | 'carpet';
export interface BoxSpec {
    id: string;
    position: V3;
    size: V3;
    angles: V3;
    material: MaterialKey;
    shell: boolean;
    solid: boolean;
    glass?: boolean;
}
export interface ObjectSpec {
    id: string;
    kind: 'locker' | 'radio' | 'prop' | 'cover' | 'table';
    position: V3;
    size: V3;
    yaw: number;
    room: string;
    node: string;
}
export interface LightSpec {
    id: string;
    position: V3;
    room?: string;
    warm: boolean;
    intensity: number;
    range: number;
}
export interface BuildingGeometry {
    boxes: BoxSpec[];
    objects: ObjectSpec[];
    lights: LightSpec[];
}
export function createBuildingGeometry(city: CityPlan, b: BuildingPlan): BuildingGeometry {
    const boxes: BoxSpec[] = [], objects: ObjectSpec[] = [], lights: LightSpec[] = [];
    const [cx, , cz] = b.center, w = b.width, d = b.depth;
    let serial = 0;
    const box = (name: string, position: V3, size: V3, material: MaterialKey, shell = false, solid = true, angles: V3 = [0, 0, 0], glass = false): void => { if (size.some(s => s <= .001))
        return; boxes.push({ id: `${b.id}:${name}:${serial++}`, position, size, material, shell, solid, angles, glass }); };
    const wallMat = `wall${b.tint}` as MaterialKey;
    // Openings are cut from solid wall geometry. A dark texture is never an entry.
    function wall(name: string, axis: 'x' | 'z', fixed: number, start: number, end: number, y: number, openings: {
        at: number;
        width: number;
        bottom: number;
        top: number;
        glass?: boolean;
    }[], shell: boolean, material: MaterialKey): void {
        const slab = (a: number, c: number, lo: number, hi: number, m: MaterialKey = material, isGlass = false): void => {
            const pos: V3 = axis === 'x' ? [(a + c) / 2, y + (lo + hi) / 2, fixed] : [fixed, y + (lo + hi) / 2, (a + c) / 2];
            const size: V3 = axis === 'x' ? [c - a, hi - lo, .28] : [.28, hi - lo, c - a];
            box(name, pos, size, m, shell, true, [0, 0, 0], isGlass);
        };
        let cursor = start;
        for (const o of [...openings].sort((a, c) => a.at - c.at)) {
            const a = Math.max(start, o.at - o.width / 2), c = Math.min(end, o.at + o.width / 2);
            slab(cursor, a, 0, H - .18);
            slab(a, c, 0, o.bottom);
            slab(a, c, o.top, H - .18);
            if (o.glass) {
                slab(a, c, o.bottom, o.top, 'glass', true);
                const p: V3 = axis === 'x' ? [o.at, y + o.bottom - .035, fixed] : [fixed, y + o.bottom - .035, o.at];
                box('sill', p, axis === 'x' ? [o.width + .18, .10, .43] : [.43, .10, o.width + .18], 'trim', shell);
                const p2: V3 = axis === 'x' ? [o.at, y + (o.bottom + o.top) / 2, fixed] : [fixed, y + (o.bottom + o.top) / 2, o.at];
                box('window-bar', p2, axis === 'x' ? [.045, o.top - o.bottom, .31] : [.31, o.top - o.bottom, .045], 'trim', shell, false);
            }
            cursor = c;
        }
        slab(cursor, end, 0, H - .18);
    }
    for (let f = 0; f < b.floors; f++) {
        const y = GROUND_Y + f * H, front = cz - d / 2, rear = cz + d / 2;
        const frontOpen = [{ at: cx - w / 2 + 2.6, width: 1.8, bottom: 1.1, top: 2.6, glass: true }, { at: cx, width: 2, bottom: f === 0 ? 0 : 1.1, top: 2.6, glass: f !== 0 }, { at: cx + w / 2 - 2.2, width: 1.6, bottom: 1.1, top: 2.6, glass: true }];
        wall('front', 'x', front, cx - w / 2, cx + w / 2, y, frontOpen, true, wallMat);
        wall('rear', 'x', rear, cx - w / 2, cx + w / 2, y, [{ at: cx - w / 2 + 2.6, width: 1.8, bottom: 1.1, top: 2.6, glass: true }, { at: cx, width: 1.8, bottom: 1.1, top: 2.6, glass: true }, { at: b.stairX, width: 1.7, bottom: 1.1, top: 2.6, glass: true }], true, wallMat);
        for (const side of [-1, 1] as const)
            wall('side', 'z', cx + side * w / 2, front, rear, y, [-1, 1].map(h => ({ at: cz + h * (d / 2 - 3) / 2, width: 2.2, bottom: 1.1, top: 2.6, glass: true })), true, wallMat);
        // A slab hole reserves the whole stair run. The next floor cannot block the stair.
        const right = cx + w / 2 - 3.25;
        box('slab', [(cx - w / 2 + right) / 2, y - .10, cz], [right - (cx - w / 2), .2, d], 'floor', false);
        for (const sign of [-1, 1])
            box('stair-landing', [cx + w / 2 - 1.625, y - .10, cz + sign * (d / 2 - 1)], [3.25, .2, 2], 'floor', false);
        box('band', [cx, y + H - .12, front - .02], [w + .16, .22, .38], 'trim', true);
        box('band', [cx, y + H - .12, rear + .02], [w + .16, .22, .38], 'trim', true);
        for (const side of [-1, 1] as const) {
            const rooms = b.rooms.filter(r => r.floor === f && r.side === side);
            wall('hall-wall', 'z', cx + side * 1.65, front + 3, rear - 3, y, rooms.map(r => ({ at: r.center[2], width: 1.65, bottom: 0, top: 2.6 })), false, 'concrete');
            const min = side === -1 ? cx - w / 2 : cx + 1.65, max = side === -1 ? cx - 1.65 : cx + w / 2 - 3.3;
            for (const zz of [front + 3, cz, rear - 3])
                box('partition', [(min + max) / 2, y + (H - .18) / 2, zz], [max - min, H - .18, .18], 'concrete');
        }
        box('stair-wall', [cx + w / 2 - 3.3, y + (H - .18) / 2, cz], [.18, H - .18, d - 6], 'concrete');
        // Railings keep the top floor stair opening legible.
        if (f === b.floors - 1)
            box('stair-rail', [cx + w / 2 - 3.1, y + .6, cz], [.09, 1.2, d - 6], 'metal');
        if (f < b.floors - 1) {
            const run = b.stairEnd - b.stairStart, angle = -degrees(Math.atan2(H, run));
            box('ramp-collision', [b.stairX, y + H / 2 - .11, cz], [2.7, .22, Math.hypot(run, H)], 'concrete', false, true, [angle, 0, 0]);
            const steps = 22;
            for (let i = 0; i < steps; i++) {
                const top = H * (i + 1) / steps;
                box('step', [b.stairX, y + top - .055, b.stairStart + (i + .5) * run / steps], [2.7, .11, run / steps + .012], 'trim', false, false);
            }
        }
        lights.push({ id: `${b.id}:light:${f}`, position: [cx, y + H - .45, cz], warm: f % 2 === 0, intensity: 1.8, range: 11 });
        box('hall-lamp', [cx, y + H - .28, cz], [.25, .06, 1.8], 'emissive', false, false);
        for (const room of b.rooms.filter(r => r.floor === f)) {
            const r = new Random(`${city.seed}:${room.id}:props`), [x, , z] = room.center;
            // Keep the room centre and the door approach free for navigation.
            objects.push({ id: `${room.id}:cover`, kind: 'cover', position: [x - room.side * .1, y + .85, z - room.half * 1.6], size: [Math.min(2, room.size[0] - .7), 1.7, .65], yaw: 0, room: room.id, node: room.node });
            objects.push({ id: `${room.id}:table`, kind: 'table', position: [x + room.side * .8, y + .4, z + room.half * 1.1], size: [1.4, .8, .9], yaw: 0, room: room.id, node: room.node });
            const lockerX = x - room.side * (room.size[0] / 2 - .72), lockerZ = z + room.half * (room.size[2] / 2 - .78);
            objects.push({ id: `${room.id}:locker`, kind: 'locker', position: [lockerX, y, lockerZ], size: [1.15, 2.15, 1], yaw: room.half === 1 ? 0 : 180, room: room.id, node: room.node });
            objects.push({ id: `${room.id}:prop`, kind: 'prop', position: [x + room.side * .25, y + .34, z - room.half * .7], size: [.26, .65, .26], yaw: r.range(-25, 25), room: room.id, node: room.node });
            if (r.chance(.28))
                objects.push({ id: `${room.id}:radio`, kind: 'radio', position: [x + room.side * .35, y + .92, z + room.half * 1.1], size: [.38, .24, .18], yaw: 0, room: room.id, node: room.node });
            if (r.chance(.6)) {
                lights.push({ id: `${room.id}:light`, position: [x, y + H - .48, z], room: room.id, warm: room.kind !== 'office', intensity: r.range(1.3, 2.1), range: 7 });
                box('room-lamp', [x, y + H - .25, z], [.5, .07, .5], 'emissive', false, false);
            }
            if (room.kind === 'apartment')
                box('rug', [x, y + .014, z], [Math.max(1, room.size[0] - 1), .018, room.size[2] - 1], 'carpet', false, false);
        }
    }
    box('roof', [cx, GROUND_Y + b.floors * H - .05, cz], [w + .24, .2, d + .24], 'trim', true);
    box('roof-plant', [cx - w * .2, GROUND_Y + b.floors * H + .65, cz + 2], [3, 1.2, 2.2], 'metal', true);
    return { boxes, objects, lights };
}
/** Tests use this to find blocked route samples in axis-aligned wall geometry. */
export function pointInsideBox(p: V3, b: BoxSpec, margin = 0): boolean {
    const q = rotateXYZ(sub(p, b.position), [-b.angles[0], -b.angles[1], -b.angles[2]]);
    return q.every((n, i) => Math.abs(n) < b.size[i]! / 2 + margin);
}
export function roomSurface(room: RoomPlan | undefined): string { return room?.kind === 'apartment' ? 'carpet' : room?.kind === 'workshop' ? 'metal' : room ? 'tile' : 'asphalt'; }

