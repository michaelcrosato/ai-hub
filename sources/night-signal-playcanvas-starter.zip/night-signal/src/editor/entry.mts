import { Script, version, DEVICETYPE_NULL } from 'playcanvas';
import { Game } from '../game/game.mjs';
/** Build this entry as one .mjs asset. The Editor supplies the PlayCanvas module. */
export class NightSignal extends Script {
    static scriptName = 'nightSignal';
    private game: Game | null = null;
    initialize(): void {
        if (this.app.graphicsDevice.deviceType === DEVICETYPE_NULL)
            throw new Error('Night Signal needs WebGPU or WebGL2.');
        const canvas = this.app.graphicsDevice.canvas;
        if (!(canvas instanceof HTMLCanvasElement))
            throw new Error('Night Signal needs a DOM canvas.');
        const ammo = (globalThis as unknown as {
            Ammo?: {
                btVector3?: unknown;
            };
        }).Ammo;
        if (!ammo?.btVector3)
            throw new Error('Import Ammo in the Editor Physics settings and preload it before Night Signal.');
        const [major, minor] = version.split('.').map(Number);
        if (major !== 2 || (minor ?? 0) < 21)
            throw new Error('Use PlayCanvas Engine V2, version 2.21.4 or a compatible later V2 release.');
        this.game = new Game(this.app, canvas);
        this.on('destroy', () => { this.game?.destroy(); this.game = null; });
    }
}

