import type * as pc from 'playcanvas';
import type { EventBus, GameEvents } from '../core/events.mjs';
import type { CityPlan } from '../world/plan.mjs';
import type { World, EmitNoise } from '../world/runtime.mjs';
import type { Player } from './player.mjs';
import type { Session } from './session.mjs';
export interface GameContext {
    app: pc.AppBase;
    root: pc.Entity;
    city: CityPlan;
    world: World;
    player: Player;
    session: Session;
    events: EventBus<GameEvents>;
    emitNoise: EmitNoise;
}
/** A factory gives each run a fresh module. Remove all listeners in stop(). */
export interface GameModule {
    id: string;
    start(context: GameContext): void;
    update?(dt: number, context: GameContext): void;
    stop(): void;
}
export type ModuleFactory = () => GameModule;
export class ModuleHost {
    private modules: GameModule[] = [];
    private context: GameContext | null = null;
    constructor(readonly factories: readonly ModuleFactory[]) { }
    start(context: GameContext): void {
        this.stop();
        this.context = context;
        const used = new Set<string>();
        for (const factory of this.factories) {
            const module = factory();
            if (used.has(module.id))
                throw new Error(`Duplicate game module: ${module.id}`);
            used.add(module.id);
            this.modules.push(module);
            module.start(context);
        }
    }
    update(dt: number): void { if (this.context)
        for (const m of this.modules)
            m.update?.(dt, this.context); }
    stop(): void { for (const m of [...this.modules].reverse())
        m.stop(); this.modules = []; this.context = null; }
}
/** This default module shows how a feature can use events without changing the player. */
export class FieldNotes implements GameModule {
    id = 'field-notes';
    private cleanup: (() => void)[] = [];
    start(c: GameContext): void {
        this.cleanup.push(c.events.on('collected', e => c.events.emit('message', { text: e.total === 3 ? 'All fuses found. Go to the north exit.' : `Fuse ${e.total} of 3. Open your map for the next building.`, duration: 5 })));
        this.cleanup.push(c.events.on('phase', e => {
            if (e.value === 'powering')
                c.events.emit('message', { text: 'Power is rising. The alarm will draw attention.', duration: 5 });
            if (e.value === 'escape')
                c.events.emit('message', { text: 'The gate is opening. Get through it.', duration: 5 });
        }));
    }
    stop(): void { this.cleanup.splice(0).forEach(off => off()); }
}

