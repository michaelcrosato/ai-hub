import type { Action, Settings } from '../core/config.mjs';
export class Input {
    private readonly keys = new Set<string>();
    private readonly pressed = new Set<string>();
    dx = 0;
    dy = 0;
    enabled = false;
    private readonly abort = new AbortController();
    constructor(readonly canvas: HTMLCanvasElement, private settings: Settings, readonly onPause: () => void) {
        const opts = { signal: this.abort.signal };
        window.addEventListener('keydown', e => {
            if (!this.enabled)
                return;
            if (e.code === 'Escape') {
                this.onPause();
                return;
            }
            if (Object.values(this.settings.bindings).includes(e.code))
                e.preventDefault();
            if (!this.keys.has(e.code))
                this.pressed.add(e.code);
            this.keys.add(e.code);
        }, opts);
        window.addEventListener('keyup', e => { this.keys.delete(e.code); }, opts);
        window.addEventListener('mousemove', e => { if (this.enabled && document.pointerLockElement === canvas) {
            this.dx += e.movementX;
            this.dy += e.movementY;
        } }, opts);
        window.addEventListener('blur', () => { this.clear(); if (this.enabled)
            this.onPause(); }, opts);
        document.addEventListener('visibilitychange', () => { if (document.hidden && this.enabled)
            this.onPause(); }, opts);
        document.addEventListener('pointerlockchange', () => { if (this.enabled && document.pointerLockElement !== canvas)
            this.onPause(); }, opts);
        canvas.addEventListener('click', () => { if (this.enabled)
            void this.lock(); }, opts);
    }
    apply(s: Settings): void { this.settings = s; }
    down(action: Action): boolean { return this.enabled && this.keys.has(this.settings.bindings[action]); }
    take(action: Action): boolean { const key = this.settings.bindings[action]; const value = this.enabled && this.pressed.has(key); this.pressed.delete(key); return value; }
    async lock(): Promise<void> { try {
        await this.canvas.requestPointerLock();
    }
    catch {
        this.onPause();
    } }
    clear(): void { this.keys.clear(); this.pressed.clear(); this.dx = 0; this.dy = 0; }
    endFrame(): void { this.pressed.clear(); this.dx = 0; this.dy = 0; }
    destroy(): void { this.abort.abort(); this.clear(); }
}

