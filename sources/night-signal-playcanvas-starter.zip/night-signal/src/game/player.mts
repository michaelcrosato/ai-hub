import * as pc from 'playcanvas';
import type { Settings } from '../core/config.mjs';
import { add, clamp, flatDistance, normalize, radians, rotateXYZ, scale, type V3 } from '../core/math.mjs';
import { fromPc, toPc } from '../render/resources.mjs';
import { locateNode } from '../world/plan.mjs';
import { roomSurface, type ObjectSpec } from '../world/geometry.mjs';
import type { World } from '../world/runtime.mjs';
import type { Input } from './input.mjs';
import type { Session } from './session.mjs';
export class Player {
    readonly body: pc.Entity;
    readonly camera: pc.Entity;
    yaw = 180;
    pitch = 0;
    crouched = false;
    flashlight = true;
    cranking = false;
    holdingBreath = false;
    running = false;
    noiseLevel = 0;
    exposure = .2;
    hidden: ObjectSpec | null = null;
    private exitPosition: V3 = [0, 0, 0];
    private height = 1.75;
    private stride = 0;
    private oldPosition: V3;
    private breathTimer = 0;
    private crankTimer = 0;
    private exhausted = false;
    private breathExhausted = false;
    private bob = 0;
    constructor(readonly app: pc.AppBase, readonly root: pc.Entity, readonly session: Session, position: V3) {
        this.body = new pc.Entity('Player capsule');
        root.addChild(this.body);
        this.body.tags.add('player');
        this.body.setPosition(position[0], position[1] + this.height / 2 + .04, position[2]);
        this.body.addComponent('collision', { type: 'capsule', radius: .32, height: this.height });
        this.body.addComponent('rigidbody', { type: 'dynamic', mass: 70, friction: 0, restitution: 0, angularFactor: new pc.Vec3(0, 0, 0), linearDamping: 0 });
        this.camera = new pc.Entity('First person camera');
        root.addChild(this.camera);
        this.camera.addComponent('camera', { nearClip: .045, farClip: 220, fov: 82, clearColor: new pc.Color(.035, .055, .066) });
        this.oldPosition = position;
        this.syncCamera(false);
    }
    get position(): V3 { const p = fromPc(this.body.getPosition()); p[1] -= this.height / 2; return p; }
    get savePosition(): V3 { return this.hidden ? [...this.exitPosition] : this.position; }
    get eye(): V3 { return fromPc(this.camera.getPosition()); }
    get forward(): V3 { return fromPc(this.camera.forward); }
    get lightOn(): boolean { return this.flashlight && !this.cranking && this.session.battery > 0 && !this.hidden; }
    update(dt: number, input: Input, settings: Settings, world: World): void {
        this.yaw -= input.dx * settings.sensitivity;
        this.pitch = clamp(this.pitch - input.dy * settings.sensitivity * (settings.invertY ? -1 : 1), -85, 85);
        if (input.take('flashlight'))
            this.flashlight = !this.flashlight;
        if (input.take('crouch') && !this.hidden) {
            if (!this.crouched || !world.ray(add(this.position, [0, 1.0, 0]), add(this.position, [0, 1.86, 0])))
                this.changeHeight(!this.crouched);
        }
        this.cranking = input.down('crank') && this.session.battery < 100 && !this.hidden;
        if (this.session.stamina <= 1)
            this.breathExhausted = true;
        if (this.session.stamina >= 25)
            this.breathExhausted = false;
        this.holdingBreath = input.down('breath') && (!!this.hidden || this.crouched) && !this.breathExhausted && this.session.stamina > 1;
        const mx = Number(input.down('right')) - Number(input.down('left')), mz = Number(input.down('forward')) - Number(input.down('back'));
        const moving = (mx !== 0 || mz !== 0) && !this.hidden;
        if (this.session.stamina < 1)
            this.exhausted = true;
        if (this.session.stamina > 22)
            this.exhausted = false;
        this.running = moving && input.down('sprint') && !this.crouched && !this.cranking && !this.exhausted;
        this.session.stamina = clamp(this.session.stamina + dt * (this.running ? -23 : this.holdingBreath ? -14 : moving ? 10 : 18), 0, 100);
        if (this.lightOn)
            this.session.battery = Math.max(0, this.session.battery - dt * .42);
        if (this.cranking)
            this.session.battery = Math.min(100, this.session.battery + dt * 10);
        if (!this.hidden) {
            const y = radians(this.yaw), direction = normalize([-Math.sin(y) * mz + Math.cos(y) * mx, 0, -Math.cos(y) * mz - Math.sin(y) * mx]);
            const speed = this.cranking ? .7 : this.crouched ? 1.25 : this.running ? 5.5 : 2.7;
            const current = this.body.rigidbody!.linearVelocity;
            this.body.rigidbody!.friction = moving ? 0 : .8;
            this.body.rigidbody!.linearVelocity = new pc.Vec3(direction[0] * speed, current.y, direction[2] * speed);
        }
        const p = this.position, delta = flatDistance(p, this.oldPosition);
        this.oldPosition = [...p];
        const grounded = !!world.ray(add(p, [0, .15, 0]), add(p, [0, -.30, 0]));
        this.noiseLevel = Math.max(0, this.noiseLevel - dt * .8);
        if (moving && grounded && delta < 1) {
            this.stride += delta;
            this.bob += delta * 6;
            if (this.stride > (this.crouched ? .8 : this.running ? 1.55 : 1.1)) {
                this.stride = 0;
                const node = locateNode(world.city, p), room = world.city.buildings.flatMap(b => b.rooms).find(r => r.id === node.room), surface = roomSurface(room);
                const level = (this.crouched ? 27 : this.running ? 70 : 44) + (surface === 'metal' ? 8 : surface === 'carpet' ? -10 : 0);
                world.emit(p, level, 'step', 'player', surface);
                this.noiseLevel = clamp(level / 80, 0, 1);
            }
        }
        this.crankTimer -= dt;
        if (this.cranking && this.crankTimer < 0) {
            this.crankTimer = .6;
            world.emit(p, 60, 'crank', 'player');
            this.noiseLevel = .7;
        }
        this.breathTimer -= dt;
        if (!this.holdingBreath && this.breathTimer < 0 && (this.session.stamina < 40 || this.hidden)) {
            this.breathTimer = this.session.stamina < 20 ? 1 : 2.2;
            const level = this.session.stamina < 20 ? 54 : this.session.stamina < 40 ? 38 : 21;
            world.emit(p, level, 'breath', 'player');
            this.noiseLevel = Math.max(this.noiseLevel, level / 100);
        }
        this.syncCamera(settings.headBob && moving && grounded);
        if (p[1] < -15 || Math.abs(p[0]) > world.city.extent + 4 || Math.abs(p[2]) > world.city.extent + 4)
            this.teleport(world.city.spawn);
    }
    private changeHeight(crouch: boolean): void {
        const feet = this.position;
        this.crouched = crouch;
        this.height = crouch ? 1.05 : 1.75;
        this.body.collision!.height = this.height;
        this.body.rigidbody!.teleport(new pc.Vec3(feet[0], feet[1] + this.height / 2 + .015, feet[2]));
    }
    hide(locker: ObjectSpec): void {
        this.exitPosition = add(locker.position, rotateXYZ([0, .02, -1.15], [0, locker.yaw, 0]));
        this.hidden = locker;
        this.body.rigidbody!.linearVelocity = new pc.Vec3();
        this.body.rigidbody!.enabled = false;
        this.body.setPosition(locker.position[0], locker.position[1] + this.height / 2, locker.position[2]);
        this.yaw = locker.yaw;
        this.pitch = 0;
        this.oldPosition = this.position;
        this.syncCamera(false);
    }
    leaveHide(): void { this.hidden = null; this.body.rigidbody!.enabled = true; this.teleport(this.exitPosition); }
    teleport(feet: V3): void { this.body.rigidbody!.teleport(new pc.Vec3(feet[0], feet[1] + this.height / 2 + .03, feet[2])); this.body.rigidbody!.linearVelocity = new pc.Vec3(); this.oldPosition = [...feet]; this.syncCamera(false); }
    private syncCamera(bob: boolean): void {
        const p = this.position;
        this.camera.setPosition(p[0], p[1] + (this.hidden ? 1.57 : this.crouched ? .88 : 1.60) + (bob ? Math.sin(this.bob) * .025 : 0), p[2]);
        this.camera.setEulerAngles(this.pitch, this.yaw, 0);
    }
    destroy(): void { this.body.destroy(); this.camera.destroy(); }
}

