import { GENERATOR_VERSION } from '../core/config.mjs';
import { clamp, finiteV3, type V3 } from '../core/math.mjs';
export type Phase = 'scavenge' | 'powering' | 'escape' | 'won' | 'lost';
export interface PropState {
    position: V3;
    rotation: [
        number,
        number,
        number,
        number
    ];
}
export interface SaveData {
    version: number;
    generator: number;
    seed: string;
    size: number;
    time: number;
    phase: Phase;
    alarmLeft: number;
    collected: string[];
    battery: number;
    stamina: number;
    decoys: number;
    player: V3;
    yaw: number;
    pitch: number;
    doors: Record<string, boolean>;
    props: Record<string, PropState>;
    explored: string[];
}
export class Session {
    phase: Phase = 'scavenge';
    time = 0;
    alarmLeft = 35;
    battery = 100;
    stamina = 100;
    decoys = 4;
    readonly collected = new Set<string>();
    readonly explored = new Set<string>();
    collect(id: string): boolean { if (!/^fuse:[0-2]$/.test(id) || this.phase !== 'scavenge' || this.collected.has(id))
        return false; this.collected.add(id); return true; }
    startPower(): boolean { if (this.collected.size !== 3 || this.phase !== 'scavenge')
        return false; this.phase = 'powering'; this.alarmLeft = 35; return true; }
    update(dt: number): void {
        if (!Number.isFinite(dt) || dt < 0 || this.phase === 'lost' || this.phase === 'won')
            return;
        this.time += dt;
        if (this.phase === 'powering') {
            this.alarmLeft = Math.max(0, this.alarmLeft - dt);
            if (this.alarmLeft === 0)
                this.phase = 'escape';
        }
    }
    restore(save: SaveData): void {
        this.phase = save.phase;
        this.time = save.time;
        this.alarmLeft = save.alarmLeft;
        this.battery = save.battery;
        this.stamina = save.stamina;
        this.decoys = save.decoys;
        this.collected.clear();
        save.collected.forEach(id => this.collected.add(id));
        this.explored.clear();
        save.explored.forEach(id => this.explored.add(id));
    }
}
export function parseSave(text: string | null): SaveData | null {
    if (!text || text.length > 2000000)
        return null;
    try {
        const x: unknown = JSON.parse(text);
        if (!x || typeof x !== 'object')
            return null;
        const s = x as SaveData;
        if (s.version !== 1 || s.generator !== GENERATOR_VERSION || typeof s.seed !== 'string' || s.seed.length > 80 || ![3, 5, 7].includes(s.size) || !finiteV3(s.player))
            return null;
        if (!['scavenge', 'powering', 'escape'].includes(s.phase))
            return null;
        if (![s.time, s.alarmLeft, s.battery, s.stamina, s.decoys, s.yaw, s.pitch].every(Number.isFinite))
            return null;
        if (!Array.isArray(s.collected) || s.collected.length > 3 || s.collected.some(id => !/^fuse:[0-2]$/.test(id)) || new Set(s.collected).size !== s.collected.length)
            return null;
        if ((s.phase === 'powering' || s.phase === 'escape') && s.collected.length !== 3)
            return null;
        if (s.player.some(n => Math.abs(n) > 500) || s.time < 0 || s.time > 604800)
            return null;
        s.alarmLeft = clamp(s.alarmLeft, 0, 35);
        s.battery = clamp(s.battery, 0, 100);
        s.stamina = clamp(s.stamina, 0, 100);
        s.decoys = clamp(Math.floor(s.decoys), 0, 4);
        s.pitch = clamp(s.pitch, -85, 85);
        s.yaw = ((s.yaw % 360) + 360) % 360;
        if (!s.doors || typeof s.doors !== 'object' || Array.isArray(s.doors) || Object.keys(s.doors).length > 1000)
            return null;
        s.doors = Object.fromEntries(Object.entries(s.doors).filter(([key, val]) => key.startsWith('b:') && typeof val === 'boolean'));
        if (!s.props || typeof s.props !== 'object' || Array.isArray(s.props) || Object.keys(s.props).length > 2000)
            return null;
        s.props = Object.fromEntries(Object.entries(s.props).filter(([, p]) => p && finiteV3(p.position) && p.position.every(n => Math.abs(n) < 500) && Array.isArray(p.rotation) && p.rotation.length === 4 && p.rotation.every(Number.isFinite)));
        s.explored = Array.isArray(s.explored) ? s.explored.filter(id => typeof id === 'string' && id.startsWith('b:')).slice(0, 49) : [];
        return s;
    }
    catch {
        return null;
    }
}

