import * as pc from 'playcanvas';
import { DEFAULT_SETTINGS, GENERATOR_VERSION, keyLabel, validateSettings, type Settings } from '../core/config.mjs';
import { EventBus, type GameEvents, type SoundKind } from '../core/events.mjs';
import { add, clamp, distance, scale, type V3 } from '../core/math.mjs';
import { createCity, validateCity, buildingAt, locateNode, type CityPlan } from '../world/plan.mjs';
import { Navigation } from '../world/navigation.mjs';
import { World, type Interactable } from '../world/runtime.mjs';
import { Resources, toPc } from '../render/resources.mjs';
import { Lighting } from '../render/lighting.mjs';
import { NoiseLog, propagateSound } from '../audio/acoustics.mjs';
import { Sound } from '../audio/sound.mjs';
import { Enemies } from '../ai/enemies.mjs';
import { UI } from '../ui/ui.mjs';
import { Input } from './input.mjs';
import { Player } from './player.mjs';
import { Session, parseSave, type SaveData, type Phase } from './session.mjs';
import { FieldNotes, ModuleHost, type ModuleFactory } from './modules.mjs';
const SETTINGS_KEY = 'night-signal:settings:1', SAVE_KEY = 'night-signal:save:1';
function storageRead(key: string): string | null { try {
    return localStorage.getItem(key);
}
catch {
    return null;
} }
function storageWrite(key: string, value: string | null): boolean { try {
    if (value === null)
        localStorage.removeItem(key);
    else
        localStorage.setItem(key, value);
    return true;
}
catch {
    return false;
} }
function readSettings(): Settings { try {
    return validateSettings(JSON.parse(storageRead(SETTINGS_KEY) ?? 'null'));
}
catch {
    return validateSettings(DEFAULT_SETTINGS);
} }
export interface GameOptions {
    modules?: readonly ModuleFactory[];
}
/** Owns one run. The Editor owns the application; this class never destroys it. */
export class Game {
    readonly events = new EventBus<GameEvents>();
    readonly noise = new NoiseLog();
    readonly ui: UI;
    readonly input: Input;
    readonly sound: Sound;
    settings: Settings = readSettings();
    session: Session | null = null;
    city: CityPlan | null = null;
    world: World | null = null;
    player: Player | null = null;
    enemies: Enemies | null = null;
    private root: pc.Entity | null = null;
    private resources: Resources | null = null;
    private lighting: Lighting | null = null;
    private nav: Navigation | null = null;
    private readonly modules: ModuleHost;
    private running = false;
    private destroyed = false;
    private busy = false;
    private oldTimeScale: number;
    private alarmTimer = 0;
    private saveTimer = 0;
    private senseTimer = 0;
    private hudTimer = 0;
    private phase: Phase = 'scavenge';
    private target: Interactable | null = null;
    private fps = 0;
    private fpsFrames = 0;
    private fpsStart = performance.now();
    private readonly updateBound = (dt: number) => this.update(dt);
    constructor(readonly app: pc.AppBase, readonly canvas: HTMLCanvasElement, options: GameOptions = {}) {
        this.oldTimeScale = app.timeScale;
        app.timeScale = 0;
        this.ui = new UI(this.settings, { newGame: (seed, size) => void this.start(seed, size), continueGame: () => void this.continue(), resume: () => void this.resume(), saveMenu: () => this.returnMenu(), settings: s => this.applySettings(s) }, String(app.graphicsDevice.deviceType));
        this.input = new Input(canvas, this.settings, () => this.pause());
        this.sound = new Sound(this.settings, text => this.ui.caption(text));
        this.modules = new ModuleHost([() => new FieldNotes(), ...(options.modules ?? [])]);
        this.events.on('message', e => this.ui.toast(e.text, e.duration));
        app.on('update', this.updateBound);
        this.ui.main(!!parseSave(storageRead(SAVE_KEY)));
    }
    async start(seed: string, size: number, save?: SaveData): Promise<void> {
        if (this.busy || this.destroyed)
            return;
        this.busy = true;
        this.suspend();
        this.ui.loading('Create the street plan, rooms, and exit routes.');
        // Paint the loading state before this small, finite city is built on the main thread.
        await new Promise<void>(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve())));
        if (this.destroyed) {
            this.busy = false;
            return;
        }
        try {
            this.clearRun();
            const city = this.city = createCity(seed, size), errors = validateCity(city);
            if (errors.length)
                throw new Error(errors.slice(0, 3).join(' / '));
            const session = this.session = new Session();
            if (save)
                session.restore(save);
            this.phase = session.phase;
            const root = this.root = new pc.Entity('Night Signal run');
            this.app.root.addChild(root);
            this.resources = new Resources(this.app);
            this.nav = new Navigation(city);
            this.player = new Player(this.app, root, session, save?.player ?? city.spawn);
            if (save) {
                this.player.yaw = save.yaw;
                this.player.pitch = save.pitch;
                this.player.teleport(save.player);
            }
            this.lighting = new Lighting(this.app, root, this.player.camera, this.settings);
            const world = this.world = new World(this.app, city, this.nav, this.resources, this.lighting, session.collected, (p, l, k, s, surface) => this.emitNoise(p, l, k, s, surface), root);
            if (save) {
                for (const [id, open] of Object.entries(save.doors))
                    if (world.doorState.has(id)) {
                        world.doorState.set(id, open);
                        this.nav.doorOpen.set(id, open);
                    }
                const propIds = new Set([...world.geometry.values()].flatMap(g => g.objects.filter(o => o.kind === 'prop').map(o => o.id)));
                for (const [id, prop] of Object.entries(save.props))
                    if (propIds.has(id))
                        world.propState.set(id, prop);
            }
            world.prime(this.player.position);
            this.enemies = new Enemies(world, this.nav, this.resources, session, this.noise, root, () => this.finish(false));
            this.modules.start({ app: this.app, root, city, world, player: this.player, session, events: this.events, emitNoise: (...args) => world.emit(...args) });
            this.lighting.update(0, this.player.position, this.player.lightOn, session.time);
            this.sound.listener(this.player.eye, this.player.forward);
            this.alarmTimer = 0;
            this.saveTimer = 0;
            this.senseTimer = 0;
            this.hudTimer = 0;
            this.player.camera.enabled = false;
            this.ui.pause('City ready. Select Enter the city to capture the mouse and start sound.');
            this.save();
        }
        catch (error) {
            console.error('[Night Signal] Start failed', error);
            this.clearRun();
            this.ui.error(error instanceof Error ? error.message : 'An unknown error stopped the game.');
        }
        finally {
            this.busy = false;
        }
    }
    private async continue(): Promise<void> { const save = parseSave(storageRead(SAVE_KEY)); if (!save) {
        this.ui.main(false);
        return;
    } await this.start(save.seed, save.size, save); }
    async resume(): Promise<void> {
        if (this.busy || !this.session || this.session.phase === 'won' || this.session.phase === 'lost')
            return;
        this.input.clear();
        if (this.player)
            this.player.camera.enabled = true;
        this.input.enabled = true;
        this.running = true;
        this.app.timeScale = 1;
        this.ui.play();
        // Both requests start inside the click handler. Do not await one before the other.
        const audio = this.sound.unlock().catch(error => { console.warn('[Night Signal] Audio failed', error); this.ui.toast('Sound could not start. Sound captions remain available.', 6); });
        const pointer = this.input.lock();
        await Promise.all([audio, pointer]);
    }
    pause(reason = 'The city is paused.'): void { if (!this.session || this.busy || ['won', 'lost'].includes(this.session.phase))
        return; this.suspend(); this.ui.pause(reason); }
    private suspend(): void { this.running = false; if (this.player)
        this.player.camera.enabled = false; this.input?.clear(); if (this.input)
        this.input.enabled = false; this.app.timeScale = 0; if (document.pointerLockElement === this.canvas)
        document.exitPointerLock(); this.sound?.stopAll(); this.sound?.pause(); }
    private returnMenu(): void { this.suspend(); if (this.session && !['won', 'lost'].includes(this.session.phase))
        this.save(); this.clearRun(); this.ui.main(!!parseSave(storageRead(SAVE_KEY))); }
    private applySettings(s: Settings): void { this.settings = s; storageWrite(SETTINGS_KEY, JSON.stringify(s)); this.input.apply(s); this.sound.apply(s); this.lighting?.apply(s); this.ui.apply(s); }
    private emitNoise(position: V3, level: number, kind: SoundKind, source: string, surface?: string): void {
        if (!this.city || !this.session || !this.nav || !Number.isFinite(level))
            return;
        const event = this.noise.emit({ time: this.session.time, position, node: locateNode(this.city, position).id, level: clamp(level, 0, 120), kind, source, ...(surface ? { surface } : {}) });
        this.events.emit('noise', event);
        if (this.player) {
            const heard = propagateSound(this.nav, event, locateNode(this.city, this.player.position).id, this.player.eye);
            if (heard)
                this.sound.play(heard);
        }
    }
    private update(rawDt: number): void {
        if (this.destroyed)
            return;
        this.fpsFrames++;
        const wallNow = performance.now();
        if (wallNow - this.fpsStart >= 500) {
            this.fps = Math.round(this.fpsFrames * 1000 / (wallNow - this.fpsStart));
            this.fpsFrames = 0;
            this.fpsStart = wallNow;
        }
        if (!this.running || !this.player || !this.world || !this.city || !this.session || !this.enemies || !this.lighting)
            return;
        const dt = clamp(rawDt, 0, .05);
        if (dt === 0)
            return;
        const player = this.player, world = this.world, session = this.session, city = this.city;
        if (this.input.take('journal')) {
            this.suspend();
            this.ui.journal({ city, player: player.position, explored: session.explored, collected: session.collected });
            return;
        }
        if (this.input.take('hints'))
            this.applySettings({ ...this.settings, hints: !this.settings.hints });
        session.update(dt);
        world.update(dt, player.position, this.settings, this.enemies.positions(), session.phase === 'escape');
        player.update(dt, this.input, this.settings, world);
        this.sound.listener(player.eye, player.forward);
        this.lighting.update(dt, player.position, player.lightOn, session.time);
        this.senseTimer -= dt;
        if (this.senseTimer <= 0) {
            this.senseTimer = .2;
            player.exposure = world.exposure(player.position);
            const b = buildingAt(city, player.position);
            if (b)
                session.explored.add(b.id);
        }
        const ray = world.ray(player.eye, add(player.eye, scale(player.forward, 2.55)));
        this.target = ray ? world.interactions.get(ray.entity) ?? null : null;
        if (this.input.take('interact'))
            this.interact();
        if (this.input.take('throw'))
            this.throwBottle();
        if (session.phase !== this.phase) {
            this.phase = session.phase;
            this.events.emit('phase', { value: session.phase });
        }
        this.alarmTimer -= dt;
        if (session.phase === 'powering' && this.alarmTimer <= 0) {
            this.alarmTimer = 1.8;
            this.emitNoise(add(city.exit, [-4.8, 1.4, 1.2]), 93, 'alarm', 'exit-alarm');
        }
        this.enemies.update(dt, player);
        if (!this.running)
            return;
        this.modules.update(dt);
        this.noise.prune(session.time);
        if (session.phase === 'escape' && player.position[2] > city.exit[2] + 3.2 && Math.abs(player.position[0]) < 3.1) {
            this.finish(true);
            return;
        }
        this.saveTimer += dt;
        if (this.saveTimer > 30) {
            this.saveTimer = 0;
            this.save();
        }
        this.hudTimer -= dt;
        if (this.hudTimer <= 0) {
            this.hudTimer = .10;
            const b = buildingAt(city, player.position), node = locateNode(city, player.position);
            const location = b ? `BLOCK ${String.fromCharCode(65 + b.lotX)}${b.lotZ + 1} / FLOOR ${(node.floor ?? 0) + 1} / ${b.kind.toUpperCase()}` : `STREET / NORTH EXIT ${Math.round(distance(player.position, city.exit))} m`;
            this.ui.update({ phase: session.phase, fuses: session.collected.size, alarm: session.alarmLeft, battery: session.battery, stamina: session.stamina, noise: player.noiseLevel, decoys: session.decoys, location, prompt: this.prompt(), hidden: !!player.hidden, breath: player.holdingBreath, crank: player.cranking, fps: this.fps, lights: this.lighting.activeCount });
        }
        this.input.endFrame();
    }
    private prompt(): string {
        const key = keyLabel(this.settings.bindings.interact);
        if (this.player?.hidden)
            return `[${key}] Leave locker`;
        const t = this.target;
        if (!t)
            return '';
        const label = t.kind === 'door' ? `${this.world!.doorState.get(t.id) ? 'Close' : 'Open'} door${this.player?.crouched ? ' slowly' : ''}` : t.kind === 'locker' ? 'Hide in locker' : t.kind === 'radio' ? `Turn radio ${this.world!.radios.get(t.id) ? 'off' : 'on'}` : t.kind === 'fuse' ? 'Take fuse' : t.kind === 'prop' ? 'Knock object' : this.session!.phase === 'scavenge' ? 'Power exit (three fuses)' : 'Exit power is on';
        return `[${key}] ${label}`;
    }
    private interact(): void {
        const player = this.player!, world = this.world!, session = this.session!;
        if (player.hidden) {
            player.leaveHide();
            world.emit(player.position, 34, 'door', 'player');
            return;
        }
        const t = this.target;
        if (!t)
            return;
        if (t.kind === 'door') {
            const open = !world.doorState.get(t.id);
            if (world.setDoor(t.id, open, player.crouched)) {
                this.events.emit('door', { id: t.id, open });
            }
            else
                this.ui.toast('Step away from the door before you close it.');
        }
        else if (t.kind === 'locker' && t.object) {
            this.enemies!.witnessHide(player, t.id);
            player.hide(t.object);
            world.emit(t.object.position, player.crouched ? 27 : 42, 'door', 'player');
        }
        else if (t.kind === 'radio') {
            const on = world.toggleRadio(t.id);
            this.ui.toast(`Radio ${on ? 'on. Move away from the sound.' : 'off.'}`);
        }
        else if (t.kind === 'prop') {
            const rigid = t.entity.rigidbody;
            if (rigid) {
                rigid.applyImpulse(toPc(add(scale(player.forward, 1.9), [0, .3, 0])));
                rigid.angularVelocity = new pc.Vec3(2.5, 0, 4);
                world.emit([t.entity.getPosition().x, t.entity.getPosition().y, t.entity.getPosition().z], 47, 'impact', 'player', 'metal');
            }
        }
        else if (t.kind === 'fuse' && session.collect(t.id)) {
            world.takeFuse(t.id);
            world.emit(player.position, 24, 'pickup', 'player');
            this.events.emit('collected', { id: t.id, total: session.collected.size });
            this.target = null;
            this.save();
        }
        else if (t.kind === 'exit') {
            if (!session.startPower())
                this.ui.toast(session.phase === 'scavenge' ? `You need ${3 - session.collected.size} more fuse${3 - session.collected.size === 1 ? '' : 's'}.` : 'Power is on. Use cover until the gate opens.');
            else
                this.save();
        }
    }
    private throwBottle(): void {
        if (!this.player || !this.world || !this.session)
            return;
        if (this.player.hidden) {
            this.ui.toast('Leave the locker before you throw a bottle.');
            return;
        }
        if (this.session.decoys < 1) {
            this.ui.toast('No bottles left. A radio can still draw a threat away.');
            return;
        }
        const pos = add(this.player.eye, scale(this.player.forward, .65));
        if (this.world.ray(this.player.eye, pos)) {
            this.ui.toast('Move away from the surface before you throw.');
            return;
        }
        this.session.decoys--;
        this.world.throwDecoy(pos, this.player.forward);
        this.player.noiseLevel = Math.max(this.player.noiseLevel, .2);
    }
    private finish(won: boolean): void {
        if (!this.session || !this.city || ['won', 'lost'].includes(this.session.phase))
            return;
        this.session.phase = won ? 'won' : 'lost';
        this.suspend();
        if (won)
            storageWrite(SAVE_KEY, null);
        this.events.emit('phase', { value: this.session.phase });
        this.ui.end(won, this.city.seed, this.session.time);
    }
    save(): boolean {
        if (!this.session || !this.city || !this.player || !this.world || ['won', 'lost'].includes(this.session.phase))
            return false;
        const s = this.session, save: SaveData = { version: 1, generator: GENERATOR_VERSION, seed: this.city.seed, size: this.city.size, time: s.time, phase: s.phase, alarmLeft: s.alarmLeft, collected: [...s.collected], battery: s.battery, stamina: s.stamina, decoys: s.decoys, player: this.player.savePosition, yaw: this.player.yaw, pitch: this.player.pitch, doors: Object.fromEntries(this.world.doorState), props: this.world.snapshotProps(), explored: [...s.explored] };
        const ok = storageWrite(SAVE_KEY, JSON.stringify(save));
        if (!ok)
            this.ui.toast('The browser could not store this save. Check site storage access.', 6);
        return ok;
    }
    diagnostics(): Record<string, unknown> { return { engine: pc.version, backend: this.app.graphicsDevice.deviceType, running: this.running, phase: this.session?.phase, seed: this.city?.seed, fingerprint: this.city?.fingerprint, buildings: this.city?.buildings.length, loadedBuildings: this.world?.chunks.size, activeShadowLights: this.lighting?.activeCount, fps: this.fps }; }
    private clearRun(): void {
        this.modules.stop();
        this.noise.clear();
        this.sound.stopAll();
        this.enemies?.destroy();
        this.enemies = null;
        this.world?.destroy();
        this.world = null;
        this.lighting?.destroy();
        this.lighting = null;
        this.player?.destroy();
        this.player = null;
        this.root?.destroy();
        this.root = null;
        this.resources?.destroy();
        this.resources = null;
        this.session = null;
        this.city = null;
        this.nav = null;
        this.target = null;
    }
    destroy(): void { if (this.destroyed)
        return; this.destroyed = true; this.suspend(); this.app.off('update', this.updateBound); this.clearRun(); this.input.destroy(); void this.sound.destroy(); this.ui.destroy(); this.events.clear(); this.app.timeScale = this.oldTimeScale; }
}

