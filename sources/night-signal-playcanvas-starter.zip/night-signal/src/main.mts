import * as pc from 'playcanvas';
import { Game } from './game/game.mjs';
interface AmmoApi {
    btVector3: unknown;
}
type AmmoFactory = () => Promise<AmmoApi>;
const globals = globalThis as unknown as {
    Ammo?: AmmoApi | AmmoFactory;
    nightSignal?: {
        diagnostics: () => Record<string, unknown>;
    };
};
async function loadAmmo(): Promise<void> {
    if (globals.Ammo && typeof globals.Ammo === 'object' && globals.Ammo.btVector3)
        return;
    if (!globals.Ammo)
        await new Promise<void>((resolve, reject) => {
            const script = document.createElement('script');
            script.src = new URL('./vendor/ammo.js', document.baseURI).href;
            script.async = true;
            script.onload = () => resolve();
            script.onerror = () => reject(new Error('Ammo did not load. Run npm run build, then serve the dist folder.'));
            document.head.append(script);
        });
    const factory = globals.Ammo;
    if (typeof factory === 'function')
        globals.Ammo = await factory();
    if (!globals.Ammo || typeof globals.Ammo !== 'object' || !globals.Ammo.btVector3)
        throw new Error('Ammo did not initialize. Check the browser console.');
}
async function boot(): Promise<void> {
    const canvas = document.querySelector<HTMLCanvasElement>('#game-canvas'), status = document.querySelector<HTMLElement>('#boot-status');
    if (!canvas)
        throw new Error('The game canvas is missing.');
    if (status)
        status.textContent = 'Load physics and graphics.';
    await loadAmmo();
    const forceWebGL = new URLSearchParams(location.search).get('webgl') === '1';
    const device = await pc.createGraphicsDevice(canvas, { deviceTypes: forceWebGL ? [pc.DEVICETYPE_WEBGL2] : [pc.DEVICETYPE_WEBGPU, pc.DEVICETYPE_WEBGL2], antialias: false, powerPreference: 'high-performance' });
    if (device.deviceType === pc.DEVICETYPE_NULL) {
        device.destroy();
        throw new Error('No usable WebGPU or WebGL2 device was found. Enable browser hardware acceleration and check the graphics driver.');
    }
    const app = new pc.Application(canvas, { graphicsDevice: device });
    app.setCanvasFillMode(pc.FILLMODE_FILL_WINDOW);
    app.setCanvasResolution(pc.RESOLUTION_AUTO);
    app.maxDeltaTime = .05;
    app.systems.rigidbody.gravity = new pc.Vec3(0, -14, 0);
    const resize = () => app.resizeCanvas();
    window.addEventListener('resize', resize);
    resize();
    // start() initializes the Ammo physics world. No game bodies exist before this call.
    app.start();
    const game = new Game(app, canvas);
    status?.remove();
    globals.nightSignal = { diagnostics: () => game.diagnostics() };
    const lost = () => game.pause('The graphics device was lost. Reload the page to restore the last saved run.');
    device.on('devicelost', lost);
    window.addEventListener('pagehide', () => { game.save(); game.destroy(); window.removeEventListener('resize', resize); app.destroy(); }, { once: true });
    console.info('[Night Signal]', game.diagnostics());
}
void boot().catch(error => {
    console.error('[Night Signal] Boot failed', error);
    const status = document.querySelector<HTMLElement>('#boot-status');
    if (status) {
        status.textContent = `Start failed. ${error instanceof Error ? error.message : String(error)}`;
        status.setAttribute('role', 'alert');
    }
});

