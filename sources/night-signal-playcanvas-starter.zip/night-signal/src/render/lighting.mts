import * as pc from 'playcanvas';
import { PRESETS, type Settings } from '../core/config.mjs';
import { distance, type V3 } from '../core/math.mjs';
import type { LightSpec } from '../world/geometry.mjs';
interface ManagedLight {
    entity: pc.Entity;
    spec: LightSpec;
    active: boolean;
}
export class Lighting {
    readonly moon: pc.Entity;
    readonly flashlight: pc.Entity;
    readonly frame: pc.CameraFrame;
    readonly lamps = new Map<string, ManagedLight>();
    activeCount = 0;
    private timer = 0;
    private settings: Settings;
    constructor(readonly app: pc.AppBase, readonly root: pc.Entity, readonly camera: pc.Entity, settings: Settings) {
        this.settings = settings;
        app.scene.ambientLight = new pc.Color(.055, .075, .095);
        app.scene.exposure = 1.15;
        app.scene.fog.type = pc.FOG_EXP2;
        app.scene.fog.color = new pc.Color(.035, .055, .066);
        app.scene.fog.density = .013;
        app.scene.lighting.cells = new pc.Vec3(12, 4, 12);
        app.scene.lighting.maxLightsPerCell = 24;
        app.scene.lighting.shadowsEnabled = true;
        app.scene.lighting.cookiesEnabled = false;
        app.scene.lighting.areaLightsEnabled = false;
        this.moon = new pc.Entity('Moon');
        root.addChild(this.moon);
        this.moon.addComponent('light', { type: 'directional', color: new pc.Color(.44, .62, .82), intensity: .65, castShadows: true, shadowResolution: 2048, shadowBias: .12, normalOffsetBias: .06 });
        this.moon.setEulerAngles(42, -35, 0);
        this.flashlight = new pc.Entity('Flashlight');
        camera.addChild(this.flashlight);
        this.flashlight.setLocalPosition(.16, -.12, -.1);
        this.flashlight.setLocalEulerAngles(90, 0, 0);
        this.flashlight.addComponent('light', { type: 'spot', color: new pc.Color(.90, .94, .81), intensity: 3.2, range: 27, innerConeAngle: 18, outerConeAngle: 29, castShadows: true, shadowResolution: 1024, shadowBias: .08, normalOffsetBias: .03 });
        this.frame = new pc.CameraFrame(app, camera.camera!);
        this.apply(settings);
    }
    apply(settings: Settings): void {
        this.settings = settings;
        const p = PRESETS[settings.quality];
        this.app.graphicsDevice.maxPixelRatio = 1;
        this.app.scene.lighting.shadowAtlasResolution = p.atlas;
        this.app.scene.lighting.shadowType = settings.quality === 'ultra' ? pc.SHADOW_PCF5_32F : pc.SHADOW_PCF3_32F;
        const moon = this.moon.light!;
        moon.numCascades = p.cascades;
        moon.shadowDistance = p.shadowDistance;
        moon.cascadeDistribution = .65;
        moon.shadowType = settings.pcss ? pc.SHADOW_PCSS_32F : pc.SHADOW_PCF3_32F;
        moon.penumbraSize = 1.1;
        moon.shadowSamples = 12;
        moon.shadowBlockerSamples = 8;
        this.camera.camera!.fov = settings.fov;
        this.frame.rendering.renderTargetScale = settings.resolution;
        this.frame.rendering.toneMapping = pc.TONEMAP_ACES;
        this.frame.rendering.samples = settings.taa ? 1 : 4;
        this.frame.taa.enabled = settings.taa;
        this.frame.bloom.intensity = settings.bloom ? .025 : 0;
        this.frame.bloom.blurLevel = 6;
        this.frame.ssao.type = settings.ssao ? pc.SSAOTYPE_LIGHTING : pc.SSAOTYPE_NONE;
        this.frame.ssao.samples = p.ssaoSamples;
        this.frame.ssao.scale = .5;
        this.frame.ssao.intensity = .6;
        this.frame.ssao.radius = 6;
        this.frame.ssao.power = 2;
        this.frame.vignette.intensity = .28;
        this.frame.vignette.inner = .55;
        this.frame.vignette.outer = 1.4;
        this.frame.volumetricFog.enabled = settings.volumetric;
        this.frame.volumetricFog.light = moon;
        this.frame.volumetricFog.density = .018;
        this.frame.volumetricFog.steps = p.fogSteps;
        this.frame.volumetricFog.scale = .5;
        this.frame.volumetricFog.maxDistance = 90;
        this.frame.volumetricFog.heightFalloff = .11;
        this.frame.volumetricFog.ambientIntensity = .012;
        this.frame.dof.enabled = false;
        this.frame.update();
        this.timer = 0;
    }
    add(spec: LightSpec, parent: pc.Entity): void {
        const e = new pc.Entity(spec.id);
        parent.addChild(e);
        e.setPosition(...spec.position);
        e.addComponent('light', { type: 'spot', color: spec.warm ? new pc.Color(1, .73, .43) : new pc.Color(.58, .85, .88), intensity: spec.intensity, range: spec.range, innerConeAngle: 48, outerConeAngle: 72, castShadows: true, shadowResolution: 512, shadowBias: .10, normalOffsetBias: .035 });
        e.light!.enabled = false;
        this.lamps.set(spec.id, { entity: e, spec, active: false });
    }
    remove(id: string): void { this.lamps.delete(id); }
    update(dt: number, position: V3, flashOn: boolean, time: number): void {
        this.flashlight.light!.enabled = flashOn;
        this.timer -= dt;
        if (this.timer <= 0) {
            this.timer = .25;
            const budget = PRESETS[this.settings.quality].shadowLights;
            const candidates = [...this.lamps.values()].sort((a, b) => {
                const score = (l: ManagedLight) => distance(l.spec.position, position) + Math.abs(l.spec.position[1] - position[1]) * .8 - (l.active ? 2 : 0);
                return score(a) - score(b);
            });
            this.activeCount = 0;
            for (let i = 0; i < candidates.length; i++) {
                const l = candidates[i]!;
                l.active = i < budget && distance(l.spec.position, position) < 42;
                l.entity.light!.enabled = l.active;
                if (l.active)
                    this.activeCount++;
            }
        }
        // No unshadowed local fill is used. This avoids light passing through walls.
        if (this.settings.flicker) {
            for (const l of this.lamps.values())
                if (l.active)
                    l.entity.light!.intensity = l.spec.intensity * (.94 + .06 * Math.sin(time * 8 + l.spec.position[0]));
        }
        else {
            for (const l of this.lamps.values())
                if (l.active)
                    l.entity.light!.intensity = l.spec.intensity;
        }
        this.frame.update();
    }
    destroy(): void { this.frame.destroy(); this.lamps.clear(); this.flashlight.destroy(); this.moon.destroy(); }
}

