import * as pc from 'playcanvas';
import { add, rotateXYZ, type V3 } from '../core/math.mjs';
import type { BoxSpec, MaterialKey } from '../world/geometry.mjs';
export const toPc = (v: V3): pc.Vec3 => new pc.Vec3(...v);
export const fromPc = (v: {
    x: number;
    y: number;
    z: number;
}): V3 => [v.x, v.y, v.z];
export class Resources {
    readonly materials = new Map<MaterialKey, pc.StandardMaterial>();
    private readonly extraMaterials: pc.StandardMaterial[] = [];
    private readonly textures: pc.Texture[] = [];
    constructor(readonly app: pc.AppBase) {
        const palette: Record<MaterialKey, [
            number,
            number,
            number
        ]> = {
            wall0: [.30, .34, .34], wall1: [.35, .30, .27], wall2: [.26, .31, .35], wall3: [.34, .35, .28],
            concrete: [.37, .39, .38], trim: [.17, .20, .21], floor: [.23, .25, .25], metal: [.13, .17, .18], wood: [.28, .18, .11],
            glass: [.14, .23, .25], emissive: [.65, .79, .69], red: [.55, .10, .04], road: [.075, .09, .10], paint: [.45, .47, .39], carpet: [.16, .20, .19]
        };
        for (const [key, color] of Object.entries(palette) as [
            MaterialKey,
            [
                number,
                number,
                number
            ]
        ][]) {
            const m = new pc.StandardMaterial();
            m.name = key;
            m.diffuse = new pc.Color(...color);
            m.useMetalness = true;
            m.metalness = key === 'metal' ? .7 : 0;
            m.enableGGXSpecular = true;
            m.gloss = key === 'road' ? .75 : key === 'glass' ? .95 : key === 'metal' ? .60 : .18;
            if (key === 'glass') {
                m.opacity = .20;
                m.blendType = pc.BLEND_NORMAL;
                m.depthWrite = false;
                m.cull = pc.CULLFACE_NONE;
            }
            if (key === 'emissive') {
                m.emissive = new pc.Color(.8, 1, .72);
                m.emissiveIntensity = 4;
            }
            if (key === 'red') {
                m.emissive = new pc.Color(.7, .035, .008);
                m.emissiveIntensity = 1.2;
            }
            m.update();
            this.materials.set(key, m);
        }
    }
    material(key: MaterialKey): pc.StandardMaterial { return this.materials.get(key)!; }
    /** Merge static boxes by material. Individual wall blocks do not each need a draw call. */
    batch(parent: pc.Entity, name: string, boxes: BoxSpec[]): pc.Entity {
        const root = new pc.Entity(name);
        parent.addChild(root);
        const groups = new Map<MaterialKey, BoxSpec[]>();
        for (const b of boxes)
            groups.set(b.material, [...(groups.get(b.material) ?? []), b]);
        const faces: {
            n: V3;
            p: V3[];
        }[] = [
            { n: [0, 0, 1], p: [[-.5, -.5, .5], [.5, -.5, .5], [.5, .5, .5], [-.5, .5, .5]] },
            { n: [0, 0, -1], p: [[.5, -.5, -.5], [-.5, -.5, -.5], [-.5, .5, -.5], [.5, .5, -.5]] },
            { n: [1, 0, 0], p: [[.5, -.5, .5], [.5, -.5, -.5], [.5, .5, -.5], [.5, .5, .5]] },
            { n: [-1, 0, 0], p: [[-.5, -.5, -.5], [-.5, -.5, .5], [-.5, .5, .5], [-.5, .5, -.5]] },
            { n: [0, 1, 0], p: [[-.5, .5, .5], [.5, .5, .5], [.5, .5, -.5], [-.5, .5, -.5]] },
            { n: [0, -1, 0], p: [[-.5, -.5, -.5], [.5, -.5, -.5], [.5, -.5, .5], [-.5, -.5, .5]] }
        ];
        for (const [key, list] of groups) {
            const positions: number[] = [], normals: number[] = [], uv: number[] = [], indices: number[] = [];
            for (const b of list)
                for (const f of faces) {
                    const offset = positions.length / 3, n = rotateXYZ(f.n, b.angles);
                    for (const p of f.p) {
                        const local: V3 = [p[0] * b.size[0], p[1] * b.size[1], p[2] * b.size[2]];
                        positions.push(...add(rotateXYZ(local, b.angles), b.position));
                        normals.push(...n);
                    }
                    uv.push(0, 0, 1, 0, 1, 1, 0, 1);
                    indices.push(offset, offset + 1, offset + 2, offset, offset + 2, offset + 3);
                }
            const mesh = new pc.Mesh(this.app.graphicsDevice);
            mesh.setPositions(positions);
            mesh.setNormals(normals);
            mesh.setUvs(0, uv);
            mesh.setIndices(indices);
            mesh.update(pc.PRIMITIVE_TRIANGLES);
            const e = new pc.Entity(`${name}:${key}`);
            root.addChild(e);
            e.addComponent('render', { meshInstances: [new pc.MeshInstance(mesh, this.material(key), e)], castShadows: key !== 'glass' && key !== 'emissive', receiveShadows: true });
        }
        return root;
    }
    box(parent: pc.Entity, id: string, position: V3, size: V3, material: MaterialKey, body: 'static' | 'dynamic' | 'kinematic' | null = null, angles: V3 = [0, 0, 0]): pc.Entity {
        const entity = new pc.Entity(id);
        parent.addChild(entity);
        entity.setLocalPosition(...position);
        entity.setLocalEulerAngles(...angles);
        const visual = new pc.Entity(`${id}:mesh`);
        entity.addChild(visual);
        visual.setLocalScale(...size);
        visual.addComponent('render', { type: 'box', material: this.material(material), castShadows: material !== 'glass' && material !== 'emissive', receiveShadows: true });
        if (body)
            this.collider(entity, size, body);
        return entity;
    }
    collider(entity: pc.Entity, size: V3, type: 'static' | 'dynamic' | 'kinematic' = 'static'): void {
        entity.addComponent('collision', { type: 'box', halfExtents: new pc.Vec3(size[0] / 2, size[1] / 2, size[2] / 2) });
        entity.addComponent('rigidbody', { type, mass: type === 'dynamic' ? .65 : 0, friction: .65, restitution: .12, linearDamping: .12, angularDamping: .12 });
    }
    solid(parent: pc.Entity, b: BoxSpec): pc.Entity {
        const e = new pc.Entity(b.id);
        parent.addChild(e);
        e.setLocalPosition(...b.position);
        e.setLocalEulerAngles(...b.angles);
        this.collider(e, b.size);
        if (b.glass)
            e.tags.add('glass');
        return e;
    }
    sign(parent: pc.Entity, text: string, position: V3, width = 2.8, height = .6): pc.Entity {
        const canvas = document.createElement('canvas');
        canvas.width = 512;
        canvas.height = 128;
        const ctx = canvas.getContext('2d')!;
        ctx.fillStyle = '#102127';
        ctx.fillRect(0, 0, 512, 128);
        ctx.strokeStyle = '#708c86';
        ctx.strokeRect(8, 8, 496, 112);
        ctx.fillStyle = '#cddbc7';
        ctx.font = 'bold 38px monospace';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(text, 256, 64, 460);
        const texture = new pc.Texture(this.app.graphicsDevice, { width: 512, height: 128, mipmaps: true });
        texture.setSource(canvas);
        this.textures.push(texture);
        const material = new pc.StandardMaterial();
        material.diffuseMap = texture;
        material.emissiveMap = texture;
        material.emissive = new pc.Color(.16, .16, .16);
        material.cull = pc.CULLFACE_NONE;
        material.update();
        this.extraMaterials.push(material);
        const e = new pc.Entity(`sign:${text}`);
        parent.addChild(e);
        e.setPosition(...position);
        e.setLocalScale(width, 1, height);
        e.setLocalEulerAngles(90, 0, 0);
        e.addComponent('render', { type: 'plane', material, castShadows: false });
        return e;
    }
    destroy(): void { for (const t of this.textures)
        t.destroy(); for (const m of [...this.materials.values(), ...this.extraMaterials])
        m.destroy(); this.materials.clear(); }
}

