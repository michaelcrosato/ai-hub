import type { Settings } from '../core/config.mjs';
import type { NoiseEvent } from '../core/events.mjs';
import { clamp, sub, dot, type V3 } from '../core/math.mjs';
import { Random } from '../core/random.mjs';
import type { HeardSound } from './acoustics.mjs';
export class Sound {
    private context: AudioContext | null = null;
    private master: GainNode | null = null;
    private compressor: DynamicsCompressorNode | null = null;
    private noise: AudioBuffer | null = null;
    private active = 0;
    private readonly sources = new Set<AudioScheduledSourceNode>();
    private listenerPosition: V3 = [0, 0, 0];
    private listenerForward: V3 = [0, 0, -1];
    constructor(private settings: Settings, private readonly caption: (text: string) => void) { }
    async unlock(): Promise<void> {
        if (!this.context) {
            const c = this.context = new AudioContext();
            this.master = c.createGain();
            this.compressor = c.createDynamicsCompressor();
            this.master.connect(this.compressor);
            this.compressor.connect(c.destination);
            this.noise = c.createBuffer(1, c.sampleRate * 2, c.sampleRate);
            const data = this.noise.getChannelData(0), rng = new Random('audio-noise');
            for (let i = 0; i < data.length; i++)
                data[i] = rng.range(-1, 1);
            this.apply(this.settings);
        }
        if (this.context.state === 'suspended')
            await this.context.resume();
    }
    apply(s: Settings): void {
        this.settings = s;
        if (this.master && this.context)
            this.master.gain.setTargetAtTime(s.volume, this.context.currentTime, .03);
        if (this.compressor) {
            this.compressor.threshold.value = s.range === 'night' ? -35 : -10;
            this.compressor.ratio.value = s.range === 'night' ? 8 : 3;
            this.compressor.knee.value = 18;
        }
    }
    listener(position: V3, forward: V3): void {
        this.listenerPosition = position;
        this.listenerForward = forward;
        if (!this.context)
            return;
        const l = this.context.listener, t = this.context.currentTime;
        l.positionX.setValueAtTime(position[0], t);
        l.positionY.setValueAtTime(position[1], t);
        l.positionZ.setValueAtTime(position[2], t);
        l.forwardX.setValueAtTime(forward[0], t);
        l.forwardY.setValueAtTime(forward[1], t);
        l.forwardZ.setValueAtTime(forward[2], t);
        l.upX.setValueAtTime(0, t);
        l.upY.setValueAtTime(1, t);
        l.upZ.setValueAtTime(0, t);
    }
    play(heard: HeardSound): void {
        const e = heard.event;
        if (heard.level < 8)
            return;
        if (this.settings.captions && !['step', 'crank', 'breath', 'pickup'].includes(e.kind) && e.source !== 'player') {
            const labels: Record<NoiseEvent['kind'], string> = { step: 'Footsteps', door: 'A door moves', impact: e.surface === 'glass' ? 'Glass hits a surface' : 'Metal strikes a surface', glass: 'Glass breaks', radio: 'A radio plays', breath: 'Breathing', crank: 'A handle turns', enemy: 'A low pulse', alarm: 'The exit alarm', pickup: 'Fuse collected' };
            const delta = sub(heard.apparentPosition, this.listenerPosition), side = dot(delta, [-this.listenerForward[2], 0, this.listenerForward[0]]);
            const front = dot(delta, this.listenerForward);
            const vertical = delta[1] > 2 ? 'above' : delta[1] < -2 ? 'below' : Math.abs(side) > 2 ? (side > 0 ? 'right' : 'left') : Math.abs(front) > 2 ? (front > 0 ? 'ahead' : 'behind') : 'nearby';
            this.caption(`${labels[e.kind]} — ${vertical}`);
        }
        if (!this.context || !this.master || this.context.state !== 'running' || this.active >= 24 || this.settings.volume === 0)
            return;
        const c = this.context, t = c.currentTime + Math.min(.3, heard.delay), gain = c.createGain(), filter = c.createBiquadFilter(), panner = c.createPanner();
        panner.panningModel = 'HRTF';
        panner.distanceModel = 'inverse';
        panner.rolloffFactor = 0;
        panner.positionX.value = heard.apparentPosition[0];
        panner.positionY.value = heard.apparentPosition[1];
        panner.positionZ.value = heard.apparentPosition[2];
        filter.type = 'lowpass';
        filter.frequency.value = Math.min(heard.lowpass, e.kind === 'step' ? 1700 : 12000);
        gain.connect(filter);
        filter.connect(panner);
        panner.connect(this.master);
        const amp = clamp(Math.pow(10, (heard.level - 65) / 25), .004, .65);
        const toneKinds = ['radio', 'enemy', 'alarm', 'pickup'];
        let source: AudioScheduledSourceNode, duration = .22;
        if (toneKinds.includes(e.kind)) {
            const osc = c.createOscillator();
            osc.type = e.kind === 'pickup' ? 'sine' : 'triangle';
            const f = e.kind === 'enemy' ? 48 : e.kind === 'alarm' ? 340 : e.kind === 'radio' ? 210 : 680;
            osc.frequency.setValueAtTime(f, t);
            osc.frequency.exponentialRampToValueAtTime(e.kind === 'alarm' ? 520 : e.kind === 'pickup' ? 980 : f * .74, t + .35);
            duration = e.kind === 'enemy' ? .85 : e.kind === 'alarm' ? .75 : .45;
            osc.connect(gain);
            source = osc;
        }
        else {
            const buffer = c.createBufferSource();
            buffer.buffer = this.noise;
            buffer.playbackRate.value = e.kind === 'door' ? .35 : e.kind === 'breath' ? .4 : e.kind === 'crank' ? .7 : 1;
            duration = e.kind === 'door' ? .5 : e.kind === 'breath' ? .55 : e.kind === 'glass' ? .6 : .18;
            if (e.kind === 'step')
                filter.frequency.value = Math.min(filter.frequency.value, e.surface === 'carpet' ? 450 : e.surface === 'metal' ? 3500 : 1300);
            buffer.connect(gain);
            source = buffer;
        }
        gain.gain.setValueAtTime(.0001, t);
        gain.gain.exponentialRampToValueAtTime(Math.max(.001, amp), t + .012);
        gain.gain.exponentialRampToValueAtTime(.0001, t + duration);
        this.active++;
        this.sources.add(source);
        source.onended = () => { this.active--; this.sources.delete(source); source.disconnect(); gain.disconnect(); filter.disconnect(); panner.disconnect(); };
        source.start(t);
        source.stop(t + duration + .02);
    }
    pause(): void { if (this.context)
        void this.context.suspend(); }
    stopAll(): void { for (const s of [...this.sources]) {
        try {
            s.stop();
        }
        catch { /* The source can already be stopped. */ }
    } }
    async destroy(): Promise<void> { this.stopAll(); await this.context?.close(); this.context = null; }
}

