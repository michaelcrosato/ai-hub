import { distance, type V3 } from '../core/math.mjs';
import type { NoiseEvent } from '../core/events.mjs';
import type { Navigation } from '../world/navigation.mjs';
export interface HeardSound {
    event: NoiseEvent;
    level: number;
    pathLength: number;
    loss: number;
    apparentPosition: V3;
    lowpass: number;
    delay: number;
}
/** Levels are relative game values. This is not a calibrated acoustic simulation. */
export function propagateSound(nav: Navigation, event: NoiseEvent, listenerNode: string, listener: V3): HeardSound | null {
    const route = nav.route(listenerNode, event.node, 'sound');
    if (!route)
        return null;
    let loss = 0, pathLength = 0;
    if (route.nodes.length === 1)
        pathLength = distance(listener, event.position);
    else {
        let previous = listener;
        for (const p of route.portals) {
            pathLength += distance(previous, p.position);
            previous = p.position;
            if (p.kind === 'window')
                loss += 14;
            else if (p.kind === 'door')
                loss += p.door && nav.doorOpen.get(p.door) ? 2 : 18;
            else if (p.kind === 'stair')
                loss += 3;
        }
        pathLength += distance(previous, event.position);
    }
    pathLength = Math.max(pathLength, distance(listener, event.position));
    const level = event.level - 20 * Math.log10(Math.max(1, pathLength)) - loss - pathLength * .025;
    return { event, level, pathLength, loss, apparentPosition: loss > 3 && route.portals.length ? route.portals[0]!.position : event.position, lowpass: Math.max(350, 18000 * Math.exp(-loss * .095)), delay: pathLength / 343 };
}
export class NoiseLog {
    private sequence = 0;
    readonly events: NoiseEvent[] = [];
    emit(event: Omit<NoiseEvent, 'id'>): NoiseEvent {
        const value = { ...event, position: [...event.position] as V3, id: ++this.sequence };
        this.events.push(value);
        if (this.events.length > 96)
            this.events.shift();
        return value;
    }
    prune(time: number): void { while (this.events.length && time - this.events[0]!.time > 3)
        this.events.shift(); }
    clear(): void { this.events.length = 0; }
}

