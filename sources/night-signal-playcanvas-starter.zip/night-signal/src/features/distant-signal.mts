import type { GameContext, GameModule } from '../game/modules.mjs';
/** Optional example. Register this factory in GameOptions to enable it.
 * A distant signal gives both the player and enemies a point to investigate.
 * It uses game noise, not speaker gain, so mute does not change enemy hearing.
 */
export class DistantSignal implements GameModule {
    readonly id = 'distant-signal';
    private remaining = 90;
    start(_context: GameContext): void {
        this.remaining = 90;
    }
    update(dt: number, context: GameContext): void {
        if (context.session.phase !== 'scavenge')
            return;
        this.remaining -= dt;
        if (this.remaining > 0)
            return;
        this.remaining = 90;
        const nodes = context.city.nodes.filter(node => node.kind === 'street');
        if (!nodes.length)
            return;
        // Use a stable clock-based index. Do not use Math.random for game state.
        const index = Math.floor(context.session.time / 90) % nodes.length;
        const node = nodes[index]!;
        context.emitNoise([...node.position], 78, 'radio', this.id);
    }
    stop(): void {
        this.remaining = 90;
    }
}

