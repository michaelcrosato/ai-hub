# NIGHT SIGNAL
## Modular first-person horror · Prototype source 0.1

Find three fuses in a silent city. Restore power at the north gate. Survive the alarm. Escape.

**Status:** This package contains game source, tests, and setup files. It is not a tested game release. The 19 core tests pass. They include 1,000 city seeds. Nine browser menu checks also pass. The PlayCanvas build, Ammo gameplay, Editor import, WebGPU rendering, and RTX 3060 performance are not verified. Package downloads were blocked in the build environment. Read `docs/VALIDATION.md` before you use the source.

## Start with the local build

Use Node.js 22.18 or later. This also meets the current PlayCanvas Editor MCP server requirement. [P9]

Open a terminal in this folder. Run:

```sh
npm install
npm test
npm run build
npm run preview
```

Open this address in a browser with graphics acceleration:

```text
http://127.0.0.1:5173
```

Select a city size. A new seed appears by default. Enter a known seed to repeat a city. Select **Start a new run**, then **Enter the city**. The second click starts sound and requests mouse control.

The standalone entry tries WebGPU first. It then tries WebGL2. The menu shows the backend that was selected. A null graphics device causes a clear start error. To test the WebGL2 path, use:

```text
http://127.0.0.1:5173/?webgl=1
```

Do not open `public/index.html` as a game. Do not use `file://` for the game build. The build must first create the JavaScript and physics files in `dist/`.

`npm run dev` builds once and starts the same server. It does not watch source files. After an edit, run `npm run build`, then reload the page. Run `npm run typecheck` for the full TypeScript check. Run `npm run check` for the full local check sequence.

No lockfile is supplied because dependency installation did not complete here. After a successful install, review and commit the generated `package-lock.json`. Use `npm ci` for later repeatable installs.

## What the source includes

| System | Initial implementation |
| --- | --- |
| City | Seeded 3 × 3, 5 × 5, or 7 × 7 block district. Open streets. Enterable buildings. The city is finite, not infinite. |
| Buildings | Two to four floors. Four rooms per floor. Real door and window openings. Stairs, hallways, furniture, and lockers. |
| Variety | Building size, use, height, colour group, empty lots, props, and fuse sites vary by seed. The street grid and main floor layout remain regular. |
| Player | First-person mouse look. Walk, run, crouch, hide, hold breath, and use objects. No visible hands, weapons, or skeletal animation. |
| Survival | Stamina and flashlight charge. A hand-crank charge action restores power but makes noise. Four throwable bottle decoys. |
| Sound | Game noise events, portal-based sound loss, closed-door filtering, spatial audio, and optional directional captions. Speaker volume does not change enemy hearing. |
| Threats | One Listener at first. A second starts after two fuses. Rigid shapes need no walk or attack animation. Threats investigate sound and search the last place they saw the player. |
| Objects | Slow or fast door motion. Physics cans. Tables and cabinets for cover. Lockers for hiding. Radios as noise sources. |
| Escape | Three fuses in separate upper-floor rooms. A 35-second alarm. A rising gate and a win/loss state. |
| Display | Main menu, pause menu, settings, key changes, control reference, map, notes, status display, captions, and optional bottom control hints. |
| Rendering | Shadowed moon and flashlight. Budgeted local spotlights. Material groups, fog, SSAO, bloom, tone mapping, and anti-aliasing. Optional directional PCSS shadows and volumetric fog. |
| Saves | One local checkpoint and local settings. Door states, stable prop transforms, collected fuses, explored buildings, and player values persist. |
| Extension | Typed events, pure city data, separate systems, and per-run feature modules. An optional module example is included. |

The world is built at runtime. It does not appear as an editable city in the Editor viewport before Launch. The Editor owns the host scene and script asset. The source owns the generated layout.

## Controls

| Input | Action |
| --- | --- |
| Mouse | Look |
| W A S D | Move |
| Left Shift, hold | Run |
| C | Toggle crouch |
| E | Use, open, hide, or leave a locker |
| F | Toggle flashlight |
| R, hold | Charge the light; the crank makes noise |
| G | Throw one bottle |
| Space, hold | Hold breath while crouched or hidden |
| Tab | Map and fuse notes |
| H | Show or hide bottom control hints |
| Escape | Pause and release the mouse |

Change the keys in **Controls**. There is no jump or combat action. Use the stairs. Crouch before you use a door to move it slowly. A threat can open doors. A threat that sees you enter a locker can search that locker.

## Use the PlayCanvas Editor

The source pins the standalone engine to **2.21.4**. The current Engine V2 API includes the frame and fog features used here. [P1, P4] The Editor supplies its own engine version. Select Engine V2 and verify that the loaded version supports the same API.

Build first. Add `editor-build/night-signal.mjs` to an empty Engine V2 project. Import and preload Ammo. Add the `nightSignal` script to one host entity. Do not load the standalone engine or standalone Ammo loader into the Editor. The full procedure is in `docs/EDITOR_WORKFLOW.md`.

The `.vscode/` folder contains tasks and settings. `.codex/config.example.toml` contains an optional MCP configuration. `AGENTS.md` gives the coding agent project rules and test requirements. These files do not connect to or modify an Editor project by themselves.

## Project map

```text
src/core/       Seeded random values, events, settings, and maths
src/world/      City plan, geometry, route graph, and streamed runtime objects
src/audio/      Noise propagation and browser sound
src/ai/         Evidence-based brain and runtime threat actors
src/game/       Input, player, session, feature modules, and run ownership
src/render/     Mesh/material resources, light budget, and camera effects
src/ui/         Menus, controls, map, status display, and styles
src/features/   Optional module example
src/editor/     Editor ESM script entry
src/main.mts    Standalone entry
scripts/        Build and local server
```

Read `docs/DESIGN.md` for the game rules. Read `docs/ARCHITECTURE.md` before you add a system. Read `docs/LIGHTING_AND_PERFORMANCE.md` before you raise the light budget.

## Important limits

This is a foundation, not a claim of production readiness. Native physics and full escape play have not been tested here. The graph tests cannot prove capsule clearance or enemy movement in Ammo. The threat controller has no full navmesh or local obstacle avoidance. It can need work near moved props and tight cover.

The save is a checkpoint, not a full simulation snapshot. Threats restart from their initial sites on Continue. Radio switches and thrown bottles do not persist. Long-distance physics is not simulated after a building unloads.

There is no infinite world, multiplayer, hunger system, crafting, damage simulation, destructible glass, ray-traced lighting, DLSS, screen-space reflections, or dynamic global illumination. The current floor plan is deliberately simple. These are possible later features, not hidden parts of this package.

The RTX 3060 target is **1080p at 60 frames per second on High**, subject to measurement. It is not an observed result. Start with a 3 × 3 city for the first graphics and physics check.

## Tests and ownership

Core tests use Node's test runner. Browser menu tests are optional and use Python plus Playwright:

```sh
python -m pip install playwright
python -m playwright install chromium
npm run test:ui
```

On systems where Python is named `python3`, use `npx tsc -p tsconfig.ui.json`, then `python3 tests/ui-smoke.py`. Set `CHROMIUM_PATH` to use a specific browser. Screenshots go to `.ui-test-results/`. The UI test does not load PlayCanvas or Ammo.

Game source uses the MIT licence. See `LICENSE`. Third-party packages keep their own licences. The build copies available licence files and writes a notice. No paid assets, recorded audio, or external font files are included. All game geometry and placeholder sounds are generated in code.

Settings and the checkpoint use browser `localStorage`. The game has no analytics, account system, or AI API calls. Your coding agent is a development tool, not a runtime game service.

External API and tool references are in `docs/SOURCES.md`.
