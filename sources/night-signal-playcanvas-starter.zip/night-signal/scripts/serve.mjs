import { createServer } from 'node:http';
import { stat,readFile } from 'node:fs/promises';
import { resolve,extname,sep } from 'node:path';
import { fileURLToPath } from 'node:url';
const root=resolve(fileURLToPath(new URL('../dist',import.meta.url))),port=Number(process.env.PORT??5173);
if(!Number.isInteger(port)||port<1024||port>65535)throw new Error('PORT must be an integer from 1024 to 65535.');
try{await stat(resolve(root,'index.html'));}catch{console.error('dist/index.html is missing. Run npm run build first.');process.exit(1);}
const mime={'.html':'text/html; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.map':'application/json; charset=utf-8','.css':'text/css; charset=utf-8','.wasm':'application/wasm','.png':'image/png','.txt':'text/plain; charset=utf-8'};
const server=createServer(async(req,res)=>{
  if(!['GET','HEAD'].includes(req.method??'')){res.writeHead(405,{'Allow':'GET, HEAD'});res.end();return;}
  try{
    const pathname=decodeURIComponent(new URL(req.url??'/',`http://127.0.0.1:${port}`).pathname);
    if(pathname.includes('\0')||pathname.includes('\\')){res.writeHead(400);res.end();return;}
    let file=resolve(root,`.${pathname}`);if(file!==root&&!file.startsWith(root+sep)){res.writeHead(403);res.end();return;}
    if((await stat(file)).isDirectory())file=resolve(file,'index.html');
    const bytes=await readFile(file);res.writeHead(200,{'Content-Type':mime[extname(file)]??'application/octet-stream','Content-Length':bytes.length,'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});res.end(req.method==='HEAD'?undefined:bytes);
  }catch(error){res.writeHead(error instanceof URIError?400:404);res.end('Not found.');}
});
server.on('error',error=>{console.error('Server failed:',error.message);process.exitCode=1;});
server.listen(port,'127.0.0.1',()=>console.info(`Night Signal: http://127.0.0.1:${port}\nUse Ctrl+C to stop. Rebuild after a source change.`));
