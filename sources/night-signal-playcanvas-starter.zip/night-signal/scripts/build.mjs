import { build } from 'esbuild';
import { mkdir,copyFile,writeFile,access,rm } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve,join } from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url));
const exists=async path=>{try{await access(path);return true;}catch{return false;}};
try{
  for(const folder of ['dist','editor-build']){await rm(join(root,folder),{recursive:true,force:true});await mkdir(join(root,folder),{recursive:true});}
  await mkdir(join(root,'dist/vendor'),{recursive:true});
  const ammoPath=join(root,'node_modules/ammojs-typed/ammo/ammo.js');
  if(!await exists(ammoPath))throw new Error('ammojs-typed/ammo/ammo.js is missing. Run npm install in the project folder.');
  const common={bundle:true,format:'esm',platform:'browser',target:'es2022',sourcemap:true,legalComments:'eof',logLevel:'info',absWorkingDir:root};
  const result=await build({...common,entryPoints:['src/main.mts'],outfile:'dist/main.mjs',minify:true,metafile:true});
  await build({...common,entryPoints:['src/editor/entry.mts'],outfile:'editor-build/night-signal.mjs',external:['playcanvas'],minify:false,keepNames:true});
  await copyFile(join(root,'public/index.html'),join(root,'dist/index.html'));await copyFile(ammoPath,join(root,'dist/vendor/ammo.js'));
  await writeFile(join(root,'dist/build-meta.json'),JSON.stringify(result.metafile,null,2));
  const notices=['Night Signal 0.1.0','Game source: MIT. See LICENSE.','PlayCanvas 2.21.4: MIT; https://github.com/playcanvas/engine','ammojs-typed 1.0.6: see the package license and Ammo/Bullet notices; https://github.com/giniedp/ammojs-typed','No paid assets or external font files are used.'];
  for(const [label,candidates]of [['PlayCanvas',['node_modules/playcanvas/LICENSE','node_modules/playcanvas/LICENSE.md']],['Ammo',['node_modules/ammojs-typed/LICENSE','node_modules/ammojs-typed/LICENSE.md','node_modules/ammojs-typed/ammo/LICENSE']]]){
    for(const candidate of candidates)if(await exists(join(root,candidate))){await copyFile(join(root,candidate),join(root,'dist/vendor',`${label}-LICENSE.txt`));break;}
  }
  await copyFile(join(root,'LICENSE'),join(root,'dist/LICENSE'));await writeFile(join(root,'dist/vendor/NOTICE.txt'),notices.join('\n')+'\n');
  console.info('\nBuilt dist/ and editor-build/night-signal.mjs. Run npm run preview.');
}catch(error){console.error('Build failed:',error instanceof Error?error.message:error);process.exitCode=1;}
