#!/usr/bin/env bash
# Packs an already built wasm into game.html (build.sh without the cargo step).
# usage: pack-local.sh <path to wasm-bindgen>
set -euo pipefail
cd "$(dirname "$0")/../.."
T=${CARGO_TARGET_DIR:-$PWD/target}
out=$T/jungle-web
rm -rf "$out"
mkdir -p "$out"
"$1" --target web --no-typescript --out-dir "$out" --out-name shardfall "$T/wasm32-unknown-unknown/dist/shardfall.wasm"
python3 test-games/jungle-strike/pack.py "$out" test-games/jungle-strike/game.html
