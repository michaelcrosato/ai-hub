// Drives game.html in headless Chromium (WebGPU on SwiftShader) and saves screenshots.
// usage: node browser-test.mjs <out dir> [script]   (needs playwright-core: set PW to its path)
// script is a list of steps: "wait:ms", "key:KeyW:ms", "down:KeyW", "up:KeyW", "click:x:y", "mouse:x:y", "shot:name"
import { createRequire } from 'module';
import path from 'path';
import { fileURLToPath } from 'url';
const require = createRequire(import.meta.url);
const { chromium } = require(process.env.PW || 'playwright-core');
const here = path.dirname(fileURLToPath(import.meta.url));
const out = process.argv[2] || '/tmp/jstest';
const steps = (process.argv[3] || 'wait:15000,shot:title').split(',');
import fs from 'fs';
fs.mkdirSync(out, { recursive: true });
const browser = await chromium.launch({
  executablePath: process.env.CHROME || undefined,
  args: ['--enable-unsafe-webgpu', '--enable-features=Vulkan', '--use-vulkan=swiftshader', '--use-angle=swiftshader', '--ignore-gpu-blocklist', '--no-sandbox'],
});
const page = await browser.newPage({ viewport: { width: 1280, height: 720 } });
page.on('console', (m) => { const t = m.text(); if (!/GPU stall|deprecated/i.test(t)) console.log('[console]', m.type(), t.slice(0, 300)); });
page.on('pageerror', (e) => console.log('[pageerror]', String(e).slice(0, 400)));
await page.goto('file://' + path.join(here, 'game.html'));
for (const s of steps) {
  const [op, a, b] = s.split(':');
  if (op === 'wait') await page.waitForTimeout(+a);
  else if (op === 'shot') { await page.screenshot({ path: path.join(out, a + '.png') }); console.log('shot', a); }
  else if (op === 'key') { await page.keyboard.down(a); await page.waitForTimeout(+(b || 100)); await page.keyboard.up(a); }
  else if (op === 'down') await page.keyboard.down(a);
  else if (op === 'up') await page.keyboard.up(a);
  else if (op === 'click') { await page.mouse.move(+a, +b); await page.mouse.down(); await page.waitForTimeout(80); await page.mouse.up(); }
  else if (op === 'mdown') await page.mouse.down({ button: a || 'left' });
  else if (op === 'mup') await page.mouse.up({ button: a || 'left' });
  else if (op === 'mouse') await page.mouse.move(+a, +b);
}
await browser.close();
