# Capital Strike: source

A test game built on the Shardfall engine (the "Pavilion" engine) from the prompt "spiritual successor
to Jungle Strike (1993; SNES, Sega Genesis)". The game code lives inside the engine's crates, so
the source is a patch series against engine commit 6618522:

    git am patches/*.patch        # in a checkout of the engine at 6618522
    test-games/jungle-strike/build.sh   # builds game.html (needs wasm-bindgen-cli 0.2.129)

The engine evaluation from this build is in the engine repo's docs/FEEDBACK.md.
