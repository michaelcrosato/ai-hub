#!/usr/bin/env python3
"""Packs the wasm-bindgen output into one self-contained HTML file (no network loads).
usage: pack.py <wasm-bindgen out dir> <out.html>"""
import base64
import gzip
import pathlib
import sys

d = pathlib.Path(sys.argv[1])
out = pathlib.Path(sys.argv[2])
here = pathlib.Path(__file__).parent
glue = (d / "shardfall.js").read_bytes()
wasm = gzip.compress((d / "shardfall_bg.wasm").read_bytes(), 9)
page = (here / "page.html").read_text()
page = page.replace("__GLUE__", base64.b64encode(glue).decode()).replace("__WASM__", base64.b64encode(wasm).decode())
out.write_text(page)
print(f"{out}: {out.stat().st_size / 1e6:.1f} MB (wasm gz {len(wasm) / 1e6:.1f} MB)")
