#!/usr/bin/env bash
# Builds test-games/jungle-strike/game.html: the engine as WebAssembly plus the Capital Strike
# scene, packed into one file. Needs wasm-bindgen-cli 0.2.129 on PATH
# (cargo install wasm-bindgen-cli --version 0.2.129 --locked).
set -euo pipefail
cd "$(dirname "$0")/../.."
: "${CARGO_TARGET_DIR:=$PWD/target}"
export CARGO_TARGET_DIR
cargo build --locked --profile dist --target wasm32-unknown-unknown -p pav_app
out=$CARGO_TARGET_DIR/jungle-web
rm -rf "$out"
mkdir -p "$out"
wasm-bindgen --target web --no-typescript --out-dir "$out" --out-name shardfall "$CARGO_TARGET_DIR/wasm32-unknown-unknown/dist/shardfall.wasm"
python3 test-games/jungle-strike/pack.py "$out" test-games/jungle-strike/game.html
